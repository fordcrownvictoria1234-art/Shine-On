(() => {
  'use strict';

  // Lichess 3.1 — Game End Popup
  // This is intentionally self-contained. It contains only the game-end
  // detection/popup feature transplanted from the OGN extension; no OGN
  // board themes, sounds, panels, share cards, streaks, etc. are included.

  const STYLE_ID = 'w31-game-end-popup-style';
  let popup = null;
  let observedBoard = null;
  let pageObserver = null;
  let lastUrl = location.href;
  let gameWasAlreadyOver = false;
  let gameEndShown = false;
  let pollTimer = null;
  let showTimer = null;

  function ensureStyle() {
    if (document.getElementById(STYLE_ID)) return;

    const style = document.createElement('style');
    style.id = STYLE_ID;
    style.textContent = `
      .w31-game-end-backdrop {
        position: fixed !important;
        inset: 0 !important;
        z-index: 2147483647 !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        background: rgba(0, 32, 32, .42) !important;
        font-family: var(--cdc-font, 'Pixelify Sans', 'MS Sans Serif', 'Microsoft Sans Serif', Tahoma, Arial, sans-serif) !important;
        animation: w31-end-fade .12s linear !important;
      }

      @keyframes w31-end-fade {
        from { opacity: 0; }
        to { opacity: 1; }
      }

      .w31-game-end-window {
        width: min(430px, calc(100vw - 32px)) !important;
        box-sizing: border-box !important;
        background: #c0c0c0 !important;
        color: #000 !important;
        border: 1px solid #000 !important;
        padding: 3px !important;
        box-shadow:
          2px 2px 0 #000,
          inset 1px 1px 0 #fff,
          inset -1px -1px 0 #808080 !important;
        font-family: var(--cdc-font, 'Pixelify Sans', 'MS Sans Serif', 'Microsoft Sans Serif', Tahoma, Arial, sans-serif) !important;
        image-rendering: pixelated !important;
        animation: w31-end-pop .16s steps(2, end) !important;
      }

      @keyframes w31-end-pop {
        from { transform: scale(.94); }
        to { transform: scale(1); }
      }

      .w31-game-end-titlebar {
        min-height: 25px !important;
        box-sizing: border-box !important;
        display: flex !important;
        align-items: center !important;
        gap: 6px !important;
        padding: 3px 4px !important;
        background: #000080 !important;
        color: #fff !important;
        font-weight: 700 !important;
        font-size: 14px !important;
        line-height: 1 !important;
        letter-spacing: .15px !important;
        user-select: none !important;
      }

      .w31-game-end-titlebar .w31-app-icon {
        width: 13px !important;
        height: 13px !important;
        flex: 0 0 13px !important;
        background: #fff !important;
        color: #000080 !important;
        display: grid !important;
        place-items: center !important;
        font-family: Arial, sans-serif !important;
        font-size: 9px !important;
        font-weight: 900 !important;
        box-shadow: inset 1px 1px 0 #808080, inset -1px -1px 0 #000 !important;
      }

      .w31-game-end-close {
        margin-left: auto !important;
        width: 18px !important;
        height: 17px !important;
        padding: 0 !important;
        border: 1px solid #000 !important;
        background: #c0c0c0 !important;
        color: #000 !important;
        font-family: Arial, sans-serif !important;
        font-size: 12px !important;
        font-weight: 900 !important;
        line-height: 14px !important;
        text-align: center !important;
        cursor: pointer !important;
        box-shadow: inset 1px 1px 0 #fff, inset -1px -1px 0 #808080 !important;
      }

      .w31-game-end-close:active {
        box-shadow: inset 1px 1px 0 #808080, inset -1px -1px 0 #fff !important;
      }

      .w31-game-end-body {
        padding: 17px 17px 15px !important;
        text-align: center !important;
        background: #c0c0c0 !important;
      }

      .w31-game-end-status {
        display: inline-block !important;
        min-width: 170px !important;
        box-sizing: border-box !important;
        padding: 6px 12px 7px !important;
        margin: 0 0 8px !important;
        background: #fff !important;
        border: 1px solid #000 !important;
        box-shadow: inset 1px 1px 0 #808080 !important;
        color: #000080 !important;
        font-size: 20px !important;
        font-weight: 700 !important;
        line-height: 1.05 !important;
        text-transform: uppercase !important;
      }

      .w31-game-end-status.win { color: #006400 !important; }
      .w31-game-end-status.loss { color: #800000 !important; }
      .w31-game-end-status.draw { color: #000080 !important; }
      .w31-game-end-status.timeout { color: #800000 !important; }

      .w31-game-end-reason {
        margin: 0 0 14px !important;
        color: #404040 !important;
        font-size: 12px !important;
        line-height: 1.25 !important;
      }

      .w31-game-end-players {
        display: grid !important;
        grid-template-columns: 1fr 30px 1fr !important;
        align-items: stretch !important;
        gap: 7px !important;
        margin: 0 0 15px !important;
      }

      .w31-game-end-player {
        min-width: 0 !important;
        padding: 7px 5px !important;
        background: #d4d0c8 !important;
        border: 1px solid #000 !important;
        box-shadow: inset 1px 1px 0 #fff, inset -1px -1px 0 #808080 !important;
      }

      .w31-game-end-player .name {
        overflow: hidden !important;
        text-overflow: ellipsis !important;
        white-space: nowrap !important;
        font-size: 12px !important;
        font-weight: 700 !important;
      }

      .w31-game-end-player .rating {
        margin-top: 2px !important;
        font-family: 'Courier New', monospace !important;
        font-size: 11px !important;
      }

      .w31-game-end-player .delta {
        margin-top: 2px !important;
        font-size: 13px !important;
        font-weight: 700 !important;
      }

      .w31-game-end-player .delta.up { color: #006400 !important; }
      .w31-game-end-player .delta.down { color: #800000 !important; }

      .w31-game-end-vs {
        align-self: center !important;
        color: #000 !important;
        font-size: 12px !important;
        font-weight: 700 !important;
      }

      .w31-game-end-actions {
        display: grid !important;
        grid-template-columns: 1fr 1fr !important;
        gap: 8px !important;
      }

      .w31-game-end-btn {
        min-height: 32px !important;
        padding: 5px 9px !important;
        border: 1px solid #000 !important;
        border-radius: 0 !important;
        background: #c0c0c0 !important;
        color: #000 !important;
        font-family: inherit !important;
        font-size: 12px !important;
        font-weight: 700 !important;
        cursor: pointer !important;
        box-shadow: inset 1px 1px 0 #fff, inset -1px -1px 0 #808080 !important;
      }

      .w31-game-end-btn:hover {
        background: #d4d4d4 !important;
      }

      .w31-game-end-btn:active {
        box-shadow: inset 1px 1px 0 #808080, inset -1px -1px 0 #fff !important;
        padding-top: 6px !important;
        padding-left: 10px !important;
      }

      .w31-game-end-btn.primary {
        background: #000080 !important;
        color: #fff !important;
        box-shadow: inset 1px 1px 0 #4040c0, inset -1px -1px 0 #000040 !important;
      }

      .w31-game-end-btn.primary:hover {
        background: #0000a0 !important;
      }

      .w31-game-end-btn:disabled {
        color: #808080 !important;
        cursor: default !important;
        text-shadow: 1px 1px 0 #fff !important;
        box-shadow: inset 1px 1px 0 #808080, inset -1px -1px 0 #fff !important;
      }

      .w31-game-end-btn.primary:disabled {
        background: #808080 !important;
        color: #c0c0c0 !important;
        text-shadow: 1px 1px 0 #404040 !important;
      }

      @media (max-width: 520px) {
        .w31-game-end-window { width: calc(100vw - 18px) !important; }
        .w31-game-end-body { padding: 13px 10px 11px !important; }
        .w31-game-end-actions { grid-template-columns: 1fr !important; }
      }
    `;
    (document.head || document.documentElement).appendChild(style);
  }

  function isGamePage() {
    return Boolean(document.querySelector('.round__app') && document.querySelector('cg-board'));
  }

  function isAnalysisPage() {
    return /\/analysis(?:\/|$)/.test(location.pathname) || Boolean(document.querySelector('.analyse'));
  }

  function latestSan() {
    const moves = [...document.querySelectorAll('move')]
      .map(el => (el.textContent || '').replace(/\s+/g, ' ').trim())
      .filter(text => text && !/^\d+\.{1,3}$/.test(text));
    return moves.length
      ? moves[moves.length - 1].replace(/^\d+\.{1,3}\s*/, '').replace(/[!?]+$/g, '').trim()
      : '';
  }

  function liveGameEnded() {
    if (!isGamePage() || isAnalysisPage()) return false;

    const san = latestSan();
    if (/#|‡/.test(san)) return true;

    const result = document.querySelector(
      '.result-wrap, .game__meta__infos .result, .round__app .result, .game-over-status'
    );
    if (result && /1-0|0-1|½-½/.test(result.textContent || '')) return true;

    const gameText = document.querySelector('.round__app')?.textContent || '';
    return /[ée]chec et mat|checkmate|victoire des (blancs|noirs)|[ée]coul[ée]|partie nulle|draw by|a gagn[ée]|a abandonn[ée]|resigned|won by|time(?:'s)? (?:up|out)|out of time|timeout/i.test(gameText);
  }

  function findButtonByText(patterns, root) {
    const candidates = (root || document).querySelectorAll('button, a');
    for (const el of candidates) {
      const text = (el.textContent || '').trim();
      if (text && patterns.some(p => p.test(text))) return el;
    }
    return null;
  }

  function findPlayers() {
    const boxes = [document.querySelector('.ruser-top'), document.querySelector('.ruser-bottom')];
    const players = [];

    for (const box of boxes) {
      if (!box) continue;
      const link = box.querySelector('a.user-link');
      const ratingEl = box.querySelector('rating');
      const deltaEl = box.querySelector('good, bad');
      if (!link || !ratingEl || !deltaEl) continue;

      const name = (link.childNodes[0]?.textContent || link.textContent || '').trim();
      if (!name) continue;

      players.push({
        name,
        rating: ratingEl.textContent.trim(),
        delta: deltaEl.textContent.trim(),
        up: deltaEl.tagName.toLowerCase() === 'good'
      });
    }
    return players;
  }

  function looksLikeMoves(text) {
    // Move-list rows such as "1. e4 e5", bare move numbers, or SAN tokens.
    return /^\d+\.{0,3}$/.test(text) ||
      /^\d+\.{1,3}\s*\S/.test(text) ||
      /^(?:[KQRBN]?[a-h]?[1-8]?x?[a-h][1-8](?:=[QRBN])?[+#]?|O-O(?:-O)?[+#]?)$/.test(text);
  }

  function findResultText() {
    const pattern = /Échec et mat|Checkmate|écoulé|Time|Abandon|Resign|Partie nulle|Draw/i;
    const candidates = document.querySelectorAll(
      '.round__app div, .round__app p, .round__app span, .round__app strong, .round__app em, .round__app small'
    );

    for (const el of candidates) {
      if (el.children.length > 0) continue;
      const own = (el.textContent || '').trim();
      if (!own || !pattern.test(own)) continue;

      const parent = el.parentElement;
      if (parent) {
        const lines = (parent.innerText || '')
          .split(/\r?\n/)
          .map(s => s.trim())
          .filter(Boolean)
          .filter(l => !looksLikeMoves(l));
        if (lines.length && lines.length <= 4) return lines.join(' • ');
      }
      return own;
    }

    const line = (document.querySelector('.round__app')?.innerText || '')
      .split(/\r?\n/)
      .map(s => s.trim())
      .find(l => /Victoire des (Blancs|Noirs)|White wins|Black wins|Partie nulle|Draw|1-0|0-1|½-½|time|resign/i.test(l));

    return (line || 'Game over').trim();
  }

  function getOutcome(resultText) {
    const text = String(resultText || '').toLowerCase();
    const black = document.querySelector('.cg-wrap.orientation-black');
    const userIsBlack = Boolean(black);

    if (/partie nulle|draw|½-½|stalemate|répétition|repetition|insufficient|agreement/.test(text)) {
      return { label: 'DRAW', cls: 'draw' };
    }

    if (/écoulé|time|timeout|out of time|flagged/.test(text)) {
      const blackWon = /noir|black/.test(text);
      const whiteWon = /blanc|white/.test(text);
      const userWon = whiteWon ? !userIsBlack : blackWon ? userIsBlack : false;
      return { label: userWon ? 'TIME WIN' : 'TIME OUT', cls: userWon ? 'win' : 'timeout' };
    }

    if (/abandon|resign|a gagné|won by|victoire|wins|checkmate|échec et mat|1-0|0-1/.test(text)) {
      const blackWon = /noir|black|0-1/.test(text);
      const whiteWon = /blanc|white|1-0/.test(text);
      if (whiteWon || blackWon) {
        const userWon = whiteWon ? !userIsBlack : userIsBlack;
        return { label: userWon ? 'YOU WON' : 'YOU LOST', cls: userWon ? 'win' : 'loss' };
      }
    }

    // If the reason is simply "resigned", Lichess normally has the result
    // available in the players/result markup. Use the result token if present.
    const roundText = (document.querySelector('.round__app')?.textContent || '').toLowerCase();
    if (/1-0/.test(roundText)) return { label: userIsBlack ? 'YOU LOST' : 'YOU WON', cls: userIsBlack ? 'loss' : 'win' };
    if (/0-1/.test(roundText)) return { label: userIsBlack ? 'YOU WON' : 'YOU LOST', cls: userIsBlack ? 'win' : 'loss' };

    return { label: 'GAME OVER', cls: 'draw' };
  }

  function removePopup() {
    popup?.remove();
    popup = null;
  }

  function gameNavigation() {
    const path = location.pathname.replace(/\/+$/, '');
    const parts = path.split('/').filter(Boolean);
    const gameId = parts[0] && /^[A-Za-z0-9]{6,}$/.test(parts[0]) ? parts[0] : '';
    const orientation = parts[1] === 'black' || document.querySelector('.cg-wrap.orientation-black') ? 'black' : 'white';
    const ply = [...document.querySelectorAll('move')].filter(el => (el.textContent || '').trim()).length;
    return { gameId, orientation, ply };
  }

  function directNewGameUrl() {
    const { gameId } = gameNavigation();
    return gameId ? `/?hook_like=${encodeURIComponent(gameId)}` : '/';
  }

  function directAnalysisUrl() {
    const { gameId, orientation, ply } = gameNavigation();
    if (!gameId) return '/analysis';
    return `/${gameId}/${orientation}/analysis#${Math.max(0, ply)}`;
  }

  function makeButton(label, cls, target, fallbackUrl) {
    const btn = document.createElement('button');
    btn.className = `w31-game-end-btn ${cls || ''}`.trim();
    btn.type = 'button';
    btn.textContent = label;

    btn.addEventListener('click', (event) => {
      event.preventDefault();
      event.stopPropagation();

      // Navigation buttons use an explicit URL. This avoids depending on
      // Lichess's internal delegated event handlers, which can be replaced
      // while the round result screen is being rendered.
      if (fallbackUrl) {
        window.location.href = fallbackUrl;
        return;
      }

      if (!target) return;

      if (target instanceof HTMLAnchorElement && target.href) {
        window.location.href = target.href;
        return;
      }

      // Rematch and other action buttons are real Lichess controls. Trigger
      // their native click after the popup has stopped intercepting the event.
      removePopup();
      target.click();
    });
    return btn;
  }

  function showPopup() {
    if (!isGamePage() || !liveGameEnded()) return;

    removePopup();
    ensureStyle();

    const scope = document.querySelector('.round__app') || document;
    const resultText = findResultText();
    const outcome = getOutcome(resultText);

    const modal = document.createElement('div');
    modal.className = 'w31-game-end-backdrop';

    const win = document.createElement('div');
    win.className = 'w31-game-end-window';
    win.setAttribute('role', 'dialog');
    win.setAttribute('aria-label', 'Game result');

    const titlebar = document.createElement('div');
    titlebar.className = 'w31-game-end-titlebar';

    const icon = document.createElement('span');
    icon.className = 'w31-app-icon';
    icon.textContent = '♟';
    titlebar.appendChild(icon);

    const title = document.createElement('span');
    title.textContent = 'Lichess 3.1 — Game Over';
    titlebar.appendChild(title);

    const close = document.createElement('button');
    close.className = 'w31-game-end-close';
    close.textContent = '×';
    close.setAttribute('aria-label', 'Close');
    close.addEventListener('click', removePopup);
    titlebar.appendChild(close);

    const body = document.createElement('div');
    body.className = 'w31-game-end-body';

    const status = document.createElement('div');
    status.className = `w31-game-end-status ${outcome.cls}`;
    status.textContent = outcome.label;
    body.appendChild(status);

    const reason = document.createElement('div');
    reason.className = 'w31-game-end-reason';
    reason.textContent = resultText;
    body.appendChild(reason);

    const players = findPlayers();
    if (players.length >= 2) {
      const row = document.createElement('div');
      row.className = 'w31-game-end-players';

      players.slice(0, 2).forEach((p, i) => {
        const box = document.createElement('div');
        box.className = 'w31-game-end-player';

        const name = document.createElement('div');
        name.className = 'name';
        name.textContent = p.name;

        const rating = document.createElement('div');
        rating.className = 'rating';
        rating.textContent = p.rating;

        const delta = document.createElement('div');
        delta.className = `delta ${p.up ? 'up' : 'down'}`;
        delta.textContent = p.delta;

        box.append(name, rating, delta);
        row.appendChild(box);

        if (i === 0) {
          const vs = document.createElement('div');
          vs.className = 'w31-game-end-vs';
          vs.textContent = 'VS';
          row.appendChild(vs);
        }
      });
      body.appendChild(row);
    }

    const actions = document.createElement('div');
    actions.className = 'w31-game-end-actions';

    const rematch = findButtonByText([/^revanche$/i, /^rematch$/i], scope);
    const newOpponent = findButtonByText(
      [/nouvel adversaire/i, /new opponent/i, /nouvelle partie/i, /new game/i],
      scope
    );
    const analysis = findButtonByText(
      [/échiquier d'analyse/i, /game analysis/i, /^analyse$/i, /^analysis$/i],
      scope
    );

    actions.appendChild(makeButton('Rematch', 'primary', rematch));
    actions.appendChild(makeButton('New Game', '', newOpponent, directNewGameUrl()));
    actions.appendChild(makeButton('Analysis', '', analysis, directAnalysisUrl()));
    body.appendChild(actions);

    win.append(titlebar, body);
    modal.appendChild(win);

    modal.addEventListener('click', (event) => {
      if (event.target === modal) removePopup();
    });

    document.body.appendChild(modal);
    popup = modal;
  }

  function schedulePopup() {
    clearTimeout(showTimer);
    // Give Lichess a beat to paint the result, ratings and action buttons.
    showTimer = setTimeout(() => {
      if (!gameEndShown) {
        showPopup();
        gameEndShown = true;
      }
    }, 300);
  }

  function attachToCurrentGame() {
    const board = document.querySelector('cg-board');
    const round = document.querySelector('.round__app');

    if (!board || !round || isAnalysisPage()) {
      observedBoard = null;
      gameWasAlreadyOver = false;
      gameEndShown = false;
      return;
    }

    if (board === observedBoard) return;

    const wasActiveBeforeBoardSwap = Boolean(observedBoard) && !gameWasAlreadyOver;
    const endedOnThisBoard = liveGameEnded();

    removePopup();
    observedBoard = board;
    gameEndShown = false;
    gameWasAlreadyOver = endedOnThisBoard;

    // Lichess can occasionally replace the board node while committing the
    // final result. If the previous board was a live game and the replacement
    // is already finished, treat that as the real end transition.
    if (wasActiveBeforeBoardSwap && endedOnThisBoard) {
      gameWasAlreadyOver = true;
      schedulePopup();
    }

    if (pageObserver) {
      pageObserver.disconnect();
      pageObserver = null;
    }

    // The board changes for every move, so watching only the board is enough
    // for checkmate/result changes. Timeout/resignation with no board change
    // is handled by the lightweight polling loop below.
    pageObserver = new MutationObserver(() => {
      if (!gameEndShown && !gameWasAlreadyOver && liveGameEnded()) {
        gameWasAlreadyOver = true;
        schedulePopup();
      }
    });

    pageObserver.observe(board, {
      subtree: true,
      childList: true,
      attributes: true,
      attributeFilter: ['class', 'style']
    });
  }

  function poll() {
    if (location.href !== lastUrl) {
      lastUrl = location.href;
      removePopup();
      observedBoard = null;
      gameWasAlreadyOver = false;
      gameEndShown = false;
    }

    attachToCurrentGame();

    if (!observedBoard || gameEndShown || gameWasAlreadyOver) return;

    if (liveGameEnded()) {
      gameWasAlreadyOver = true;
      schedulePopup();
    }
  }

  function start() {
    ensureStyle();
    attachToCurrentGame();
    clearInterval(pollTimer);
    pollTimer = setInterval(poll, 350);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start, { once: true });
  } else {
    start();
  }
})();
