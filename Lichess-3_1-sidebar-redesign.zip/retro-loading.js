// Lichess 3.1: shows the Windows 3.1 hourglass while a page is loading.
// It only toggles a class on <html>; the cursor itself is drawn by content.css.
(() => {
  const root = document.documentElement;
  const CLASS = 'w31-loading';
  let timer = 0;

  const stop = () => {
    clearTimeout(timer);
    root.classList.remove(CLASS);
  };
  // Never leave the hourglass stuck: a cancelled navigation or a slow resource ends it.
  const start = (maxMs) => {
    root.classList.add(CLASS);
    clearTimeout(timer);
    timer = setTimeout(stop, maxMs);
  };

  // This page loading.
  if (document.readyState !== 'complete') {
    start(15000);
    window.addEventListener('load', stop, { once: true });
  }

  // Leaving for the next page (the old page stays up while the new one loads).
  window.addEventListener('beforeunload', () => start(6000));
  // Back/forward cache restores the page without a load event.
  window.addEventListener('pageshow', (e) => { if (e.persisted) stop(); });
})();
