(function() {

//#region \0rolldown/runtime.js
	var __create = Object.create;
	var __defProp = Object.defineProperty;
	var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
	var __getOwnPropNames = Object.getOwnPropertyNames;
	var __getProtoOf = Object.getPrototypeOf;
	var __hasOwnProp = Object.prototype.hasOwnProperty;
	var __commonJSMin = (cb, mod) => () => (mod || (cb((mod = { exports: {} }).exports, mod), cb = null), mod.exports);
	var __copyProps = (to, from, except, desc) => {
		if (from && typeof from === "object" || typeof from === "function") {
			for (var keys = __getOwnPropNames(from), i = 0, n = keys.length, key; i < n; i++) {
				key = keys[i];
				if (!__hasOwnProp.call(to, key) && key !== except) {
					__defProp(to, key, {
						get: ((k) => from[k]).bind(null, key),
						enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
					});
				}
			}
		}
		return to;
	};
	var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(isNodeMode || !mod || !mod.__esModule || !__hasOwnProp.call(mod, "default") ? __defProp(target, "default", {
		value: mod,
		enumerable: true
	}) : target, mod));

//#endregion
//#region src/shared/features.ts
/** Starts each feature in order; one that throws doesn't keep the others from starting. */
	function startFeatures(features) {
		for (const feature of features) try {
			feature.start();
		} catch (error) {
			console.error(`[LichessDotCom] ${feature.name} failed to start`, error);
		}
	}

//#endregion
//#region src/shared/dom.ts
	const isParsing = () => document.readyState === "loading";
	/** Runs `callback` once the document is parsed, or right away if it already is. */
	function onDomReady(callback) {
		if (isParsing()) document.addEventListener("DOMContentLoaded", callback, { once: true });
		else callback();
	}
	function queryOne(root, selector, type) {
		const element = root.querySelector(selector);
		return element instanceof type ? element : null;
	}
	function queryAll(root, selector, type) {
		return [...root.querySelectorAll(selector)].filter((element) => element instanceof type);
	}
	function closestTo(target, selector, type) {
		if (!(target instanceof Element)) return null;
		const element = target.closest(selector);
		return element instanceof type ? element : null;
	}
	/** Sets the class, the id, the text, then the attributes, in that order. */
	function applyOptions(element, options = {}) {
		if (options.className !== void 0) element.className = options.className;
		if (options.id !== void 0) element.id = options.id;
		if (options.text !== void 0) element.textContent = options.text;
		for (const [name, value] of Object.entries(options.attrs ?? {})) element.setAttribute(name, value);
		return element;
	}
	function createElement(tag, options) {
		return applyOptions(document.createElement(tag), options);
	}
	/** An element lib.dom has no type for, such as Lichess's `rating` or chessground's `piece`. */
	function createCustomElement(tag, options) {
		return applyOptions(document.createElement(tag), options);
	}
	/**
	* Sets a `data-*` attribute only when it changes, and removes it for `null`.
	* Writing an unchanged value still counts as a mutation, which wakes every
	* observer on the page.
	*/
	function setData(element, key, value) {
		const { dataset } = element;
		if (value === null) {
			if (key in dataset) delete dataset[key];
		} else if (dataset[key] !== value) dataset[key] = value;
	}
	/**
	* Sets a data attribute that reads as empty when absent: an empty value
	* clears one already there, but doesn't add it.
	*/
	function setDataText(element, key, value) {
		if ((element.dataset[key] ?? "") !== value) element.dataset[key] = value;
	}
	/** Sets an inline style property (a custom one, or any other) only when it changes. */
	function setStyleProperty(element, name, value) {
		const current = element.style.getPropertyValue(name);
		if (value === null) {
			if (current !== "") element.style.removeProperty(name);
		} else if (current !== value) element.style.setProperty(name, value);
	}

//#endregion
//#region src/content/platform/runtime.ts
/** A bundled file's URL, from its path in public/ (`img/…`, `sounds/…`). */
	const extensionUrl = (path) => chrome.runtime.getURL(path);
	/** Loaded unpacked (development), rather than installed from a store. */
	const isUnpacked = () => !("update_url" in chrome.runtime.getManifest());
	/** Whether this content script still belongs to a running extension (not orphaned by a reload). */
	const isConnected = () => chrome.runtime?.id !== void 0;

//#endregion
//#region node_modules/.pnpm/zod@4.6.5/node_modules/zod/v4/core/util.js
	function getEnumValues(entries) {
		const numericValues = Object.values(entries).filter((v) => typeof v === "number");
		return Object.entries(entries).filter(([k, _]) => numericValues.indexOf(+k) === -1).map(([_, v]) => v);
	}
	function jsonStringifyReplacer(_, value) {
		if (typeof value === "bigint") return value.toString();
		return value;
	}
	var Cached = class {
		constructor(getter) {
			this._getter = getter;
			this._value = void 0;
		}
		get value() {
			const getter = this._getter;
			if (getter !== void 0) {
				this._value = getter();
				this._getter = void 0;
			}
			return this._value;
		}
	};
	function cached(getter) {
		return new Cached(getter);
	}
	function nullish(input) {
		return input === null || input === void 0;
	}
	function cleanRegex(source) {
		const start = source.startsWith("^") ? 1 : 0;
		const end = source.endsWith("$") ? source.length - 1 : source.length;
		return source.slice(start, end);
	}
	function assignProp(target, prop, value) {
		Object.defineProperty(target, prop, {
			value,
			writable: true,
			enumerable: true,
			configurable: true
		});
	}
	const captureStackTrace = "captureStackTrace" in Error ? Error.captureStackTrace : (..._args) => {};
	function isObject(data) {
		return typeof data === "object" && data !== null && !Array.isArray(data);
	}
	function isPlainObject(o) {
		if (isObject(o) === false) return false;
		const ctor = o.constructor;
		if (ctor === void 0) return true;
		if (typeof ctor !== "function") return true;
		const prot = ctor.prototype;
		if (isObject(prot) === false) return false;
		if (Object.prototype.hasOwnProperty.call(prot, "isPrototypeOf") === false) return false;
		return true;
	}
	const propertyKeyTypes = /* @__PURE__*/ new Set([
		"string",
		"number",
		"symbol"
	]);
	function escapeRegex(str) {
		return str.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
	}
	function clone(inst, def, params) {
		const cl = new inst._zod.constr(def ?? inst._zod.def);
		if (!def || params?.parent) cl._zod.parent = inst;
		return cl;
	}
	function normalizeParams(_params) {
		const params = _params;
		if (!params) return {};
		if (typeof params === "string") return { error: () => params };
		if (params?.message !== void 0) {
			if (params?.error !== void 0) throw new Error("Cannot specify both `message` and `error` params");
			params.error = params.message;
		}
		delete params.message;
		if (typeof params.error === "string") return {
			...params,
			error: () => params.error
		};
		return params;
	}
	function optionalKeys(shape) {
		return Object.keys(shape).filter((k) => {
			return shape[k]._zod.optin !== void 0 && shape[k]._zod.optout === "optional";
		});
	}
	const NUMBER_FORMAT_RANGES = /*@__PURE__*/ (() => ({
		safeint: [Number.MIN_SAFE_INTEGER, Number.MAX_SAFE_INTEGER],
		int32: [-2147483648, 2147483647],
		uint32: [0, 4294967295],
		float32: [-34028234663852886e22, 34028234663852886e22],
		float64: [-Number.MAX_VALUE, Number.MAX_VALUE]
	}))();
	function aborted(x, startIndex = 0) {
		if (x.aborted === true) return true;
		for (let i = startIndex; i < x.issues.length; i++) if (x.issues[i]?.continue !== true) return true;
		return false;
	}
	function explicitlyAborted(x, startIndex = 0) {
		if (x.aborted === true) return true;
		for (let i = startIndex; i < x.issues.length; i++) if (x.issues[i]?.continue === false) return true;
		return false;
	}
	function prefixIssues(path, issues) {
		return issues.map((iss) => {
			var _a;
			(_a = iss).path ?? (_a.path = []);
			iss.path.unshift(path);
			return iss;
		});
	}
	function unwrapMessage(message) {
		return typeof message === "string" ? message : message?.message;
	}
	function attachSchema(issues, start, inst) {
		var _a;
		for (let i = start; i < issues.length; i++) (_a = issues[i]).schema ?? (_a.schema = inst);
	}
	function finalizeIssue(iss, ctx, config) {
		var _a;
		const traits = iss.inst?._zod?.traits;
		if (traits?.has("$ZodType")) {
			if (traits.has("$ZodCheck")) (_a = iss).schema ?? (_a.schema = iss.inst);
			else iss.schema = iss.inst;
		}
		const schemaError = iss.schema !== iss.inst ? iss.schema?._zod.def?.error : void 0;
		const message = iss.message ? iss.message : unwrapMessage(iss.inst?._zod.def?.error?.(iss)) ?? unwrapMessage(schemaError?.(iss)) ?? unwrapMessage(ctx?.error?.(iss)) ?? unwrapMessage(config.customError?.(iss)) ?? unwrapMessage(config.localeError?.(iss)) ?? "Invalid input";
		const full = {};
		for (const k of Object.keys(iss)) {
			if (k === "inst" || k === "schema" || k === "continue" || k === "input" || k === "__proto__") continue;
			full[k] = iss[k];
		}
		full.path ?? (full.path = []);
		full.message = message;
		if (ctx?.reportInput) full.input = iss.input;
		return full;
	}
	const highSurrogate = /[\uD800-\uDBFF]/;
	function codePointLength(str) {
		const units = str.length;
		if (!highSurrogate.test(str)) return units;
		let count = units;
		for (let i = 0; i < units - 1; i++) if ((str.charCodeAt(i) & 64512) === 55296 && (str.charCodeAt(i + 1) & 64512) === 56320) {
			count--;
			i++;
		}
		return count;
	}
	function getLengthableOrigin(input) {
		if (Array.isArray(input)) return "array";
		if (typeof input === "string") return "string";
		return "unknown";
	}
	function issue(...args) {
		const [iss, input, inst] = args;
		if (typeof iss === "string") return {
			message: iss,
			code: "custom",
			input,
			inst
		};
		return { ...iss };
	}
	/**
	* Installs a trait's members on its prototype. Each value builds that member for the instance on first read; the built value shadows the accessor as an own property, so a detached `const { parse } = schema` keeps working.
	*
	* Call this from a `proto` initializer, which runs once per prototype — never per instance.
	*/
	function members(proto, table) {
		for (const key in table) {
			const desc = Object.getOwnPropertyDescriptor(table, key);
			if (desc.get) Object.defineProperty(proto, key, {
				...desc,
				enumerable: false
			});
			else defineBound(proto, key, desc.value);
		}
	}
	/** Shadows a prototype member with an own value, so a getter that builds from the instance runs once. */
	function own(inst, key, value, enumerable = true) {
		Object.defineProperty(inst, key, {
			configurable: true,
			writable: true,
			enumerable,
			value
		});
		return value;
	}
	/** Like {@link own}, for a member that was never an own data property and has to stay out of `Object.keys`. */
	function hide(inst, key, value) {
		return own(inst, key, value, false);
	}
	function defineBound(proto, key, fn) {
		Object.defineProperty(proto, key, {
			configurable: true,
			get() {
				return this == null ? fn : own(this, key, fn.bind(this));
			},
			set(value) {
				own(this, key, value);
			}
		});
	}
	/** Returns the prototype to install on, or `undefined` if this group is already installed on it. */
	function claim(inst, sentinel) {
		const proto = Object.getPrototypeOf(inst);
		return sentinel in proto ? void 0 : proto;
	}
	let installing;
	let broke = false;
	const breaker = {
		configurable: true,
		get() {
			broke = true;
		}
	};
	/**
	* Installs a lazily-derived internal on the `_zod` prototype of `inst`'s
	* constructor, computed from the internals object itself and cached there on
	* first read. One accessor per constructor rather than one per instance.
	*/
	function defineLazyInternal(inst, key, compute) {
		const proto = Object.getPrototypeOf(inst._zod);
		if (key in proto && installing !== inst._zod) {
			installing = void 0;
			return;
		}
		installing = inst._zod;
		Object.defineProperty(proto, key, {
			configurable: true,
			get() {
				Object.defineProperty(this, key, breaker);
				const outer = broke;
				broke = false;
				try {
					const value = compute(this);
					if (broke) delete this[key];
					else Object.defineProperty(this, key, {
						configurable: true,
						writable: true,
						value
					});
					broke = broke || outer;
					return value;
				} catch (err) {
					delete this[key];
					broke = broke || outer;
					throw err;
				}
			},
			set(value) {
				Object.defineProperty(this, key, {
					configurable: true,
					writable: true,
					value
				});
			}
		});
	}
	/**
	* Installs `key` on `inst`'s prototype, computed by `make` on first read and cached there as an own
	* data property. One accessor per constructor rather than one per instance, because an own accessor
	* puts every instance after the first into v8 dictionary mode. The key doubles as the sentinel.
	*/
	function installLazyProp(inst, key, make, enumerable) {
		const proto = claim(inst, key);
		if (!proto) return;
		Object.defineProperty(proto, key, {
			configurable: true,
			get() {
				const desc = {
					configurable: true,
					writable: true,
					enumerable,
					value: void 0
				};
				Object.defineProperty(this, key, desc);
				desc.value = make(this);
				Object.defineProperty(this, key, desc);
				return desc.value;
			},
			set(value) {
				Object.defineProperty(this, key, {
					configurable: true,
					writable: true,
					enumerable,
					value
				});
			}
		});
	}
	/** Marks the thunk `_catch` synthesises for a constant catch value. `Function.length` cannot tell that thunk from a user callback — rest and defaulted parameters both report arity 0 — and a user callback reads `ctx.error`, whose issues only finalize correctly against the caller's per-parse error map. Provenance can say what arity cannot. A plain string key rather than `Symbol.for`, whose call at module scope no bundler can prove pure — the same shape that anchored `urlCanParse` into every build. */
	const CONSTANT_CATCH = "~constantCatch";
	/** Wraps a constant catch value in a thunk tagged with {@link CONSTANT_CATCH}. */
	function constantCatch(value) {
		const fn = () => value;
		fn[CONSTANT_CATCH] = true;
		return fn;
	}

//#endregion
//#region node_modules/.pnpm/zod@4.6.5/node_modules/zod/v4/core/core.js
	var _a;
	const _zodDesc = {
		value: void 0,
		enumerable: false
	};
	let _E = "captureStackTrace" in Error ? Error : null;
	function newError(Definition) {
		const E = _E;
		if (E) {
			const saved = E.stackTraceLimit;
			if (typeof saved === "number") {
				try {
					E.stackTraceLimit = 0;
				} catch {
					_E = null;
					return new Definition();
				}
				try {
					return new Definition();
				} finally {
					E.stackTraceLimit = saved;
				}
			}
		}
		return new Definition();
	}
	function $constructor(name, initializer, proto, params) {
		const zodProto = {};
		function Internals(def) {
			this.def = def;
			this.constr = _;
			this.traits = /* @__PURE__ */ new Set();
		}
		Internals.prototype = zodProto;
		const protoMembers = proto;
		const initialized = protoMembers && /* @__PURE__ */ new WeakSet();
		function init(inst, def) {
			if (!inst._zod) {
				_zodDesc.value = new Internals(def);
				try {
					Object.defineProperty(inst, "_zod", _zodDesc);
				} finally {
					_zodDesc.value = void 0;
				}
			} else if (inst._zod.traits.has(name)) return;
			inst._zod.traits.add(name);
			initializer(inst, def);
			if (initialized) {
				const own = Object.getPrototypeOf(inst);
				const ctorProto = inst._zod.constr.prototype;
				let up = own;
				while (up && up !== ctorProto) up = Object.getPrototypeOf(up);
				const target = up ?? own;
				if (!initialized.has(target)) {
					initialized.add(target);
					members(target, protoMembers);
				}
			}
			const proto = _.prototype;
			for (const k in proto) {
				if (!Object.prototype.hasOwnProperty.call(proto, k)) continue;
				if (!(k in inst)) inst[k] = proto[k].bind(inst);
			}
		}
		const Parent = params?.Parent ?? Object;
		class Definition extends Parent {}
		Object.defineProperty(Definition, "name", { value: name });
		function _(def) {
			const inst = params?.Parent ? newError(Definition) : this;
			init(inst, def);
			const deferred = inst._zod.deferred;
			if (deferred) {
				for (const fn of deferred) fn();
				inst._zod.deferred = void 0;
			}
			const pp = globalThis.__zod_globalConfig?.postProcessor;
			if (pp) pp(inst);
			return inst;
		}
		Object.defineProperty(_, "init", { value: init });
		Object.defineProperty(_, Symbol.hasInstance, { value: (inst) => {
			if (params?.Parent && inst instanceof params.Parent) return true;
			return inst?._zod?.traits?.has(name);
		} });
		Object.defineProperty(_, "name", { value: name });
		return _;
	}
	var $ZodAsyncError = class extends Error {
		constructor() {
			super(`Encountered Promise during synchronous parse. Use .parseAsync() instead.`);
		}
	};
	var $ZodEncodeError = class extends Error {
		constructor(name) {
			super(`Encountered unidirectional transform during encode: ${name}`);
			this.name = "ZodEncodeError";
		}
	};
	(_a = globalThis).__zod_globalConfig ?? (_a.__zod_globalConfig = {});
	const globalConfig = globalThis.__zod_globalConfig;
	function config(newConfig) {
		if (newConfig) Object.assign(globalConfig, newConfig);
		return globalConfig;
	}

//#endregion
//#region node_modules/.pnpm/zod@4.6.5/node_modules/zod/v4/core/errors.js
	function _getMessage() {
		const internals = this._zod;
		internals.message ?? (internals.message = JSON.stringify(internals.def, jsonStringifyReplacer, 2));
		return internals.message;
	}
	function _setMessage(value) {
		this._zod.message = value;
	}
	const _messageDesc = {
		get: _getMessage,
		set: _setMessage,
		enumerable: true,
		configurable: true
	};
	const _issuesDesc = {
		value: void 0,
		enumerable: false
	};
	const _installedToString = /* @__PURE__ */ new WeakSet([Object.prototype, Error.prototype]);
	const initializer = (inst, def) => {
		inst.name = "$ZodError";
		_issuesDesc.value = def;
		Object.defineProperty(inst, "issues", _issuesDesc);
		_issuesDesc.value = void 0;
		Object.defineProperty(inst, "message", _messageDesc);
		const proto = Object.getPrototypeOf(inst);
		if (!_installedToString.has(proto)) {
			_installedToString.add(proto);
			Object.defineProperty(proto, "toString", {
				configurable: true,
				enumerable: false,
				get() {
					const value = () => this.message;
					Object.defineProperty(this, "toString", {
						value,
						configurable: true,
						writable: true
					});
					return value;
				},
				set(value) {
					Object.defineProperty(this, "toString", {
						value,
						configurable: true,
						writable: true
					});
				}
			});
		}
	};
	const $ZodError = $constructor("$ZodError", initializer);
	const $ZodRealError = $constructor("$ZodError", initializer, void 0, { Parent: Error });

//#endregion
//#region node_modules/.pnpm/zod@4.6.5/node_modules/zod/v4/core/parse.js
	const _parse = (_Err) => {
		const fn = (schema, value, _ctx, _params) => {
			const ctx = _ctx ? {
				..._ctx,
				async: false
			} : { async: false };
			const result = schema._zod.run({
				value,
				issues: []
			}, ctx);
			if (result instanceof Promise) throw new $ZodAsyncError();
			if (result.issues.length) {
				const e = new ((_params?.Err) ?? _Err)(result.issues.map((iss) => finalizeIssue(iss, ctx, config())));
				captureStackTrace(e, _params?.callee ?? fn);
				throw e;
			}
			return result.value;
		};
		return fn;
	};
	const parse = /* @__PURE__*/ _parse($ZodRealError);
	const _parseAsync = (_Err) => {
		const fn = async (schema, value, _ctx, params) => {
			const ctx = _ctx ? {
				..._ctx,
				async: true
			} : { async: true };
			let result = schema._zod.run({
				value,
				issues: []
			}, ctx);
			if (result instanceof Promise) result = await result;
			if (result.issues.length) {
				const e = new ((params?.Err) ?? _Err)(result.issues.map((iss) => finalizeIssue(iss, ctx, config())));
				captureStackTrace(e, params?.callee ?? fn);
				throw e;
			}
			return result.value;
		};
		return fn;
	};
	const parseAsync = /* @__PURE__*/ _parseAsync($ZodRealError);
	const _safeParse = (_Err) => (schema, value, _ctx) => {
		const ctx = _ctx ? {
			..._ctx,
			async: false
		} : { async: false };
		const result = schema._zod.run({
			value,
			issues: []
		}, ctx);
		if (result instanceof Promise) throw new $ZodAsyncError();
		return result.issues.length ? failure(_Err, result.issues, ctx) : {
			success: true,
			data: result.value
		};
	};
	const safeParse = /* @__PURE__*/ _safeParse($ZodRealError);
	function failure(Err, issues, ctx) {
		let error;
		return {
			success: false,
			get error() {
				if (!error) {
					error = new Err(issues.map((iss) => finalizeIssue(iss, ctx, config())));
					issues = void 0;
					ctx = void 0;
				}
				return error;
			},
			set error(e) {
				error = e;
				issues = void 0;
				ctx = void 0;
			}
		};
	}
	const _safeParseAsync = (_Err) => async (schema, value, _ctx) => {
		const ctx = _ctx ? {
			..._ctx,
			async: true
		} : { async: true };
		let result = schema._zod.run({
			value,
			issues: []
		}, ctx);
		if (result instanceof Promise) result = await result;
		return result.issues.length ? failure(_Err, result.issues, ctx) : {
			success: true,
			data: result.value
		};
	};
	const safeParseAsync = /* @__PURE__*/ _safeParseAsync($ZodRealError);

//#endregion
//#region node_modules/.pnpm/zod@4.6.5/node_modules/zod/v4/core/regexes.js
	const anyString = /^[\s\S]{0,}$/;
	const number$2 = /^-?\d+(?:\.\d+)?$/;
	const boolean$1 = /^(?:true|false)$/i;

//#endregion
//#region node_modules/.pnpm/zod@4.6.5/node_modules/zod/v4/core/checks.js
	const $ZodCheck = /*@__PURE__*/ $constructor("$ZodCheck", (inst, def) => {
		var _a;
		inst._zod ?? (inst._zod = {});
		inst._zod.def = def;
		(_a = inst._zod).onattach ?? (_a.onattach = []);
	});
	/** Default `when` for length-based checks: run only on non-nullish values with a `length`. */
	const _whenHasLength = (payload) => {
		const val = payload.value;
		return !nullish(val) && val.length !== void 0;
	};
	const numericOriginMap = {
		number: "number",
		bigint: "bigint",
		object: "date"
	};
	const $ZodCheckLessThan = /*@__PURE__*/ $constructor("$ZodCheckLessThan", (inst, def) => {
		$ZodCheck.init(inst, def);
		const origin = numericOriginMap[typeof def.value];
		inst._zod.check = (payload) => {
			if (def.inclusive ? payload.value <= def.value : payload.value < def.value) return;
			payload.issues.push({
				origin: numericOriginMap[typeof payload.value] ?? origin,
				code: "too_big",
				maximum: typeof def.value === "object" ? def.value.getTime() : def.value,
				input: payload.value,
				inclusive: def.inclusive,
				inst,
				continue: !def.abort
			});
		};
	});
	const $ZodCheckGreaterThan = /*@__PURE__*/ $constructor("$ZodCheckGreaterThan", (inst, def) => {
		$ZodCheck.init(inst, def);
		const origin = numericOriginMap[typeof def.value];
		inst._zod.check = (payload) => {
			if (def.inclusive ? payload.value >= def.value : payload.value > def.value) return;
			payload.issues.push({
				origin: numericOriginMap[typeof payload.value] ?? origin,
				code: "too_small",
				minimum: typeof def.value === "object" ? def.value.getTime() : def.value,
				input: payload.value,
				inclusive: def.inclusive,
				inst,
				continue: !def.abort
			});
		};
	});
	const $ZodCheckNumberFormat = /*@__PURE__*/ $constructor("$ZodCheckNumberFormat", (inst, def) => {
		$ZodCheck.init(inst, def);
		def.format = def.format || "float64";
		const isInt = def.format?.includes("int");
		const origin = isInt ? "int" : "number";
		const [minimum, maximum] = NUMBER_FORMAT_RANGES[def.format];
		inst._zod.check = (payload) => {
			const input = payload.value;
			if (isInt) {
				if (!Number.isInteger(input)) {
					payload.issues.push({
						expected: origin,
						format: def.format,
						code: "invalid_type",
						continue: false,
						input,
						inst
					});
					return;
				}
				if (!Number.isSafeInteger(input)) {
					if (input > 0) payload.issues.push({
						input,
						code: "too_big",
						maximum: Number.MAX_SAFE_INTEGER,
						note: "Integers must be within the safe integer range.",
						inst,
						origin,
						inclusive: true,
						continue: !def.abort
					});
					else payload.issues.push({
						input,
						code: "too_small",
						minimum: Number.MIN_SAFE_INTEGER,
						note: "Integers must be within the safe integer range.",
						inst,
						origin,
						inclusive: true,
						continue: !def.abort
					});
					return;
				}
			}
			if (input < minimum) payload.issues.push({
				origin: "number",
				input,
				code: "too_small",
				minimum,
				inclusive: true,
				inst,
				continue: !def.abort
			});
			if (input > maximum) payload.issues.push({
				origin: "number",
				input,
				code: "too_big",
				maximum,
				inclusive: true,
				inst,
				continue: !def.abort
			});
		};
	});
	const $ZodCheckMinLength = /*@__PURE__*/ $constructor("$ZodCheckMinLength", (inst, def) => {
		var _a;
		$ZodCheck.init(inst, def);
		(_a = inst._zod.def).when ?? (_a.when = _whenHasLength);
		inst._zod.check = (payload) => {
			const input = payload.value;
			const units = input.length;
			if ((typeof input === "string" && units >= def.minimum && units < def.minimum * 2 ? codePointLength(input) : units) >= def.minimum) return;
			const origin = getLengthableOrigin(input);
			payload.issues.push({
				origin,
				code: "too_small",
				minimum: def.minimum,
				inclusive: true,
				input,
				inst,
				continue: !def.abort
			});
		};
	});
	const $ZodCheckStringFormat = /*@__PURE__*/ $constructor("$ZodCheckStringFormat", (inst, def) => {
		var _a, _b;
		$ZodCheck.init(inst, def);
		if (def.pattern) (_a = inst._zod).check ?? (_a.check = (payload) => {
			def.pattern.lastIndex = 0;
			if (def.pattern.test(payload.value)) return;
			payload.issues.push({
				origin: "string",
				code: "invalid_format",
				format: def.format,
				input: payload.value,
				...def.pattern ? { pattern: def.pattern.toString() } : {},
				inst,
				continue: !def.abort
			});
		});
		else (_b = inst._zod).check ?? (_b.check = () => {});
	});
	const $ZodCheckRegex = /*@__PURE__*/ $constructor("$ZodCheckRegex", (inst, def) => {
		$ZodCheckStringFormat.init(inst, def);
		inst._zod.check = (payload) => {
			def.pattern.lastIndex = 0;
			if (def.pattern.test(payload.value)) return;
			payload.issues.push({
				origin: "string",
				code: "invalid_format",
				format: "regex",
				input: payload.value,
				pattern: def.pattern.toString(),
				inst,
				continue: !def.abort
			});
		};
	});

//#endregion
//#region node_modules/.pnpm/zod@4.6.5/node_modules/zod/v4/core/versions.js
	const version = {
		major: 4,
		minor: 6,
		patch: 5
	};

//#endregion
//#region node_modules/.pnpm/zod@4.6.5/node_modules/zod/v4/core/schemas.js
	const $ZodType = /*@__PURE__*/ $constructor("$ZodType", (inst, def) => {
		var _a;
		inst ?? (inst = {});
		inst._zod.def = def;
		inst._zod.bag = inst._zod.bag || {};
		inst._zod.version = version;
		const defChecks = inst._zod.def.checks;
		const checks = inst._zod.traits.has("$ZodCheck") ? [inst, ...defChecks ?? []] : defChecks?.length ? [...defChecks] : [];
		for (const ch of checks) for (const fn of ch._zod.onattach) fn(inst);
		if (checks.length === 0) {
			(_a = inst._zod).deferred ?? (_a.deferred = []);
			inst._zod.deferred?.push(() => {
				inst._zod.run = inst._zod.parse;
			});
		} else {
			const runChecks = (payload, checks, ctx) => {
				if (payload.memo) return payload;
				let isAborted = aborted(payload);
				let asyncResult;
				for (const ch of checks) {
					if (ch._zod.def.when) {
						if (explicitlyAborted(payload)) continue;
						if (!ch._zod.def.when(payload)) continue;
					} else if (isAborted) continue;
					const currLen = payload.issues.length;
					const _ = ch._zod.check(payload);
					if (_ instanceof Promise && ctx?.async === false) throw new $ZodAsyncError();
					if (asyncResult || _ instanceof Promise) asyncResult = (asyncResult ?? Promise.resolve()).then(async () => {
						await _;
						if (payload.issues.length === currLen) return;
						attachSchema(payload.issues, currLen, inst);
						if (!isAborted) isAborted = aborted(payload, currLen);
					});
					else {
						if (payload.issues.length === currLen) continue;
						attachSchema(payload.issues, currLen, inst);
						if (!isAborted) isAborted = aborted(payload, currLen);
					}
				}
				if (asyncResult) return asyncResult.then(() => {
					return payload;
				});
				return payload;
			};
			const handleCanaryResult = (canary, payload, ctx) => {
				if (aborted(canary)) {
					canary.aborted = true;
					return canary;
				}
				const checkResult = runChecks(payload, checks, ctx);
				if (checkResult instanceof Promise) {
					if (ctx.async === false) throw new $ZodAsyncError();
					return checkResult.then((checkResult) => inst._zod.parse(checkResult, ctx));
				}
				return inst._zod.parse(checkResult, ctx);
			};
			inst._zod.run = (payload, ctx) => {
				if (ctx.skipChecks) return inst._zod.parse(payload, ctx);
				if (ctx.direction === "backward") {
					const canary = inst._zod.parse({
						value: payload.value,
						issues: []
					}, {
						...ctx,
						skipChecks: true
					});
					if (canary instanceof Promise) return canary.then((canary) => {
						return handleCanaryResult(canary, payload, ctx);
					});
					return handleCanaryResult(canary, payload, ctx);
				}
				const result = inst._zod.parse(payload, ctx);
				if (result instanceof Promise) {
					if (ctx.async === false) throw new $ZodAsyncError();
					return result.then((result) => runChecks(result, checks, ctx));
				}
				return runChecks(result, checks, ctx);
			};
		}
	}, {
		get "~standard"() {
			return hide(this, "~standard", standardProps(this));
		},
		set "~standard"(value) {
			own(this, "~standard", value);
		}
	});
	/** The Standard Schema surface for `inst`. Shared so wrappers can extend it without forcing it. */
	const toStandardResult = (r, ctx) => r.issues.length ? { issues: r.issues.map((iss) => finalizeIssue(iss, ctx, config())) } : { value: r.value };
	async function validateAsync(inst, value) {
		const ctx = { async: true };
		return toStandardResult(await inst._zod.run({
			value,
			issues: []
		}, ctx), ctx);
	}
	function standardProps(inst) {
		return {
			validate: (value) => {
				const ctx = { async: false };
				try {
					const r = inst._zod.run({
						value,
						issues: []
					}, ctx);
					if (!(r instanceof Promise)) return toStandardResult(r, ctx);
				} catch (_) {}
				return validateAsync(inst, value);
			},
			vendor: "zod",
			version: 1
		};
	}
	const $ZodString = /*@__PURE__*/ $constructor("$ZodString", (inst, def) => {
		$ZodType.init(inst, def);
		inst._zod.pattern = def.pattern ?? anyString;
		inst._zod.parse = (payload, _) => {
			if (def.coerce) try {
				payload.value = String(payload.value);
			} catch (_) {}
			if (typeof payload.value === "string") return payload;
			payload.issues.push({
				expected: "string",
				code: "invalid_type",
				input: payload.value,
				inst
			});
			return payload;
		};
	});
	const $ZodNumber = /*@__PURE__*/ $constructor("$ZodNumber", (inst, def) => {
		$ZodType.init(inst, def);
		inst._zod.pattern = number$2;
		inst._zod.parse = (payload, _ctx) => {
			if (def.coerce) try {
				payload.value = Number(payload.value);
			} catch (_) {}
			const input = payload.value;
			if (typeof input === "number" && !Number.isNaN(input) && Number.isFinite(input)) return payload;
			const received = typeof input === "number" ? Number.isNaN(input) ? "NaN" : !Number.isFinite(input) ? String(input) : void 0 : void 0;
			payload.issues.push({
				expected: "number",
				code: "invalid_type",
				input,
				inst,
				...received ? { received } : {}
			});
			return payload;
		};
	});
	const $ZodNumberFormat = /*@__PURE__*/ $constructor("$ZodNumberFormat", (inst, def) => {
		$ZodCheckNumberFormat.init(inst, def);
		$ZodNumber.init(inst, def);
	});
	const $ZodBoolean = /*@__PURE__*/ $constructor("$ZodBoolean", (inst, def) => {
		$ZodType.init(inst, def);
		inst._zod.pattern = boolean$1;
		inst._zod.parse = (payload, _ctx) => {
			if (def.coerce) try {
				payload.value = Boolean(payload.value);
			} catch (_) {}
			const input = payload.value;
			if (typeof input === "boolean") return payload;
			payload.issues.push({
				expected: "boolean",
				code: "invalid_type",
				input,
				inst
			});
			return payload;
		};
	});
	const $ZodUnknown = /*@__PURE__*/ $constructor("$ZodUnknown", (inst, def) => {
		$ZodType.init(inst, def);
		inst._zod.parse = (payload) => payload;
	});
	function handleArrayResult(result, final, index) {
		if (result.issues.length) final.issues.push(...prefixIssues(index, result.issues));
		final.value[index] = result.value;
	}
	const $ZodArray = /*@__PURE__*/ $constructor("$ZodArray", (inst, def) => {
		$ZodType.init(inst, def);
		const memo = globalConfig.memoizer;
		memo?.attach(inst);
		inst._zod.parse = (payload, ctx) => {
			const input = payload.value;
			if (!Array.isArray(input)) {
				payload.issues.push({
					expected: "array",
					code: "invalid_type",
					input,
					inst
				});
				return payload;
			}
			payload.value = memo ? memo.alloc(inst, payload, Array(input.length), ctx) : Array(input.length);
			const proms = [];
			const abortEarly = ctx?.abortEarly;
			for (let i = 0; i < input.length; i++) {
				const item = input[i];
				const result = def.element._zod.run({
					value: item,
					issues: []
				}, ctx);
				if (result instanceof Promise) proms.push(result.then((result) => handleArrayResult(result, payload, i)));
				else {
					handleArrayResult(result, payload, i);
					if (abortEarly && result.issues.length !== 0 && aborted(result)) break;
				}
			}
			if (proms.length) return Promise.all(proms).then(() => payload);
			return payload;
		};
	});
	function handlePropertyResult(result, final, key, input, optin, optout) {
		const isPresent = key in input;
		const isOptionalOut = optout === "optional";
		if (!isPresent && isOptionalOut && optin === "optional") return;
		if (result.issues.length) {
			if (optin !== void 0 && isOptionalOut && !isPresent) return;
			final.issues.push(...prefixIssues(key, result.issues));
		}
		if (!isPresent && optin === void 0) {
			if (!result.issues.length) final.issues.push({
				code: "invalid_type",
				expected: "nonoptional",
				input: void 0,
				path: [key]
			});
			return;
		}
		if (result.value === void 0) {
			if (isPresent || optin === "defaulted" && !isOptionalOut) final.value[key] = void 0;
		} else final.value[key] = result.value;
	}
	const NO_SYMBOL_KEYS = [];
	function normalizeDef(def) {
		const keys = Object.keys(def.shape);
		const ownSymbols = Object.getOwnPropertySymbols(def.shape);
		const symbolKeys = ownSymbols.length ? ownSymbols : NO_SYMBOL_KEYS;
		const allKeys = symbolKeys.length ? [...keys, ...symbolKeys] : keys;
		for (const k of allKeys) if (!def.shape?.[k]?._zod?.traits?.has("$ZodType")) throw new Error(`Invalid element at key "${String(k)}": expected a Zod schema`);
		const okeys = optionalKeys(def.shape);
		return {
			...def,
			allKeys,
			symbolKeys,
			keySet: new Set(keys),
			numKeys: keys.length,
			optionalKeys: new Set(okeys)
		};
	}
	function handleCatchall(proms, input, payload, ctx, def, inst, abortEarly) {
		const unrecognized = [];
		const keySet = def.keySet;
		const _catchall = def.catchall._zod;
		const t = _catchall.def.type;
		const optin = _catchall.optin;
		const optout = _catchall.optout;
		let seen = 0;
		for (const key in input) {
			if (abortEarly && payload.issues.length !== seen) {
				if (aborted(payload, seen)) break;
				seen = payload.issues.length;
			}
			if (keySet.has(key)) continue;
			if (key === "__proto__") {
				if (t === "never") unrecognized.push(key);
				continue;
			}
			if (t === "never") {
				unrecognized.push(key);
				continue;
			}
			const r = _catchall.run({
				value: input[key],
				issues: []
			}, ctx);
			if (r instanceof Promise) proms.push(r.then((r) => handlePropertyResult(r, payload, key, input, optin, optout)));
			else handlePropertyResult(r, payload, key, input, optin, optout);
		}
		if (unrecognized.length) payload.issues.push({
			code: "unrecognized_keys",
			keys: unrecognized,
			input,
			inst,
			continue: true
		});
		if (!proms.length) return payload;
		return Promise.all(proms).then(() => {
			return payload;
		});
	}
	const $ZodObject = /*@__PURE__*/ $constructor("$ZodObject", (inst, def) => {
		$ZodType.init(inst, def);
		const desc = Object.getOwnPropertyDescriptor(def, "shape");
		const sh = desc?.get ? desc.get.raw : def.shape ?? {};
		if (sh) {
			const get = () => {
				const newSh = { ...sh };
				Object.defineProperty(def, "shape", { value: newSh });
				get.raw = newSh;
				return newSh;
			};
			get.raw = sh;
			Object.defineProperty(def, "shape", { get });
		}
		const _normalized = cached(() => normalizeDef(def));
		defineLazyInternal(inst, "propValues", (zod) => {
			const shape = zod.def.shape;
			const propValues = {};
			for (const key in shape) {
				const field = shape[key]._zod;
				if (field.values) {
					if (!Object.prototype.hasOwnProperty.call(propValues, key)) assignProp(propValues, key, /* @__PURE__ */ new Set());
					for (const v of field.values) propValues[key].add(v);
					if (field.optin !== void 0) propValues[key].add(void 0);
				}
			}
			return propValues;
		});
		const isObject$2 = isObject;
		const catchall = def.catchall;
		let value;
		const memo = globalConfig.memoizer;
		memo?.attach(inst);
		inst._zod.parse = (payload, ctx) => {
			value ?? (value = _normalized.value);
			const input = payload.value;
			if (!isObject$2(input)) {
				payload.issues.push({
					expected: "object",
					code: "invalid_type",
					input,
					inst
				});
				return payload;
			}
			payload.value = memo ? memo.alloc(inst, payload, {}, ctx) : {};
			const proms = [];
			const shape = value.shape;
			const abortEarly = ctx?.abortEarly;
			let seen = payload.issues.length;
			for (const key of value.allKeys) {
				if (abortEarly && payload.issues.length !== seen) {
					if (aborted(payload, seen)) break;
					seen = payload.issues.length;
				}
				if (key === "__proto__") continue;
				const el = shape[key];
				const optin = el._zod.optin;
				const optout = el._zod.optout;
				const r = el._zod.run({
					value: input[key],
					issues: []
				}, ctx);
				if (r instanceof Promise) proms.push(r.then((r) => handlePropertyResult(r, payload, key, input, optin, optout)));
				else handlePropertyResult(r, payload, key, input, optin, optout);
			}
			if (!catchall) return proms.length ? Promise.all(proms).then(() => payload) : payload;
			return handleCatchall(proms, input, payload, ctx, _normalized.value, inst, abortEarly === true);
		};
	});
	function handleUnionResults(results, final, inst, ctx) {
		for (const result of results) if (result.issues.length === 0) {
			final.value = result.value;
			return final;
		}
		const nonaborted = results.filter((r) => !aborted(r));
		if (nonaborted.length === 1) {
			final.value = nonaborted[0].value;
			return nonaborted[0];
		}
		final.issues.push({
			code: "invalid_union",
			input: final.value,
			inst,
			errors: results.map((result) => result.issues.map((iss) => finalizeIssue(iss, ctx, config())))
		});
		return final;
	}
	const $ZodUnion = /*@__PURE__*/ $constructor("$ZodUnion", (inst, def) => {
		$ZodType.init(inst, def);
		defineLazyInternal(inst, "optin", (zod) => zod.def.options.some((o) => o._zod.optin === "defaulted") ? "defaulted" : zod.def.options.some((o) => o._zod.optin !== void 0) ? "optional" : void 0);
		defineLazyInternal(inst, "optout", (zod) => zod.def.options.some((o) => o._zod.optout === "optional") ? "optional" : void 0);
		defineLazyInternal(inst, "values", (zod) => {
			if (zod.def.options.every((o) => o._zod.values)) return new Set(zod.def.options.flatMap((option) => Array.from(option._zod.values)));
		});
		defineLazyInternal(inst, "pattern", (zod) => {
			if (zod.def.options.every((o) => o._zod.pattern)) {
				const patterns = zod.def.options.map((o) => o._zod.pattern);
				return new RegExp(`^(${patterns.map((p) => cleanRegex(p.source)).join("|")})$`);
			}
		});
		const first = def.options.length === 1 ? def.options[0]._zod.run : null;
		inst._zod.parse = (payload, ctx) => {
			if (first) return first(payload, ctx);
			let async = false;
			const results = [];
			for (const option of def.options) {
				const result = option._zod.run({
					value: payload.value,
					issues: []
				}, ctx);
				if (result instanceof Promise) {
					results.push(result);
					async = true;
				} else {
					if (result.issues.length === 0) return result;
					results.push(result);
				}
			}
			if (!async) return handleUnionResults(results, payload, inst, ctx);
			return Promise.all(results).then((results) => {
				return handleUnionResults(results, payload, inst, ctx);
			});
		};
	});
	const $ZodTuple = /*@__PURE__*/ $constructor("$ZodTuple", (inst, def) => {
		$ZodType.init(inst, def);
		const items = def.items;
		const memo = globalConfig.memoizer;
		memo?.attach(inst);
		inst._zod.parse = (payload, ctx) => {
			const input = payload.value;
			if (!Array.isArray(input)) {
				payload.issues.push({
					input,
					inst,
					expected: "tuple",
					code: "invalid_type"
				});
				return payload;
			}
			payload.value = memo ? memo.alloc(inst, payload, [], ctx) : [];
			const proms = [];
			const optinStart = getTupleOptStart(items, "optin");
			const optoutStart = getTupleOptStart(items, "optout");
			if (!def.rest) {
				if (input.length < optinStart) {
					payload.issues.push({
						code: "too_small",
						minimum: optinStart,
						inclusive: true,
						input,
						inst,
						origin: "array"
					});
					return payload;
				}
				if (input.length > items.length) payload.issues.push({
					code: "too_big",
					maximum: items.length,
					inclusive: true,
					input,
					inst,
					origin: "array"
				});
			}
			const itemResults = new Array(items.length);
			const abortEarly = def.rest ? ctx?.abortEarly : void 0;
			let itemAborted = false;
			for (let i = 0; i < items.length; i++) {
				const r = items[i]._zod.run({
					value: input[i],
					issues: []
				}, ctx);
				if (r instanceof Promise) proms.push(r.then((rr) => {
					itemResults[i] = rr;
				}));
				else {
					itemResults[i] = r;
					if (abortEarly && !itemAborted && r.issues.length) itemAborted = aborted(r);
				}
			}
			if (def.rest && !itemAborted) {
				let i = items.length - 1;
				const rest = input.slice(items.length);
				let seen = payload.issues.length;
				for (const el of rest) {
					if (abortEarly && payload.issues.length !== seen) {
						if (aborted(payload, seen)) break;
						seen = payload.issues.length;
					}
					i++;
					const result = def.rest._zod.run({
						value: el,
						issues: []
					}, ctx);
					if (result instanceof Promise) proms.push(result.then((r) => handleTupleResult(r, payload, i)));
					else handleTupleResult(result, payload, i);
				}
			}
			if (proms.length) return Promise.all(proms).then(() => handleTupleResults(itemResults, payload, items, input, optoutStart));
			return handleTupleResults(itemResults, payload, items, input, optoutStart);
		};
	});
	function getTupleOptStart(items, key) {
		for (let i = items.length - 1; i >= 0; i--) if (!(key === "optin" ? items[i]._zod.optin !== void 0 : items[i]._zod.optout === "optional")) return i + 1;
		return 0;
	}
	function handleTupleResult(result, final, index) {
		if (result.issues.length) final.issues.push(...prefixIssues(index, result.issues));
		final.value[index] = result.value;
	}
	function handleTupleResults(itemResults, final, items, input, optoutStart) {
		for (let i = 0; i < items.length; i++) {
			const r = itemResults[i];
			const isPresent = i < input.length;
			if (!isPresent && i >= optoutStart && items[i]._zod.optin === "optional") {
				final.value.length = i;
				break;
			}
			if (r.issues.length) {
				if (!isPresent && i >= optoutStart) {
					final.value.length = i;
					break;
				}
				final.issues.push(...prefixIssues(i, r.issues));
			}
			final.value[i] = r.value;
		}
		for (let i = final.value.length - 1; i >= input.length; i--) if (items[i]._zod.optout === "optional" && final.value[i] === void 0) final.value.length = i;
		else break;
		return final;
	}
	const $ZodRecord = /*@__PURE__*/ $constructor("$ZodRecord", (inst, def) => {
		$ZodType.init(inst, def);
		const memo = globalConfig.memoizer;
		memo?.attach(inst);
		inst._zod.parse = (payload, ctx) => {
			const input = payload.value;
			if (!isPlainObject(input)) {
				payload.issues.push({
					expected: "record",
					code: "invalid_type",
					input,
					inst
				});
				return payload;
			}
			const proms = [];
			const values = def.keyType._zod.values;
			if (values && !def.partial) {
				payload.value = memo ? memo.alloc(inst, payload, {}, ctx) : {};
				const recordKeys = /* @__PURE__ */ new Set();
				for (const key of values) if (typeof key === "string" || typeof key === "number" || typeof key === "symbol") {
					recordKeys.add(typeof key === "number" ? key.toString() : key);
					if (key === "__proto__") continue;
					const keyResult = def.keyType._zod.run({
						value: key,
						issues: []
					}, ctx);
					if (keyResult instanceof Promise) throw new Error("Async schemas not supported in object keys currently");
					if (keyResult.issues.length) {
						payload.issues.push({
							code: "invalid_key",
							origin: "record",
							issues: keyResult.issues.map((iss) => finalizeIssue(iss, ctx, config())),
							input: key,
							path: [key],
							inst
						});
						continue;
					}
					const outKey = keyResult.value;
					if (outKey === "__proto__") continue;
					const result = def.valueType._zod.run({
						value: input[key],
						issues: []
					}, ctx);
					if (result instanceof Promise) proms.push(result.then((result) => {
						if (result.issues.length) payload.issues.push(...prefixIssues(key, result.issues));
						payload.value[outKey] = result.value;
					}));
					else {
						if (result.issues.length) payload.issues.push(...prefixIssues(key, result.issues));
						payload.value[outKey] = result.value;
					}
				}
				let unrecognized;
				for (const key in input) if (!recordKeys.has(key)) {
					if (def.mode === "loose") {
						if (key === "__proto__") continue;
						payload.value[key] = input[key];
					} else {
						unrecognized = unrecognized ?? [];
						unrecognized.push(key);
					}
				}
				if (unrecognized && unrecognized.length > 0) payload.issues.push({
					code: "unrecognized_keys",
					input,
					inst,
					keys: unrecognized,
					continue: true
				});
			} else {
				payload.value = memo ? memo.alloc(inst, payload, {}, ctx) : {};
				let unrecognized;
				for (const key of Reflect.ownKeys(input)) {
					if (key === "__proto__") continue;
					if (!Object.prototype.propertyIsEnumerable.call(input, key)) continue;
					let keyResult = def.keyType._zod.run({
						value: key,
						issues: []
					}, ctx);
					if (keyResult instanceof Promise) throw new Error("Async schemas not supported in object keys currently");
					if (typeof key === "string" && number$2.test(key) && keyResult.issues.length) {
						const retryResult = def.keyType._zod.run({
							value: Number(key),
							issues: []
						}, ctx);
						if (retryResult instanceof Promise) throw new Error("Async schemas not supported in object keys currently");
						if (retryResult.issues.length === 0) keyResult = retryResult;
					}
					if (keyResult.issues.length) {
						if (def.mode === "loose") payload.value[key] = input[key];
						else if (values) {
							unrecognized = unrecognized ?? [];
							unrecognized.push(key);
						} else payload.issues.push({
							code: "invalid_key",
							origin: "record",
							issues: keyResult.issues.map((iss) => finalizeIssue(iss, ctx, config())),
							input: key,
							path: [key],
							inst
						});
						continue;
					}
					const outKey = keyResult.value;
					if (outKey === "__proto__") continue;
					const result = def.valueType._zod.run({
						value: input[key],
						issues: []
					}, ctx);
					if (result instanceof Promise) proms.push(result.then((result) => {
						if (result.issues.length) payload.issues.push(...prefixIssues(key, result.issues));
						payload.value[outKey] = result.value;
					}));
					else {
						if (result.issues.length) payload.issues.push(...prefixIssues(key, result.issues));
						payload.value[outKey] = result.value;
					}
				}
				if (unrecognized && unrecognized.length > 0) payload.issues.push({
					code: "unrecognized_keys",
					input,
					inst,
					keys: unrecognized,
					continue: true
				});
			}
			if (proms.length) return Promise.all(proms).then(() => payload);
			return payload;
		};
	});
	const $ZodEnum = /*@__PURE__*/ $constructor("$ZodEnum", (inst, def) => {
		$ZodType.init(inst, def);
		const values = getEnumValues(def.entries);
		const valuesSet = new Set(values);
		inst._zod.values = valuesSet;
		defineLazyInternal(inst, "pattern", (zod) => {
			const patternValues = getEnumValues(zod.def.entries).filter((k) => propertyKeyTypes.has(typeof k));
			return new RegExp(patternValues.length ? `^(${patternValues.map((o) => escapeRegex(o.toString())).join("|")})$` : "^[^\\s\\S]$");
		});
		inst._zod.parse = (payload, _ctx) => {
			const input = payload.value;
			if (valuesSet.has(input)) return payload;
			payload.issues.push({
				code: "invalid_value",
				values,
				input,
				inst
			});
			return payload;
		};
	});
	const $ZodLiteral = /*@__PURE__*/ $constructor("$ZodLiteral", (inst, def) => {
		$ZodType.init(inst, def);
		const values = new Set(def.values);
		inst._zod.values = values;
		defineLazyInternal(inst, "pattern", (zod) => {
			const vals = zod.def.values;
			return new RegExp(vals.length ? `^(${vals.map((o) => typeof o === "string" ? escapeRegex(o) : o ? escapeRegex(o.toString()) : String(o)).join("|")})$` : "^[^\\s\\S]$");
		});
		inst._zod.parse = (payload, _ctx) => {
			const input = payload.value;
			if (values.has(input)) return payload;
			payload.issues.push({
				code: "invalid_value",
				values: def.values,
				input,
				inst
			});
			return payload;
		};
	});
	const $ZodTransform = /*@__PURE__*/ $constructor("$ZodTransform", (inst, def) => {
		$ZodType.init(inst, def);
		inst._zod.optin = "optional";
		globalConfig.memoizer?.guard(inst);
		inst._zod.parse = (payload, ctx) => {
			if (ctx.direction === "backward") throw new $ZodEncodeError(inst.constructor.name);
			const _out = def.transform(payload.value, payload);
			if (ctx.async) return (_out instanceof Promise ? _out : Promise.resolve(_out)).then((output) => {
				payload.value = output;
				return payload;
			});
			if (_out instanceof Promise) throw new $ZodAsyncError();
			payload.value = _out;
			return payload;
		};
	});
	function handleOptionalResult(payload, result) {
		payload.value = result.issues.length ? void 0 : result.value;
		return payload;
	}
	const $ZodOptional = /*@__PURE__*/ $constructor("$ZodOptional", (inst, def) => {
		$ZodType.init(inst, def);
		defineLazyInternal(inst, "optin", (zod) => zod.def.innerType._zod.optin === "defaulted" ? "defaulted" : "optional");
		inst._zod.optout = "optional";
		defineLazyInternal(inst, "values", (zod) => {
			const values = zod.def.innerType._zod.values;
			return values ? /* @__PURE__ */ new Set([...values, void 0]) : void 0;
		});
		defineLazyInternal(inst, "pattern", (zod) => {
			const pattern = zod.def.innerType._zod.pattern;
			return pattern ? new RegExp(`^(${cleanRegex(pattern.source)})?$`) : void 0;
		});
		inst._zod.parse = (payload, ctx) => {
			if (payload.value === void 0) {
				if (def.innerType._zod.optin !== "defaulted") return payload;
				const result = def.innerType._zod.run({
					value: payload.value,
					issues: []
				}, ctx);
				if (result instanceof Promise) return result.then((result) => handleOptionalResult(payload, result));
				return handleOptionalResult(payload, result);
			}
			return def.innerType._zod.run(payload, ctx);
		};
	});
	const $ZodNullable = /*@__PURE__*/ $constructor("$ZodNullable", (inst, def) => {
		$ZodType.init(inst, def);
		defineLazyInternal(inst, "optin", (zod) => zod.def.innerType._zod.optin);
		defineLazyInternal(inst, "optout", (zod) => zod.def.innerType._zod.optout);
		defineLazyInternal(inst, "pattern", (zod) => {
			const pattern = zod.def.innerType._zod.pattern;
			return pattern ? new RegExp(`^(${cleanRegex(pattern.source)}|null)$`) : void 0;
		});
		defineLazyInternal(inst, "values", (zod) => {
			return zod.def.innerType._zod.values ? /* @__PURE__ */ new Set([...zod.def.innerType._zod.values, null]) : void 0;
		});
		inst._zod.parse = (payload, ctx) => {
			if (payload.value === null) return payload;
			return def.innerType._zod.run(payload, ctx);
		};
	});
	function handleCatchResult(payload, result, def, ctx) {
		if (!result.issues.length) {
			payload.value = result.value;
			if (result.memo) payload.memo = true;
			return payload;
		}
		payload.value = def.catchValue({
			...result,
			value: payload.value,
			error: { issues: result.issues.map((iss) => finalizeIssue(iss, ctx, config())) },
			input: payload.value
		});
		return payload;
	}
	const $ZodCatch = /*@__PURE__*/ $constructor("$ZodCatch", (inst, def) => {
		$ZodType.init(inst, def);
		defineLazyInternal(inst, "optin", (zod) => zod.def.innerType._zod.optin === "defaulted" ? "defaulted" : "optional");
		defineLazyInternal(inst, "optout", (zod) => zod.def.innerType._zod.optout);
		defineLazyInternal(inst, "values", (zod) => zod.def.innerType._zod.values);
		inst._zod.parse = (payload, ctx) => {
			if (ctx.direction === "backward") return def.innerType._zod.run(payload, ctx);
			const result = def.innerType._zod.run({
				value: payload.value,
				issues: []
			}, ctx);
			if (result instanceof Promise) return result.then((result) => handleCatchResult(payload, result, def, ctx));
			return handleCatchResult(payload, result, def, ctx);
		};
	});
	const $ZodPipe = /*@__PURE__*/ $constructor("$ZodPipe", (inst, def) => {
		$ZodType.init(inst, def);
		defineLazyInternal(inst, "values", (zod) => zod.def.in._zod.values);
		defineLazyInternal(inst, "optin", (zod) => zod.def.in._zod.optin);
		defineLazyInternal(inst, "optout", (zod) => zod.def.out._zod.optout);
		defineLazyInternal(inst, "propValues", (zod) => zod.def.in._zod.propValues);
		inst._zod.parse = (payload, ctx) => {
			if (ctx.direction === "backward") {
				const right = def.out._zod.run(payload, ctx);
				if (right instanceof Promise) return right.then((right) => handlePipeResult(right, def.in, ctx));
				return handlePipeResult(right, def.in, ctx);
			}
			const left = def.in._zod.run(payload, ctx);
			if (left instanceof Promise) return left.then((left) => handlePipeResult(left, def.out, ctx));
			return handlePipeResult(left, def.out, ctx);
		};
	});
	function handlePipeResult(left, next, ctx) {
		if (left.issues.some((iss) => iss.code !== "unrecognized_keys")) {
			left.aborted = true;
			return left;
		}
		return next._zod.run({
			value: left.value,
			issues: left.issues
		}, ctx);
	}
	const $ZodCustom = /*@__PURE__*/ $constructor("$ZodCustom", (inst, def) => {
		$ZodCheck.init(inst, def);
		$ZodType.init(inst, def);
		inst._zod.parse = (payload, _) => {
			return payload;
		};
		inst._zod.check = (payload) => {
			const input = payload.value;
			const r = def.fn(input);
			if (r instanceof Promise) return r.then((r) => handleRefineResult(r, payload, input, inst));
			handleRefineResult(r, payload, input, inst);
		};
	});
	function handleRefineResult(result, payload, input, inst) {
		if (!result) {
			const _iss = {
				code: "custom",
				input,
				inst,
				path: [...inst._zod.def.path ?? []],
				continue: !inst._zod.def.abort
			};
			if (inst._zod.def.params) _iss.params = inst._zod.def.params;
			payload.issues.push(issue(_iss));
		}
	}

//#endregion
//#region node_modules/.pnpm/zod@4.6.5/node_modules/zod/v4/core/api.js
	function snapshotChecks(def) {
		if (def.checks) def.checks = [...def.checks];
		return def;
	}
	// @__NO_SIDE_EFFECTS__
	function _string(Class, params) {
		return new Class(snapshotChecks({
			type: "string",
			...normalizeParams(params)
		}));
	}
	// @__NO_SIDE_EFFECTS__
	function _number(Class, params) {
		return new Class(snapshotChecks({
			type: "number",
			checks: [],
			...normalizeParams(params)
		}));
	}
	// @__NO_SIDE_EFFECTS__
	function _coercedNumber(Class, params) {
		return new Class(snapshotChecks({
			type: "number",
			coerce: true,
			checks: [],
			...normalizeParams(params)
		}));
	}
	// @__NO_SIDE_EFFECTS__
	function _int(Class, params) {
		return new Class({
			type: "number",
			check: "number_format",
			abort: false,
			format: "safeint",
			...normalizeParams(params)
		});
	}
	// @__NO_SIDE_EFFECTS__
	function _boolean(Class, params) {
		return new Class({
			type: "boolean",
			...normalizeParams(params)
		});
	}
	// @__NO_SIDE_EFFECTS__
	function _unknown(Class) {
		return new Class({ type: "unknown" });
	}
	// @__NO_SIDE_EFFECTS__
	function _lte(value, params) {
		return new $ZodCheckLessThan({
			check: "less_than",
			...normalizeParams(params),
			value,
			inclusive: true
		});
	}
	// @__NO_SIDE_EFFECTS__
	function _gte(value, params) {
		return new $ZodCheckGreaterThan({
			check: "greater_than",
			...normalizeParams(params),
			value,
			inclusive: true
		});
	}
	// @__NO_SIDE_EFFECTS__
	function _minLength(minimum, params) {
		return new $ZodCheckMinLength({
			check: "min_length",
			...normalizeParams(params),
			minimum
		});
	}
	// @__NO_SIDE_EFFECTS__
	function _regex(pattern, params) {
		return new $ZodCheckRegex({
			check: "string_format",
			format: "regex",
			...normalizeParams(params),
			pattern
		});
	}
	// @__NO_SIDE_EFFECTS__
	function _custom(Class, fn, _params) {
		const norm = normalizeParams(_params);
		norm.abort ?? (norm.abort = true);
		return new Class({
			type: "custom",
			check: "custom",
			fn,
			...norm
		});
	}
	// @__NO_SIDE_EFFECTS__
	function _refine(Class, fn, _params) {
		return new Class({
			type: "custom",
			check: "custom",
			fn,
			...normalizeParams(_params)
		});
	}

//#endregion
//#region node_modules/.pnpm/zod@4.6.5/node_modules/zod/v4/mini/schemas.js
	const ZodMiniType = /*@__PURE__*/ $constructor("ZodMiniType", (inst, def) => {
		if (!inst._zod) throw new Error("Uninitialized schema in ZodMiniType.");
		$ZodType.init(inst, def);
		inst.def = def;
		inst.type = def.type;
	}, {
		get with() {
			return this.check;
		},
		set with(value) {
			own(this, "with", value);
		},
		parse(data, params) {
			return parse(this, data, params, { callee: this.parse });
		},
		parseAsync(data, params) {
			return parseAsync(this, data, params, { callee: this.parseAsync });
		},
		safeParse(data, params) {
			return safeParse(this, data, params);
		},
		safeParseAsync(data, params) {
			return safeParseAsync(this, data, params);
		},
		check(...checks) {
			const def = this.def;
			return this.clone({
				...def,
				checks: [...def.checks ?? [], ...checks.map((ch) => typeof ch === "function" ? { _zod: {
					check: ch,
					def: { check: "custom" },
					onattach: []
				} } : ch)]
			}, { parent: true });
		},
		clone(_def, params) {
			return clone(this, _def, params);
		},
		brand() {
			return this;
		},
		register(reg, meta) {
			reg.add(this, meta);
			return this;
		},
		apply(fn, ...args) {
			return args.length === 0 ? fn(this) : fn(this, ...args);
		}
	});
	const ZodMiniString = /*@__PURE__*/ $constructor("ZodMiniString", (inst, def) => {
		$ZodString.init(inst, def);
		ZodMiniType.init(inst, def);
	});
	// @__NO_SIDE_EFFECTS__
	function string(params) {
		return _string(ZodMiniString, params);
	}
	const ZodMiniNumber = /*@__PURE__*/ $constructor("ZodMiniNumber", (inst, def) => {
		$ZodNumber.init(inst, def);
		ZodMiniType.init(inst, def);
	});
	// @__NO_SIDE_EFFECTS__
	function number$1(params) {
		return _number(ZodMiniNumber, params);
	}
	const ZodMiniNumberFormat = /*@__PURE__*/ $constructor("ZodMiniNumberFormat", (inst, def) => {
		$ZodNumberFormat.init(inst, def);
		ZodMiniNumber.init(inst, def);
	});
	function int(params) {
		return _int(ZodMiniNumberFormat, params);
	}
	const ZodMiniBoolean = /*@__PURE__*/ $constructor("ZodMiniBoolean", (inst, def) => {
		$ZodBoolean.init(inst, def);
		ZodMiniType.init(inst, def);
	});
	// @__NO_SIDE_EFFECTS__
	function boolean(params) {
		return _boolean(ZodMiniBoolean, params);
	}
	const ZodMiniUnknown = /*@__PURE__*/ $constructor("ZodMiniUnknown", (inst, def) => {
		$ZodUnknown.init(inst, def);
		ZodMiniType.init(inst, def);
	});
	// @__NO_SIDE_EFFECTS__
	function unknown() {
		return _unknown(ZodMiniUnknown);
	}
	const ZodMiniArray = /*@__PURE__*/ $constructor("ZodMiniArray", (inst, def) => {
		$ZodArray.init(inst, def);
		ZodMiniType.init(inst, def);
	});
	// @__NO_SIDE_EFFECTS__
	function array(element, params) {
		return new ZodMiniArray({
			type: "array",
			element,
			...normalizeParams(params)
		});
	}
	const ZodMiniObject = /*@__PURE__*/ $constructor("ZodMiniObject", (inst, def) => {
		$ZodObject.init(inst, def);
		ZodMiniType.init(inst, def);
		installLazyProp(inst, "shape", (self) => self._zod.def.shape, false);
	});
	// @__NO_SIDE_EFFECTS__
	function object(shape, params) {
		const def = {
			type: "object",
			shape: shape ?? {},
			...normalizeParams(params)
		};
		return new ZodMiniObject(def);
	}
	const ZodMiniUnion = /*@__PURE__*/ $constructor("ZodMiniUnion", (inst, def) => {
		$ZodUnion.init(inst, def);
		ZodMiniType.init(inst, def);
	});
	// @__NO_SIDE_EFFECTS__
	function union(options, params) {
		return new ZodMiniUnion({
			type: "union",
			options,
			...normalizeParams(params)
		});
	}
	const ZodMiniTuple = /*@__PURE__*/ $constructor("ZodMiniTuple", (inst, def) => {
		$ZodTuple.init(inst, def);
		ZodMiniType.init(inst, def);
	});
	// @__NO_SIDE_EFFECTS__
	function tuple(items, _paramsOrRest, _params) {
		const hasRest = _paramsOrRest instanceof $ZodType;
		const params = hasRest ? _params : _paramsOrRest;
		return new ZodMiniTuple({
			type: "tuple",
			items,
			rest: hasRest ? _paramsOrRest : null,
			...normalizeParams(params)
		});
	}
	const ZodMiniRecord = /*@__PURE__*/ $constructor("ZodMiniRecord", (inst, def) => {
		$ZodRecord.init(inst, def);
		ZodMiniType.init(inst, def);
	});
	// @__NO_SIDE_EFFECTS__
	function record(keyType, valueType, params) {
		if (!valueType || !valueType._zod) return new ZodMiniRecord({
			type: "record",
			keyType: /* @__PURE__ */ string(),
			valueType: keyType,
			...normalizeParams(valueType)
		});
		return new ZodMiniRecord({
			type: "record",
			keyType,
			valueType,
			...normalizeParams(params)
		});
	}
	// @__NO_SIDE_EFFECTS__
	function partialRecord(keyType, valueType, params) {
		return new ZodMiniRecord({
			type: "record",
			keyType,
			valueType,
			...normalizeParams(params),
			partial: true
		});
	}
	const ZodMiniEnum = /*@__PURE__*/ $constructor("ZodMiniEnum", (inst, def) => {
		$ZodEnum.init(inst, def);
		ZodMiniType.init(inst, def);
		inst.options = [...inst._zod.values];
	});
	// @__NO_SIDE_EFFECTS__
	function _enum(values, params) {
		const entries = Array.isArray(values) ? Object.fromEntries(values.map((v) => [v, v])) : values;
		return new ZodMiniEnum({
			type: "enum",
			entries,
			...normalizeParams(params)
		});
	}
	const ZodMiniLiteral = /*@__PURE__*/ $constructor("ZodMiniLiteral", (inst, def) => {
		$ZodLiteral.init(inst, def);
		ZodMiniType.init(inst, def);
	});
	// @__NO_SIDE_EFFECTS__
	function literal(value, params) {
		return new ZodMiniLiteral({
			type: "literal",
			values: Array.isArray(value) ? value : [value],
			...normalizeParams(params)
		});
	}
	const ZodMiniTransform = /*@__PURE__*/ $constructor("ZodMiniTransform", (inst, def) => {
		$ZodTransform.init(inst, def);
		ZodMiniType.init(inst, def);
	});
	// @__NO_SIDE_EFFECTS__
	function transform(fn) {
		return new ZodMiniTransform({
			type: "transform",
			transform: fn
		});
	}
	const ZodMiniOptional = /*@__PURE__*/ $constructor("ZodMiniOptional", (inst, def) => {
		$ZodOptional.init(inst, def);
		ZodMiniType.init(inst, def);
	});
	// @__NO_SIDE_EFFECTS__
	function optional(innerType) {
		return new ZodMiniOptional({
			type: "optional",
			innerType
		});
	}
	const ZodMiniNullable = /*@__PURE__*/ $constructor("ZodMiniNullable", (inst, def) => {
		$ZodNullable.init(inst, def);
		ZodMiniType.init(inst, def);
	});
	// @__NO_SIDE_EFFECTS__
	function nullable(innerType) {
		return new ZodMiniNullable({
			type: "nullable",
			innerType
		});
	}
	const ZodMiniCatch = /*@__PURE__*/ $constructor("ZodMiniCatch", (inst, def) => {
		$ZodCatch.init(inst, def);
		ZodMiniType.init(inst, def);
	});
	// @__NO_SIDE_EFFECTS__
	function _catch(innerType, catchValue) {
		return new ZodMiniCatch({
			type: "catch",
			innerType,
			catchValue: typeof catchValue === "function" ? catchValue : constantCatch(catchValue)
		});
	}
	const ZodMiniPipe = /*@__PURE__*/ $constructor("ZodMiniPipe", (inst, def) => {
		$ZodPipe.init(inst, def);
		ZodMiniType.init(inst, def);
	});
	// @__NO_SIDE_EFFECTS__
	function pipe(in_, out) {
		return new ZodMiniPipe({
			type: "pipe",
			in: in_,
			out
		});
	}
	const ZodMiniCustom = /*@__PURE__*/ $constructor("ZodMiniCustom", (inst, def) => {
		$ZodCustom.init(inst, def);
		ZodMiniType.init(inst, def);
	});
	// @__NO_SIDE_EFFECTS__
	function custom(fn, _params) {
		return _custom(ZodMiniCustom, fn ?? (() => true), _params);
	}
	// @__NO_SIDE_EFFECTS__
	function refine(fn, _params = {}) {
		return _refine(ZodMiniCustom, fn, _params);
	}
	// @__NO_SIDE_EFFECTS__
	function _instanceof(cls, params = {}) {
		const inst = /* @__PURE__ */ custom((data) => data instanceof cls, params);
		inst._zod.bag.Class = cls;
		inst._zod.check = (payload) => {
			if (!(payload.value instanceof cls)) payload.issues.push({
				code: "invalid_type",
				expected: cls.name,
				input: payload.value,
				inst,
				path: [...inst._zod.def.path ?? []]
			});
		};
		return inst;
	}

//#endregion
//#region node_modules/.pnpm/zod@4.6.5/node_modules/zod/v4/mini/coerce.js
	// @__NO_SIDE_EFFECTS__
	function number(params) {
		return _coercedNumber(ZodMiniNumber, params);
	}

//#endregion
//#region src/shared/chess/types.ts
	const COLORS = ["white", "black"];
	const ROLES = [
		"pawn",
		"knight",
		"bishop",
		"rook",
		"queen",
		"king"
	];
	const opposite = (color) => color === "white" ? "black" : "white";

//#endregion
//#region src/shared/chess/pieces.ts
	const ROLE_LETTERS = {
		pawn: "p",
		knight: "n",
		bishop: "b",
		rook: "r",
		queen: "q",
		king: "k"
	};
	const ROLE_BY_LETTER = new Map(ROLES.map((role) => [ROLE_LETTERS[role], role]));
	const colorLetter = (color) => color === "white" ? "w" : "b";
	/** The king counts for nothing: it can't be traded. */
	const PIECE_VALUES = {
		pawn: 1,
		knight: 3,
		bishop: 3,
		rook: 5,
		queen: 9,
		king: 0
	};

//#endregion
//#region src/content/boards/catalog.json
	var catalog_default = {
		boards: [
			{
				"id": "win31",
				"name": "Windows 3.1",
				"light": "#b7b5b5",
				"dark": "#019694"
			},
			{
				"id": "green",
				"name": "Green",
				"light": "#ebecd0",
				"dark": "#739552"
			},
			{
				"id": "dark_wood",
				"name": "Dark Wood",
				"light": "#c3a370",
				"dark": "#7e5736"
			},
			{
				"id": "glass",
				"name": "Glass",
				"light": "#717b8e",
				"dark": "#282e3c"
			},
			{
				"id": "brown",
				"name": "Brown",
				"light": "#edd6b0",
				"dark": "#b88762"
			},
			{
				"id": "icy_sea",
				"name": "Icy Sea",
				"light": "#d4dfe4",
				"dark": "#7fa1b5"
			},
			{
				"id": "newspaper",
				"name": "Newspaper",
				"light": "#cfcdc4",
				"dark": "#a09e98"
			},
			{
				"id": "walnut",
				"name": "Walnut",
				"light": "#ba9e79",
				"dark": "#73533a"
			},
			{
				"id": "sky",
				"name": "Sky",
				"light": "#f0f1f0",
				"dark": "#c4d8e4"
			},
			{
				"id": "lolz",
				"name": "Lolz",
				"light": "#d9e3e4",
				"dark": "#9ba4a3"
			},
			{
				"id": "stone",
				"name": "Stone",
				"light": "#b0aca5",
				"dark": "#4e4c4b"
			},
			{
				"id": "bases",
				"name": "Bases",
				"light": "#efc99e",
				"dark": "#c56e3a"
			},
			{
				"id": "8_bit",
				"name": "8-Bit",
				"light": "#f3f3f4",
				"dark": "#6a9b41"
			},
			{
				"id": "marble",
				"name": "Marble",
				"light": "#c4bda7",
				"dark": "#716c66"
			},
			{
				"id": "purple",
				"name": "Purple",
				"light": "#f0f1f0",
				"dark": "#8476ba"
			},
			{
				"id": "translucent",
				"name": "Translucent",
				"light": "#efefef",
				"dark": "#ababab"
			},
			{
				"id": "metal",
				"name": "Metal",
				"light": "#d7d7d7",
				"dark": "#767675"
			},
			{
				"id": "tournament",
				"name": "Tournament",
				"light": "#e9e9e6",
				"dark": "#32674a"
			},
			{
				"id": "dash",
				"name": "Dash",
				"light": "#ba8e52",
				"dark": "#6a3826"
			},
			{
				"id": "burled_wood",
				"name": "Burled Wood",
				"light": "#e8c39a",
				"dark": "#744025"
			},
			{
				"id": "4fs27",
				"name": "Blue",
				"light": "#f2f6fa",
				"dark": "#5596f2",
				"host": "themes",
				"format": "png"
			},
			{
				"id": "blue",
				"name": "Dark Blue",
				"light": "#eae9d2",
				"dark": "#4b7399"
			},
			{
				"id": "bubblegum",
				"name": "Bubblegum",
				"light": "#fefffe",
				"dark": "#fbd9e1"
			},
			{
				"id": "checkers",
				"name": "Checkers",
				"light": "#c64d52",
				"dark": "#333333"
			},
			{
				"id": "graffiti",
				"name": "Graffiti",
				"light": "#919191",
				"dark": "#a68866"
			},
			{
				"id": "light",
				"name": "Light",
				"light": "#d8d9d8",
				"dark": "#a8a9a8"
			},
			{
				"id": "neon",
				"name": "Neon",
				"light": "#c3c5c5",
				"dark": "#655c58"
			},
			{
				"id": "orange",
				"name": "Orange",
				"light": "#fae4ae",
				"dark": "#d18815"
			},
			{
				"id": "parchment",
				"name": "Parchment",
				"light": "#d5d0b2",
				"dark": "#af955c"
			},
			{
				"id": "g715q",
				"name": "Pink",
				"light": "#f5f0f1",
				"dark": "#ec94a4",
				"host": "themes",
				"format": "png"
			},
			{
				"id": "red",
				"name": "Red",
				"light": "#f5dbc3",
				"dark": "#bb5746"
			},
			{
				"id": "sand",
				"name": "Sand",
				"light": "#d3c4b7",
				"dark": "#c0ab97"
			},
			{
				"id": "tan",
				"name": "Tan",
				"light": "#edcba5",
				"dark": "#d8a46d"
			},
			{
				"id": "6m5lc",
				"name": "Sky and Sea",
				"light": "#90bdcd",
				"dark": "#064b85",
				"host": "themes",
				"format": "jpg"
			},
			{
				"id": "my2xa",
				"name": "Chess the Musical",
				"light": "#d7d4d4",
				"dark": "#807b76",
				"host": "themes",
				"format": "png"
			},
			{
				"id": "ohdxn",
				"name": "Band Class",
				"light": "#ebddb7",
				"dark": "#8e8d90",
				"host": "themes",
				"format": "png"
			},
			{
				"id": "bju81",
				"name": "Naroditsky Memorial",
				"light": "#fbfae9",
				"dark": "#cea861",
				"host": "themes",
				"format": "png"
			},
			{
				"id": "z4m3d",
				"name": "Esports World Cup",
				"light": "#f7f7f7",
				"dark": "#ccaa6c",
				"host": "themes",
				"format": "png"
			}
		],
		pieceSets: [
			{
				"id": "8_bit",
				"name": "8-Bit"
			},
			{
				"id": "neo",
				"name": "Neo"
			},
			{
				"id": "8qetl",
				"name": "Neo Angle",
				"host": "themes"
			},
			{
				"id": "game_room",
				"name": "Game Room"
			},
			{
				"id": "wood",
				"name": "Wood"
			},
			{
				"id": "glass",
				"name": "Glass"
			},
			{
				"id": "gothic",
				"name": "Gothic"
			},
			{
				"id": "classic",
				"name": "Classic"
			},
			{
				"id": "metal",
				"name": "Metal"
			},
			{
				"id": "bases",
				"name": "Bases"
			},
			{
				"id": "neo_wood",
				"name": "Neo-Wood"
			},
			{
				"id": "icy_sea",
				"name": "Icy Sea"
			},
			{
				"id": "club",
				"name": "Club"
			},
			{
				"id": "ocean",
				"name": "Ocean"
			},
			{
				"id": "newspaper",
				"name": "Newspaper"
			},
			{
				"id": "space",
				"name": "Space"
			},
			{
				"id": "cases",
				"name": "Cases"
			},
			{
				"id": "condal",
				"name": "Condal"
			},
			{
				"id": "marble",
				"name": "Marble"
			},
			{
				"id": "book",
				"name": "Book"
			},
			{
				"id": "alpha",
				"name": "Alpha"
			},
			{
				"id": "bubblegum",
				"name": "Bubblegum"
			},
			{
				"id": "dash",
				"name": "Dash"
			},
			{
				"id": "graffiti",
				"name": "Graffiti"
			},
			{
				"id": "light",
				"name": "Light"
			},
			{
				"id": "lolz",
				"name": "Lolz"
			},
			{
				"id": "luca",
				"name": "Luca"
			},
			{
				"id": "maya",
				"name": "Maya"
			},
			{
				"id": "modern",
				"name": "Modern"
			},
			{
				"id": "nature",
				"name": "Nature"
			},
			{
				"id": "neon",
				"name": "Neon"
			},
			{
				"id": "sky",
				"name": "Sky"
			},
			{
				"id": "tigers",
				"name": "Tigers"
			},
			{
				"id": "tournament",
				"name": "Tournament"
			},
			{
				"id": "vintage",
				"name": "Vintage"
			},
			{
				"id": "ca09k",
				"name": "Band Class",
				"host": "themes"
			},
			{
				"id": "3d_wood",
				"name": "3D - Wood"
			},
			{
				"id": "3d_staunton",
				"name": "3D - Staunton"
			},
			{
				"id": "3d_plastic",
				"name": "3D - Plastic"
			},
			{
				"id": "3d_chesskid",
				"name": "3D - ChessKid"
			}
		]
	};

//#endregion
//#region src/content/boards/catalog.ts
/** Hands the board or the pieces back to Lichess and its own pref. */
	const LICHESS = "lichess";
	const HostSchema = optional(_enum(["files", "themes"]));
	const BoardSchema = object({
		id: string(),
		name: string(),
		light: string(),
		dark: string(),
		host: HostSchema,
		format: optional(_enum(["png", "jpg"]))
	});
	const PieceSetSchema = object({
		id: string(),
		name: string(),
		host: HostSchema
	});
	const CatalogSchema = object({
		boards: tuple([BoardSchema], BoardSchema),
		pieceSets: tuple([PieceSetSchema], PieceSetSchema)
	});
	const { boards: BOARDS, pieceSets: PIECE_SETS } = CatalogSchema.parse(catalog_default);
	/** Each piece as its images are named: wp, wn… bk. */
	const PIECE_CODES = COLORS.flatMap((color) => ROLES.map((role) => `${colorLetter(color)}${ROLE_LETTERS[role]}`));
	const boardPath = (id) => `img/boards/${id}.webp`;
	const boardTilePath = (id) => `img/boards/${id}-tile.webp`;
	const piecePath = (setId, code) => `img/pieces/${setId}/${code}.webp`;
	/** The stored pick if it's still on offer (or Lichess's), else the default. */
	function validPick(stored, choices) {
		const onOffer = stored === "lichess" || choices.some((choice) => choice.id === stored);
		return stored !== null && onOffer ? stored : choices[0].id;
	}

//#endregion
//#region src/content/boards/panel.ts
	const TABS = [["cdc", "Extension"], [LICHESS, "Lichess"]];
	const viewOf = (pick) => pick === "lichess" ? LICHESS : "cdc";
	/**
	* Rings the current pick, in its own tab only: while one of our boards is on,
	* Lichess's current board isn't the one the page shows.
	*/
	function markPanel(panel, picker) {
		const current = picker.current();
		setData(panel, "cdcSrcOn", viewOf(current));
		for (const item of queryAll(panel, ".cdc-src-item", HTMLElement)) item.classList.toggle("active", item.dataset.cdcChoice === current);
	}
	function showView(panel, view) {
		setData(panel, "cdcView", view);
		for (const tab of queryAll(panel, ".cdc-src-tabs button", HTMLElement)) tab.classList.toggle("active", tab.dataset.cdcTab === view);
	}
	function tabBar(onTab) {
		const bar = createElement("div", { className: "cdc-src-tabs" });
		for (const [view, label] of TABS) {
			const tab = createElement("button", {
				text: label,
				attrs: {
					type: "button",
					class: "",
					"data-cdc-tab": view
				}
			});
			tab.addEventListener("click", () => onTab(view));
			bar.append(tab);
		}
		return bar;
	}
	function choiceList(picker, onPick) {
		const list = createElement("div", { className: "cdc-src-list" });
		for (const { id, name } of picker.choices) {
			const item = createElement("button", { attrs: {
				type: "button",
				class: "cdc-src-item",
				"data-cdc-choice": id
			} });
			const thumb = createElement("span", { className: "cdc-src-thumb" });
			setStyleProperty(thumb, "background-image", `url('${picker.thumbnail(id)}')`);
			item.append(thumb, createElement("span", {
				className: "cdc-src-name",
				text: name
			}));
			item.addEventListener("click", () => onPick(id));
			list.append(item);
		}
		return list;
	}
	/**
	* Puts the tabs after the panel's title and our choices after them. Snabbdom
	* leaves alone the nodes it didn't create, so ours can sit among Lichess's.
	*/
	function dressPanel(panel, picker, options) {
		const tabs = tabBar((view) => {
			options.onTab(view);
			showView(panel, view);
		});
		panel.querySelector(":scope > .head")?.after(tabs, choiceList(picker, options.onPick));
		markPanel(panel, picker);
		showView(panel, options.view);
	}

//#endregion
//#region src/content/boards/dasher.ts
	function choose(picker, id) {
		picker.choose(id);
		for (const panel of queryAll(document, `#dasher_app .sub.${picker.kind}`, HTMLElement)) markPanel(panel, picker);
	}
	function syncPanels(states) {
		const app = document.getElementById("dasher_app");
		for (const state of states) {
			const panel = app && queryOne(app, `.sub.${state.picker.kind}`, HTMLElement);
			if (!panel) {
				state.open = false;
				continue;
			}
			if (!state.open) state.view = viewOf(state.picker.current());
			state.open = true;
			if (panel.matches(".d2") && !panel.querySelector(":scope > .cdc-src-tabs")) dressPanel(panel, state.picker, {
				view: state.view,
				onTab: (view) => {
					state.view = view;
				},
				onPick: (id) => choose(state.picker, id)
			});
		}
	}
	function onLichessPick(states, target) {
		for (const { picker } of states) {
			const selector = `#dasher_app .sub.${picker.kind}.d2 .list > button`;
			if (closestTo(target, selector, Element) && picker.current() !== "lichess") choose(picker, LICHESS);
		}
	}
	/**
	* The menu is drawn when first opened, then again on every click in it. It's
	* watched rather than polled, so a panel never shows without its tabs.
	*/
	function watchDasher(pickers) {
		const states = pickers.map((picker) => ({
			picker,
			open: false,
			view: "cdc"
		}));
		document.addEventListener("click", (event) => onLichessPick(states, event.target));
		onDomReady(() => {
			const parent = document.getElementById("dasher_app")?.parentElement;
			if (!parent) return;
			new MutationObserver(() => syncPanels(states)).observe(parent, {
				childList: true,
				subtree: true
			});
			syncPanels(states);
		});
	}

//#endregion
//#region src/shared/json.ts
/** Parses JSON and validates it, or returns null if either step fails. */
	function parseJson(text, schema) {
		if (text === null || text === void 0) return null;
		let value;
		try {
			value = JSON.parse(text);
		} catch {
			return null;
		}
		const result = schema.safeParse(value);
		return result.success ? result.data : null;
	}

//#endregion
//#region src/shared/storage.ts
	const StorageKey = {
		board: "cdc-board",
		pieces: "cdc-pieces",
		coach: "cdc-coach",
		boardZoom: "cdc-board-zoom",
		ratingChartRange: "cdc-rchart:range",
		reviewCache: (gameId, positions, version) => `cdc-review:${gameId}:${positions}:v${version}`
	};
	const SessionKey = {
		lateReload: "cdc-late-reload",
		gameStarted: (gameId) => `cdc-started:${gameId}`
	};
	const area = (name) => name === "local" ? localStorage : sessionStorage;
	/**
	* The stored value if it passes `schema`, else null. A blocked storage throws,
	* as it did in the original: since its writes are lost too, reading it as
	* missing would make a once-per-game check pass on every load. So read before
	* changing the page.
	*/
	function readStored(key, schema, from = "local") {
		const result = schema.safeParse(area(from).getItem(key));
		return result.success ? result.data : null;
	}
	/** Stores a value. A full or blocked storage loses the value without throwing. */
	function writeStored(key, value, to = "local") {
		try {
			area(to).setItem(key, String(value));
		} catch {}
	}
	/** Removes a value. As with a write, a blocked storage doesn't throw. */
	function removeStored(key, from = "local") {
		try {
			area(from).removeItem(key);
		} catch {}
	}

//#endregion
//#region src/content/boards/appearance.ts
	const cssUrl = (path) => `url('${extensionUrl(path)}')`;
	/** The board's CSS variables, null for each one to remove. */
	function boardVariables(id) {
		const board = BOARDS.find((entry) => entry.id === id);
		if (board === void 0 || board.id === "green") return {
			"--cdc-board-img": null,
			"--cdc-sq-light": null,
			"--cdc-sq-dark": null
		};
		return {
			"--cdc-board-img": cssUrl(boardPath(board.id)),
			"--cdc-sq-light": board.light,
			"--cdc-sq-dark": board.dark
		};
	}
	/** A CSS variable per piece, null for each one to remove. */
	function pieceVariables(id) {
		const set = PIECE_SETS.find((entry) => entry.id === id);
		const custom = set === void 0 || set.id === "neo" ? void 0 : set;
		return Object.fromEntries(PIECE_CODES.map((code) => [`--cdc-piece-${code}`, custom === void 0 ? null : cssUrl(piecePath(custom.id, code))]));
	}
	function applyVariables(variables) {
		const root = document.documentElement;
		for (const [name, value] of Object.entries(variables)) setStyleProperty(root, name, value);
	}
	function applyBoard(id) {
		setData(document.documentElement, "cdcBoard", id);
		applyVariables(boardVariables(id));
	}
	function applyPieces(id) {
		setData(document.documentElement, "cdcPieces", id);
		applyVariables(pieceVariables(id));
	}

//#endregion
//#region src/content/boards/pickers.ts
	function createPicker({ kind, storageKey, choices, thumbnail, apply }) {
		let current = validPick(readStored(storageKey, string()), choices);
		apply(current);
		return {
			kind,
			choices,
			thumbnail,
			current: () => current,
			choose: (id) => {
				current = id;
				apply(id);
				writeStored(storageKey, id);
			}
		};
	}
	/** Reads both picks and puts them on <html>. */
	function createPickers() {
		return [createPicker({
			kind: "board",
			storageKey: StorageKey.board,
			choices: BOARDS,
			thumbnail: (id) => extensionUrl(boardTilePath(id)),
			apply: applyBoard
		}), createPicker({
			kind: "piece",
			storageKey: StorageKey.pieces,
			choices: PIECE_SETS,
			thumbnail: (id) => extensionUrl(piecePath(id, "wn")),
			apply: applyPieces
		})];
	}

//#endregion
//#region src/content/boards/index.ts
	const boards = {
		name: "boards",
		start: () => {
			setData(document.documentElement, "cdcAssets", extensionUrl(""));
			watchDasher(createPickers());
		}
	};

//#endregion
//#region src/content/bootstrap/fonts.ts
	const FAMILIES = [
		"Roboto",
		"Noto Sans",
		"CDC Sans"
	];
	const WEIGHTS = [
		["100 450", [
			"Segoe UI",
			"SegoeUI",
			"Helvetica Neue",
			"Roboto"
		]],
		["451 650", [
			"Segoe UI Semibold",
			"SegoeUI-Semibold",
			"HelveticaNeue-Medium",
			"Roboto Medium"
		]],
		["651 850", [
			"Segoe UI Bold",
			"SegoeUI-Bold",
			"HelveticaNeue-Bold",
			"Roboto Bold"
		]],
		["851 1000", [
			"Segoe UI Black",
			"SegoeUI-Black",
			"HelveticaNeue-Bold",
			"Roboto Black"
		]]
	];
	function fontFaces() {
		return FAMILIES.flatMap((family) => WEIGHTS.map(([range, sources]) => {
			return `@font-face{font-family:'${family}';font-weight:${range};src:${sources.map((name) => `local('${name}')`).join(", ")}}`;
		})).join("");
	}
	const fonts = {
		name: "fonts",
		start: () => onDomReady(() => {
			document.head.append(createElement("style", {
				id: "cdc-fonts",
				text: fontFaces()
			}));
		})
	};

//#endregion
//#region src/content/sidebar/donate.ts
	function addDonateItem() {
		const nav = document.getElementById("topnav");
		const patron = nav && queryOne(nav, "a.community-patron", HTMLAnchorElement);
		if (!nav || !patron || document.getElementById("cdc-donate")) return;
		const item = createElement("a", {
			id: "cdc-donate",
			text: patron.textContent.trim()
		});
		item.href = patron.href;
		nav.after(item);
	}
	const donate = {
		name: "donate",
		start: () => onDomReady(addDonateItem)
	};

//#endregion
//#region src/shared/coach.ts
/** The Game Review's coaches: one portrait each, in public/img/coaches. */
	const COACH_COUNT = 4;
	const CoachIdSchema = number().check(int(), _gte(1), _lte(4));
	/** The coach's expression for a move, set by its verdict (see the review's move classes). */
	const CoachMoodSchema = _enum([
		"neutral",
		"happy",
		"delight",
		"doubt",
		"worry",
		"shock"
	]);
	const COACH_MOODS = CoachMoodSchema.options;
	/**
	* The coach kept in storage, or one picked at random and kept the first time.
	* The review and the practice drills read the same key, so both show the same coach.
	*/
	function pickCoach() {
		const stored = readStored(StorageKey.coach, CoachIdSchema);
		if (stored !== null) return stored;
		const coach = 1 + Math.floor(Math.random() * 4);
		writeStored(StorageKey.coach, coach);
		return coach;
	}

//#endregion
//#region src/content/bootstrap/coach-choice.ts
	const coachChoice = {
		name: "coach choice",
		start: () => setData(document.documentElement, "cdcCoach", String(pickCoach()))
	};

//#endregion
//#region src/content/pages/fide.ts
	const ROWS_PER_PAGE = 30;
	/** How many rows the pages before this one hold, or null on a first page. */
	function fideRankOffset(pathname, search) {
		if (!/\/fide(\/federation)?$/.test(pathname)) return null;
		const page = Number(new URLSearchParams(search).get("page"));
		return page > 1 ? (page - 1) * ROWS_PER_PAGE : null;
	}
	const fideOffset = {
		name: "FIDE rank offset",
		start: () => {
			const offset = fideRankOffset(location.pathname, location.search);
			if (offset === null) return;
			const root = document.documentElement;
			setData(root, "cdcFideSkip", String(offset));
			setStyleProperty(root, "--cdc-fide-skip", String(offset));
		}
	};

//#endregion
//#region src/shared/text.ts
/** The text, or undefined when it's empty or missing: for `??` fallbacks that skip ''. */
	const nonEmpty = (text) => text === null || text === "" ? void 0 : text;

//#endregion
//#region src/content/sync-loop.ts
	const INTERVAL_MS = 250;
	const tasks = [];
	const failed = /* @__PURE__ */ new Set();
	/** Runs `run` on every tick of the sync loop, after the tasks registered before it. */
	function onEveryTick(name, run) {
		tasks.push({
			name,
			run
		});
	}
	function tick() {
		for (const task of tasks) try {
			task.run();
		} catch (error) {
			if (!failed.has(task.name)) console.error(`[LichessDotCom] ${task.name} failed`, error);
			failed.add(task.name);
		}
	}
	function startSyncLoop() {
		setInterval(tick, INTERVAL_MS);
	}

//#endregion
//#region src/content/layout/marks.ts
	const NAV_LINKS = {
		bots: ["/player/bots"],
		broadcast: ["/broadcast/calendar"],
		puzzles: ["/training/themes"],
		account: ["/account/kid"],
		about: ["/thanks"],
		variants: ["/variant/chess960"],
		streamers: ["/streamer/edit"]
	};
	const hrefIn = (element, selector) => element.querySelector(selector)?.getAttribute("href");
	const iconIn = (element, selector) => queryOne(element, selector, HTMLElement)?.dataset.icon;
	const navsOf = (menu) => Object.entries(NAV_LINKS).filter(([, ends]) => ends.some((end) => menu.querySelector(`a[href$='${end}']`))).map(([nav]) => nav).join(" ");
	const PLAYER_ROWS = ":scope > table.slist-invert > tbody > tr > td:first-child > .user-link, :scope > table.slist-invert > tbody > tr:only-child > td:only-child";
	const MARKS = [
		{
			selector: ".subnav",
			key: "cdcNav",
			read: navsOf
		},
		{
			selector: "main.page-menu",
			key: "cdcNavActive",
			read: (main) => hrefIn(main, ".subnav a.active")
		},
		{
			selector: "main.round .game__meta",
			key: "cdcIcon",
			read: (meta) => iconIn(meta, ".game__meta__infos")
		},
		{
			selector: ".community .user-top, .tournament-leaderboards__item",
			key: "cdcIcon",
			read: (board) => iconIn(board, ":scope > h2")
		},
		{
			selector: ".tournament-shields__item",
			key: "cdcHref",
			read: (shield) => hrefIn(shield, ":scope > h2 > a")
		},
		{
			selector: "main.forum .categs tr",
			key: "cdcHref",
			read: (row) => hrefIn(row, "h2 a")
		},
		{
			selector: "main.forum-categ",
			key: "cdcHref",
			read: (main) => hrefIn(main, "td.subject a")
		},
		{
			selector: "main.forum:is(.forum-categ, .forum-topic)",
			key: "cdcBack",
			read: (main) => hrefIn(main, ".box__top h1 > a")
		},
		{
			selector: "main.search",
			key: "cdcSearch",
			read: (main) => main.querySelector(":scope > .box__top form.search")?.getAttribute("action")
		},
		{
			selector: "main.box.page-small",
			key: "cdcList",
			read: (main) => main.querySelector(PLAYER_ROWS) ? "players" : null
		}
	];
	function syncMarks() {
		for (const { selector, key, read } of MARKS) for (const element of queryAll(document, selector, HTMLElement)) setData(element, key, nonEmpty(read(element)) ?? null);
	}
	function markWhileParsing() {
		const parsing = new MutationObserver(syncMarks);
		parsing.observe(document, {
			childList: true,
			subtree: true
		});
		document.addEventListener("DOMContentLoaded", () => {
			parsing.disconnect();
			syncMarks();
		}, { once: true });
	}
	const marks = {
		name: "marks",
		start: () => {
			if (isParsing()) markWhileParsing();
			else syncMarks();
			onEveryTick("marks", syncMarks);
		}
	};

//#endregion
//#region src/shared/frame.ts
/**
	* Wraps `task` so it runs at most once per animation frame, however many
	* times it is asked for in between.
	*/
	function oncePerFrame(task) {
		let queued = false;
		return () => {
			if (queued) return;
			queued = true;
			requestAnimationFrame(() => {
				queued = false;
				task();
			});
		};
	}

//#endregion
//#region src/content/layout/has-flags.ts
	const CLOCK_EXTRAS = ":is(.berserked, .go-berserk, .moretime, .tour-rank, .rclock-turn__text)";
	const FLAGS = {
		round: "main.round",
		"round-chat": "main.round .mchat",
		"tv-channels": "main.round.tv-single > .round__side > .subnav",
		pocket: "main.round .pocket",
		"clock-extras-top": `main.round .rclock-top > ${CLOCK_EXTRAS}`,
		"clock-extras-bottom": `main.round .rclock-bottom > ${CLOCK_EXTRAS}`,
		analyse: "main.analyse",
		"analyse-chat": "main.analyse > .mchat",
		"analyse-players": "main.analyse > .cdc-player",
		"analyse-clock": "main.analyse .analyse__clock",
		"analyse-white": "main.analyse .analyse__board > .orientation-white",
		"analyse-black": "main.analyse .analyse__board > .orientation-black",
		"round-black": "main.round .round__app__board > .orientation-black",
		"relay-tour": "main.analyse.has-relay-tour",
		"study-side": "main.analyse > .analyse__side > .study__side",
		practice: "main.analyse .practice__side",
		"practice-box": "main.analyse .practice-box",
		"keyboard-move": "main.analyse .keyboard-move",
		puzzle: "main.puzzle",
		"puzzle-keyboard": "main.puzzle > .keyboard-move",
		storm: "main > .storm",
		"storm-play": "main > .storm--play",
		swiss: "main.swiss",
		lobby: "main.lobby",
		"coach-list": "main.coach-list",
		"team-list": "main.team-list",
		"user-show": "main.page-menu .user-show",
		"perf-stat": "main.page-menu > .perf-stat",
		"puzzle-themes": "main.page-menu .puzzle-themes"
	};
	/** The words for what `root` holds, space-separated. */
	function presentFlags(root) {
		return Object.entries(FLAGS).filter(([, selector]) => root.querySelector(selector)).map(([flag]) => flag).join(" ");
	}
	function syncHasFlags() {
		setData(document.documentElement, "cdcHas", presentFlags(document));
	}
	const isBoardOrClock = (record) => closestTo(record.target, "cg-container, .time", Element) !== null;
	const hasFlags = {
		name: "has flags",
		start: () => {
			const syncSoon = oncePerFrame(syncHasFlags);
			new MutationObserver((records) => {
				if (!records.every(isBoardOrClock)) syncSoon();
			}).observe(document, {
				childList: true,
				subtree: true,
				attributes: true,
				attributeFilter: ["class"]
			});
			syncHasFlags();
		}
	};

//#endregion
//#region src/shared/page-init-data.ts
	const ID = "page-init-data";
	let node = null;
	let readers = null;
	function watch$1() {
		readers = [];
		const observer = new MutationObserver(() => {
			node = document.getElementById(ID);
			if (node) observer.disconnect();
		});
		observer.observe(document, {
			childList: true,
			subtree: true
		});
		document.addEventListener("DOMContentLoaded", () => {
			observer.disconnect();
			const text = node?.textContent ?? null;
			node = null;
			const waiting = readers ?? [];
			readers = null;
			for (const read of waiting) try {
				read(text);
			} catch (error) {
				console.error("[LichessDotCom] page init data reader failed", error);
			}
		}, { once: true });
	}
	/**
	* Hands the page's init data to `read` once the page is parsed, or right away
	* (whatever is still in the document) when it already is.
	*/
	function readPageInitData(read) {
		if (!isParsing()) {
			read(document.getElementById(ID)?.textContent ?? null);
			return;
		}
		if (readers === null) watch$1();
		readers?.push(read);
	}

//#endregion
//#region src/content/game/ai-players.ts
	const AI_RATINGS = [
		800,
		1100,
		1400,
		1700,
		2e3,
		2300,
		2700,
		3e3
	];
	const ComputerSchema = object({
		color: _enum(COLORS),
		ai: number$1()
	});
	const GameDataSchema = object({
		player: unknown(),
		opponent: unknown()
	});
	const PageInitSchema = union([object({ data: GameDataSchema }), object({ cfg: object({ data: GameDataSchema }) })]);
	/** The computer's seats in a game page's init data, with their level's rating. */
	function readComputerPlayers(initData) {
		const init = parseJson(initData, PageInitSchema);
		if (!init) return [];
		const { player, opponent } = "data" in init ? init.data : init.cfg.data;
		return [player, opponent].flatMap((seat) => {
			const computer = ComputerSchema.safeParse(seat);
			if (!computer.success || computer.data.ai === 0) return [];
			const { color, ai } = computer.data;
			return [{
				color,
				rating: AI_RATINGS[ai - 1]
			}];
		});
	}
	const ratings = /* @__PURE__ */ new Map();
	/** The rating shown for each color the computer plays, in the order of the game's data. */
	const computerRatings = () => ratings;
	function markComputerPlayers(players) {
		if (players.length === 0) return;
		const root = document.documentElement;
		setData(root, "cdcAi", players.map(({ color }) => color).join(" "));
		for (const { color, rating } of players) {
			if (rating === void 0) continue;
			ratings.set(color, String(rating));
			setStyleProperty(root, `--cdc-ai-${color}`, `"${rating}"`);
		}
	}
	const aiPlayers = {
		name: "computer players",
		start: () => {
			if (!isParsing()) return;
			readPageInitData((text) => markComputerPlayers(readComputerPlayers(text)));
		}
	};

//#endregion
//#region src/content/layout/board-zoom.ts
	const FULL = 100;
	const StoredZoomSchema = pipe(string(), number());
	function setZoom(zoom) {
		setStyleProperty(document.documentElement, "--cdc-zoom", zoom >= FULL ? null : String(zoom));
	}
	function followDrag() {
		const zoom = Number.parseInt(document.body.style.getPropertyValue("---zoom"), 10);
		if (!(zoom >= 0)) return;
		setZoom(zoom);
		if (zoom >= FULL) removeStored(StorageKey.boardZoom);
		else writeStored(StorageKey.boardZoom, zoom);
		window.dispatchEvent(new Event("resize"));
	}
	let drag = null;
	function startDrag(event) {
		if (drag || !closestTo(event.target, "cg-resize", Element)) return;
		const current = getComputedStyle(document.documentElement).getPropertyValue("--cdc-zoom");
		document.body.style.setProperty("---zoom", current === "" ? String(FULL) : current);
		const observer = new MutationObserver(followDrag);
		observer.observe(document.body, {
			attributes: true,
			attributeFilter: ["style"]
		});
		drag = observer;
		const end = event.type === "touchstart" ? "touchend" : "mouseup";
		document.addEventListener(end, () => {
			observer.disconnect();
			drag = null;
		}, { once: true });
	}
	const boardZoom = {
		name: "board zoom",
		start: () => {
			const saved = readStored(StorageKey.boardZoom, StoredZoomSchema);
			if (saved !== null) setZoom(saved);
			document.addEventListener("mousedown", startDrag, true);
			document.addEventListener("touchstart", startDrag, {
				capture: true,
				passive: true
			});
		}
	};

//#endregion
//#region src/shared/sounds.ts
	const SoundNameSchema = _enum([
		"move-self",
		"move-opponent",
		"move-check",
		"capture",
		"castle",
		"promote",
		"premove",
		"illegal",
		"notify",
		"tenseconds",
		"game-start",
		"game-end"
	]);
	const SOUND_NAMES = SoundNameSchema.options;

//#endregion
//#region src/shared/protocol.ts
	const PageReadySchema = object({ type: literal("cdc:page-ready") });
	const SoundsSchema = object({
		type: literal("cdc:sounds"),
		sounds: partialRecord(SoundNameSchema, _instanceof(ArrayBuffer))
	});
	const CoachStateSchema = object({
		type: literal("cdc:coach"),
		coach: int(),
		mood: CoachMoodSchema,
		talking: boolean()
	});
	function listen(schema, handler) {
		const listener = (event) => {
			if (event.source !== window) return;
			const result = schema.safeParse(event.data);
			if (result.success) handler(result.data);
		};
		window.addEventListener("message", listener);
		return () => window.removeEventListener("message", listener);
	}
	function post(message) {
		window.postMessage(message, location.origin);
	}
	const onPageReady = (handler) => listen(PageReadySchema, handler);
	/** Content → page: the bundled sounds' bytes, which only the content script can read. */
	const postSounds = (sounds) => post({
		type: "cdc:sounds",
		sounds
	});
	const onCoachState = (handler) => listen(CoachStateSchema, ({ coach, mood, talking }) => handler({
		coach,
		mood,
		talking
	}));

//#endregion
//#region src/content/sounds/load.ts
	async function loadSound(name) {
		try {
			return [name, await (await fetch(extensionUrl(`sounds/${name}.mp3`))).arrayBuffer()];
		} catch {
			return null;
		}
	}
	/** Every sound that could be read, by name. */
	async function loadSounds() {
		const sounds = {};
		for (const loaded of await Promise.all(SOUND_NAMES.map(loadSound))) if (loaded) sounds[loaded[0]] = loaded[1];
		return sounds;
	}

//#endregion
//#region src/content/sounds/index.ts
	async function shareSounds() {
		let loaded = null;
		onPageReady(() => {
			if (loaded) postSounds(loaded);
		});
		loaded = await loadSounds();
		postSounds(loaded);
	}
	const sounds = {
		name: "sounds",
		start: () => void shareSounds()
	};

//#endregion
//#region src/content/layout/controls-height.ts
	function syncControlsHeight() {
		const main = queryOne(document, "main.round, main.analyse", HTMLElement);
		if (!main) return;
		const controls = main.querySelector(".rcontrols, .analyse__controls");
		const height = controls ? Math.ceil(controls.getBoundingClientRect().height) : 0;
		setStyleProperty(main, "--cdc-controls-h", `${height}px`);
	}
	const controlsHeight = {
		name: "controls height",
		start: () => onEveryTick("controls height", syncControlsHeight)
	};

//#endregion
//#region src/shared/chessground.ts
/** The side at the bottom of a board's `.cg-wrap`. */
	const wrapOrientation = (wrap) => wrap.classList.contains("orientation-black") ? "black" : "white";
	/** The piece a `piece` element shows, or null for one that isn't on the board. */
	function pieceOf(element) {
		const { classList } = element;
		if (classList.contains("ghost") || classList.contains("fading")) return null;
		const color = COLORS.find((name) => classList.contains(name));
		const role = ROLES.find((name) => classList.contains(name));
		return color && role ? {
			color,
			role
		} : null;
	}

//#endregion
//#region src/shared/owned-element.ts
/**
	* Keeps one element of ours at the end of a Lichess container, built again
	* when Lichess replaces the container (a new page, a redrawn board).
	*/
	function createOwnedElement(build) {
		let current = null;
		return (parent) => {
			if (current?.parentNode === parent) return {
				element: current,
				isNew: false
			};
			current = build();
			parent.append(current);
			return {
				element: current,
				isNew: true
			};
		};
	}

//#endregion
//#region src/content/analysis/player-bar.ts
	function userParts(link) {
		const rating = link.querySelector(".rating")?.textContent.replace(/[()\s]/g, "");
		const change = link.querySelector("good, bad");
		for (const extra of link.querySelectorAll(".rating, good, bad")) extra.remove();
		for (const node of link.childNodes) if (node instanceof Text) node.data = node.data.trim();
		const parts = [link];
		if (rating) parts.push(createCustomElement("rating", { text: rating }));
		if (change) parts.push(change);
		return parts;
	}
	/** Fills `bar` from a player of the game info (`.game__meta__players .player`). */
	function fillPlayerBar(bar, source) {
		const copy = (source && queryOne(source, "a.user-link", HTMLAnchorElement))?.cloneNode(true);
		if (copy instanceof HTMLAnchorElement) {
			bar.replaceChildren(...userParts(copy));
			return;
		}
		bar.replaceChildren(createCustomElement("name", { text: source?.textContent.trim() ?? "" }));
	}

//#endregion
//#region src/content/analysis/players.ts
/** A sync task keeping the two bars in step with the game info and the board's orientation. */
	function createPlayersSync() {
		const ownTopBar = createOwnedElement(() => createElement("div", { className: "cdc-player cdc-player--top" }));
		const ownBottomBar = createOwnedElement(() => createElement("div", { className: "cdc-player cdc-player--bottom" }));
		let lastKey = "";
		return () => {
			const main = queryOne(document, "main.analyse", HTMLElement);
			const wrap = main && queryOne(main, ".analyse__board > .cg-wrap", Element);
			const meta = main && queryOne(main, ".game__meta__players", Element);
			if (!main || !wrap || !meta || main.querySelector(".practice__side")) return;
			const topBar = ownTopBar(main);
			const bottomBar = ownBottomBar(main);
			if (topBar.isNew || bottomBar.isNew) lastKey = "";
			const bottomColor = wrapOrientation(wrap);
			const key = bottomColor + meta.innerHTML;
			if (key === lastKey) return;
			lastKey = key;
			fillPlayerBar(topBar.element, meta.querySelector(`.player.${opposite(bottomColor)}`));
			fillPlayerBar(bottomBar.element, meta.querySelector(`.player.${bottomColor}`));
		};
	}
	const analysisPlayers = {
		name: "analysis players",
		start: () => onEveryTick("analysis players", createPlayersSync())
	};

//#endregion
//#region src/shared/html.ts
	const ENTITIES = {
		"&": "&amp;",
		"<": "&lt;",
		">": "&gt;",
		"\"": "&quot;",
		"'": "&#39;"
	};
	function escapeHtml(value) {
		return value.replace(/[&<>"']/g, (char) => ENTITIES[char] ?? char);
	}
	var SafeHtml = class {
		#markup;
		constructor(markup) {
			this.#markup = markup;
		}
		get value() {
			return this.#markup;
		}
		toString() {
			return this.#markup;
		}
	};
	function render(value) {
		if (value instanceof SafeHtml) return value.value;
		if (typeof value === "string") return escapeHtml(value);
		if (typeof value === "number") return String(value);
		if (value === false || value === null || value === void 0) return "";
		return value.map(render).join("");
	}
	function html(strings, ...values) {
		let out = strings[0] ?? "";
		for (const [i, value] of values.entries()) out += render(value) + (strings[i + 1] ?? "");
		return new SafeHtml(out);
	}
	/** Markup that is known to be safe: a constant, never user or page data. */
	const trustedHtml = (markup) => new SafeHtml(markup);
	function setHtml(element, markup) {
		element.innerHTML = markup.value;
	}

//#endregion
//#region src/content/game/material.ts
	const CAPTURABLE_ROLES = [
		"pawn",
		"knight",
		"bishop",
		"rook",
		"queen"
	];
	const START = {
		pawn: 8,
		knight: 2,
		bishop: 2,
		rook: 2,
		queen: 1
	};
	const VARIANT_START = /* @__PURE__ */ new Map([["racingKings", {
		white: {
			...START,
			pawn: 0
		},
		black: {
			...START,
			pawn: 0
		}
	}], ["horde", {
		white: {
			pawn: 36,
			knight: 0,
			bishop: 0,
			rook: 0,
			queen: 0
		},
		black: START
	}]]);
	function countArmy(pieces, color) {
		const army = {
			pawn: 0,
			knight: 0,
			bishop: 0,
			rook: 0,
			queen: 0
		};
		for (const piece of pieces) if (piece.color === color) army[piece.role] += 1;
		return army;
	}
	function countMissing(start, onBoard) {
		const missing = { ...start };
		for (const role of CAPTURABLE_ROLES) missing[role] = Math.max(0, start[role] - onBoard[role]);
		return missing;
	}
	const materialOf = (army) => CAPTURABLE_ROLES.reduce((sum, role) => sum + army[role] * PIECE_VALUES[role], 0);
	function group$1(pieceUrl, count) {
		const piece = html`<img src="${pieceUrl}" alt="" draggable="false">`;
		return html`<div class="cdc-captured__group">${Array.from({ length: count }, () => piece)}</div>`;
	}
	function rowMarkup({ color, missing, lead, checks, piecesUrl }) {
		const pieceUrl = (role) => `${piecesUrl}${colorLetter(color)}${ROLE_LETTERS[role]}.webp`;
		const groups = CAPTURABLE_ROLES.filter((role) => missing[role] > 0).map((role) => group$1(pieceUrl(role), missing[role]));
		const kings = checks > 0 && group$1(pieceUrl("king"), checks);
		const score = lead > 0 && html`<span class="cdc-captured__score">+${lead}</span>`;
		return html`${groups}${kings}${score}`;
	}
	/** Both bars' captured pieces: each shows the pieces of the other color that are gone. */
	function capturedMarkup(input) {
		if (input.variant === "crazyhouse") return {
			top: html``,
			bottom: html``
		};
		const { pieces, bottom, variant, checks, piecesUrl } = input;
		const top = opposite(bottom);
		const armies = {
			white: countArmy(pieces, "white"),
			black: countArmy(pieces, "black")
		};
		const row = (color, lead, given) => {
			return rowMarkup({
				color,
				missing: countMissing(VARIANT_START.get(variant ?? "")?.[color] ?? START, armies[color]),
				lead,
				checks: given,
				piecesUrl
			});
		};
		const topMaterial = materialOf(armies[top]);
		const bottomMaterial = materialOf(armies[bottom]);
		return {
			top: row(bottom, topMaterial - bottomMaterial, checks.top),
			bottom: row(top, bottomMaterial - topMaterial, checks.bottom)
		};
	}

//#endregion
//#region src/content/game/captured.ts
	function readPieces(board) {
		const pieces = [];
		for (const element of board.querySelectorAll("piece")) {
			const piece = pieceOf(element);
			if (!piece) continue;
			const role = CAPTURABLE_ROLES.find((name) => name === piece.role);
			if (role) pieces.push({
				color: piece.color,
				role
			});
		}
		return pieces;
	}
	function readChecks(main) {
		const count = (side) => main.querySelectorAll(`.material-${side} mpiece.king`).length;
		return {
			top: count("top"),
			bottom: count("bottom")
		};
	}
	function readVariant(main) {
		const classes = queryOne(main, ".round__app", HTMLElement)?.className ?? main.className;
		return /\bvariant-(\w+)/.exec(classes)?.[1];
	}
	/** A sync task drawing the captured pieces, with the Neo pieces at `piecesUrl`. */
	function createCapturedSync(piecesUrl) {
		const ownTopRow = createOwnedElement(() => createElement("div", { className: "cdc-captured cdc-captured--top" }));
		const ownBottomRow = createOwnedElement(() => createElement("div", { className: "cdc-captured cdc-captured--bottom" }));
		let lastKey = "";
		return () => {
			const main = queryOne(document, "main.round, main.analyse", HTMLElement);
			const wrap = main && queryOne(main, ".round__app__board .cg-wrap, .analyse__board > .cg-wrap", Element);
			const board = wrap?.querySelector("cg-board");
			if (!main || !wrap || !board) return;
			if (main.matches(".analyse") && !main.querySelector(":scope > .cdc-player")) return;
			const variant = readVariant(main);
			const bottomColor = wrapOrientation(wrap);
			const checks = variant === "threeCheck" ? readChecks(main) : {
				top: 0,
				bottom: 0
			};
			const markup = capturedMarkup({
				pieces: readPieces(board),
				bottom: bottomColor,
				variant,
				checks,
				piecesUrl
			});
			const topRow = ownTopRow(main);
			const bottomRow = ownBottomRow(main);
			if (topRow.isNew || bottomRow.isNew) lastKey = "";
			const key = `${markup.top.value}|${markup.bottom.value}`;
			if (key === lastKey) return;
			lastKey = key;
			setHtml(topRow.element, markup.top);
			setHtml(bottomRow.element, markup.bottom);
		};
	}
	const capturedPieces = {
		name: "captured pieces",
		start: () => onEveryTick("captured pieces", createCapturedSync(extensionUrl("img/pieces/neo/")))
	};

//#endregion
//#region src/content/game/board-tools.ts
	const HOVER = "cdc-board-tools--hover";
	const BUTTON = "cdc-board-tools__btn";
	function toolButton(name, key) {
		const button = createElement("button", { attrs: {
			type: "button",
			class: `${BUTTON} ${BUTTON}--${name}`
		} });
		button.addEventListener("click", () => button.dispatchEvent(new KeyboardEvent("keypress", {
			key,
			bubbles: true
		})));
		return button;
	}
	function buildTools() {
		const root = createElement("div", { className: "cdc-board-tools" });
		root.append(toolButton("menu", "h"), toolButton("flip", "f"));
		return root;
	}
	function setTip(button, label) {
		if (!button || !label || button.dataset.cdcTip === label) return;
		setData(button, "cdcTip", label);
		button.setAttribute("aria-label", label);
	}
	const ownTools = createOwnedElement(buildTools);
	/** The tools built last, for the pointer handlers. */
	let tools = null;
	function syncBoardTools() {
		const main = queryOne(document, "main.round", HTMLElement);
		if (!main) return;
		tools = ownTools(main).element;
		const menu = queryOne(tools, `.${BUTTON}--menu`, HTMLButtonElement);
		const lichessMenu = queryOne(main, ".board-menu-toggle-btn", HTMLElement);
		setTip(menu, nonEmpty(lichessMenu?.title) ?? lichessMenu?.dataset.cdcTip);
		setTip(queryOne(tools, `.${BUTTON}--flip`, HTMLButtonElement), document.documentElement.dataset.cdcFlipLabel);
		menu?.classList.toggle(`${BUTTON}--on`, lichessMenu?.classList.contains("active") ?? false);
	}
	function onMouseOver(event) {
		if (!tools?.isConnected) return;
		const target = closestTo(event.target, "main.round :is(.round__app__board, .cdc-board-tools)", Element);
		tools.classList.toggle(HOVER, target !== null);
	}
	function onMouseOut(event) {
		if (!event.relatedTarget) tools?.classList.toggle(HOVER, false);
	}
	const boardTools = {
		name: "board tools",
		start: () => {
			onEveryTick("board tools", syncBoardTools);
			document.addEventListener("mouseover", onMouseOver);
			document.addEventListener("mouseout", onMouseOut);
		}
	};

//#endregion
//#region src/content/game/clock-times.ts
	const ClockSchema = object({
		initial: number$1(),
		increment: number$1()
	});
	const GameExportSchema = object({
		clock: optional(ClockSchema),
		clocks: optional(array(number$1()))
	});
	/** The centiseconds spent on each move. */
	function spentTimes({ clock, clocks = [] }) {
		const initial = (clock?.initial ?? 0) * 100;
		const increment = (clock?.increment ?? 0) * 100;
		return clocks.map((left, i) => Math.max(0, i < 2 ? initial - left : (clocks[i - 2] ?? 0) + increment - left));
	}
	/** "4.2s" under a minute, "1:05" from there. */
	function formatSpent(centiseconds) {
		const seconds = centiseconds / 100;
		if (seconds < 60) return `${seconds.toFixed(1)}s`;
		return `${Math.floor(seconds / 60)}:${String(Math.floor(seconds % 60)).padStart(2, "0")}`;
	}

//#endregion
//#region src/content/game/game-id.ts
/** The game id a path starts with (`/abcd1234/black`), if any. */
	const gameIdFrom = (path) => /^\/([A-Za-z0-9]{8})/.exec(path)?.[1] ?? null;

//#endregion
//#region src/content/game/move-times.ts
	const MAX_TRIES = 5;
	const RETRY_MS = 1e3;
	async function fetchExport(id) {
		try {
			const url = `/game/export/${id}?moves=false&clocks=true&evals=false&opening=false`;
			const response = await fetch(url, { headers: { Accept: "application/json" } });
			if (!response.ok) return null;
			const body = await response.json();
			const result = GameExportSchema.safeParse(body);
			return result.success ? result.data : null;
		} catch {
			return null;
		}
	}
	function currentGameId() {
		const link = document.querySelector("main.round :is(i5d, rm6) a.analysis")?.getAttribute("href");
		return gameIdFrom(nonEmpty(link) ?? location.pathname);
	}
	function moveElements(list, result) {
		const indexTag = list.firstElementChild?.tagName;
		return [...list.children].filter((child) => child instanceof HTMLElement && child.tagName !== indexTag && child !== result && !child.classList.contains("empty"));
	}
	function showTimes(moves, spent) {
		const longest = Math.max(...spent) || 1;
		for (const [i, move] of moves.entries()) {
			const time = spent[i];
			if (time === void 0) continue;
			setData(move, "cdcTime", formatSpent(time));
			setStyleProperty(move, "--cdc-time", (time / longest).toFixed(3));
		}
	}
	const newGameTimes = (id) => ({
		id,
		spent: null,
		clock: null,
		tries: 0,
		at: 0
	});
	function createMoveTimes() {
		let game = newGameTimes("");
		let loading = false;
		async function load(id) {
			loading = true;
			const data = await fetchExport(id);
			if (data && game.id === id) {
				game.clock = data.clock ?? null;
				game.spent = spentTimes(data);
			}
			loading = false;
			game.at = Date.now();
		}
		function sync() {
			const result = queryOne(document, "main.round .result-wrap", HTMLElement);
			const list = result?.parentElement;
			const id = list ? currentGameId() : null;
			if (!result || !list || id === null) return;
			if (game.id !== id) game = newGameTimes(id);
			const moves = moveElements(list, result);
			if ((!game.spent || game.clock !== null && game.spent.length < moves.length) && !loading && game.tries < MAX_TRIES && Date.now() - game.at > RETRY_MS) {
				game.tries++;
				load(id);
			}
			if (!game.spent || game.spent.length === 0) return;
			showTimes(moves, game.spent);
			setData(list, "cdcTimes", "");
		}
		const finishedGame = () => game.clock ? {
			id: game.id,
			clock: game.clock
		} : null;
		return {
			sync,
			finishedGame
		};
	}
	const tracker = createMoveTimes();
	/** The game shown, once its export came back with a clock (for the New game button). */
	const finishedGame = () => tracker.finishedGame();
	const moveTimes = {
		name: "move times",
		start: () => onEveryTick("move times", tracker.sync)
	};

//#endregion
//#region src/shared/lang.ts
/** The page's language, as Lichess sets it on <html> (`fr`, `en-US`…). */
	const pageLang = () => document.documentElement.lang;
	const isFrench = () => pageLang().startsWith("fr");
	/** The page's language for `Intl`, or undefined (the browser's) when the page sets none. */
	function pageLocale() {
		const lang = pageLang();
		return lang === "" ? void 0 : lang;
	}

//#endregion
//#region src/content/game/time-control.ts
	const NO_BREAK_SPACE = "\xA0";
	const WORD_JOINER = "⁠";
	function timeControlText({ initial, increment }) {
		const minutes = Number((initial / 60).toFixed(2));
		if (increment !== 0) return `${minutes} | ${increment}`;
		return initial < 60 ? `${initial} s` : `${minutes} min`;
	}
	/**
	* "New 10 | 5", "New 3 min", "Nouvelle 30 s". Where it has to wrap, the time
	* control stays in one piece: no-break spaces, and a word joiner after the
	* bar, which lines may otherwise break after.
	*/
	function newGameLabel(clock, french) {
		const text = timeControlText(clock).replaceAll(" ", NO_BREAK_SPACE).replace("|", `|${WORD_JOINER}`);
		return french ? `Nouvelle ${text}` : `New ${text}`;
	}

//#endregion
//#region src/content/game/new-game.ts
	function syncNewGame(game) {
		const followUp = queryOne(document, "main.round .rcontrols .follow-up", HTMLElement);
		if (!followUp || !game) return;
		const label = newGameLabel(game.clock, isFrench());
		const lichessButton = queryOne(followUp, ".new-opponent", HTMLElement);
		if (lichessButton) {
			setData(lichessButton, "cdcLabel", label);
			return;
		}
		if (!followUp.querySelector(".rematch") || followUp.querySelector(".cdc-new-game")) return;
		const button = createElement("a", {
			className: "fbt cdc-new-game",
			text: label
		});
		button.href = `/?hook_like=${game.id}`;
		followUp.prepend(button);
	}
	const newGame = {
		name: "new game button",
		start: () => onEveryTick("new game button", () => syncNewGame(finishedGame()))
	};

//#endregion
//#region src/content/game/flag-emoji.ts
	const SPECIAL_FLAGS = /* @__PURE__ */ new Map([
		["GB-ENG", "🏴󠁧󠁢󠁥󠁮󠁧󠁿"],
		["GB-SCT", "🏴󠁧󠁢󠁳󠁣󠁴󠁿"],
		["GB-WLS", "🏴󠁧󠁢󠁷󠁬󠁳󠁿"],
		["_rainbow", "🏳️‍🌈"],
		["_transgender", "🏳️‍⚧️"],
		["_pirate", "🏴‍☠️"],
		["_united-nations", "🇺🇳"],
		["_earth", "🌍"]
	]);
	const REGIONAL_OFFSET = 127462 - "A".charCodeAt(0);
	function flagEmoji(code) {
		if (code === void 0) return "";
		const special = SPECIAL_FLAGS.get(code);
		if (special !== void 0) return special;
		if (!/^[A-Z]{2}$/.test(code)) return "";
		return String.fromCodePoint(REGIONAL_OFFSET + code.charCodeAt(0), REGIONAL_OFFSET + code.charCodeAt(1));
	}

//#endregion
//#region src/content/game/flags.ts
	const BARS = "main.round .ruser, main.analyse > .cdc-player, main.round .game__meta__players a.user-link";
	const UsersSchema = array(object({
		id: string(),
		profile: optional(object({ flag: optional(string()) }))
	}));
	async function fetchUsers(names) {
		try {
			const body = await (await fetch("/api/users", {
				method: "POST",
				body: names.join(",")
			})).json();
			const result = UsersSchema.safeParse(body);
			return result.success ? result.data : [];
		} catch {
			return [];
		}
	}
	function userName$1(bar) {
		const link = bar.matches("a") ? bar : bar.querySelector("a.user-link");
		return link instanceof HTMLAnchorElement ? link.pathname.split("/").pop()?.toLowerCase() : void 0;
	}
	/** A sync task marking each bar with its player's flag, fetched once per name. */
	function createFlagsSync() {
		const flags = /* @__PURE__ */ new Map();
		async function load(names) {
			for (const name of names) flags.set(name, null);
			const users = await fetchUsers(names);
			for (const name of names) flags.set(name, "");
			for (const user of users) flags.set(user.id, flagEmoji(user.profile?.flag));
		}
		return () => {
			const bars = queryAll(document, BARS, HTMLElement);
			const names = bars.map(userName$1);
			const missing = names.filter((name) => name !== void 0 && name !== "" && !flags.has(name));
			if (missing.length > 0) load(missing);
			for (const [i, bar] of bars.entries()) {
				const name = names[i];
				const flag = name === void 0 ? void 0 : flags.get(name);
				setDataText(bar, "cdcFlag", flag ?? "");
			}
		};
	}
	const countryFlags = {
		name: "country flags",
		start: () => onEveryTick("country flags", createFlagsSync())
	};

//#endregion
//#region src/content/layout/board-inset.ts
	const wholePixels = (gap) => Math.max(0, Math.round(gap));
	/** How far inside the wrapper the squares sit, per side. */
	function squaresInset(squares, wrapper) {
		return {
			t: wholePixels(squares.top - wrapper.top),
			r: wholePixels(wrapper.right - squares.right),
			b: wholePixels(wrapper.bottom - squares.bottom),
			l: wholePixels(squares.left - wrapper.left)
		};
	}
	function syncBoardInset() {
		const main = queryOne(document, "main.round, main.analyse", HTMLElement);
		const container = main?.querySelector(".main-board cg-container");
		const wrapper = container?.closest(".cg-wrap");
		if (!main || !container || !wrapper) return;
		const inset = squaresInset(container.getBoundingClientRect(), wrapper.getBoundingClientRect());
		for (const [side, pixels] of Object.entries(inset)) setStyleProperty(main, `--cdc-inset-${side}`, `${pixels}px`);
	}
	const boardInset = {
		name: "board inset",
		start: () => onEveryTick("board inset", syncBoardInset)
	};

//#endregion
//#region src/content/analysis/eval-gauge.ts
	const MINUS = "−";
	/** The score of the engine line's pearl ("+1.2", "#-3"). */
	function gaugeScore(pearl) {
		const match = /^(#)?([+\-\u2212])?(\d+(?:\.\d+)?)$/.exec(pearl.trim());
		if (!match) return {
			label: "",
			lead: "white"
		};
		const [, mate, sign, value = ""] = match;
		const lead = sign === "-" || sign === MINUS ? "black" : "white";
		return {
			label: mate ? `M${value}` : value,
			lead
		};
	}
	/** A sync task copying the engine line's score onto the eval bar. */
	function syncEvalGauge() {
		const main = queryOne(document, "main.puzzle, main.analyse", HTMLElement);
		const gauge = main && queryOne(main, ".eval-gauge", HTMLElement);
		if (!main || !gauge) return;
		const { label, lead } = gaugeScore(main.querySelector(".ceval pearl")?.textContent ?? "");
		setDataText(gauge, "cdcEval", label);
		setData(gauge, "cdcLead", lead);
	}
	const evalGauge = {
		name: "eval gauge",
		start: () => onEveryTick("eval gauge", syncEvalGauge)
	};

//#endregion
//#region src/content/pages/puzzle.ts
/** A sync task scrolling the session to its end whenever a chip is added. */
	function createSessionSync() {
		let lastChips = 0;
		return () => {
			const session = queryOne(document, "main.puzzle .puzzle__session", HTMLElement);
			const chips = session?.childElementCount ?? 0;
			if (chips === lastChips) return;
			lastChips = chips;
			if (session) session.scrollLeft = session.scrollWidth;
		};
	}
	const puzzleSession = {
		name: "puzzle session",
		start: () => onEveryTick("puzzle session", createSessionSync())
	};

//#endregion
//#region src/content/pages/hero-texts.ts
	const ENGLISH = {
		eyebrow: "Free · No ads · Open source",
		title: "Play chess online",
		greeting: (name) => `Ready to play, ${name}?`,
		sub: "Take on thousands of players worldwide, solve puzzles and improve, completely free."
	};
	const HERO_TEXTS = {
		en: ENGLISH,
		fr: {
			eyebrow: "Gratuit · Sans publicité · Open source",
			title: "Jouer aux échecs en ligne",
			greeting: (name) => `Prêt pour une partie, ${name} ?`,
			sub: "Affrontez des milliers de joueurs du monde entier, résolvez des problèmes et progressez, entièrement gratuitement."
		},
		de: {
			eyebrow: "Kostenlos · Werbefrei · Open Source",
			title: "Schach online spielen",
			greeting: (name) => `Bereit für eine Partie, ${name}?`,
			sub: "Spiele gegen Tausende Gegner aus aller Welt, löse Aufgaben und werde besser, völlig kostenlos."
		},
		es: {
			eyebrow: "Gratis · Sin anuncios · Código abierto",
			title: "Juega al ajedrez en línea",
			greeting: (name) => `¿Listo para jugar, ${name}?`,
			sub: "Enfréntate a miles de jugadores de todo el mundo, resuelve problemas y mejora, totalmente gratis."
		},
		pt: {
			eyebrow: "Grátis · Sem anúncios · Código aberto",
			title: "Jogue xadrez online",
			greeting: (name) => `Pronto para jogar, ${name}?`,
			sub: "Enfrente milhares de jogadores do mundo todo, resolva problemas e evolua, totalmente grátis."
		}
	};
	/** The hero's text for a page language (`fr`, `pt-BR`…). */
	const heroText = (lang) => HERO_TEXTS[lang.slice(0, 2)] ?? ENGLISH;

//#endregion
//#region src/content/pages/home-hero.ts
	function buildHero(text, user) {
		const hero = createElement("section", { className: "cdc-hero" });
		hero.append(createElement("p", {
			className: "cdc-hero__eyebrow",
			text: text.eyebrow
		}), createElement("h1", {
			className: "cdc-hero__title",
			text: user ? text.greeting(user) : text.title
		}), createElement("p", {
			className: "cdc-hero__sub",
			text: text.sub
		}));
		return hero;
	}
	function userName() {
		const tag = document.getElementById("user_tag")?.textContent.trim();
		return nonEmpty(tag) ?? document.body.dataset.user;
	}
	function addHero(text) {
		const main = queryOne(document, "main.lobby", HTMLElement);
		if (!main || main.querySelector(":scope > .cdc-hero")) return;
		main.prepend(buildHero(text, userName()));
	}
	const homeHero = {
		name: "home hero",
		start: () => {
			const text = heroText(pageLang());
			onDomReady(() => addHero(text));
			onEveryTick("home hero", () => addHero(text));
		}
	};

//#endregion
//#region src/content/pages/coach-titles.ts
	const TITLES = /* @__PURE__ */ new Set([
		"GM",
		"IM",
		"FM",
		"CM",
		"NM",
		"WGM",
		"WIM",
		"WFM",
		"WCM",
		"WNM",
		"LM",
		"BOT"
	]);
	/** The title a coach's picture alt starts with, or ''. */
	function coachTitle(alt) {
		const title = alt?.split(" ")[0];
		return title !== void 0 && TITLES.has(title) ? title : "";
	}
	function badgeTitle(name) {
		const card = closestTo(name, ".coach-widget", Element);
		const title = coachTitle(card ? queryOne(card, "img.picture", HTMLImageElement)?.alt : void 0);
		setData(name, "cdcTitle", title);
		if (title === "") return;
		const text = name.firstChild;
		if (text instanceof Text && text.data.startsWith(`${title} `)) text.data = text.data.slice(title.length + 1);
		name.prepend(createElement("span", {
			className: "cdc-coach-title",
			text: title
		}));
	}
	function syncCoachTitles() {
		for (const name of queryAll(document, ".coach-widget .coach-name:not([data-cdc-title])", HTMLElement)) badgeTitle(name);
	}
	const coachTitles = {
		name: "coach titles",
		start: () => onEveryTick("coach titles", syncCoachTitles)
	};

//#endregion
//#region src/content/pages/swiss.ts
	const MEDALS = /* @__PURE__ */ new Set([
		"1",
		"2",
		"3"
	]);
	/** The progress bar's width for a round count ("5/10 rounds", digits in every language). */
	function roundsProgress(text) {
		const match = /(\d+)\s*\/\s*(\d+)/.exec(text);
		if (!match) return null;
		const played = Number(match[1]);
		const total = Number(match[2]);
		return total ? `${Math.min(100, 100 * played / total)}%` : null;
	}
	function syncRounds() {
		for (const rounds of queryAll(document, ".swiss-home .swisses .rounds, main.swiss .swiss__meta__round", HTMLElement)) {
			const text = rounds.textContent;
			if (rounds.dataset.cdcRounds === text) continue;
			setData(rounds, "cdcRounds", text);
			const progress = roundsProgress(text);
			const bar = rounds.matches(".swiss__meta__round") ? rounds.parentElement : rounds;
			if (progress !== null && bar) setStyleProperty(bar, "--cdc-progress", progress);
		}
	}
	function syncMedals() {
		for (const rank of queryAll(document, "main.swiss .swiss__standing td.rank", HTMLElement)) {
			const text = rank.textContent.trim();
			setData(rank, "cdcMedal", MEDALS.has(text) ? text : null);
		}
	}
	function syncFocus() {
		const column = queryOne(document, "main.swiss .swiss__main:not([tabindex])", HTMLElement);
		if (!column || !matchMedia("(min-width: 1260px)").matches) return;
		column.tabIndex = -1;
		if (document.activeElement === document.body) column.focus({ preventScroll: true });
	}
	const swiss = {
		name: "swiss",
		start: () => {
			onEveryTick("swiss rounds", syncRounds);
			onEveryTick("swiss medals", syncMedals);
			onEveryTick("swiss focus", syncFocus);
		}
	};

//#endregion
//#region src/content/pages/forum.ts
	function labelCounts(table) {
		setData(table, "cdcLabels", "");
		const names = [...table.tHead?.rows[0]?.cells ?? []].map((cell) => cell.textContent.trim());
		for (const row of table.tBodies[0]?.rows ?? []) for (const cell of row.cells) {
			const name = names[cell.cellIndex];
			if (name) setData(cell, "cdcLabel", name);
		}
	}
	function syncForumLabels() {
		for (const table of queryAll(document, "main.forum table.categs:not([data-cdc-labels])", HTMLTableElement)) labelCounts(table);
	}
	const forumLabels = {
		name: "forum labels",
		start: () => onEveryTick("forum labels", syncForumLabels)
	};

//#endregion
//#region src/content/pages/tv.ts
	const TV_PATH = /\/tv(\/|$)/;
	function comesFromTv(referrer) {
		try {
			const url = new URL(referrer);
			return url.origin === location.origin && TV_PATH.test(url.pathname);
		} catch {
			return false;
		}
	}
	function isReload() {
		const entry = performance.getEntriesByType("navigation")[0];
		return entry !== void 0 && "type" in entry && entry.type === "reload";
	}
	function markStillIntro() {
		if (!TV_PATH.test(location.pathname)) return;
		if (comesFromTv(document.referrer) || isReload()) document.documentElement.classList.toggle("cdc-tv-still", true);
	}
	/** A channel's tooltip, shown where only its tile is (below 1260px). */
	function channelTip(name, champion) {
		if (!name) return null;
		return champion ? `${name} · ${champion}` : name;
	}
	function syncChannels() {
		const list = queryOne(document, "main.tv-single .subnav__inner:not([data-cdc-tv])", HTMLElement);
		if (!list || list.clientHeight === 0) return;
		setData(list, "cdcTv", "");
		for (const channel of queryAll(list, "a.tv-channel", HTMLElement)) {
			const name = channel.querySelector("strong")?.textContent.trim();
			const champion = channel.querySelector(".champion")?.textContent.replace(/\s+/g, " ").trim();
			const tip = channelTip(name, champion);
			if (tip !== null) setData(channel, "cdcTip", tip);
		}
		const active = queryOne(list, "a.tv-channel.active", HTMLElement);
		if (active) list.scrollTop = active.offsetTop - (list.clientHeight - active.offsetHeight) / 2;
	}
	const tv = {
		name: "tv",
		start: () => {
			markStillIntro();
			onEveryTick("tv channels", syncChannels);
		}
	};

//#endregion
//#region src/content/game/game-meta.ts
/** The parts of a line of the game info. */
	const infoParts = (text) => text.split("•").map((part) => part.trim()).filter((part) => part !== "");
	function splitParts(line) {
		setData(line, "cdcParts", "");
		for (const node of Array.from(line.childNodes)) {
			if (!(node instanceof Text)) continue;
			const parts = infoParts(node.data).map((text) => createElement("span", {
				className: "cdc-part",
				text
			}));
			node.replaceWith(...parts);
		}
	}
	function wrapName(link) {
		setData(link, "cdcName", "");
		for (const node of Array.from(link.childNodes)) {
			const name = node instanceof Text ? node.data.trim() : "";
			if (name !== "") node.replaceWith(createElement("span", {
				className: "cdc-meta-name",
				text: name
			}));
		}
		const rating = queryOne(link, ".rating", HTMLElement);
		if (!rating) return;
		const bare = rating.textContent.replace(/[()\s]/g, "");
		if (rating.textContent !== bare) rating.textContent = bare;
	}
	function addComputerRatings(meta, ratings) {
		for (const [color, rating] of ratings) {
			const selector = `.game__meta__players .player.${color} > span.user-link`;
			const link = queryOne(meta, selector, HTMLElement);
			if (!link || link.querySelector(".rating")) continue;
			link.append(createElement("span", {
				className: "rating",
				text: rating
			}));
		}
	}
	function syncGameMeta(ratings) {
		const meta = queryOne(document, "main.round .round__side > .game__meta", HTMLElement);
		if (!meta) return;
		for (const line of queryAll(meta, ":is(.setup, section.status):not([data-cdc-parts])", HTMLElement)) splitParts(line);
		for (const link of queryAll(meta, ".game__meta__players .user-link:not([data-cdc-name])", HTMLElement)) wrapName(link);
		addComputerRatings(meta, ratings);
	}
	const gameMeta = {
		name: "game info",
		start: () => onEveryTick("game info", () => syncGameMeta(computerRatings()))
	};

//#endregion
//#region src/shared/math.ts
/** `value`, kept between `low` and `high` (`low` wins if they cross). */
	const clamp = (value, low, high) => Math.max(low, Math.min(high, value));
	/** Rounds to a tenth: precise enough for a pixel coordinate, and short in markup. */
	const roundTenth = (value) => Math.round(value * 10) / 10;

//#endregion
//#region src/content/ui/card-fit.ts
	const NAME_GAP = 10;
	/**
	* Where the card should go to fit the window: below the name, else above,
	* else against the edge. Null when it already fits.
	*/
	function fitCard(card, anchor, viewport) {
		const maxTop = viewport.height - 8 - card.height;
		const maxLeft = viewport.width - 8 - card.width;
		if (card.top >= 8 && card.top <= maxTop && card.left >= 8 && card.left <= maxLeft) return null;
		let top = clamp(card.top, 8, maxTop);
		if (anchor && card.left < anchor.right && card.right > anchor.left) {
			if (anchor.bottom + NAME_GAP <= maxTop) top = anchor.bottom + NAME_GAP;
			else if (anchor.top - NAME_GAP - card.height >= 8) top = anchor.top - NAME_GAP - card.height;
		}
		return {
			top,
			left: clamp(card.left, 8, maxLeft)
		};
	}

//#endregion
//#region src/content/ui/card-ratings.ts
/** A rating's text without Lichess's column padding (no-break spaces). */
	const ratingText = (text) => text.replaceAll("\xA0", "").trim();
	/** Unrated ("?") and never played ("-") chips are dimmed. */
	const ratingState = (text) => text === "?" || text === "-" ? "none" : "rated";

//#endregion
//#region src/content/ui/powertip.ts
	function cleanRatings(card) {
		for (const rating of queryAll(card, ".upt__info__ratings > span", HTMLElement)) {
			const text = ratingText(rating.textContent);
			if (rating.textContent !== text) rating.textContent = text;
			setData(rating, "cdcRating", ratingState(text));
		}
	}
	/** The name the pointer is on, which the card belongs to. */
	let anchor = null;
	function trackAnchor(event) {
		const target = closestTo(event.target, "a, [data-href]", Element);
		if (target && !target.closest("#powerTip")) anchor = target;
	}
	function fitPowertip(card) {
		if (getComputedStyle(card).visibility !== "visible") return;
		const box = card.getBoundingClientRect();
		const name = anchor?.isConnected ? anchor.getBoundingClientRect() : null;
		const target = fitCard(box, name, {
			width: innerWidth,
			height: innerHeight
		});
		if (!target) return;
		card.style.top = `${(parseFloat(card.style.top) || 0) + target.top - box.top}px`;
		card.style.left = `${(parseFloat(card.style.left) || 0) + target.left - box.left}px`;
	}
	function watch(card) {
		new MutationObserver((records) => {
			if (records.some((record) => record.type === "childList")) cleanRatings(card);
			fitPowertip(card);
		}).observe(card, {
			childList: true,
			attributes: true,
			attributeFilter: ["style"]
		});
		new ResizeObserver(() => fitPowertip(card)).observe(card);
		cleanRatings(card);
	}
	function createPowertipSync() {
		let watched = null;
		return () => {
			const card = document.getElementById("powerTip");
			if (!card || card === watched) return;
			watched = card;
			watch(card);
		};
	}
	const powertip = {
		name: "hover card",
		start: () => {
			document.addEventListener("mouseover", trackAnchor, true);
			onEveryTick("hover card", createPowertipSync());
		}
	};

//#endregion
//#region src/content/ui/tooltip-layout.ts
	const GAP = 8;
	function splitShortcut(title) {
		const match = /^(.*\S)\s*\((\S)\)$/.exec(title);
		return match ? {
			label: match[1] ?? "",
			key: match[2] ?? null
		} : {
			label: title,
			key: null
		};
	}
	/** Centered above the target, or below it where there's no room above. */
	function placeTooltip(target, tooltip, viewportWidth) {
		const below = target.top - GAP - tooltip.height < 8;
		const middle = target.left + target.width / 2;
		const maxLeft = viewportWidth - 8 - tooltip.width;
		const left = clamp(middle - tooltip.width / 2, 8, maxLeft);
		const top = below ? target.bottom + GAP : target.top - GAP - tooltip.height;
		return {
			side: below ? "below" : "above",
			top,
			left,
			arrow: middle - left
		};
	}

//#endregion
//#region src/content/ui/tooltip.ts
	const TARGETS = "main :is(button:is([title], [data-cdc-tip]), a.tv-channel[data-cdc-tip]):not(#cdc-review *)";
	const ON$1 = "cdc-tooltip--on";
	const FIRST_DELAY_MS = 250;
	const CHAIN_MS = 400;
	function hoverTarget(event) {
		const target = closestTo(event.target, TARGETS, HTMLElement);
		if (target?.matches("a") && !matchMedia("(max-width: 1259.98px)").matches) return null;
		return target;
	}
	function adoptTitle(target) {
		if (!target.title) return;
		setData(target, "cdcTip", target.title);
		if (!target.hasAttribute("aria-label")) target.setAttribute("aria-label", target.title);
		target.removeAttribute("title");
	}
	var Tooltip = class {
		#element = createElement("div", {
			className: "cdc-tooltip",
			attrs: { "aria-hidden": "true" }
		});
		#target = null;
		#timer = 0;
		#hiddenAt = 0;
		hide() {
			clearTimeout(this.#timer);
			if (this.#target && this.#element.classList.contains(ON$1)) this.#hiddenAt = Date.now();
			this.#target = null;
			this.#element.classList.toggle(ON$1, false);
		}
		hover(event) {
			const target = hoverTarget(event);
			if (target === this.#target) return;
			this.hide();
			if (!target) return;
			adoptTitle(target);
			if (!target.dataset.cdcTip) return;
			this.#target = target;
			const delay = Date.now() - this.#hiddenAt < CHAIN_MS ? 0 : FIRST_DELAY_MS;
			this.#timer = setTimeout(() => this.#show(target), delay);
		}
		/** Snabbdom replaced the button under the pointer. */
		dropDetached() {
			if (this.#target && !this.#target.isConnected) this.hide();
		}
		#show(target) {
			const tooltip = this.#element;
			const { label, key } = splitShortcut(target.dataset.cdcTip ?? "");
			tooltip.textContent = label;
			if (key !== null) tooltip.append(createElement("kbd", { text: key }));
			if (!tooltip.isConnected) document.body.append(tooltip);
			const place = placeTooltip(target.getBoundingClientRect(), tooltip.getBoundingClientRect(), innerWidth);
			setData(tooltip, "side", place.side);
			tooltip.style.top = `${place.top}px`;
			tooltip.style.left = `${place.left}px`;
			setStyleProperty(tooltip, "--cdc-tooltip-arrow", `${place.arrow}px`);
			tooltip.classList.toggle(ON$1, true);
		}
	};
	/** Shows `tip` for the buttons hovered, and hides it on a press, a scroll or leaving the window. */
	function listenForTooltips(tip) {
		const hide = () => tip.hide();
		document.addEventListener("mouseover", (event) => tip.hover(event), true);
		document.addEventListener("mouseout", (event) => {
			if (!event.relatedTarget) hide();
		});
		document.addEventListener("pointerdown", hide, true);
		document.addEventListener("scroll", hide, true);
	}
	const tooltip = {
		name: "tooltip",
		start: () => {
			const tip = new Tooltip();
			listenForTooltips(tip);
			onEveryTick("tooltip", () => tip.dropDetached());
		}
	};

//#endregion
//#region src/content/ui/tab-bars.ts
	const kind = (bar, tab, active, look) => ({
		bar,
		tab,
		active,
		look
	});
	const TAB_BARS = [
		kind(".user-show > .angles", ".nm-item", ".active", "pill"),
		kind(".game-setup .time-control-tabs .tabs-horiz", "button", ".active", "pill"),
		kind(".ublog-index .btn-rack", ".btn-rack__btn", ".active", "pill"),
		kind("main.forum-topic .markdown-editor .header", ".header-tab", ".active", "pill"),
		kind(".tabs-horiz:not(.lobby__app > .tabs-horiz)", "*", ".active", "line"),
		kind(".mchat__tabs", ".mchat__tab", ".mchat__tab-active", "line"),
		kind(".auth .auth-tabs", "a", ".active", "line"),
		kind(".relay-tour__tabs", "button", ".active", "pill"),
		kind("#dasher_app .cdc-src-tabs", "button", ".active", "pill")
	];
	/** The tab's box within the bar's padding box, scrolled content included. */
	function tabOffset(bar, tab, frame) {
		return [
			tab.left - bar.left - frame.clientLeft + frame.scrollLeft,
			tab.top - bar.top - frame.clientTop + frame.scrollTop,
			tab.width,
			tab.height
		];
	}
	const sameOffset = (offset, previous) => previous !== null && offset.every((value, i) => value === previous[i]);
	/** A click on a tab link that the browser will follow: the page is about to go. */
	function leavesPage(event, tab) {
		const modified = event.ctrlKey || event.metaKey || event.shiftKey || event.altKey;
		const newTab = tab instanceof HTMLAnchorElement && tab.target === "_blank";
		return tab.matches("a[href]") && !event.defaultPrevented && event.button === 0 && !modified && !newTab;
	}

//#endregion
//#region src/content/ui/tab-bar.ts
	var TabBar = class {
		element;
		kind;
		/** A tab link just followed: shown picked while the next page loads. */
		leaving = null;
		/** Places the highlight on the next frame. */
		queue;
		#sizes;
		#changes;
		#onDetach;
		#item = null;
		#offset = null;
		constructor(element, kind, onDetach) {
			this.element = element;
			this.kind = kind;
			this.#onDetach = onDetach;
			this.queue = oncePerFrame(() => this.place());
			this.#sizes = new ResizeObserver(this.queue);
			this.#sizes.observe(element);
			this.#changes = new MutationObserver(this.queue);
			this.#changes.observe(element, {
				subtree: true,
				childList: true,
				attributes: true,
				attributeFilter: ["class"]
			});
		}
		place() {
			if (!this.element.isConnected) {
				this.#sizes.disconnect();
				this.#changes.disconnect();
				this.#onDetach();
				return;
			}
			const tabs = [...this.element.children].filter((child) => child.matches(this.kind.tab));
			for (const tab of tabs) this.#sizes.observe(tab);
			const item = this.leaving?.isConnected ? this.leaving : tabs.find((tab) => tab.matches(this.kind.active));
			if (!item) {
				setData(this.element, "cdcTabs", null);
				this.#item = null;
				return;
			}
			if (!(item instanceof HTMLElement) || item.offsetWidth === 0) return;
			const bar = this.element.getBoundingClientRect();
			const offset = tabOffset(bar, item.getBoundingClientRect(), this.element);
			if (item === this.#item && sameOffset(offset, this.#offset)) return;
			this.#draw(item, offset);
		}
		#draw(item, offset) {
			const [x, y, width, height] = offset;
			const slides = this.#item !== null && item !== this.#item;
			setData(this.element, "cdcTabsStill", slides ? null : "");
			setStyleProperty(this.element, "--cdc-tab-x", `${x}px`);
			setStyleProperty(this.element, "--cdc-tab-y", `${y}px`);
			setStyleProperty(this.element, "--cdc-tab-w", `${width}px`);
			setStyleProperty(this.element, "--cdc-tab-h", `${height}px`);
			setData(this.element, "cdcTabs", this.kind.look);
			this.#item = item;
			this.#offset = offset;
		}
	};

//#endregion
//#region src/content/ui/tabs.ts
	function createTabBars() {
		const bars = /* @__PURE__ */ new Map();
		function sync() {
			for (const kind of TAB_BARS) for (const element of queryAll(document, kind.bar, HTMLElement)) {
				if (bars.has(element)) continue;
				bars.set(element, new TabBar(element, kind, () => bars.delete(element)));
			}
			for (const bar of bars.values()) bar.place();
		}
		function clickedTab(target) {
			for (let tab = target instanceof Element ? target : null; tab; tab = tab.parentElement) {
				const bar = tab.parentElement ? bars.get(tab.parentElement) : void 0;
				if (bar) return {
					tab,
					bar
				};
			}
			return null;
		}
		function onClick(event) {
			const clicked = clickedTab(event.target);
			if (!clicked?.tab.matches(clicked.bar.kind.tab) || !leavesPage(event, clicked.tab)) return;
			clicked.bar.leaving = clicked.tab;
			clicked.bar.queue();
		}
		function onPageShow(event) {
			if (!event.persisted) return;
			for (const bar of bars.values()) {
				bar.leaving = null;
				bar.queue();
			}
		}
		return {
			sync,
			onClick,
			onPageShow
		};
	}
	const tabs = {
		name: "sliding tabs",
		start: () => {
			const bars = createTabBars();
			onEveryTick("sliding tabs", bars.sync);
			document.addEventListener("click", bars.onClick);
			window.addEventListener("pageshow", bars.onPageShow);
		}
	};

//#endregion
//#region src/shared/dev-check.ts
	const DevCheckRequestSchema = object({ type: literal("cdc:dev-check") });
	const DevCheckResponseSchema = object({ reload: boolean() });

//#endregion
//#region src/content/dev/reload.ts
	const ORPHAN_POLL_MS = 100;
	const RELOAD_DELAY_MS = 250;
	function reloadWhenOrphaned() {
		const poll = setInterval(() => {
			if (isConnected()) return;
			clearInterval(poll);
			setTimeout(() => location.reload(), RELOAD_DELAY_MS);
		}, ORPHAN_POLL_MS);
	}
	async function isStale() {
		const request = { type: "cdc:dev-check" };
		try {
			const response = await chrome.runtime.sendMessage(request);
			return DevCheckResponseSchema.safeParse(response).data?.reload === true;
		} catch {
			return false;
		}
	}
	async function checkForUpdate() {
		if (document.visibilityState !== "visible") return;
		if (!isConnected()) {
			location.reload();
			return;
		}
		if (await isStale()) reloadWhenOrphaned();
	}
	const onFocus = () => void checkForUpdate();
	const devReload = {
		name: "dev reload",
		start: () => {
			if (!isUnpacked()) return;
			document.addEventListener("visibilitychange", onFocus);
			window.addEventListener("focus", onFocus);
			onFocus();
		}
	};

//#endregion
//#region src/content/charts/radar/geometry.ts
	const RADIUS = 100;
	const MIN_SHARE = .06;
	/** Corner `index` of a regular polygon, starting at the top as Chart.js does. */
	function vertex(index, corners, radius) {
		const angle = index / corners * 2 * Math.PI - Math.PI / 2;
		return [Math.cos(angle) * radius, Math.sin(angle) * radius];
	}
	const formatPoint = ([x, y]) => `${x.toFixed(2)},${y.toFixed(2)}`;
	function polygon(corners, radius) {
		return Array.from({ length: corners }, (_, i) => formatPoint(vertex(i, corners, radius))).join(" ");
	}
	/**
	* The scale's ends. There are no tick labels (each theme shows its own
	* number), so it only has to keep the points well inside the rim.
	*/
	function bounds(values) {
		const min = Math.min(...values);
		const max = Math.max(...values);
		const span = max - min;
		return span === 0 ? [min - 10, min + 10] : [min - span * .6, max + span * .25];
	}
	/** Where each value sits on its spoke. */
	function plotPoints(values) {
		const [low, high] = bounds(values);
		return values.map((value, i) => {
			const share = clamp((value - low) / (high - low), MIN_SHARE, 1);
			return vertex(i, values.length, 100 * share);
		});
	}

//#endregion
//#region src/content/charts/radar/render.ts
	function grid(themes) {
		const rings = Array.from({ length: 4 }, (_, k) => html`<polygon points="${polygon(themes, 100 * (k + 1) / 4)}"/>`);
		const spokes = Array.from({ length: themes }, (_, i) => {
			const [x, y] = vertex(i, themes, 100);
			return html`<line x1="0" y1="0" x2="${x.toFixed(2)}" y2="${y.toFixed(2)}"/>`;
		});
		return html`<g class="cdc-radar__rings">${rings}</g><g class="cdc-radar__spokes">${spokes}</g>`;
	}
	function label(name, value, i, themes) {
		const [unitX, unitY] = vertex(i, themes, 1);
		const style = `--cdc-x:${(50 + 50 * unitX).toFixed(2)}%;--cdc-y:${(50 + 50 * unitY).toFixed(2)}%;--cdc-ox:${unitX.toFixed(3)};--cdc-oy:${unitY.toFixed(3)}`;
		return html`<div class="cdc-radar__label" style="${style}"><span class="cdc-radar__name">${name}</span><span class="cdc-radar__value">${Math.round(value)}</span></div>`;
	}
	function radarMarkup({ labels, values }) {
		const themes = values.length;
		const points = plotPoints(values);
		const dots = points.map(([x, y]) => html`<circle cx="${x.toFixed(2)}" cy="${y.toFixed(2)}" r="2.6"/>`);
		const viewBox = `${-100} ${-100} ${100 * 2} ${100 * 2}`;
		const area = points.map(formatPoint).join(" ");
		const chart = html`<svg class="cdc-radar__chart" viewBox="${viewBox}" aria-hidden="true">${grid(themes)}<polygon class="cdc-radar__area" points="${area}"/><g class="cdc-radar__dots">${dots}</g></svg>`;
		const labelsMarkup = labels.map((name, i) => label(name, values[i] ?? 0, i, themes));
		return html`<div class="cdc-radar__plot">${chart}${labelsMarkup}</div>`;
	}

//#endregion
//#region src/content/charts/radar/schema.ts
	const MIN_THEMES = 3;
	const RadarSchema = pipe(object({
		labels: array(string()),
		datasets: tuple([object({ data: array(number()) })], unknown())
	}), transform(({ labels, datasets: [{ data }] }) => ({
		labels,
		values: data
	}))).check(refine(({ labels, values }) => values.length >= MIN_THEMES && values.length === labels.length));
	const DashboardInitSchema = object({ radar: RadarSchema });

//#endregion
//#region src/content/charts/radar/index.ts
	function draw(text) {
		const host = queryOne(document, ".puzzle-dashboard__global", HTMLElement);
		if (!host || host.querySelector(".cdc-radar")) return;
		const init = parseJson(text, DashboardInitSchema);
		if (!init) return;
		const figure = createElement("div", { className: "cdc-radar" });
		setHtml(figure, radarMarkup(init.radar));
		host.append(figure);
	}
	const radar = {
		name: "puzzle radar",
		start: () => readPageInitData(draw)
	};

//#endregion
//#region src/shared/svg.ts
	const SVG_NS = "http://www.w3.org/2000/svg";
	function setAttributes(element, attributes) {
		for (const [name, value] of Object.entries(attributes)) element.setAttribute(name, String(value));
	}
	function createSvgElement(tag, attributes = {}) {
		const element = document.createElementNS(SVG_NS, tag);
		setAttributes(element, attributes);
		return element;
	}
	/** Sizes an SVG to `width` × `height` pixels, with a viewBox in pixels too. */
	function sizeSvg(svg, width, height) {
		setAttributes(svg, {
			width,
			height
		});
		svg.setAttribute("viewBox", `0 0 ${width} ${height}`);
	}
	/**
	* Parses SVG markup into the start of `parent`. The markup is parsed inside an
	* SVG element, so it's SVG in any DOM (happy-dom reads insertAdjacentHTML on
	* an SVG element as HTML).
	*/
	function prependSvg(parent, markup) {
		const scratch = createSvgElement("g");
		setHtml(scratch, markup);
		parent.prepend(...scratch.childNodes);
	}
	/** The pointer's x from the element's left edge. */
	const pointerX = (event, element) => event.clientX - element.getBoundingClientRect().left;

//#endregion
//#region src/content/charts/rating-chart/dates.ts
	const DAY_MS = 864e5;
	function addMonths(time, months) {
		const date = new Date(time);
		return Date.UTC(date.getUTCFullYear(), date.getUTCMonth() + months, date.getUTCDate());
	}
	function todayUtc() {
		const now = /* @__PURE__ */ new Date();
		return Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate());
	}
	const RangeKeySchema = _enum([
		"1M",
		"3M",
		"6M",
		"YTD",
		"1Y",
		"ALL"
	]);
	const RANGE_KEYS = RangeKeySchema.options;
	const RANGE_FLOORS = {
		"1M": ({ end }) => addMonths(end, -1),
		"3M": ({ end }) => addMonths(end, -3),
		"6M": ({ end }) => addMonths(end, -6),
		YTD: ({ end }) => Date.UTC(new Date(end).getUTCFullYear(), 0, 1),
		"1Y": ({ end }) => addMonths(end, -12),
		ALL: ({ first }) => first
	};
	/** Where a range starts: never before the history does. */
	const rangeStart = (key, span) => Math.max(span.first, RANGE_FLOORS[key](span));
	/** The range picked last, else Lichess's default: three months, unless the history is shorter. */
	function initialRange(stored, span) {
		if (stored !== null) return stored;
		return span.first < addMonths(span.end, -3) ? "3M" : "ALL";
	}

//#endregion
//#region src/shared/charts/markup.ts
	const SWATCH = trustedHtml("<span class=\"cdc-rchart__swatch\"></span>");
	/** A chip's color dot and name. */
	const chipLabel = (name) => html`${SWATCH}<span class="cdc-rchart__name">${name}</span>`;
	const tipTitle = (title) => html`<div class="cdc-rchart__tipdate">${title}</div>`;
	const tipRow = ({ color, name, value }) => html`<div class="cdc-rchart__tiprow" style="--cdc-series-color:${color}">${SWATCH}<span>${name}</span><strong>${value}</strong></div>`;
	const xAxisLabel = ({ x, y, text }) => html`<text class="cdc-rchart__xlabel" x="${x}" y="${y}">${text}</text>`;
	/** A horizontal grid line, its value on the left. */
	const gridLine = ({ y, left, right, label, extraClass = "" }) => html`<line class="cdc-rchart__grid${extraClass}" x1="${left}" x2="${right}" y1="${y}" y2="${y}"/><text class="cdc-rchart__ylabel" x="${left - 10}" y="${y}">${label}</text>`;
	/** The transparent rectangle that catches the pointer over the plot. */
	const hitArea = ({ x, y, width, height }) => html`<rect class="cdc-rchart__hit" x="${x}" y="${y}" width="${width}" height="${height}"/>`;

//#endregion
//#region src/shared/charts/tooltip.ts
	const ON = "cdc-rchart__tip--on";
	/** The tooltip's left edge: right of the anchor, or left of it when there's no room. */
	function tipLeft({ anchor, width, gap, limit }) {
		return anchor + gap + width > limit ? anchor - gap - width : anchor + gap;
	}
	/** Fills the tooltip and shows it beside `anchor`; its width is only known once filled. */
	function showTip(tip, markup, placement) {
		setHtml(tip, markup);
		tip.classList.toggle(ON, true);
		const left = tipLeft({
			...placement,
			width: tip.offsetWidth
		});
		setStyleProperty(tip, "transform", `translate(${Math.round(left)}px, ${placement.top}px)`);
	}
	function hideTip(tip) {
		tip.classList.toggle(ON, false);
	}

//#endregion
//#region src/shared/charts/steps.ts
/**
	* The values from `from` up to `to`, `step` (> 0) apart. They're summed one
	* step at a time, so fractional steps drift exactly as a plain loop's would.
	*/
	function steps(from, to, step) {
		const values = [];
		for (let value = from; value <= to; value += step) values.push(value);
		return values;
	}

//#endregion
//#region src/content/charts/rating-chart/scales.ts
	const PADDING = {
		top: 14,
		right: 14,
		bottom: 28,
		left: 46
	};
	const HEIGHT = 300;
	const PLOT_HEIGHT = 300 - PADDING.top - PADDING.bottom;
	const STEPS = [
		5,
		10,
		20,
		25,
		50,
		100,
		150,
		200,
		250,
		300,
		400,
		500,
		1e3
	];
	/** A rating scale around `low`–`high` with some margin, in about four round steps. */
	function niceTicks(low, high) {
		const [lowest, highest] = low === high ? [low - 20, high + 20] : [low, high];
		const padding = (highest - lowest) * .08;
		const from = lowest - padding;
		const to = highest + padding;
		const rough = (to - from) / 4;
		const step = STEPS.find((candidate) => candidate >= rough) ?? 1e3;
		const min = Math.floor(from / step) * step;
		const max = Math.ceil(to / step) * step;
		return {
			min,
			max,
			ticks: steps(min, max + step / 2, step)
		};
	}
	function scalePlot(layout, hidden) {
		const shown = layout.rows.filter((row) => !hidden.has(row.index));
		const values = shown.flatMap((row) => row.values.filter((value) => value !== null));
		const ratings = niceTicks(Math.min(...values), Math.max(...values));
		const plotWidth = layout.width - PADDING.left - PADDING.right;
		const span = Math.max(DAY_MS, layout.end - layout.start);
		return {
			...layout,
			shown,
			ratings,
			bottom: PADDING.top + PLOT_HEIGHT,
			x: (time) => PADDING.left + (time - layout.start) / span * plotWidth,
			y: (rating) => PADDING.top + (1 - (rating - ratings.min) / (ratings.max - ratings.min)) * PLOT_HEIGHT
		};
	}

//#endregion
//#region src/content/charts/rating-chart/hover.ts
	function nearestSample(plot, x) {
		let nearest = 0;
		let distance = Infinity;
		for (const [k, time] of plot.times.entries()) {
			const gap = Math.abs(plot.x(time) - x);
			if (gap < distance) {
				nearest = k;
				distance = gap;
			}
		}
		return nearest;
	}
	function placeDots(svg, hits, x, plot) {
		const guide = queryOne(svg, ".cdc-rchart__guide", SVGElement);
		if (guide) setAttributes(guide, {
			x1: x,
			x2: x
		});
		for (const dot of queryAll(svg, ".cdc-rchart__dot", SVGElement)) {
			const hit = hits.find(({ row }) => row.index === Number(dot.dataset.cdcSeries));
			dot.classList.toggle("cdc-rchart__dot--on", hit !== void 0);
			if (hit) setAttributes(dot, {
				cx: x,
				cy: plot.y(hit.value)
			});
		}
	}
	function hideSample({ svg, tip }) {
		svg.classList.toggle("cdc-rchart__svg--hover", false);
		hideTip(tip);
	}
	/** Snaps to the sample nearest the pointer: a dot on every curve shown there, and their ratings. */
	function showSample({ event, plot, parts, formats }) {
		const j = nearestSample(plot, pointerX(event, parts.svg));
		const time = plot.times[j] ?? 0;
		const hits = plot.shown.flatMap((row) => {
			const value = row.values[j];
			return value === null || value === void 0 ? [] : [{
				row,
				value
			}];
		});
		if (hits.length === 0) {
			hideSample(parts);
			return;
		}
		const x = plot.x(time);
		parts.svg.classList.toggle("cdc-rchart__svg--hover", true);
		placeDots(parts.svg, hits, x, plot);
		const rows = hits.toSorted((one, other) => other.value - one.value).map(({ row, value }) => tipRow({
			color: row.color,
			name: row.name,
			value
		}));
		showTip(parts.tip, html`${tipTitle(formats.full.format(time))}${rows}`, {
			anchor: x,
			gap: 14,
			limit: plot.width - PADDING.right,
			top: PADDING.top
		});
	}

//#endregion
//#region src/content/charts/rating-chart/legend.ts
/** A rating change as a chip shows it: `+12`, `−8` (a real minus sign), `±0`. */
	function signedChange(change) {
		if (change > 0) return `+${change}`;
		if (change < 0) return `−${-change}`;
		return "±0";
	}
	function trend(change) {
		if (change > 0) return "up";
		if (change < 0) return "down";
		return "flat";
	}
	/** One chip per rating: its value at the range's end and its change over the range. */
	function legendMarkup({ rows, hidden, single }) {
		const chips = rows.map(({ index, name, color, values }) => {
			const ratings = values.filter((value) => value !== null);
			const now = ratings.at(-1) ?? 0;
			const change = now - (ratings[0] ?? 0);
			const off = hidden.has(index) ? " cdc-rchart__chip--off" : "";
			return html`<button type="button" class="cdc-rchart__chip${off}" data-cdc-series="${index}" style="--cdc-series-color:${color}"${single ? html` disabled` : ""}>${chipLabel(name)}<strong>${now}</strong><span class="cdc-rchart__diff cdc-rchart__diff--${trend(change)}">${signedChange(change)}</span></button>`;
		});
		return html`${chips}`;
	}

//#endregion
//#region src/content/charts/rating-chart/markup.ts
/** The chart's frame, filled in by each draw. */
	function chartShell() {
		const ranges = RANGE_KEYS.map((key) => html`<button type="button" data-cdc-range="${key}">${key}</button>`);
		return html`<div class="cdc-rchart__top"><div class="cdc-rchart__legend"></div><div class="cdc-rchart__ranges"><span class="cdc-rchart__thumb"></span>${ranges}</div></div><div class="cdc-rchart__plot"><svg class="cdc-rchart__svg" aria-hidden="true"></svg><div class="cdc-rchart__tip"></div></div>`;
	}
	const gradientId = (index) => `cdc-rg-${index}`;
	function dateLabels(plot, ticks) {
		return ticks.filter(([time]) => plot.x(time) > PADDING.left + 16 && plot.x(time) < plot.width - PADDING.right - 16).map(([time, label]) => xAxisLabel({
			x: plot.x(time),
			y: 300 - 8,
			text: label
		}));
	}
	/** Everything in the SVG but the rating grid and the curves' paths, which `update` sets. */
	function plotMarkup(plot, ticks) {
		const plotWidth = plot.width - PADDING.left - PADDING.right;
		const gradients = plot.rows.map(({ index, color }) => html`<linearGradient id="${gradientId(index)}" gradientUnits="userSpaceOnUse" x1="0" x2="0"><stop offset="0" stop-color="${color}" stop-opacity="0.3"/><stop offset="1" stop-color="${color}" stop-opacity="0"/></linearGradient>`);
		const series = plot.rows.map(({ index, color }) => html`<g class="cdc-rchart__series" data-cdc-series="${index}" style="--cdc-series-color:${color}"><path class="cdc-rchart__area" fill="url(#${gradientId(index)})"/><path class="cdc-rchart__line"/></g>`);
		const dots = plot.rows.map(({ index, color }) => html`<circle class="cdc-rchart__dot" data-cdc-series="${index}" r="4.5" style="--cdc-series-color:${color}"/>`);
		const clip = html`<clipPath id="cdc-rclip"><rect class="cdc-rchart__wipe" x="${PADDING.left - 4}" y="0" width="${plotWidth + 8}" height="${300}"/></clipPath>`;
		const hit = hitArea({
			x: PADDING.left,
			y: PADDING.top,
			width: plotWidth,
			height: plot.bottom - PADDING.top
		});
		return html`<defs>${gradients}${clip}</defs><g class="cdc-rchart__axis">${dateLabels(plot, ticks)}</g><g class="cdc-rchart__all" clip-path="url(#cdc-rclip)">${series}</g><g class="cdc-rchart__hover"><line class="cdc-rchart__guide" y1="${PADDING.top}" y2="${plot.bottom}"/>${dots}</g>${hit}`;
	}
	/** The rating grid, which follows the ratings shown. */
	function ratingGrid(plot) {
		const lines = plot.ratings.ticks.map((rating) => gridLine({
			y: plot.y(rating),
			left: PADDING.left,
			right: plot.width - PADDING.right,
			label: rating
		}));
		return html`${lines}`;
	}

//#endregion
//#region src/content/charts/rating-chart/parts.ts
	function findParts(root) {
		const legend = queryOne(root, ".cdc-rchart__legend", HTMLElement);
		const plot = queryOne(root, ".cdc-rchart__plot", HTMLElement);
		const svg = queryOne(root, "svg", SVGSVGElement);
		const tip = queryOne(root, ".cdc-rchart__tip", HTMLElement);
		const thumb = queryOne(root, ".cdc-rchart__thumb", HTMLElement);
		if (!legend || !plot || !svg || !tip || !thumb) return null;
		return {
			root,
			legend,
			plot,
			svg,
			tip,
			thumb
		};
	}

//#endregion
//#region src/shared/charts/curve.ts
	function segmentsOf(points) {
		const segments = [];
		for (let k = 1; k < points.length; k++) {
			const from = points[k - 1];
			const to = points[k];
			if (!from || !to) continue;
			const width = to[0] - from[0];
			segments.push({
				from,
				to,
				width,
				slope: (to[1] - from[1]) / width
			});
		}
		return segments;
	}
	function tangentBetween(before, after) {
		if (!before) return after?.slope ?? 0;
		if (!after) return before.slope;
		if (before.slope * after.slope <= 0) return 0;
		return 3 * (before.width + after.width) / ((2 * after.width + before.width) / before.slope + (after.width + 2 * before.width) / after.slope);
	}
	/**
	* An SVG path through the points as a monotone cubic (d3's curveMonotoneX):
	* smooth, yet never above or below the points it joins.
	*/
	function monotoneCurve(points) {
		const [first] = points;
		if (!first) return "";
		if (points.length === 1) return `M${first[0]},${first[1]}h0.01`;
		const segments = segmentsOf(points);
		const tangents = points.map((_, k) => tangentBetween(segments[k - 1], segments[k]));
		const curves = segments.map(({ from, to, width }, k) => {
			const handle = width / 3;
			const startTangent = tangents[k] ?? 0;
			const endTangent = tangents[k + 1] ?? 0;
			return `C${[
				from[0] + handle,
				from[1] + startTangent * handle,
				to[0] - handle,
				to[1] - endTangent * handle,
				to[0],
				to[1]
			].map(roundTenth).join(",")}`;
		});
		return `M${roundTenth(first[0])},${roundTenth(first[1])}${curves.join("")}`;
	}

//#endregion
//#region src/content/charts/rating-chart/paths.ts
	function seriesPaths(plot, row) {
		const points = plot.times.flatMap((time, j) => {
			const value = row.values[j];
			return value === null || value === void 0 ? [] : [[plot.x(time), plot.y(value)]];
		});
		const line = monotoneCurve(points);
		const [first] = points;
		const last = points.at(-1);
		const area = first && last ? `${line}L${last[0]},${plot.bottom}L${first[0]},${plot.bottom}Z` : line;
		const heights = points.map(([, y]) => y);
		return {
			line,
			area,
			top: Math.min(...heights),
			low: Math.max(...heights)
		};
	}

//#endregion
//#region src/content/charts/rating-chart/sampling.ts
	const MAX_SAMPLES = 180;
	function sampleTimes(start, end) {
		const step = Math.max(1, Math.ceil((end - start) / DAY_MS / MAX_SAMPLES)) * DAY_MS;
		const times = [];
		for (let time = start; time < end; time += step) times.push(time);
		times.push(end);
		return times;
	}
	/** The rating at each time: the last one on or before it. */
	function ratingsAt(points, times) {
		let next = 0;
		let current = null;
		return times.map((time) => {
			for (let point = points[next]; point && point[0] <= time; point = points[next]) {
				current = point[1];
				next++;
			}
			return current;
		});
	}
	const playedBetween = (series, start, end) => series.points.some(([time]) => time >= start && time <= end);
	/**
	* Every series sampled on one time grid, so a series' path keeps the same
	* commands when the scale changes and the CSS can morph it (`d`).
	*/
	function sampleRange(series, start, end) {
		const times = sampleTimes(start, end);
		const anyPlayed = series.some((one) => playedBetween(one, start, end));
		return {
			times,
			rows: series.flatMap((one) => {
				if (anyPlayed && !playedBetween(one, start, end)) return [];
				const values = ratingsAt(one.points, times);
				return values.some((value) => value !== null) ? [{
					...one,
					values
				}] : [];
			})
		};
	}

//#endregion
//#region src/content/charts/rating-chart/thumb.ts
/**
	* Places the active range's highlight, one element that slides from the last
	* pill picked to the new one. It jumps without sliding the first time and
	* when the pills reflow, so it never flies in from nowhere.
	*/
	function createThumbPlacer(root, thumb) {
		let placedAt = "";
		return () => {
			const active = queryOne(root, "[data-cdc-range].active", HTMLElement);
			if (!active) return;
			const { offsetLeft, offsetTop, offsetWidth, offsetHeight } = active;
			const at = `${offsetLeft},${offsetTop},${offsetWidth}`;
			if (at === placedAt) return;
			const slide = placedAt !== "" && root.dataset.cdcSlide === "1";
			thumb.classList.toggle("cdc-rchart__thumb--still", !slide);
			setStyleProperty(thumb, "width", `${offsetWidth}px`);
			setStyleProperty(thumb, "height", `${offsetHeight}px`);
			setStyleProperty(thumb, "transform", `translate(${offsetLeft}px, ${offsetTop}px)`);
			placedAt = at;
			setData(root, "cdcSlide", null);
		};
	}

//#endregion
//#region src/content/charts/rating-chart/time-ticks.ts
	function dateFormats(locale) {
		const format = (options) => new Intl.DateTimeFormat(locale, {
			timeZone: "UTC",
			...options
		});
		return {
			day: format({
				day: "numeric",
				month: "short"
			}),
			month: format({ month: "short" }),
			monthYear: format({
				month: "short",
				year: "numeric"
			}),
			year: format({ year: "numeric" }),
			full: format({
				day: "numeric",
				month: "short",
				year: "numeric"
			})
		};
	}
	function dayTicks(start, end, formats) {
		return [
			1,
			2,
			3,
			4
		].map((k) => {
			const time = Math.round((start + (end - start) * k / 5) / DAY_MS) * DAY_MS;
			return [time, formats.day.format(time)];
		});
	}
	function monthTicks(start, end, formats) {
		const from = new Date(start);
		const ticks = [];
		let time = Date.UTC(from.getUTCFullYear(), from.getUTCMonth() + 1, 1);
		while (time <= end) {
			const format = new Date(time).getUTCMonth() === 0 ? formats.monthYear : formats.month;
			ticks.push([time, format.format(time)]);
			time = addMonths(time, 1);
		}
		return ticks;
	}
	function yearTicks(start, end, formats) {
		const ticks = [];
		for (let year = new Date(start).getUTCFullYear() + 1; Date.UTC(year, 0, 1) <= end; year++) {
			const time = Date.UTC(year, 0, 1);
			ticks.push([time, formats.year.format(time)]);
		}
		return ticks;
	}
	/** The date labels under the plot, thinned to one per 72px so they don't collide. */
	function timeTicks({ start, end, width }, formats) {
		const days = (end - start) / DAY_MS;
		let ticks;
		if (days <= 45) ticks = dayTicks(start, end, formats);
		else if (days <= 800) ticks = monthTicks(start, end, formats);
		else ticks = yearTicks(start, end, formats);
		const room = Math.max(1, Math.floor(width / 72));
		const every = Math.ceil(ticks.length / room);
		return ticks.filter((_, k) => k % every === 0);
	}

//#endregion
//#region src/content/charts/rating-chart/chart.ts
	function historySpan(series) {
		const firsts = series.flatMap(({ points }) => points.slice(0, 1).map(([time]) => time));
		const lasts = series.flatMap(({ points }) => points.slice(-1).map(([time]) => time));
		return {
			first: Math.min(...firsts),
			end: Math.max(todayUtc(), ...lasts)
		};
	}
	function setPath(path, data) {
		if (path) setStyleProperty(path, "d", `path("${data}")`);
	}
	/** The chart's state: the range, the ratings hidden, and what's drawn. */
	var RatingChart = class {
		#series;
		#parts;
		#span;
		#formats;
		#hidden = /* @__PURE__ */ new Set();
		#placeThumb;
		#range;
		#layout = null;
		#plot = null;
		constructor({ series, parts, span, range, formats }) {
			this.#series = series;
			this.#parts = parts;
			this.#span = span;
			this.#range = range;
			this.#formats = formats;
			this.#placeThumb = createThumbPlacer(parts.root, parts.thumb);
		}
		/** Draws it all again, for a new range or a new width; `animate` wipes the curves in. */
		draw(animate) {
			const { root, plot: plotElement, svg } = this.#parts;
			const start = rangeStart(this.#range, this.#span);
			const layout = {
				...sampleRange(this.#series, start, this.#span.end),
				width: Math.max(200, Math.round(plotElement.clientWidth)),
				start,
				end: this.#span.end
			};
			this.#layout = layout;
			const plot = scalePlot(layout, this.#hidden);
			const axis = {
				start,
				end: layout.end,
				width: layout.width - PADDING.left - PADDING.right
			};
			sizeSvg(svg, layout.width, 300);
			setHtml(svg, plotMarkup(plot, timeTicks(axis, this.#formats)));
			svg.classList.toggle("cdc-rchart__svg--intro", animate);
			this.#update();
			this.#renderLegend();
			for (const button of queryAll(root, "[data-cdc-range]", HTMLElement)) button.classList.toggle("active", button.dataset.cdcRange === this.#range);
			this.#placeThumb();
		}
		#update() {
			if (!this.#layout) return;
			const { svg } = this.#parts;
			const plot = scalePlot(this.#layout, this.#hidden);
			this.#plot = plot;
			for (const group of queryAll(svg, ".cdc-rchart__series", SVGElement)) {
				const row = plot.rows.find(({ index }) => index === Number(group.dataset.cdcSeries));
				if (!row) continue;
				group.classList.toggle("cdc-rchart__series--hidden", this.#hidden.has(row.index));
				const { line, area, top, low } = seriesPaths(plot, row);
				setPath(queryOne(group, ".cdc-rchart__line", SVGElement), line);
				setPath(queryOne(group, ".cdc-rchart__area", SVGElement), area);
				const gradient = queryOne(svg, `#${gradientId(row.index)}`, SVGElement);
				if (gradient) setAttributes(gradient, {
					y1: top,
					y2: Math.min(plot.bottom, low + 70)
				});
			}
			const axis = queryOne(svg, ".cdc-rchart__axis", SVGElement);
			if (!axis) return;
			for (const old of queryAll(axis, ".cdc-rchart__grid, .cdc-rchart__ylabel", Element)) old.remove();
			prependSvg(axis, ratingGrid(plot));
		}
		#renderLegend() {
			if (!this.#plot) return;
			const single = this.#series.length === 1;
			setHtml(this.#parts.legend, legendMarkup({
				rows: this.#plot.rows,
				hidden: this.#hidden,
				single
			}));
		}
		click(event) {
			const range = RangeKeySchema.safeParse(closestTo(event.target, "[data-cdc-range]", HTMLElement)?.dataset.cdcRange);
			if (range.success && range.data !== this.#range) {
				this.#range = range.data;
				writeStored(StorageKey.ratingChartRange, range.data);
				setData(this.#parts.root, "cdcSlide", "1");
				this.leave();
				this.draw(true);
			}
			const chip = closestTo(event.target, ".cdc-rchart__chip", HTMLElement);
			if (chip) this.#toggleSeries(Number(chip.dataset.cdcSeries));
		}
		#toggleSeries(index) {
			const shown = this.#plot?.rows.filter((row) => !this.#hidden.has(row.index)).length ?? 0;
			if (this.#hidden.has(index)) this.#hidden.delete(index);
			else if (shown > 1) this.#hidden.add(index);
			else return;
			this.leave();
			this.#update();
			this.#renderLegend();
		}
		hover(event) {
			if (this.#plot) showSample({
				event,
				plot: this.#plot,
				parts: this.#parts,
				formats: this.#formats
			});
		}
		leave() {
			hideSample(this.#parts);
		}
	};
	function redrawOnResize(plot, draw) {
		let lastWidth = 0;
		new ResizeObserver(() => {
			const width = Math.round(plot.clientWidth);
			if (Math.abs(width - lastWidth) < 2) return;
			const first = lastWidth === 0;
			lastWidth = width;
			draw(first);
		}).observe(plot);
	}
	/** Adds our chart to Lichess's rating history card. */
	function mountChart(host, series) {
		const span = historySpan(series);
		const range = initialRange(readStored(StorageKey.ratingChartRange, RangeKeySchema), span);
		const formats = dateFormats(pageLocale());
		const root = createElement("div", { className: "cdc-rchart" });
		setHtml(root, chartShell());
		host.append(root);
		host.classList.toggle("cdc-rchart-on", true);
		const parts = findParts(root);
		if (!parts) return;
		const chart = new RatingChart({
			series,
			parts,
			span,
			range,
			formats
		});
		root.addEventListener("click", (event) => chart.click(event));
		parts.svg.addEventListener("pointermove", (event) => chart.hover(event));
		parts.svg.addEventListener("pointerleave", () => chart.leave());
		redrawOnResize(parts.plot, (animate) => chart.draw(animate));
	}

//#endregion
//#region src/content/charts/rating-chart/inline-init.ts
	const MODULE = "'chart.ratingHistory'";
	const PERF_NAME = /singlePerfName:\s*'((?:[^'\\]|\\.)*)'/;
	function closingBracket(text, open) {
		let depth = 0;
		let inString = false;
		for (let k = open; k < text.length; k++) {
			const char = text[k];
			if (inString) {
				if (char === "\\") k++;
				else if (char === "\"") inString = false;
			} else if (char === "\"") inString = true;
			else if (char === "[") depth++;
			else if (char === "]") {
				depth--;
				if (depth === 0) return k;
			}
		}
		return -1;
	}
	/** The module's data, if this script calls it with a readable one. */
	function extractInlineInit(text) {
		const call = text.indexOf(MODULE);
		const key = call < 0 ? -1 : text.indexOf("data:", call);
		const open = key < 0 ? -1 : text.indexOf("[", key);
		if (open < 0) return null;
		const close = closingBracket(text, open);
		let data;
		try {
			data = JSON.parse(text.slice(open, close + 1));
		} catch {
			return null;
		}
		const name = PERF_NAME.exec(text.slice(close))?.[1];
		return {
			data,
			singlePerfName: name?.replaceAll(/\\(.)/g, "$1")
		};
	}
	function readInlineInit(root) {
		for (const script of queryAll(root, "script:not([src])", HTMLScriptElement)) {
			const init = extractInlineInit(script.textContent);
			if (init) return init;
		}
		return null;
	}

//#endregion
//#region src/shared/zod.ts
/** An optional field that reads as absent when malformed, rather than failing the whole parse. */
	function lenient(schema) {
		return _catch(optional(schema), void 0);
	}

//#endregion
//#region src/content/charts/rating-chart/schema.ts
/** A point; Lichess may add fields after the four we read. */
	const PointSchema = tuple([
		number$1(),
		number$1(),
		number$1(),
		number$1()
	], number$1());
	const SeriesSchema = object({
		name: string(),
		points: array(unknown())
	});
	const RatingHistorySchema = object({
		data: array(SeriesSchema).check(_minLength(1)),
		singlePerfName: lenient(string())
	});

//#endregion
//#region src/shared/charts/colors.ts
	const GAME_COLORS = /* @__PURE__ */ new Map([
		["ultraBullet", "#bd93f9"],
		["bullet", "#ffb86c"],
		["blitz", "#8be9fd"],
		["rapid", "#50fa7b"],
		["classical", "#7cf0cf"],
		["correspondence", "#f1fa8c"],
		["crazyhouse", "#ff79c6"],
		["chess960", "#9580ff"],
		["kingOfTheHill", "#f0b98d"],
		["threeCheck", "#ff6e96"],
		["antichess", "#a4abcb"],
		["atomic", "#ff5555"],
		["horde", "#b6f26c"],
		["racingKings", "#66d9ef"]
	]);
	const PUZZLE_COLOR = "#ff5555";
	const BLITZ_COLOR = "#8be9fd";
	const SERIES_COLORS = [...GAME_COLORS.values(), PUZZLE_COLOR];
	/** The color of the rating history's series at `index`. */
	const seriesColor = (index) => SERIES_COLORS[index % SERIES_COLORS.length] ?? BLITZ_COLOR;

//#endregion
//#region src/content/charts/rating-chart/series.ts
	function ratingPoints(points) {
		return points.flatMap((point) => {
			const result = PointSchema.safeParse(point);
			if (!result.success) return [];
			const [year, month, day, rating] = result.data;
			return [[Date.UTC(year, month, day), rating]];
		}).toSorted(([oneTime], [otherTime]) => oneTime - otherTime);
	}
	/** The series worth drawing: those with a point, or just the page's own rating. */
	function toSeries({ data, singlePerfName }) {
		const series = data.flatMap(({ name, points }, index) => {
			const ratings = ratingPoints(points);
			return ratings.length > 0 ? [{
				index,
				name,
				color: seriesColor(index),
				points: ratings
			}] : [];
		});
		return singlePerfName ? series.filter(({ name }) => name === singlePerfName) : series;
	}
	/** The series in the module's data, or null if it isn't the data we know. */
	function readSeries(value) {
		const result = RatingHistorySchema.safeParse(value);
		return result.success ? toSeries(result.data) : null;
	}

//#endregion
//#region src/content/charts/rating-chart/index.ts
	const HOST = ".rating-history-container:has(> .rating-history-container)";
	function pageSeries(initData) {
		const history = parseJson(initData, RatingHistorySchema);
		const series = history ? toSeries(history) : null;
		if (series && series.length > 0) return series;
		const inline = readInlineInit(document);
		return inline ? readSeries(inline) : null;
	}
	function boot(initData) {
		const host = queryOne(document, HOST, HTMLElement);
		if (!host) return;
		const series = pageSeries(initData);
		if (series?.length === 0) host.classList.toggle("cdc-rchart-none", true);
		if (!series || series.length === 0 || host.querySelector(".cdc-rchart")) return;
		mountChart(host, series);
	}
	const ratingChart = {
		name: "rating chart",
		start: () => readPageInitData(boot)
	};

//#endregion
//#region src/content/coach/blinks.ts
/** The loop's next blink from `frame` on, wrapping round to the first. */
	const nextBlink = (blinks, frame) => blinks.find(([first]) => first >= frame) ?? blinks[0];
	/** How long until the loop, now at `frame`, reaches `target`. */
	const delayUntil = ({ loop, fps }, frame, target) => (target - frame + loop) % loop / fps * 1e3;
	var Blinks = class {
		#options;
		#timer;
		/** The blink put off while the review panel was gone. */
		#waiting = null;
		#lastEnd = 0;
		#stopped = false;
		constructor(options) {
			this.#options = options;
		}
		/** Starts with the eyes open, at a random point of the loop. */
		start() {
			const { animation, meta } = this.#options;
			animation.goToAndStop(0, true);
			animation.addEventListener("complete", () => this.from(this.#lastEnd));
			this.from(Math.random() * meta.loop);
		}
		/** Schedules the next blink from `frame` on. */
		from(frame) {
			const blink = nextBlink(this.#options.meta.at, frame);
			if (!blink) return;
			this.#waiting = null;
			clearTimeout(this.#timer);
			const delay = delayUntil(this.#options.meta, frame, blink[0]);
			this.#timer = setTimeout(() => this.#play(blink), delay);
		}
		/** Plays the blink put off while the avatar was out of the page, if any. */
		resume() {
			if (this.#waiting !== null) this.from(this.#waiting);
		}
		stop() {
			this.#stopped = true;
			clearTimeout(this.#timer);
		}
		#play([first, last]) {
			if (this.#stopped) return;
			if (!this.#options.avatar.isConnected) {
				this.#waiting = first;
				return;
			}
			this.#lastEnd = last;
			this.#options.animation.playSegments([first, last + 1], true);
		}
	};

//#endregion
//#region src/content/coach/expression.ts
/** Where talking can stop after `frame`: the end of a syllable, the mouth back at rest. */
	const syllableEnd = ([, end, stops], frame) => stops.find((stop) => stop > frame + .5) ?? end;
	function hold(animation, frame) {
		animation.resetSegments(true);
		animation.goToAndStop(frame, true);
	}
	var Expression = class {
		#face;
		#lids;
		#meta;
		#wanted;
		#avatar;
		#mood;
		#talking = false;
		/** Set while a transition or a last syllable plays; called when the face's segment completes. */
		#pending = null;
		constructor({ face, lids, meta, mood, wanted, avatar }) {
			this.#face = face;
			this.#lids = lids;
			this.#meta = meta;
			this.#mood = mood;
			this.#wanted = wanted;
			this.#avatar = avatar;
		}
		/** Jumps to the mood's pose, so the features are drawn by the time the plate shows. */
		show() {
			this.#face.goToAndStop(this.#meta.face.pose[this.#mood], true);
			this.#lids.goToAndStop(this.#meta.lids.pose[this.#mood], true);
		}
		/** The face's segment is over (its transitions outlast the lids'). */
		finish() {
			const pending = this.#pending;
			this.#pending = null;
			pending?.();
		}
		/** Takes the next step towards what the review wants, unless one is still playing. */
		step() {
			if (this.#pending) return;
			const wanted = this.#wanted();
			const { mood } = wanted;
			const talking = wanted.talking && this.#avatar.isConnected;
			if (this.#talking && (mood !== this.#mood || !talking)) this.#stopTalking();
			else if (mood !== this.#mood) this.#changeMood(mood);
			else if (talking && !this.#talking) this.#startTalking();
		}
		#changeMood(mood) {
			const { face, lids } = this.#meta;
			const faceSegment = face.transitions[`${this.#mood}>${mood}`];
			const lidsSegment = lids.transitions[`${this.#mood}>${mood}`];
			const settle = () => {
				this.#mood = mood;
				hold(this.#face, face.pose[mood]);
				hold(this.#lids, lids.pose[mood]);
				this.step();
			};
			if (!faceSegment || !lidsSegment) {
				settle();
				return;
			}
			this.#pending = settle;
			this.#lids.playSegments([...lidsSegment], true);
			this.#face.playSegments([...faceSegment], true);
		}
		#startTalking() {
			const [start, end] = this.#meta.face.talk[this.#mood];
			this.#talking = true;
			this.#face.setLoop(true);
			this.#face.playSegments([start, end], true);
		}
		#stopTalking() {
			const loop = this.#meta.face.talk[this.#mood];
			const now = loop[0] + this.#face.currentFrame;
			this.#face.setLoop(false);
			this.#pending = () => {
				this.#talking = false;
				hold(this.#face, this.#meta.face.pose[this.#mood]);
				this.step();
			};
			this.#face.playSegments([now, syllableEnd(loop, now)], true);
		}
	};

//#endregion
//#region node_modules/.pnpm/lottie-web@5.13.0/node_modules/lottie-web/build/player/lottie_light.min.js
	var require_lottie_light_min = /* @__PURE__ */ __commonJSMin(((exports, module) => {
		"undefined" != typeof document && "undefined" != typeof navigator && function(t, e) {
			"object" == typeof exports && "undefined" != typeof module ? module.exports = e() : "function" == typeof define && define.amd ? define(e) : (t = "undefined" != typeof globalThis ? globalThis : t || self).lottie = e();
		}(exports, (function() {
			"use strict";
			var t = "", e = !1, i = -999999, s = function() {
				return t;
			};
			function a(t) {
				return document.createElement(t);
			}
			function r(t, e) {
				var i, s, a = t.length;
				for (i = 0; i < a; i += 1) for (var r in s = t[i].prototype) Object.prototype.hasOwnProperty.call(s, r) && (e.prototype[r] = s[r]);
			}
			function n(t) {
				function e() {}
				return e.prototype = t, e;
			}
			var o = function() {
				function t(t) {
					this.audios = [], this.audioFactory = t, this._volume = 1, this._isMuted = !1;
				}
				return t.prototype = {
					addAudio: function(t) {
						this.audios.push(t);
					},
					pause: function() {
						var t, e = this.audios.length;
						for (t = 0; t < e; t += 1) this.audios[t].pause();
					},
					resume: function() {
						var t, e = this.audios.length;
						for (t = 0; t < e; t += 1) this.audios[t].resume();
					},
					setRate: function(t) {
						var e, i = this.audios.length;
						for (e = 0; e < i; e += 1) this.audios[e].setRate(t);
					},
					createAudio: function(t) {
						return this.audioFactory ? this.audioFactory(t) : window.Howl ? new window.Howl({ src: [t] }) : {
							isPlaying: !1,
							play: function() {
								this.isPlaying = !0;
							},
							seek: function() {
								this.isPlaying = !1;
							},
							playing: function() {},
							rate: function() {},
							setVolume: function() {}
						};
					},
					setAudioFactory: function(t) {
						this.audioFactory = t;
					},
					setVolume: function(t) {
						this._volume = t, this._updateVolume();
					},
					mute: function() {
						this._isMuted = !0, this._updateVolume();
					},
					unmute: function() {
						this._isMuted = !1, this._updateVolume();
					},
					getVolume: function() {
						return this._volume;
					},
					_updateVolume: function() {
						var t, e = this.audios.length;
						for (t = 0; t < e; t += 1) this.audios[t].volume(this._volume * (this._isMuted ? 0 : 1));
					}
				}, function() {
					return new t();
				};
			}(), h = function() {
				function t(t, e) {
					var i, s = 0, a = [];
					switch (t) {
						case "int16":
						case "uint8c":
							i = 1;
							break;
						default: i = 1.1;
					}
					for (s = 0; s < e; s += 1) a.push(i);
					return a;
				}
				return "function" == typeof Uint8ClampedArray && "function" == typeof Float32Array ? function(e, i) {
					return "float32" === e ? new Float32Array(i) : "int16" === e ? new Int16Array(i) : "uint8c" === e ? new Uint8ClampedArray(i) : t(e, i);
				} : t;
			}();
			function l(t) {
				return Array.apply(null, { length: t });
			}
			function p(t) {
				return p = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
					return typeof t;
				} : function(t) {
					return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
				}, p(t);
			}
			var f = !0, d = null, m = null, c = "", u = /^((?!chrome|android).)*safari/i.test(navigator.userAgent), g = Math.pow, y = Math.sqrt, v = Math.floor, b = Math.min, _ = {};
			(function() {
				var t, e = [
					"abs",
					"acos",
					"acosh",
					"asin",
					"asinh",
					"atan",
					"atanh",
					"atan2",
					"ceil",
					"cbrt",
					"expm1",
					"clz32",
					"cos",
					"cosh",
					"exp",
					"floor",
					"fround",
					"hypot",
					"imul",
					"log",
					"log1p",
					"log2",
					"log10",
					"max",
					"min",
					"pow",
					"random",
					"round",
					"sign",
					"sin",
					"sinh",
					"sqrt",
					"tan",
					"tanh",
					"trunc",
					"E",
					"LN10",
					"LN2",
					"LOG10E",
					"LOG2E",
					"PI",
					"SQRT1_2",
					"SQRT2"
				], i = e.length;
				for (t = 0; t < i; t += 1) _[e[t]] = Math[e[t]];
			})(), _.random = Math.random, _.abs = function(t) {
				if ("object" === p(t) && t.length) {
					var e, i = l(t.length), s = t.length;
					for (e = 0; e < s; e += 1) i[e] = Math.abs(t[e]);
					return i;
				}
				return Math.abs(t);
			};
			var k = 150, P = Math.PI / 180, A = .5519;
			function x(t, e, i, s) {
				this.type = t, this.currentTime = e, this.totalTime = i, this.direction = s < 0 ? -1 : 1;
			}
			function w(t, e) {
				this.type = t, this.direction = e < 0 ? -1 : 1;
			}
			function D(t, e, i, s) {
				this.type = t, this.currentLoop = i, this.totalLoops = e, this.direction = s < 0 ? -1 : 1;
			}
			function C(t, e, i) {
				this.type = t, this.firstFrame = e, this.totalFrames = i;
			}
			function M(t, e) {
				this.type = t, this.target = e;
			}
			function T(t, e) {
				this.type = "renderFrameError", this.nativeError = t, this.currentTime = e;
			}
			function F(t) {
				this.type = "configError", this.nativeError = t;
			}
			var E, I = (E = 0, function() {
				return c + "__lottie_element_" + (E += 1);
			});
			function L(t, e, i) {
				var s, a, r, n, o, h = i * (1 - e), l = i * (1 - (o = 6 * t - (n = Math.floor(6 * t))) * e), p = i * (1 - (1 - o) * e);
				switch (n % 6) {
					case 0:
						s = i, a = p, r = h;
						break;
					case 1:
						s = l, a = i, r = h;
						break;
					case 2:
						s = h, a = i, r = p;
						break;
					case 3:
						s = h, a = l, r = i;
						break;
					case 4:
						s = p, a = h, r = i;
						break;
					case 5: s = i, a = h, r = l;
				}
				return [
					s,
					a,
					r
				];
			}
			function V(t, e, i) {
				var s, a = Math.max(t, e, i), r = Math.min(t, e, i), n = a - r, o = 0 === a ? 0 : n / a, h = a / 255;
				switch (a) {
					case r:
						s = 0;
						break;
					case t:
						s = e - i + n * (e < i ? 6 : 0), s /= 6 * n;
						break;
					case e:
						s = i - t + 2 * n, s /= 6 * n;
						break;
					case i: s = t - e + 4 * n, s /= 6 * n;
				}
				return [
					s,
					o,
					h
				];
			}
			function R(t, e) {
				var i = V(255 * t[0], 255 * t[1], 255 * t[2]);
				return i[1] += e, i[1] > 1 ? i[1] = 1 : i[1] <= 0 && (i[1] = 0), L(i[0], i[1], i[2]);
			}
			function z(t, e) {
				var i = V(255 * t[0], 255 * t[1], 255 * t[2]);
				return i[2] += e, i[2] > 1 ? i[2] = 1 : i[2] < 0 && (i[2] = 0), L(i[0], i[1], i[2]);
			}
			function O(t, e) {
				var i = V(255 * t[0], 255 * t[1], 255 * t[2]);
				return i[0] += e / 360, i[0] > 1 ? i[0] -= 1 : i[0] < 0 && (i[0] += 1), L(i[0], i[1], i[2]);
			}
			(function() {
				var t, e, i = [];
				for (t = 0; t < 256; t += 1) e = t.toString(16), i[t] = 1 === e.length ? "0" + e : e;
			})();
			var N = function() {
				return d;
			}, B = function() {
				return m;
			}, q = function(t) {
				k = t;
			}, j = function() {
				return k;
			};
			function W(t) {
				return document.createElementNS("http://www.w3.org/2000/svg", t);
			}
			function X(t) {
				return X = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
					return typeof t;
				} : function(t) {
					return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
				}, X(t);
			}
			var H = function() {
				var t, i, s = 1, a = [], r = {
					onmessage: function() {},
					postMessage: function(e) {
						t({ data: e });
					}
				}, n = { postMessage: function(t) {
					r.onmessage({ data: t });
				} };
				function o(i) {
					if (window.Worker && window.Blob && e) {
						var s = new Blob(["var _workerSelf = self; self.onmessage = ", i.toString()], { type: "text/javascript" }), a = URL.createObjectURL(s);
						return new Worker(a);
					}
					return t = i, r;
				}
				function h() {
					i || (i = o((function(t) {
						if (n.dataManager || (n.dataManager = function() {
							function t(a, r) {
								var n, o, h, l, p, d, m = a.length;
								for (o = 0; o < m; o += 1) if ("ks" in (n = a[o]) && !n.completed) {
									if (n.completed = !0, n.hasMask) {
										var c = n.masksProperties;
										for (l = c.length, h = 0; h < l; h += 1) if (c[h].pt.k.i) s(c[h].pt.k);
										else for (d = c[h].pt.k.length, p = 0; p < d; p += 1) c[h].pt.k[p].s && s(c[h].pt.k[p].s[0]), c[h].pt.k[p].e && s(c[h].pt.k[p].e[0]);
									}
									0 === n.ty ? (n.layers = e(n.refId, r), t(n.layers, r)) : 4 === n.ty ? i(n.shapes) : 5 === n.ty && f(n);
								}
							}
							function e(t, e) {
								var i = function(t, e) {
									for (var i = 0, s = e.length; i < s;) {
										if (e[i].id === t) return e[i];
										i += 1;
									}
									return null;
								}(t, e);
								return i ? i.layers.__used ? JSON.parse(JSON.stringify(i.layers)) : (i.layers.__used = !0, i.layers) : null;
							}
							function i(t) {
								var e = t.length - 1, a, r;
								for (; e >= 0; e -= 1) if ("sh" === t[e].ty) if (t[e].ks.k.i) s(t[e].ks.k);
								else for (r = t[e].ks.k.length, a = 0; a < r; a += 1) t[e].ks.k[a].s && s(t[e].ks.k[a].s[0]), t[e].ks.k[a].e && s(t[e].ks.k[a].e[0]);
								else "gr" === t[e].ty && i(t[e].it);
							}
							function s(t) {
								var e, i = t.i.length;
								for (e = 0; e < i; e += 1) t.i[e][0] += t.v[e][0], t.i[e][1] += t.v[e][1], t.o[e][0] += t.v[e][0], t.o[e][1] += t.v[e][1];
							}
							function a(t, e) {
								var i = e ? e.split(".") : [
									100,
									100,
									100
								];
								return t[0] > i[0] || !(i[0] > t[0]) && (t[1] > i[1] || !(i[1] > t[1]) && (t[2] > i[2] || !(i[2] > t[2]) && null));
							}
							var r, n = function() {
								var t = [
									4,
									4,
									14
								];
								function e(t) {
									var e, i, s, a = t.length;
									for (e = 0; e < a; e += 1) 5 === t[e].ty && (s = void 0, s = (i = t[e]).t.d, i.t.d = { k: [{
										s,
										t: 0
									}] });
								}
								return function(i) {
									if (a(t, i.v) && (e(i.layers), i.assets)) {
										var s, r = i.assets.length;
										for (s = 0; s < r; s += 1) i.assets[s].layers && e(i.assets[s].layers);
									}
								};
							}(), o = (r = [
								4,
								7,
								99
							], function(t) {
								if (t.chars && !a(r, t.v)) {
									var e, s = t.chars.length;
									for (e = 0; e < s; e += 1) {
										var n = t.chars[e];
										n.data && n.data.shapes && (i(n.data.shapes), n.data.ip = 0, n.data.op = 99999, n.data.st = 0, n.data.sr = 1, n.data.ks = {
											p: {
												k: [0, 0],
												a: 0
											},
											s: {
												k: [100, 100],
												a: 0
											},
											a: {
												k: [0, 0],
												a: 0
											},
											r: {
												k: 0,
												a: 0
											},
											o: {
												k: 100,
												a: 0
											}
										}, t.chars[e].t || (n.data.shapes.push({ ty: "no" }), n.data.shapes[0].it.push({
											p: {
												k: [0, 0],
												a: 0
											},
											s: {
												k: [100, 100],
												a: 0
											},
											a: {
												k: [0, 0],
												a: 0
											},
											r: {
												k: 0,
												a: 0
											},
											o: {
												k: 100,
												a: 0
											},
											sk: {
												k: 0,
												a: 0
											},
											sa: {
												k: 0,
												a: 0
											},
											ty: "tr"
										})));
									}
								}
							}), h = function() {
								var t = [
									5,
									7,
									15
								];
								function e(t) {
									var e, i, s = t.length;
									for (e = 0; e < s; e += 1) 5 === t[e].ty && (i = void 0, "number" == typeof (i = t[e].t.p).a && (i.a = {
										a: 0,
										k: i.a
									}), "number" == typeof i.p && (i.p = {
										a: 0,
										k: i.p
									}), "number" == typeof i.r && (i.r = {
										a: 0,
										k: i.r
									}));
								}
								return function(i) {
									if (a(t, i.v) && (e(i.layers), i.assets)) {
										var s, r = i.assets.length;
										for (s = 0; s < r; s += 1) i.assets[s].layers && e(i.assets[s].layers);
									}
								};
							}(), l = function() {
								var t = [
									4,
									1,
									9
								];
								function e(t) {
									var i, s, a, r = t.length;
									for (i = 0; i < r; i += 1) if ("gr" === t[i].ty) e(t[i].it);
									else if ("fl" === t[i].ty || "st" === t[i].ty) if (t[i].c.k && t[i].c.k[0].i) for (a = t[i].c.k.length, s = 0; s < a; s += 1) t[i].c.k[s].s && (t[i].c.k[s].s[0] /= 255, t[i].c.k[s].s[1] /= 255, t[i].c.k[s].s[2] /= 255, t[i].c.k[s].s[3] /= 255), t[i].c.k[s].e && (t[i].c.k[s].e[0] /= 255, t[i].c.k[s].e[1] /= 255, t[i].c.k[s].e[2] /= 255, t[i].c.k[s].e[3] /= 255);
									else t[i].c.k[0] /= 255, t[i].c.k[1] /= 255, t[i].c.k[2] /= 255, t[i].c.k[3] /= 255;
								}
								function i(t) {
									var i, s = t.length;
									for (i = 0; i < s; i += 1) 4 === t[i].ty && e(t[i].shapes);
								}
								return function(e) {
									if (a(t, e.v) && (i(e.layers), e.assets)) {
										var s, r = e.assets.length;
										for (s = 0; s < r; s += 1) e.assets[s].layers && i(e.assets[s].layers);
									}
								};
							}(), p = function() {
								var t = [
									4,
									4,
									18
								];
								function e(t) {
									var i = t.length - 1, s, a;
									for (; i >= 0; i -= 1) if ("sh" === t[i].ty) if (t[i].ks.k.i) t[i].ks.k.c = t[i].closed;
									else for (a = t[i].ks.k.length, s = 0; s < a; s += 1) t[i].ks.k[s].s && (t[i].ks.k[s].s[0].c = t[i].closed), t[i].ks.k[s].e && (t[i].ks.k[s].e[0].c = t[i].closed);
									else "gr" === t[i].ty && e(t[i].it);
								}
								function i(t) {
									var i, s, a, r, n, o, h = t.length;
									for (s = 0; s < h; s += 1) {
										if ((i = t[s]).hasMask) {
											var l = i.masksProperties;
											for (r = l.length, a = 0; a < r; a += 1) if (l[a].pt.k.i) l[a].pt.k.c = l[a].cl;
											else for (o = l[a].pt.k.length, n = 0; n < o; n += 1) l[a].pt.k[n].s && (l[a].pt.k[n].s[0].c = l[a].cl), l[a].pt.k[n].e && (l[a].pt.k[n].e[0].c = l[a].cl);
										}
										4 === i.ty && e(i.shapes);
									}
								}
								return function(e) {
									if (a(t, e.v) && (i(e.layers), e.assets)) {
										var s, r = e.assets.length;
										for (s = 0; s < r; s += 1) e.assets[s].layers && i(e.assets[s].layers);
									}
								};
							}();
							function f(t) {
								0 === t.t.a.length && t.t.p;
							}
							var d = { completeData: function(i) {
								i.__complete || (l(i), n(i), o(i), h(i), p(i), t(i.layers, i.assets), function(i, s) {
									if (i) {
										var a = 0, r = i.length;
										for (a = 0; a < r; a += 1) 1 === i[a].t && (i[a].data.layers = e(i[a].data.refId, s), t(i[a].data.layers, s));
									}
								}(i.chars, i.assets), i.__complete = !0);
							} };
							return d.checkColors = l, d.checkChars = o, d.checkPathProperties = h, d.checkShapes = p, d.completeLayers = t, d;
						}()), n.assetLoader || (n.assetLoader = function() {
							function t(t) {
								var e = t.getResponseHeader("content-type");
								return e && "json" === t.responseType && -1 !== e.indexOf("json") || t.response && "object" === X(t.response) ? t.response : t.response && "string" == typeof t.response ? JSON.parse(t.response) : t.responseText ? JSON.parse(t.responseText) : null;
							}
							return { load: function(e, i, s, a) {
								var r, n = new XMLHttpRequest();
								try {
									n.responseType = "json";
								} catch (t) {}
								n.onreadystatechange = function() {
									if (4 === n.readyState) if (200 === n.status) r = t(n), s(r);
									else try {
										r = t(n), s(r);
									} catch (t) {
										a && a(t);
									}
								};
								try {
									n.open([
										"G",
										"E",
										"T"
									].join(""), e, !0);
								} catch (t) {
									n.open([
										"G",
										"E",
										"T"
									].join(""), i + "/" + e, !0);
								}
								n.send();
							} };
						}()), "loadAnimation" === t.data.type) n.assetLoader.load(t.data.path, t.data.fullPath, (function(e) {
							n.dataManager.completeData(e), n.postMessage({
								id: t.data.id,
								payload: e,
								status: "success"
							});
						}), (function() {
							n.postMessage({
								id: t.data.id,
								status: "error"
							});
						}));
						else if ("complete" === t.data.type) {
							var e = t.data.animation;
							n.dataManager.completeData(e), n.postMessage({
								id: t.data.id,
								payload: e,
								status: "success"
							});
						} else "loadData" === t.data.type && n.assetLoader.load(t.data.path, t.data.fullPath, (function(e) {
							n.postMessage({
								id: t.data.id,
								payload: e,
								status: "success"
							});
						}), (function() {
							n.postMessage({
								id: t.data.id,
								status: "error"
							});
						}));
					})), i.onmessage = function(t) {
						var e = t.data, i = e.id, s = a[i];
						a[i] = null, "success" === e.status ? s.onComplete(e.payload) : s.onError && s.onError();
					});
				}
				function l(t, e) {
					var i = "processId_" + (s += 1);
					return a[i] = {
						onComplete: t,
						onError: e
					}, i;
				}
				return {
					loadAnimation: function(t, e, s) {
						h();
						var a = l(e, s);
						i.postMessage({
							type: "loadAnimation",
							path: t,
							fullPath: window.location.origin + window.location.pathname,
							id: a
						});
					},
					loadData: function(t, e, s) {
						h();
						var a = l(e, s);
						i.postMessage({
							type: "loadData",
							path: t,
							fullPath: window.location.origin + window.location.pathname,
							id: a
						});
					},
					completeAnimation: function(t, e, s) {
						h();
						var a = l(e, s);
						i.postMessage({
							type: "complete",
							animation: t,
							id: a
						});
					}
				};
			}(), Y = function() {
				var t = function() {
					var t = a("canvas");
					t.width = 1, t.height = 1;
					var e = t.getContext("2d");
					return e.fillStyle = "rgba(0,0,0,0)", e.fillRect(0, 0, 1, 1), t;
				}();
				function e() {
					this.loadedAssets += 1, this.loadedAssets === this.totalImages && this.loadedFootagesCount === this.totalFootages && this.imagesLoadedCb && this.imagesLoadedCb(null);
				}
				function i() {
					this.loadedFootagesCount += 1, this.loadedAssets === this.totalImages && this.loadedFootagesCount === this.totalFootages && this.imagesLoadedCb && this.imagesLoadedCb(null);
				}
				function s(t, e, i) {
					var s = "";
					if (t.e) s = t.p;
					else if (e) {
						var a = t.p;
						-1 !== a.indexOf("images/") && (a = a.split("/")[1]), s = e + a;
					} else s = i, s += t.u ? t.u : "", s += t.p;
					return s;
				}
				function r(t) {
					var e = 0, i = setInterval(function() {
						(t.getBBox().width || e > 500) && (this._imageLoaded(), clearInterval(i)), e += 1;
					}.bind(this), 50);
				}
				function n(t) {
					var e = { assetData: t }, i = s(t, this.assetsPath, this.path);
					return H.loadData(i, function(t) {
						e.img = t, this._footageLoaded();
					}.bind(this), function() {
						e.img = {}, this._footageLoaded();
					}.bind(this)), e;
				}
				function o() {
					this._imageLoaded = e.bind(this), this._footageLoaded = i.bind(this), this.testImageLoaded = r.bind(this), this.createFootageData = n.bind(this), this.assetsPath = "", this.path = "", this.totalImages = 0, this.totalFootages = 0, this.loadedAssets = 0, this.loadedFootagesCount = 0, this.imagesLoadedCb = null, this.images = [];
				}
				return o.prototype = {
					loadAssets: function(t, e) {
						var i;
						this.imagesLoadedCb = e;
						var s = t.length;
						for (i = 0; i < s; i += 1) t[i].layers || (t[i].t && "seq" !== t[i].t ? 3 === t[i].t && (this.totalFootages += 1, this.images.push(this.createFootageData(t[i]))) : (this.totalImages += 1, this.images.push(this._createImageData(t[i]))));
					},
					setAssetsPath: function(t) {
						this.assetsPath = t || "";
					},
					setPath: function(t) {
						this.path = t || "";
					},
					loadedImages: function() {
						return this.totalImages === this.loadedAssets;
					},
					loadedFootages: function() {
						return this.totalFootages === this.loadedFootagesCount;
					},
					destroy: function() {
						this.imagesLoadedCb = null, this.images.length = 0;
					},
					getAsset: function(t) {
						for (var e = 0, i = this.images.length; e < i;) {
							if (this.images[e].assetData === t) return this.images[e].img;
							e += 1;
						}
						return null;
					},
					createImgData: function(e) {
						var i = s(e, this.assetsPath, this.path), r = a("img");
						r.crossOrigin = "anonymous", r.addEventListener("load", this._imageLoaded, !1), r.addEventListener("error", function() {
							n.img = t, this._imageLoaded();
						}.bind(this), !1), r.src = i;
						var n = {
							img: r,
							assetData: e
						};
						return n;
					},
					createImageData: function(e) {
						var i = s(e, this.assetsPath, this.path), a = W("image");
						u ? this.testImageLoaded(a) : a.addEventListener("load", this._imageLoaded, !1), a.addEventListener("error", function() {
							r.img = t, this._imageLoaded();
						}.bind(this), !1), a.setAttributeNS("http://www.w3.org/1999/xlink", "href", i), this._elementHelper.append ? this._elementHelper.append(a) : this._elementHelper.appendChild(a);
						var r = {
							img: a,
							assetData: e
						};
						return r;
					},
					imageLoaded: e,
					footageLoaded: i,
					setCacheType: function(t, e) {
						"svg" === t ? (this._elementHelper = e, this._createImageData = this.createImageData.bind(this)) : this._createImageData = this.createImgData.bind(this);
					}
				}, o;
			}();
			function G() {}
			G.prototype = {
				triggerEvent: function(t, e) {
					if (this._cbs[t]) for (var i = this._cbs[t], s = 0; s < i.length; s += 1) i[s](e);
				},
				addEventListener: function(t, e) {
					return this._cbs[t] || (this._cbs[t] = []), this._cbs[t].push(e), function() {
						this.removeEventListener(t, e);
					}.bind(this);
				},
				removeEventListener: function(t, e) {
					if (e) {
						if (this._cbs[t]) {
							for (var i = 0, s = this._cbs[t].length; i < s;) this._cbs[t][i] === e && (this._cbs[t].splice(i, 1), i -= 1, s -= 1), i += 1;
							this._cbs[t].length || (this._cbs[t] = null);
						}
					} else this._cbs[t] = null;
				}
			};
			var K = function() {
				function t(t) {
					for (var e, i = t.split("\r\n"), s = {}, a = 0, r = 0; r < i.length; r += 1) 2 === (e = i[r].split(":")).length && (s[e[0]] = e[1].trim(), a += 1);
					if (0 === a) throw new Error();
					return s;
				}
				return function(e) {
					for (var i = [], s = 0; s < e.length; s += 1) {
						var a = e[s], r = {
							time: a.tm,
							duration: a.dr
						};
						try {
							r.payload = JSON.parse(e[s].cm);
						} catch (i) {
							try {
								r.payload = t(e[s].cm);
							} catch (t) {
								r.payload = { name: e[s].cm };
							}
						}
						i.push(r);
					}
					return i;
				};
			}(), J = function() {
				function t(t) {
					this.compositions.push(t);
				}
				return function() {
					function e(t) {
						for (var e = 0, i = this.compositions.length; e < i;) {
							if (this.compositions[e].data && this.compositions[e].data.nm === t) return this.compositions[e].prepareFrame && this.compositions[e].data.xt && this.compositions[e].prepareFrame(this.currentFrame), this.compositions[e].compInterface;
							e += 1;
						}
						return null;
					}
					return e.compositions = [], e.currentFrame = 0, e.registerComposition = t, e;
				};
			}(), U = {};
			function Z(t) {
				return Z = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
					return typeof t;
				} : function(t) {
					return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
				}, Z(t);
			}
			var Q = function() {
				this._cbs = [], this.name = "", this.path = "", this.isLoaded = !1, this.currentFrame = 0, this.currentRawFrame = 0, this.firstFrame = 0, this.totalFrames = 0, this.frameRate = 0, this.frameMult = 0, this.playSpeed = 1, this.playDirection = 1, this.playCount = 0, this.animationData = {}, this.assets = [], this.isPaused = !0, this.autoplay = !1, this.loop = !0, this.renderer = null, this.animationID = I(), this.assetsPath = "", this.timeCompleted = 0, this.segmentPos = 0, this.isSubframeEnabled = f, this.segments = [], this._idle = !0, this._completedLoop = !1, this.projectInterface = J(), this.imagePreloader = new Y(), this.audioController = o(), this.markers = [], this.configAnimation = this.configAnimation.bind(this), this.onSetupError = this.onSetupError.bind(this), this.onSegmentComplete = this.onSegmentComplete.bind(this), this.drawnFrameEvent = new x("drawnFrame", 0, 0, 0), this.expressionsPlugin = N();
			};
			r([G], Q), Q.prototype.setParams = function(t) {
				(t.wrapper || t.container) && (this.wrapper = t.wrapper || t.container);
				var e = "svg";
				t.animType ? e = t.animType : t.renderer && (e = t.renderer);
				var i = U[e];
				this.renderer = new i(this, t.rendererSettings), this.imagePreloader.setCacheType(e, this.renderer.globalData.defs), this.renderer.setProjectInterface(this.projectInterface), this.animType = e, "" === t.loop || null === t.loop || void 0 === t.loop || !0 === t.loop ? this.loop = !0 : !1 === t.loop ? this.loop = !1 : this.loop = parseInt(t.loop, 10), this.autoplay = !("autoplay" in t) || t.autoplay, this.name = t.name ? t.name : "", this.autoloadSegments = !Object.prototype.hasOwnProperty.call(t, "autoloadSegments") || t.autoloadSegments, this.assetsPath = t.assetsPath, this.initialSegment = t.initialSegment, t.audioFactory && this.audioController.setAudioFactory(t.audioFactory), t.animationData ? this.setupAnimation(t.animationData) : t.path && (-1 !== t.path.lastIndexOf("\\") ? this.path = t.path.substr(0, t.path.lastIndexOf("\\") + 1) : this.path = t.path.substr(0, t.path.lastIndexOf("/") + 1), this.fileName = t.path.substr(t.path.lastIndexOf("/") + 1), this.fileName = this.fileName.substr(0, this.fileName.lastIndexOf(".json")), H.loadAnimation(t.path, this.configAnimation, this.onSetupError));
			}, Q.prototype.onSetupError = function() {
				this.trigger("data_failed");
			}, Q.prototype.setupAnimation = function(t) {
				H.completeAnimation(t, this.configAnimation);
			}, Q.prototype.setData = function(t, e) {
				e && "object" !== Z(e) && (e = JSON.parse(e));
				var i = {
					wrapper: t,
					animationData: e
				}, s = t.attributes;
				i.path = s.getNamedItem("data-animation-path") ? s.getNamedItem("data-animation-path").value : s.getNamedItem("data-bm-path") ? s.getNamedItem("data-bm-path").value : s.getNamedItem("bm-path") ? s.getNamedItem("bm-path").value : "", i.animType = s.getNamedItem("data-anim-type") ? s.getNamedItem("data-anim-type").value : s.getNamedItem("data-bm-type") ? s.getNamedItem("data-bm-type").value : s.getNamedItem("bm-type") ? s.getNamedItem("bm-type").value : s.getNamedItem("data-bm-renderer") ? s.getNamedItem("data-bm-renderer").value : s.getNamedItem("bm-renderer") ? s.getNamedItem("bm-renderer").value : function() {
					if (U.canvas) return "canvas";
					for (var t in U) if (U[t]) return t;
					return "";
				}() || "canvas";
				var a = s.getNamedItem("data-anim-loop") ? s.getNamedItem("data-anim-loop").value : s.getNamedItem("data-bm-loop") ? s.getNamedItem("data-bm-loop").value : s.getNamedItem("bm-loop") ? s.getNamedItem("bm-loop").value : "";
				"false" === a ? i.loop = !1 : "true" === a ? i.loop = !0 : "" !== a && (i.loop = parseInt(a, 10));
				i.autoplay = "false" !== (s.getNamedItem("data-anim-autoplay") ? s.getNamedItem("data-anim-autoplay").value : s.getNamedItem("data-bm-autoplay") ? s.getNamedItem("data-bm-autoplay").value : !s.getNamedItem("bm-autoplay") || s.getNamedItem("bm-autoplay").value), i.name = s.getNamedItem("data-name") ? s.getNamedItem("data-name").value : s.getNamedItem("data-bm-name") ? s.getNamedItem("data-bm-name").value : s.getNamedItem("bm-name") ? s.getNamedItem("bm-name").value : "", "false" === (s.getNamedItem("data-anim-prerender") ? s.getNamedItem("data-anim-prerender").value : s.getNamedItem("data-bm-prerender") ? s.getNamedItem("data-bm-prerender").value : s.getNamedItem("bm-prerender") ? s.getNamedItem("bm-prerender").value : "") && (i.prerender = !1), i.path ? this.setParams(i) : this.trigger("destroy");
			}, Q.prototype.includeLayers = function(t) {
				t.op > this.animationData.op && (this.animationData.op = t.op, this.totalFrames = Math.floor(t.op - this.animationData.ip));
				var e, i, s = this.animationData.layers, a = s.length, r = t.layers, n = r.length;
				for (i = 0; i < n; i += 1) for (e = 0; e < a;) {
					if (s[e].id === r[i].id) {
						s[e] = r[i];
						break;
					}
					e += 1;
				}
				if ((t.chars || t.fonts) && (this.renderer.globalData.fontManager.addChars(t.chars), this.renderer.globalData.fontManager.addFonts(t.fonts, this.renderer.globalData.defs)), t.assets) for (a = t.assets.length, e = 0; e < a; e += 1) this.animationData.assets.push(t.assets[e]);
				this.animationData.__complete = !1, H.completeAnimation(this.animationData, this.onSegmentComplete);
			}, Q.prototype.onSegmentComplete = function(t) {
				this.animationData = t;
				var e = N();
				e && e.initExpressions(this), this.loadNextSegment();
			}, Q.prototype.loadNextSegment = function() {
				var t = this.animationData.segments;
				if (!t || 0 === t.length || !this.autoloadSegments) return this.trigger("data_ready"), void (this.timeCompleted = this.totalFrames);
				var e = t.shift();
				this.timeCompleted = e.time * this.frameRate;
				var i = this.path + this.fileName + "_" + this.segmentPos + ".json";
				this.segmentPos += 1, H.loadData(i, this.includeLayers.bind(this), function() {
					this.trigger("data_failed");
				}.bind(this));
			}, Q.prototype.loadSegments = function() {
				this.animationData.segments || (this.timeCompleted = this.totalFrames), this.loadNextSegment();
			}, Q.prototype.imagesLoaded = function() {
				this.trigger("loaded_images"), this.checkLoaded();
			}, Q.prototype.preloadImages = function() {
				this.imagePreloader.setAssetsPath(this.assetsPath), this.imagePreloader.setPath(this.path), this.imagePreloader.loadAssets(this.animationData.assets, this.imagesLoaded.bind(this));
			}, Q.prototype.configAnimation = function(t) {
				if (this.renderer) try {
					this.animationData = t, this.initialSegment ? (this.totalFrames = Math.floor(this.initialSegment[1] - this.initialSegment[0]), this.firstFrame = Math.round(this.initialSegment[0])) : (this.totalFrames = Math.floor(this.animationData.op - this.animationData.ip), this.firstFrame = Math.round(this.animationData.ip)), this.renderer.configAnimation(t), t.assets || (t.assets = []), this.assets = this.animationData.assets, this.frameRate = this.animationData.fr, this.frameMult = this.animationData.fr / 1e3, this.renderer.searchExtraCompositions(t.assets), this.markers = K(t.markers || []), this.trigger("config_ready"), this.preloadImages(), this.loadSegments(), this.updaFrameModifier(), this.waitForFontsLoaded(), this.isPaused && this.audioController.pause();
				} catch (t) {
					this.triggerConfigError(t);
				}
			}, Q.prototype.waitForFontsLoaded = function() {
				this.renderer && (this.renderer.globalData.fontManager.isLoaded ? this.checkLoaded() : setTimeout(this.waitForFontsLoaded.bind(this), 20));
			}, Q.prototype.checkLoaded = function() {
				if (!this.isLoaded && this.renderer.globalData.fontManager.isLoaded && (this.imagePreloader.loadedImages() || "canvas" !== this.renderer.rendererType) && this.imagePreloader.loadedFootages()) {
					this.isLoaded = !0;
					var t = N();
					t && t.initExpressions(this), this.renderer.initItems(), setTimeout(function() {
						this.trigger("DOMLoaded");
					}.bind(this), 0), this.gotoFrame(), this.autoplay && this.play();
				}
			}, Q.prototype.resize = function(t, e) {
				var i = "number" == typeof t ? t : void 0, s = "number" == typeof e ? e : void 0;
				this.renderer.updateContainerSize(i, s);
			}, Q.prototype.setSubframe = function(t) {
				this.isSubframeEnabled = !!t;
			}, Q.prototype.gotoFrame = function() {
				this.currentFrame = this.isSubframeEnabled ? this.currentRawFrame : ~~this.currentRawFrame, this.timeCompleted !== this.totalFrames && this.currentFrame > this.timeCompleted && (this.currentFrame = this.timeCompleted), this.trigger("enterFrame"), this.renderFrame(), this.trigger("drawnFrame");
			}, Q.prototype.renderFrame = function() {
				if (!1 !== this.isLoaded && this.renderer) try {
					this.expressionsPlugin && this.expressionsPlugin.resetFrame(), this.renderer.renderFrame(this.currentFrame + this.firstFrame);
				} catch (t) {
					this.triggerRenderFrameError(t);
				}
			}, Q.prototype.play = function(t) {
				t && this.name !== t || !0 === this.isPaused && (this.isPaused = !1, this.trigger("_play"), this.audioController.resume(), this._idle && (this._idle = !1, this.trigger("_active")));
			}, Q.prototype.pause = function(t) {
				t && this.name !== t || !1 === this.isPaused && (this.isPaused = !0, this.trigger("_pause"), this._idle = !0, this.trigger("_idle"), this.audioController.pause());
			}, Q.prototype.togglePause = function(t) {
				t && this.name !== t || (!0 === this.isPaused ? this.play() : this.pause());
			}, Q.prototype.stop = function(t) {
				t && this.name !== t || (this.pause(), this.playCount = 0, this._completedLoop = !1, this.setCurrentRawFrameValue(0));
			}, Q.prototype.getMarkerData = function(t) {
				for (var e, i = 0; i < this.markers.length; i += 1) if ((e = this.markers[i]).payload && e.payload.name === t) return e;
				return null;
			}, Q.prototype.goToAndStop = function(t, e, i) {
				if (!i || this.name === i) {
					var s = Number(t);
					if (isNaN(s)) {
						var a = this.getMarkerData(t);
						a && this.goToAndStop(a.time, !0);
					} else e ? this.setCurrentRawFrameValue(t) : this.setCurrentRawFrameValue(t * this.frameModifier);
					this.pause();
				}
			}, Q.prototype.goToAndPlay = function(t, e, i) {
				if (!i || this.name === i) {
					var s = Number(t);
					if (isNaN(s)) {
						var a = this.getMarkerData(t);
						a && (a.duration ? this.playSegments([a.time, a.time + a.duration], !0) : this.goToAndStop(a.time, !0));
					} else this.goToAndStop(s, e, i);
					this.play();
				}
			}, Q.prototype.advanceTime = function(t) {
				if (!0 !== this.isPaused && !1 !== this.isLoaded) {
					var e = this.currentRawFrame + t * this.frameModifier, i = !1;
					e >= this.totalFrames - 1 && this.frameModifier > 0 ? this.loop && this.playCount !== this.loop ? e >= this.totalFrames ? (this.playCount += 1, this.checkSegments(e % this.totalFrames) || (this.setCurrentRawFrameValue(e % this.totalFrames), this._completedLoop = !0, this.trigger("loopComplete"))) : this.setCurrentRawFrameValue(e) : this.checkSegments(e > this.totalFrames ? e % this.totalFrames : 0) || (i = !0, e = this.totalFrames - 1) : e < 0 ? this.checkSegments(e % this.totalFrames) || (!this.loop || this.playCount-- <= 0 && !0 !== this.loop ? (i = !0, e = 0) : (this.setCurrentRawFrameValue(this.totalFrames + e % this.totalFrames), this._completedLoop ? this.trigger("loopComplete") : this._completedLoop = !0)) : this.setCurrentRawFrameValue(e), i && (this.setCurrentRawFrameValue(e), this.pause(), this.trigger("complete"));
				}
			}, Q.prototype.adjustSegment = function(t, e) {
				this.playCount = 0, t[1] < t[0] ? (this.frameModifier > 0 && (this.playSpeed < 0 ? this.setSpeed(-this.playSpeed) : this.setDirection(-1)), this.totalFrames = t[0] - t[1], this.timeCompleted = this.totalFrames, this.firstFrame = t[1], this.setCurrentRawFrameValue(this.totalFrames - .001 - e)) : t[1] > t[0] && (this.frameModifier < 0 && (this.playSpeed < 0 ? this.setSpeed(-this.playSpeed) : this.setDirection(1)), this.totalFrames = t[1] - t[0], this.timeCompleted = this.totalFrames, this.firstFrame = t[0], this.setCurrentRawFrameValue(.001 + e)), this.trigger("segmentStart");
			}, Q.prototype.setSegment = function(t, e) {
				var i = -1;
				this.isPaused && (this.currentRawFrame + this.firstFrame < t ? i = t : this.currentRawFrame + this.firstFrame > e && (i = e - t)), this.firstFrame = t, this.totalFrames = e - t, this.timeCompleted = this.totalFrames, -1 !== i && this.goToAndStop(i, !0);
			}, Q.prototype.playSegments = function(t, e) {
				if (e && (this.segments.length = 0), "object" === Z(t[0])) {
					var i, s = t.length;
					for (i = 0; i < s; i += 1) this.segments.push(t[i]);
				} else this.segments.push(t);
				this.segments.length && e && this.adjustSegment(this.segments.shift(), 0), this.isPaused && this.play();
			}, Q.prototype.resetSegments = function(t) {
				this.segments.length = 0, this.segments.push([this.animationData.ip, this.animationData.op]), t && this.checkSegments(0);
			}, Q.prototype.checkSegments = function(t) {
				return !!this.segments.length && (this.adjustSegment(this.segments.shift(), t), !0);
			}, Q.prototype.destroy = function(t) {
				t && this.name !== t || !this.renderer || (this.renderer.destroy(), this.imagePreloader.destroy(), this.trigger("destroy"), this._cbs = null, this.onEnterFrame = null, this.onLoopComplete = null, this.onComplete = null, this.onSegmentStart = null, this.onDestroy = null, this.renderer = null, this.expressionsPlugin = null, this.imagePreloader = null, this.projectInterface = null);
			}, Q.prototype.setCurrentRawFrameValue = function(t) {
				this.currentRawFrame = t, this.gotoFrame();
			}, Q.prototype.setSpeed = function(t) {
				this.playSpeed = t, this.updaFrameModifier();
			}, Q.prototype.setDirection = function(t) {
				this.playDirection = t < 0 ? -1 : 1, this.updaFrameModifier();
			}, Q.prototype.setLoop = function(t) {
				this.loop = t;
			}, Q.prototype.setVolume = function(t, e) {
				e && this.name !== e || this.audioController.setVolume(t);
			}, Q.prototype.getVolume = function() {
				return this.audioController.getVolume();
			}, Q.prototype.mute = function(t) {
				t && this.name !== t || this.audioController.mute();
			}, Q.prototype.unmute = function(t) {
				t && this.name !== t || this.audioController.unmute();
			}, Q.prototype.updaFrameModifier = function() {
				this.frameModifier = this.frameMult * this.playSpeed * this.playDirection, this.audioController.setRate(this.playSpeed * this.playDirection);
			}, Q.prototype.getPath = function() {
				return this.path;
			}, Q.prototype.getAssetsPath = function(t) {
				var e = "";
				if (t.e) e = t.p;
				else if (this.assetsPath) {
					var i = t.p;
					-1 !== i.indexOf("images/") && (i = i.split("/")[1]), e = this.assetsPath + i;
				} else e = this.path, e += t.u ? t.u : "", e += t.p;
				return e;
			}, Q.prototype.getAssetData = function(t) {
				for (var e = 0, i = this.assets.length; e < i;) {
					if (t === this.assets[e].id) return this.assets[e];
					e += 1;
				}
				return null;
			}, Q.prototype.hide = function() {
				this.renderer.hide();
			}, Q.prototype.show = function() {
				this.renderer.show();
			}, Q.prototype.getDuration = function(t) {
				return t ? this.totalFrames : this.totalFrames / this.frameRate;
			}, Q.prototype.updateDocumentData = function(t, e, i) {
				try {
					this.renderer.getElementByPath(t).updateDocumentData(e, i);
				} catch (t) {}
			}, Q.prototype.trigger = function(t) {
				if (this._cbs && this._cbs[t]) switch (t) {
					case "enterFrame":
						this.triggerEvent(t, new x(t, this.currentFrame, this.totalFrames, this.frameModifier));
						break;
					case "drawnFrame":
						this.drawnFrameEvent.currentTime = this.currentFrame, this.drawnFrameEvent.totalTime = this.totalFrames, this.drawnFrameEvent.direction = this.frameModifier, this.triggerEvent(t, this.drawnFrameEvent);
						break;
					case "loopComplete":
						this.triggerEvent(t, new D(t, this.loop, this.playCount, this.frameMult));
						break;
					case "complete":
						this.triggerEvent(t, new w(t, this.frameMult));
						break;
					case "segmentStart":
						this.triggerEvent(t, new C(t, this.firstFrame, this.totalFrames));
						break;
					case "destroy":
						this.triggerEvent(t, new M(t, this));
						break;
					default: this.triggerEvent(t);
				}
				"enterFrame" === t && this.onEnterFrame && this.onEnterFrame.call(this, new x(t, this.currentFrame, this.totalFrames, this.frameMult)), "loopComplete" === t && this.onLoopComplete && this.onLoopComplete.call(this, new D(t, this.loop, this.playCount, this.frameMult)), "complete" === t && this.onComplete && this.onComplete.call(this, new w(t, this.frameMult)), "segmentStart" === t && this.onSegmentStart && this.onSegmentStart.call(this, new C(t, this.firstFrame, this.totalFrames)), "destroy" === t && this.onDestroy && this.onDestroy.call(this, new M(t, this));
			}, Q.prototype.triggerRenderFrameError = function(t) {
				var e = new T(t, this.currentFrame);
				this.triggerEvent("error", e), this.onError && this.onError.call(this, e);
			}, Q.prototype.triggerConfigError = function(t) {
				var e = new F(t, this.currentFrame);
				this.triggerEvent("error", e), this.onError && this.onError.call(this, e);
			};
			var $ = function() {
				var t = {}, e = [], i = 0, s = 0, r = 0, n = !0, o = !1;
				function h(t) {
					for (var i = 0, a = t.target; i < s;) e[i].animation === a && (e.splice(i, 1), i -= 1, s -= 1, a.isPaused || f()), i += 1;
				}
				function l(t, i) {
					if (!t) return null;
					for (var a = 0; a < s;) {
						if (e[a].elem === t && null !== e[a].elem) return e[a].animation;
						a += 1;
					}
					var r = new Q();
					return d(r, t), r.setData(t, i), r;
				}
				function p() {
					r += 1, u();
				}
				function f() {
					r -= 1;
				}
				function d(t, i) {
					t.addEventListener("destroy", h), t.addEventListener("_active", p), t.addEventListener("_idle", f), e.push({
						elem: i,
						animation: t
					}), s += 1;
				}
				function m(t) {
					var a, h = t - i;
					for (a = 0; a < s; a += 1) e[a].animation.advanceTime(h);
					i = t, r && !o ? window.requestAnimationFrame(m) : n = !0;
				}
				function c(t) {
					i = t, window.requestAnimationFrame(m);
				}
				function u() {
					!o && r && n && (window.requestAnimationFrame(c), n = !1);
				}
				return t.registerAnimation = l, t.loadAnimation = function(t) {
					var e = new Q();
					return d(e, null), e.setParams(t), e;
				}, t.setSpeed = function(t, i) {
					var a = 0;
					for (; a < s; a += 1) e[a].animation.setSpeed(t, i);
				}, t.setDirection = function(t, i) {
					var a = 0;
					for (; a < s; a += 1) e[a].animation.setDirection(t, i);
				}, t.play = function(t) {
					var i = 0;
					for (; i < s; i += 1) e[i].animation.play(t);
				}, t.pause = function(t) {
					var i = 0;
					for (; i < s; i += 1) e[i].animation.pause(t);
				}, t.stop = function(t) {
					var i = 0;
					for (; i < s; i += 1) e[i].animation.stop(t);
				}, t.togglePause = function(t) {
					var i = 0;
					for (; i < s; i += 1) e[i].animation.togglePause(t);
				}, t.searchAnimations = function(t, e, i) {
					var s, r = [].concat([].slice.call(document.getElementsByClassName("lottie")), [].slice.call(document.getElementsByClassName("bodymovin"))), n = r.length;
					for (s = 0; s < n; s += 1) i && r[s].setAttribute("data-bm-type", i), l(r[s], t);
					if (e && 0 === n) {
						i || (i = "svg");
						var o = document.getElementsByTagName("body")[0];
						o.innerText = "";
						var h = a("div");
						h.style.width = "100%", h.style.height = "100%", h.setAttribute("data-bm-type", i), o.appendChild(h), l(h, t);
					}
				}, t.resize = function() {
					var t = 0;
					for (; t < s; t += 1) e[t].animation.resize();
				}, t.goToAndStop = function(t, i, a) {
					var r = 0;
					for (; r < s; r += 1) e[r].animation.goToAndStop(t, i, a);
				}, t.destroy = function(t) {
					var i = s - 1;
					for (; i >= 0; i -= 1) e[i].animation.destroy(t);
				}, t.freeze = function() {
					o = !0;
				}, t.unfreeze = function() {
					o = !1, u();
				}, t.setVolume = function(t, i) {
					var a = 0;
					for (; a < s; a += 1) e[a].animation.setVolume(t, i);
				}, t.mute = function(t) {
					var i = 0;
					for (; i < s; i += 1) e[i].animation.mute(t);
				}, t.unmute = function(t) {
					var i = 0;
					for (; i < s; i += 1) e[i].animation.unmute(t);
				}, t.getRegisteredAnimations = function() {
					var t, i = e.length, s = [];
					for (t = 0; t < i; t += 1) s.push(e[t].animation);
					return s;
				}, t;
			}(), tt = function() {
				var t = { getBezierEasing: function(t, i, s, a, r) {
					var n = r || ("bez_" + t + "_" + i + "_" + s + "_" + a).replace(/\./g, "p");
					if (e[n]) return e[n];
					var o = new p([
						t,
						i,
						s,
						a
					]);
					return e[n] = o, o;
				} }, e = {};
				var i = 11, s = 1 / (i - 1), a = "function" == typeof Float32Array;
				function r(t, e) {
					return 1 - 3 * e + 3 * t;
				}
				function n(t, e) {
					return 3 * e - 6 * t;
				}
				function o(t) {
					return 3 * t;
				}
				function h(t, e, i) {
					return ((r(e, i) * t + n(e, i)) * t + o(e)) * t;
				}
				function l(t, e, i) {
					return 3 * r(e, i) * t * t + 2 * n(e, i) * t + o(e);
				}
				function p(t) {
					this._p = t, this._mSampleValues = a ? new Float32Array(i) : new Array(i), this._precomputed = !1, this.get = this.get.bind(this);
				}
				return p.prototype = {
					get: function(t) {
						var e = this._p[0], i = this._p[1], s = this._p[2], a = this._p[3];
						return this._precomputed || this._precompute(), e === i && s === a ? t : 0 === t ? 0 : 1 === t ? 1 : h(this._getTForX(t), i, a);
					},
					_precompute: function() {
						var t = this._p[0], e = this._p[1], i = this._p[2], s = this._p[3];
						this._precomputed = !0, t === e && i === s || this._calcSampleValues();
					},
					_calcSampleValues: function() {
						for (var t = this._p[0], e = this._p[2], a = 0; a < i; ++a) this._mSampleValues[a] = h(a * s, t, e);
					},
					_getTForX: function(t) {
						for (var e = this._p[0], a = this._p[2], r = this._mSampleValues, n = 0, o = 1, p = i - 1; o !== p && r[o] <= t; ++o) n += s;
						var f = n + (t - r[--o]) / (r[o + 1] - r[o]) * s, d = l(f, e, a);
						return d >= .001 ? function(t, e, i, s) {
							for (var a = 0; a < 4; ++a) {
								var r = l(e, i, s);
								if (0 === r) return e;
								e -= (h(e, i, s) - t) / r;
							}
							return e;
						}(t, f, e, a) : 0 === d ? f : function(t, e, i, s, a) {
							var r, n, o = 0;
							do
								(r = h(n = e + (i - e) / 2, s, a) - t) > 0 ? i = n : e = n;
							while (Math.abs(r) > 1e-7 && ++o < 10);
							return n;
						}(t, n, n + s, e, a);
					}
				}, t;
			}(), et = { double: function(t) {
				return t.concat(l(t.length));
			} }, it = function(t, e, i) {
				var s = 0, a = t, r = l(a);
				return {
					newElement: function() {
						return s ? r[s -= 1] : e();
					},
					release: function(t) {
						s === a && (r = et.double(r), a *= 2), i && i(t), r[s] = t, s += 1;
					}
				};
			}, st = it(8, (function() {
				return {
					addedLength: 0,
					percents: h("float32", j()),
					lengths: h("float32", j())
				};
			})), at = it(8, (function() {
				return {
					lengths: [],
					totalLength: 0
				};
			}), (function(t) {
				var e, i = t.lengths.length;
				for (e = 0; e < i; e += 1) st.release(t.lengths[e]);
				t.lengths.length = 0;
			}));
			var rt = function() {
				var t = Math;
				function e(t, e, i, s, a, r) {
					var n = t * s + e * a + i * r - a * s - r * t - i * e;
					return n > -.001 && n < .001;
				}
				var i = function(t, e, i, s) {
					var a, r, n, o, h, l, p = j(), f = 0, d = [], m = [], c = st.newElement();
					for (n = i.length, a = 0; a < p; a += 1) {
						for (h = a / (p - 1), l = 0, r = 0; r < n; r += 1) o = g(1 - h, 3) * t[r] + 3 * g(1 - h, 2) * h * i[r] + 3 * (1 - h) * g(h, 2) * s[r] + g(h, 3) * e[r], d[r] = o, null !== m[r] && (l += g(d[r] - m[r], 2)), m[r] = d[r];
						l && (f += l = y(l)), c.percents[a] = h, c.lengths[a] = f;
					}
					return c.addedLength = f, c;
				};
				function s(t) {
					this.segmentLength = 0, this.points = new Array(t);
				}
				function a(t, e) {
					this.partialLength = t, this.point = e;
				}
				var r, n = (r = {}, function(t, i, n, o) {
					var h = (t[0] + "_" + t[1] + "_" + i[0] + "_" + i[1] + "_" + n[0] + "_" + n[1] + "_" + o[0] + "_" + o[1]).replace(/\./g, "p");
					if (!r[h]) {
						var p, f, d, m, c, u, v, b = j(), _ = 0, k = null;
						2 === t.length && (t[0] !== i[0] || t[1] !== i[1]) && e(t[0], t[1], i[0], i[1], t[0] + n[0], t[1] + n[1]) && e(t[0], t[1], i[0], i[1], i[0] + o[0], i[1] + o[1]) && (b = 2);
						var P = new s(b);
						for (d = n.length, p = 0; p < b; p += 1) {
							for (v = l(d), c = p / (b - 1), u = 0, f = 0; f < d; f += 1) m = g(1 - c, 3) * t[f] + 3 * g(1 - c, 2) * c * (t[f] + n[f]) + 3 * (1 - c) * g(c, 2) * (i[f] + o[f]) + g(c, 3) * i[f], v[f] = m, null !== k && (u += g(v[f] - k[f], 2));
							_ += u = y(u), P.points[p] = new a(u, v), k = v;
						}
						P.segmentLength = _, r[h] = P;
					}
					return r[h];
				});
				function o(t, e) {
					var i = e.percents, s = e.lengths, a = i.length, r = v((a - 1) * t), n = t * e.addedLength, o = 0;
					if (r === a - 1 || 0 === r || n === s[r]) return i[r];
					for (var h = s[r] > n ? -1 : 1, l = !0; l;) if (s[r] <= n && s[r + 1] > n ? (o = (n - s[r]) / (s[r + 1] - s[r]), l = !1) : r += h, r < 0 || r >= a - 1) {
						if (r === a - 1) return i[r];
						l = !1;
					}
					return i[r] + (i[r + 1] - i[r]) * o;
				}
				var p = h("float32", 8);
				return {
					getSegmentsLength: function(t) {
						var e, s = at.newElement(), a = t.c, r = t.v, n = t.o, o = t.i, h = t._length, l = s.lengths, p = 0;
						for (e = 0; e < h - 1; e += 1) l[e] = i(r[e], r[e + 1], n[e], o[e + 1]), p += l[e].addedLength;
						return a && h && (l[e] = i(r[e], r[0], n[e], o[0]), p += l[e].addedLength), s.totalLength = p, s;
					},
					getNewSegment: function(e, i, s, a, r, n, h) {
						r < 0 ? r = 0 : r > 1 && (r = 1);
						var l, f = o(r, h), d = o(n = n > 1 ? 1 : n, h), m = e.length, c = 1 - f, u = 1 - d, g = c * c * c, y = f * c * c * 3, v = f * f * c * 3, b = f * f * f, _ = c * c * u, k = f * c * u + c * f * u + c * c * d, P = f * f * u + c * f * d + f * c * d, A = f * f * d, S = c * u * u, x = f * u * u + c * d * u + c * u * d, w = f * d * u + c * d * d + f * u * d, D = f * d * d, C = u * u * u, M = d * u * u + u * d * u + u * u * d, T = d * d * u + u * d * d + d * u * d, F = d * d * d;
						for (l = 0; l < m; l += 1) p[4 * l] = t.round(1e3 * (g * e[l] + y * s[l] + v * a[l] + b * i[l])) / 1e3, p[4 * l + 1] = t.round(1e3 * (_ * e[l] + k * s[l] + P * a[l] + A * i[l])) / 1e3, p[4 * l + 2] = t.round(1e3 * (S * e[l] + x * s[l] + w * a[l] + D * i[l])) / 1e3, p[4 * l + 3] = t.round(1e3 * (C * e[l] + M * s[l] + T * a[l] + F * i[l])) / 1e3;
						return p;
					},
					getPointInSegment: function(e, i, s, a, r, n) {
						var h = o(r, n), l = 1 - h;
						return [t.round(1e3 * (l * l * l * e[0] + (h * l * l + l * h * l + l * l * h) * s[0] + (h * h * l + l * h * h + h * l * h) * a[0] + h * h * h * i[0])) / 1e3, t.round(1e3 * (l * l * l * e[1] + (h * l * l + l * h * l + l * l * h) * s[1] + (h * h * l + l * h * h + h * l * h) * a[1] + h * h * h * i[1])) / 1e3];
					},
					buildBezierData: n,
					pointOnLine2D: e,
					pointOnLine3D: function(i, s, a, r, n, o, h, l, p) {
						if (0 === a && 0 === o && 0 === p) return e(i, s, r, n, h, l);
						var f, d = t.sqrt(t.pow(r - i, 2) + t.pow(n - s, 2) + t.pow(o - a, 2)), m = t.sqrt(t.pow(h - i, 2) + t.pow(l - s, 2) + t.pow(p - a, 2)), c = t.sqrt(t.pow(h - r, 2) + t.pow(l - n, 2) + t.pow(p - o, 2));
						return (f = d > m ? d > c ? d - m - c : c - m - d : c > m ? c - m - d : m - d - c) > -1e-4 && f < 1e-4;
					}
				};
			}(), nt = i, ot = Math.abs;
			function ht(t, e) {
				var i, s = this.offsetTime;
				"multidimensional" === this.propType && (i = h("float32", this.pv.length));
				for (var a, r, n, o, l, p, f, d, m, c = e.lastIndex, u = c, g = this.keyframes.length - 1, y = !0; y;) {
					if (a = this.keyframes[u], r = this.keyframes[u + 1], u === g - 1 && t >= r.t - s) {
						a.h && (a = r), c = 0;
						break;
					}
					if (r.t - s > t) {
						c = u;
						break;
					}
					u < g - 1 ? u += 1 : (c = 0, y = !1);
				}
				n = this.keyframesMetadata[u] || {};
				var v, b, _, k, A, S, x, w, D, C, M = r.t - s, T = a.t - s;
				if (a.to) {
					n.bezierData || (n.bezierData = rt.buildBezierData(a.s, r.s || a.e, a.to, a.ti));
					var F = n.bezierData;
					if (t >= M || t < T) {
						var E = t >= M ? F.points.length - 1 : 0;
						for (l = F.points[E].point.length, o = 0; o < l; o += 1) i[o] = F.points[E].point[o];
					} else {
						n.__fnct ? m = n.__fnct : (m = tt.getBezierEasing(a.o.x, a.o.y, a.i.x, a.i.y, a.n).get, n.__fnct = m), p = m((t - T) / (M - T));
						var I, L = F.segmentLength * p, V = e.lastFrame < t && e._lastKeyframeIndex === u ? e._lastAddedLength : 0;
						for (d = e.lastFrame < t && e._lastKeyframeIndex === u ? e._lastPoint : 0, y = !0, f = F.points.length; y;) {
							if (V += F.points[d].partialLength, 0 === L || 0 === p || d === F.points.length - 1) {
								for (l = F.points[d].point.length, o = 0; o < l; o += 1) i[o] = F.points[d].point[o];
								break;
							}
							if (L >= V && L < V + F.points[d + 1].partialLength) {
								for (I = (L - V) / F.points[d + 1].partialLength, l = F.points[d].point.length, o = 0; o < l; o += 1) i[o] = F.points[d].point[o] + (F.points[d + 1].point[o] - F.points[d].point[o]) * I;
								break;
							}
							d < f - 1 ? d += 1 : y = !1;
						}
						e._lastPoint = d, e._lastAddedLength = V - F.points[d].partialLength, e._lastKeyframeIndex = u;
					}
				} else {
					var R, z, O, N, B;
					if (g = a.s.length, v = r.s || a.e, this.sh && 1 !== a.h) if (t >= M) i[0] = v[0], i[1] = v[1], i[2] = v[2];
					else if (t <= T) i[0] = a.s[0], i[1] = a.s[1], i[2] = a.s[2];
					else {
						var q = lt(a.s), j = lt(v);
						b = i, _ = function(t, e, i) {
							var s, a, r, n, o, h = [], l = t[0], p = t[1], f = t[2], d = t[3], m = e[0], c = e[1], u = e[2], g = e[3];
							return (a = l * m + p * c + f * u + d * g) < 0 && (a = -a, m = -m, c = -c, u = -u, g = -g), 1 - a > 1e-6 ? (s = Math.acos(a), r = Math.sin(s), n = Math.sin((1 - i) * s) / r, o = Math.sin(i * s) / r) : (n = 1 - i, o = i), h[0] = n * l + o * m, h[1] = n * p + o * c, h[2] = n * f + o * u, h[3] = n * d + o * g, h;
						}(q, j, (t - T) / (M - T)), k = _[0], A = _[1], S = _[2], x = _[3], w = Math.atan2(2 * A * x - 2 * k * S, 1 - 2 * A * A - 2 * S * S), D = Math.asin(2 * k * A + 2 * S * x), C = Math.atan2(2 * k * x - 2 * A * S, 1 - 2 * k * k - 2 * S * S), b[0] = w / P, b[1] = D / P, b[2] = C / P;
					}
					else for (u = 0; u < g; u += 1) 1 !== a.h && (t >= M ? p = 1 : t < T ? p = 0 : (a.o.x.constructor === Array ? (n.__fnct || (n.__fnct = []), n.__fnct[u] ? m = n.__fnct[u] : (R = void 0 === a.o.x[u] ? a.o.x[0] : a.o.x[u], z = void 0 === a.o.y[u] ? a.o.y[0] : a.o.y[u], O = void 0 === a.i.x[u] ? a.i.x[0] : a.i.x[u], N = void 0 === a.i.y[u] ? a.i.y[0] : a.i.y[u], m = tt.getBezierEasing(R, z, O, N).get, n.__fnct[u] = m)) : n.__fnct ? m = n.__fnct : (R = a.o.x, z = a.o.y, O = a.i.x, N = a.i.y, m = tt.getBezierEasing(R, z, O, N).get, a.keyframeMetadata = m), p = m((t - T) / (M - T)))), v = r.s || a.e, B = 1 === a.h ? a.s[u] : a.s[u] + (v[u] - a.s[u]) * p, "multidimensional" === this.propType ? i[u] = B : i = B;
				}
				return e.lastIndex = c, i;
			}
			function lt(t) {
				var e = t[0] * P, i = t[1] * P, s = t[2] * P, a = Math.cos(e / 2), r = Math.cos(i / 2), n = Math.cos(s / 2), o = Math.sin(e / 2), h = Math.sin(i / 2), l = Math.sin(s / 2);
				return [
					o * h * n + a * r * l,
					o * r * n + a * h * l,
					a * h * n - o * r * l,
					a * r * n - o * h * l
				];
			}
			function pt() {
				var t = this.comp.renderedFrame - this.offsetTime, e = this.keyframes[0].t - this.offsetTime, i = this.keyframes[this.keyframes.length - 1].t - this.offsetTime;
				if (!(t === this._caching.lastFrame || this._caching.lastFrame !== nt && (this._caching.lastFrame >= i && t >= i || this._caching.lastFrame < e && t < e))) {
					this._caching.lastFrame >= t && (this._caching._lastKeyframeIndex = -1, this._caching.lastIndex = 0);
					var s = this.interpolateValue(t, this._caching);
					this.pv = s;
				}
				return this._caching.lastFrame = t, this.pv;
			}
			function ft(t) {
				var e;
				if ("unidimensional" === this.propType) e = t * this.mult, ot(this.v - e) > 1e-5 && (this.v = e, this._mdf = !0);
				else for (var i = 0, s = this.v.length; i < s;) e = t[i] * this.mult, ot(this.v[i] - e) > 1e-5 && (this.v[i] = e, this._mdf = !0), i += 1;
			}
			function dt() {
				if (this.elem.globalData.frameId !== this.frameId && this.effectsSequence.length) if (this.lock) this.setVValue(this.pv);
				else {
					var t;
					this.lock = !0, this._mdf = this._isFirstFrame;
					var e = this.effectsSequence.length, i = this.kf ? this.pv : this.data.k;
					for (t = 0; t < e; t += 1) i = this.effectsSequence[t](i);
					this.setVValue(i), this._isFirstFrame = !1, this.lock = !1, this.frameId = this.elem.globalData.frameId;
				}
			}
			function mt(t) {
				this.effectsSequence.push(t), this.container.addDynamicProperty(this);
			}
			function ct(t, e, i, s) {
				this.propType = "unidimensional", this.mult = i || 1, this.data = e, this.v = i ? e.k * i : e.k, this.pv = e.k, this._mdf = !1, this.elem = t, this.container = s, this.comp = t.comp, this.k = !1, this.kf = !1, this.vel = 0, this.effectsSequence = [], this._isFirstFrame = !0, this.getValue = dt, this.setVValue = ft, this.addEffect = mt;
			}
			function ut(t, e, i, s) {
				var a;
				this.propType = "multidimensional", this.mult = i || 1, this.data = e, this._mdf = !1, this.elem = t, this.container = s, this.comp = t.comp, this.k = !1, this.kf = !1, this.frameId = -1;
				var r = e.k.length;
				for (this.v = h("float32", r), this.pv = h("float32", r), this.vel = h("float32", r), a = 0; a < r; a += 1) this.v[a] = e.k[a] * this.mult, this.pv[a] = e.k[a];
				this._isFirstFrame = !0, this.effectsSequence = [], this.getValue = dt, this.setVValue = ft, this.addEffect = mt;
			}
			function gt(t, e, i, s) {
				this.propType = "unidimensional", this.keyframes = e.k, this.keyframesMetadata = [], this.offsetTime = t.data.st, this.frameId = -1, this._caching = {
					lastFrame: nt,
					lastIndex: 0,
					value: 0,
					_lastKeyframeIndex: -1
				}, this.k = !0, this.kf = !0, this.data = e, this.mult = i || 1, this.elem = t, this.container = s, this.comp = t.comp, this.v = nt, this.pv = nt, this._isFirstFrame = !0, this.getValue = dt, this.setVValue = ft, this.interpolateValue = ht, this.effectsSequence = [pt.bind(this)], this.addEffect = mt;
			}
			function yt(t, e, i, s) {
				var a;
				this.propType = "multidimensional";
				var r, n, o, l, p = e.k.length;
				for (a = 0; a < p - 1; a += 1) e.k[a].to && e.k[a].s && e.k[a + 1] && e.k[a + 1].s && (r = e.k[a].s, n = e.k[a + 1].s, o = e.k[a].to, l = e.k[a].ti, (2 === r.length && (r[0] !== n[0] || r[1] !== n[1]) && rt.pointOnLine2D(r[0], r[1], n[0], n[1], r[0] + o[0], r[1] + o[1]) && rt.pointOnLine2D(r[0], r[1], n[0], n[1], n[0] + l[0], n[1] + l[1]) || 3 === r.length && (r[0] !== n[0] || r[1] !== n[1] || r[2] !== n[2]) && rt.pointOnLine3D(r[0], r[1], r[2], n[0], n[1], n[2], r[0] + o[0], r[1] + o[1], r[2] + o[2]) && rt.pointOnLine3D(r[0], r[1], r[2], n[0], n[1], n[2], n[0] + l[0], n[1] + l[1], n[2] + l[2])) && (e.k[a].to = null, e.k[a].ti = null), r[0] === n[0] && r[1] === n[1] && 0 === o[0] && 0 === o[1] && 0 === l[0] && 0 === l[1] && (2 === r.length || r[2] === n[2] && 0 === o[2] && 0 === l[2]) && (e.k[a].to = null, e.k[a].ti = null));
				this.effectsSequence = [pt.bind(this)], this.data = e, this.keyframes = e.k, this.keyframesMetadata = [], this.offsetTime = t.data.st, this.k = !0, this.kf = !0, this._isFirstFrame = !0, this.mult = i || 1, this.elem = t, this.container = s, this.comp = t.comp, this.getValue = dt, this.setVValue = ft, this.interpolateValue = ht, this.frameId = -1;
				var f = e.k[0].s.length;
				for (this.v = h("float32", f), this.pv = h("float32", f), a = 0; a < f; a += 1) this.v[a] = nt, this.pv[a] = nt;
				this._caching = {
					lastFrame: nt,
					lastIndex: 0,
					value: h("float32", f)
				}, this.addEffect = mt;
			}
			var vt = { getProp: function(t, e, i, s, a) {
				var r;
				if (e.sid && (e = t.globalData.slotManager.getProp(e)), e.k.length) if ("number" == typeof e.k[0]) r = new ut(t, e, s, a);
				else switch (i) {
					case 0:
						r = new gt(t, e, s, a);
						break;
					case 1: r = new yt(t, e, s, a);
				}
				else r = new ct(t, e, s, a);
				return r.effectsSequence.length && a.addDynamicProperty(r), r;
			} };
			function bt() {}
			bt.prototype = {
				addDynamicProperty: function(t) {
					-1 === this.dynamicProperties.indexOf(t) && (this.dynamicProperties.push(t), this.container.addDynamicProperty(this), this._isAnimated = !0);
				},
				iterateDynamicProperties: function() {
					var t;
					this._mdf = !1;
					var e = this.dynamicProperties.length;
					for (t = 0; t < e; t += 1) this.dynamicProperties[t].getValue(), this.dynamicProperties[t]._mdf && (this._mdf = !0);
				},
				initDynamicPropertyContainer: function(t) {
					this.container = t, this.dynamicProperties = [], this._mdf = !1, this._isAnimated = !1;
				}
			};
			var _t = it(8, (function() {
				return h("float32", 2);
			}));
			function kt() {
				this.c = !1, this._length = 0, this._maxLength = 8, this.v = l(this._maxLength), this.o = l(this._maxLength), this.i = l(this._maxLength);
			}
			kt.prototype.setPathData = function(t, e) {
				this.c = t, this.setLength(e);
				for (var i = 0; i < e;) this.v[i] = _t.newElement(), this.o[i] = _t.newElement(), this.i[i] = _t.newElement(), i += 1;
			}, kt.prototype.setLength = function(t) {
				for (; this._maxLength < t;) this.doubleArrayLength();
				this._length = t;
			}, kt.prototype.doubleArrayLength = function() {
				this.v = this.v.concat(l(this._maxLength)), this.i = this.i.concat(l(this._maxLength)), this.o = this.o.concat(l(this._maxLength)), this._maxLength *= 2;
			}, kt.prototype.setXYAt = function(t, e, i, s, a) {
				var r;
				switch (this._length = Math.max(this._length, s + 1), this._length >= this._maxLength && this.doubleArrayLength(), i) {
					case "v":
						r = this.v;
						break;
					case "i":
						r = this.i;
						break;
					case "o":
						r = this.o;
						break;
					default: r = [];
				}
				(!r[s] || r[s] && !a) && (r[s] = _t.newElement()), r[s][0] = t, r[s][1] = e;
			}, kt.prototype.setTripleAt = function(t, e, i, s, a, r, n, o) {
				this.setXYAt(t, e, "v", n, o), this.setXYAt(i, s, "o", n, o), this.setXYAt(a, r, "i", n, o);
			}, kt.prototype.reverse = function() {
				var t = new kt();
				t.setPathData(this.c, this._length);
				var e = this.v, i = this.o, s = this.i, a = 0;
				this.c && (t.setTripleAt(e[0][0], e[0][1], s[0][0], s[0][1], i[0][0], i[0][1], 0, !1), a = 1);
				var r, n = this._length - 1, o = this._length;
				for (r = a; r < o; r += 1) t.setTripleAt(e[n][0], e[n][1], s[n][0], s[n][1], i[n][0], i[n][1], r, !1), n -= 1;
				return t;
			}, kt.prototype.length = function() {
				return this._length;
			};
			var Pt, At = ((Pt = it(4, (function() {
				return new kt();
			}), (function(t) {
				var e, i = t._length;
				for (e = 0; e < i; e += 1) _t.release(t.v[e]), _t.release(t.i[e]), _t.release(t.o[e]), t.v[e] = null, t.i[e] = null, t.o[e] = null;
				t._length = 0, t.c = !1;
			}))).clone = function(t) {
				var e, i = Pt.newElement(), s = void 0 === t._length ? t.v.length : t._length;
				for (i.setLength(s), i.c = t.c, e = 0; e < s; e += 1) i.setTripleAt(t.v[e][0], t.v[e][1], t.o[e][0], t.o[e][1], t.i[e][0], t.i[e][1], e);
				return i;
			}, Pt);
			function St() {
				this._length = 0, this._maxLength = 4, this.shapes = l(this._maxLength);
			}
			St.prototype.addShape = function(t) {
				this._length === this._maxLength && (this.shapes = this.shapes.concat(l(this._maxLength)), this._maxLength *= 2), this.shapes[this._length] = t, this._length += 1;
			}, St.prototype.releaseShapes = function() {
				var t = 0;
				for (; t < this._length; t += 1) At.release(this.shapes[t]);
				this._length = 0;
			};
			var xt, wt, Dt, Ct, Mt = (xt = {
				newShapeCollection: function() {
					return wt ? Ct[wt -= 1] : new St();
				},
				release: function(t) {
					var e, i = t._length;
					for (e = 0; e < i; e += 1) At.release(t.shapes[e]);
					t._length = 0, wt === Dt && (Ct = et.double(Ct), Dt *= 2), Ct[wt] = t, wt += 1;
				}
			}, wt = 0, Ct = l(Dt = 4), xt), Tt = function() {
				var t = -999999;
				function e(t, e, i) {
					var s, a, r, n, o, h, l, p, f, d = i.lastIndex, m = this.keyframes;
					if (t < m[0].t - this.offsetTime) s = m[0].s[0], r = !0, d = 0;
					else if (t >= m[m.length - 1].t - this.offsetTime) s = m[m.length - 1].s ? m[m.length - 1].s[0] : m[m.length - 2].e[0], r = !0;
					else {
						for (var c, u, g, y = d, v = m.length - 1, b = !0; b && (c = m[y], !((u = m[y + 1]).t - this.offsetTime > t));) y < v - 1 ? y += 1 : b = !1;
						if (g = this.keyframesMetadata[y] || {}, d = y, !(r = 1 === c.h)) {
							if (t >= u.t - this.offsetTime) p = 1;
							else if (t < c.t - this.offsetTime) p = 0;
							else {
								var _;
								g.__fnct ? _ = g.__fnct : (_ = tt.getBezierEasing(c.o.x, c.o.y, c.i.x, c.i.y).get, g.__fnct = _), p = _((t - (c.t - this.offsetTime)) / (u.t - this.offsetTime - (c.t - this.offsetTime)));
							}
							a = u.s ? u.s[0] : c.e[0];
						}
						s = c.s[0];
					}
					for (h = e._length, l = s.i[0].length, i.lastIndex = d, n = 0; n < h; n += 1) for (o = 0; o < l; o += 1) f = r ? s.i[n][o] : s.i[n][o] + (a.i[n][o] - s.i[n][o]) * p, e.i[n][o] = f, f = r ? s.o[n][o] : s.o[n][o] + (a.o[n][o] - s.o[n][o]) * p, e.o[n][o] = f, f = r ? s.v[n][o] : s.v[n][o] + (a.v[n][o] - s.v[n][o]) * p, e.v[n][o] = f;
				}
				function i() {
					var e = this.comp.renderedFrame - this.offsetTime, i = this.keyframes[0].t - this.offsetTime, s = this.keyframes[this.keyframes.length - 1].t - this.offsetTime, a = this._caching.lastFrame;
					return a !== t && (a < i && e < i || a > s && e > s) || (this._caching.lastIndex = a < e ? this._caching.lastIndex : 0, this.interpolateShape(e, this.pv, this._caching)), this._caching.lastFrame = e, this.pv;
				}
				function s() {
					this.paths = this.localShapeCollection;
				}
				function a(t) {
					(function(t, e) {
						if (t._length !== e._length || t.c !== e.c) return !1;
						var i, s = t._length;
						for (i = 0; i < s; i += 1) if (t.v[i][0] !== e.v[i][0] || t.v[i][1] !== e.v[i][1] || t.o[i][0] !== e.o[i][0] || t.o[i][1] !== e.o[i][1] || t.i[i][0] !== e.i[i][0] || t.i[i][1] !== e.i[i][1]) return !1;
						return !0;
					})(this.v, t) || (this.v = At.clone(t), this.localShapeCollection.releaseShapes(), this.localShapeCollection.addShape(this.v), this._mdf = !0, this.paths = this.localShapeCollection);
				}
				function n() {
					if (this.elem.globalData.frameId !== this.frameId) if (this.effectsSequence.length) if (this.lock) this.setVValue(this.pv);
					else {
						var t, e;
						this.lock = !0, this._mdf = !1, t = this.kf ? this.pv : this.data.ks ? this.data.ks.k : this.data.pt.k;
						var i = this.effectsSequence.length;
						for (e = 0; e < i; e += 1) t = this.effectsSequence[e](t);
						this.setVValue(t), this.lock = !1, this.frameId = this.elem.globalData.frameId;
					}
					else this._mdf = !1;
				}
				function o(t, e, i) {
					this.propType = "shape", this.comp = t.comp, this.container = t, this.elem = t, this.data = e, this.k = !1, this.kf = !1, this._mdf = !1;
					var a = 3 === i ? e.pt.k : e.ks.k;
					this.v = At.clone(a), this.pv = At.clone(this.v), this.localShapeCollection = Mt.newShapeCollection(), this.paths = this.localShapeCollection, this.paths.addShape(this.v), this.reset = s, this.effectsSequence = [];
				}
				function h(t) {
					this.effectsSequence.push(t), this.container.addDynamicProperty(this);
				}
				function l(e, a, r) {
					this.propType = "shape", this.comp = e.comp, this.elem = e, this.container = e, this.offsetTime = e.data.st, this.keyframes = 3 === r ? a.pt.k : a.ks.k, this.keyframesMetadata = [], this.k = !0, this.kf = !0;
					var n = this.keyframes[0].s[0].i.length;
					this.v = At.newElement(), this.v.setPathData(this.keyframes[0].s[0].c, n), this.pv = At.clone(this.v), this.localShapeCollection = Mt.newShapeCollection(), this.paths = this.localShapeCollection, this.paths.addShape(this.v), this.lastFrame = t, this.reset = s, this._caching = {
						lastFrame: t,
						lastIndex: 0
					}, this.effectsSequence = [i.bind(this)];
				}
				o.prototype.interpolateShape = e, o.prototype.getValue = n, o.prototype.setVValue = a, o.prototype.addEffect = h, l.prototype.getValue = n, l.prototype.interpolateShape = e, l.prototype.setVValue = a, l.prototype.addEffect = h;
				var p = function() {
					var t = A;
					function e(t, e) {
						this.v = At.newElement(), this.v.setPathData(!0, 4), this.localShapeCollection = Mt.newShapeCollection(), this.paths = this.localShapeCollection, this.localShapeCollection.addShape(this.v), this.d = e.d, this.elem = t, this.comp = t.comp, this.frameId = -1, this.initDynamicPropertyContainer(t), this.p = vt.getProp(t, e.p, 1, 0, this), this.s = vt.getProp(t, e.s, 1, 0, this), this.dynamicProperties.length ? this.k = !0 : (this.k = !1, this.convertEllToPath());
					}
					return e.prototype = {
						reset: s,
						getValue: function() {
							this.elem.globalData.frameId !== this.frameId && (this.frameId = this.elem.globalData.frameId, this.iterateDynamicProperties(), this._mdf && this.convertEllToPath());
						},
						convertEllToPath: function() {
							var e = this.p.v[0], i = this.p.v[1], s = this.s.v[0] / 2, a = this.s.v[1] / 2, r = 3 !== this.d, n = this.v;
							n.v[0][0] = e, n.v[0][1] = i - a, n.v[1][0] = r ? e + s : e - s, n.v[1][1] = i, n.v[2][0] = e, n.v[2][1] = i + a, n.v[3][0] = r ? e - s : e + s, n.v[3][1] = i, n.i[0][0] = r ? e - s * t : e + s * t, n.i[0][1] = i - a, n.i[1][0] = r ? e + s : e - s, n.i[1][1] = i - a * t, n.i[2][0] = r ? e + s * t : e - s * t, n.i[2][1] = i + a, n.i[3][0] = r ? e - s : e + s, n.i[3][1] = i + a * t, n.o[0][0] = r ? e + s * t : e - s * t, n.o[0][1] = i - a, n.o[1][0] = r ? e + s : e - s, n.o[1][1] = i + a * t, n.o[2][0] = r ? e - s * t : e + s * t, n.o[2][1] = i + a, n.o[3][0] = r ? e - s : e + s, n.o[3][1] = i - a * t;
						}
					}, r([bt], e), e;
				}(), f = function() {
					function t(t, e) {
						this.v = At.newElement(), this.v.setPathData(!0, 0), this.elem = t, this.comp = t.comp, this.data = e, this.frameId = -1, this.d = e.d, this.initDynamicPropertyContainer(t), 1 === e.sy ? (this.ir = vt.getProp(t, e.ir, 0, 0, this), this.is = vt.getProp(t, e.is, 0, .01, this), this.convertToPath = this.convertStarToPath) : this.convertToPath = this.convertPolygonToPath, this.pt = vt.getProp(t, e.pt, 0, 0, this), this.p = vt.getProp(t, e.p, 1, 0, this), this.r = vt.getProp(t, e.r, 0, P, this), this.or = vt.getProp(t, e.or, 0, 0, this), this.os = vt.getProp(t, e.os, 0, .01, this), this.localShapeCollection = Mt.newShapeCollection(), this.localShapeCollection.addShape(this.v), this.paths = this.localShapeCollection, this.dynamicProperties.length ? this.k = !0 : (this.k = !1, this.convertToPath());
					}
					return t.prototype = {
						reset: s,
						getValue: function() {
							this.elem.globalData.frameId !== this.frameId && (this.frameId = this.elem.globalData.frameId, this.iterateDynamicProperties(), this._mdf && this.convertToPath());
						},
						convertStarToPath: function() {
							var t, e, i, s, a = 2 * Math.floor(this.pt.v), r = 2 * Math.PI / a, n = !0, o = this.or.v, h = this.ir.v, l = this.os.v, p = this.is.v, f = 2 * Math.PI * o / (2 * a), d = 2 * Math.PI * h / (2 * a), m = -Math.PI / 2;
							m += this.r.v;
							var c = 3 === this.data.d ? -1 : 1;
							for (this.v._length = 0, t = 0; t < a; t += 1) {
								i = n ? l : p, s = n ? f : d;
								var u = (e = n ? o : h) * Math.cos(m), g = e * Math.sin(m), y = 0 === u && 0 === g ? 0 : g / Math.sqrt(u * u + g * g), v = 0 === u && 0 === g ? 0 : -u / Math.sqrt(u * u + g * g);
								u += +this.p.v[0], g += +this.p.v[1], this.v.setTripleAt(u, g, u - y * s * i * c, g - v * s * i * c, u + y * s * i * c, g + v * s * i * c, t, !0), n = !n, m += r * c;
							}
						},
						convertPolygonToPath: function() {
							var t, e = Math.floor(this.pt.v), i = 2 * Math.PI / e, s = this.or.v, a = this.os.v, r = 2 * Math.PI * s / (4 * e), n = .5 * -Math.PI, o = 3 === this.data.d ? -1 : 1;
							for (n += this.r.v, this.v._length = 0, t = 0; t < e; t += 1) {
								var h = s * Math.cos(n), l = s * Math.sin(n), p = 0 === h && 0 === l ? 0 : l / Math.sqrt(h * h + l * l), f = 0 === h && 0 === l ? 0 : -h / Math.sqrt(h * h + l * l);
								h += +this.p.v[0], l += +this.p.v[1], this.v.setTripleAt(h, l, h - p * r * a * o, l - f * r * a * o, h + p * r * a * o, l + f * r * a * o, t, !0), n += i * o;
							}
							this.paths.length = 0, this.paths[0] = this.v;
						}
					}, r([bt], t), t;
				}(), d = function() {
					function t(t, e) {
						this.v = At.newElement(), this.v.c = !0, this.localShapeCollection = Mt.newShapeCollection(), this.localShapeCollection.addShape(this.v), this.paths = this.localShapeCollection, this.elem = t, this.comp = t.comp, this.frameId = -1, this.d = e.d, this.initDynamicPropertyContainer(t), this.p = vt.getProp(t, e.p, 1, 0, this), this.s = vt.getProp(t, e.s, 1, 0, this), this.r = vt.getProp(t, e.r, 0, 0, this), this.dynamicProperties.length ? this.k = !0 : (this.k = !1, this.convertRectToPath());
					}
					return t.prototype = {
						convertRectToPath: function() {
							var t = this.p.v[0], e = this.p.v[1], i = this.s.v[0] / 2, s = this.s.v[1] / 2, a = b(i, s, this.r.v), r = a * (1 - A);
							this.v._length = 0, 2 === this.d || 1 === this.d ? (this.v.setTripleAt(t + i, e - s + a, t + i, e - s + a, t + i, e - s + r, 0, !0), this.v.setTripleAt(t + i, e + s - a, t + i, e + s - r, t + i, e + s - a, 1, !0), 0 !== a ? (this.v.setTripleAt(t + i - a, e + s, t + i - a, e + s, t + i - r, e + s, 2, !0), this.v.setTripleAt(t - i + a, e + s, t - i + r, e + s, t - i + a, e + s, 3, !0), this.v.setTripleAt(t - i, e + s - a, t - i, e + s - a, t - i, e + s - r, 4, !0), this.v.setTripleAt(t - i, e - s + a, t - i, e - s + r, t - i, e - s + a, 5, !0), this.v.setTripleAt(t - i + a, e - s, t - i + a, e - s, t - i + r, e - s, 6, !0), this.v.setTripleAt(t + i - a, e - s, t + i - r, e - s, t + i - a, e - s, 7, !0)) : (this.v.setTripleAt(t - i, e + s, t - i + r, e + s, t - i, e + s, 2), this.v.setTripleAt(t - i, e - s, t - i, e - s + r, t - i, e - s, 3))) : (this.v.setTripleAt(t + i, e - s + a, t + i, e - s + r, t + i, e - s + a, 0, !0), 0 !== a ? (this.v.setTripleAt(t + i - a, e - s, t + i - a, e - s, t + i - r, e - s, 1, !0), this.v.setTripleAt(t - i + a, e - s, t - i + r, e - s, t - i + a, e - s, 2, !0), this.v.setTripleAt(t - i, e - s + a, t - i, e - s + a, t - i, e - s + r, 3, !0), this.v.setTripleAt(t - i, e + s - a, t - i, e + s - r, t - i, e + s - a, 4, !0), this.v.setTripleAt(t - i + a, e + s, t - i + a, e + s, t - i + r, e + s, 5, !0), this.v.setTripleAt(t + i - a, e + s, t + i - r, e + s, t + i - a, e + s, 6, !0), this.v.setTripleAt(t + i, e + s - a, t + i, e + s - a, t + i, e + s - r, 7, !0)) : (this.v.setTripleAt(t - i, e - s, t - i + r, e - s, t - i, e - s, 1, !0), this.v.setTripleAt(t - i, e + s, t - i, e + s - r, t - i, e + s, 2, !0), this.v.setTripleAt(t + i, e + s, t + i - r, e + s, t + i, e + s, 3, !0)));
						},
						getValue: function() {
							this.elem.globalData.frameId !== this.frameId && (this.frameId = this.elem.globalData.frameId, this.iterateDynamicProperties(), this._mdf && this.convertRectToPath());
						},
						reset: s
					}, r([bt], t), t;
				}();
				return {
					getShapeProp: function(t, e, i) {
						var s;
						return 3 === i || 4 === i ? s = (3 === i ? e.pt : e.ks).k.length ? new l(t, e, i) : new o(t, e, i) : 5 === i ? s = new d(t, e) : 6 === i ? s = new p(t, e) : 7 === i && (s = new f(t, e)), s.k && t.addDynamicProperty(s), s;
					},
					getConstructorFunction: function() {
						return o;
					},
					getKeyframedConstructorFunction: function() {
						return l;
					}
				};
			}(), Ft = function() {
				var t = Math.cos, e = Math.sin, i = Math.tan, s = Math.round;
				function a() {
					return this.props[0] = 1, this.props[1] = 0, this.props[2] = 0, this.props[3] = 0, this.props[4] = 0, this.props[5] = 1, this.props[6] = 0, this.props[7] = 0, this.props[8] = 0, this.props[9] = 0, this.props[10] = 1, this.props[11] = 0, this.props[12] = 0, this.props[13] = 0, this.props[14] = 0, this.props[15] = 1, this;
				}
				function r(i) {
					if (0 === i) return this;
					var s = t(i), a = e(i);
					return this._t(s, -a, 0, 0, a, s, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);
				}
				function n(i) {
					if (0 === i) return this;
					var s = t(i), a = e(i);
					return this._t(1, 0, 0, 0, 0, s, -a, 0, 0, a, s, 0, 0, 0, 0, 1);
				}
				function o(i) {
					if (0 === i) return this;
					var s = t(i), a = e(i);
					return this._t(s, 0, a, 0, 0, 1, 0, 0, -a, 0, s, 0, 0, 0, 0, 1);
				}
				function l(i) {
					if (0 === i) return this;
					var s = t(i), a = e(i);
					return this._t(s, -a, 0, 0, a, s, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);
				}
				function p(t, e) {
					return this._t(1, e, t, 1, 0, 0);
				}
				function f(t, e) {
					return this.shear(i(t), i(e));
				}
				function d(s, a) {
					var r = t(a), n = e(a);
					return this._t(r, n, 0, 0, -n, r, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1)._t(1, 0, 0, 0, i(s), 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1)._t(r, -n, 0, 0, n, r, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);
				}
				function m(t, e, i) {
					return i || 0 === i || (i = 1), 1 === t && 1 === e && 1 === i ? this : this._t(t, 0, 0, 0, 0, e, 0, 0, 0, 0, i, 0, 0, 0, 0, 1);
				}
				function c(t, e, i, s, a, r, n, o, h, l, p, f, d, m, c, u) {
					return this.props[0] = t, this.props[1] = e, this.props[2] = i, this.props[3] = s, this.props[4] = a, this.props[5] = r, this.props[6] = n, this.props[7] = o, this.props[8] = h, this.props[9] = l, this.props[10] = p, this.props[11] = f, this.props[12] = d, this.props[13] = m, this.props[14] = c, this.props[15] = u, this;
				}
				function u(t, e, i) {
					return i = i || 0, 0 !== t || 0 !== e || 0 !== i ? this._t(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, t, e, i, 1) : this;
				}
				function g(t, e, i, s, a, r, n, o, h, l, p, f, d, m, c, u) {
					var g = this.props;
					if (1 === t && 0 === e && 0 === i && 0 === s && 0 === a && 1 === r && 0 === n && 0 === o && 0 === h && 0 === l && 1 === p && 0 === f) return g[12] = g[12] * t + g[15] * d, g[13] = g[13] * r + g[15] * m, g[14] = g[14] * p + g[15] * c, g[15] *= u, this._identityCalculated = !1, this;
					var y = g[0], v = g[1], b = g[2], _ = g[3], k = g[4], P = g[5], A = g[6], S = g[7], x = g[8], w = g[9], D = g[10], C = g[11], M = g[12], T = g[13], F = g[14], E = g[15];
					return g[0] = y * t + v * a + b * h + _ * d, g[1] = y * e + v * r + b * l + _ * m, g[2] = y * i + v * n + b * p + _ * c, g[3] = y * s + v * o + b * f + _ * u, g[4] = k * t + P * a + A * h + S * d, g[5] = k * e + P * r + A * l + S * m, g[6] = k * i + P * n + A * p + S * c, g[7] = k * s + P * o + A * f + S * u, g[8] = x * t + w * a + D * h + C * d, g[9] = x * e + w * r + D * l + C * m, g[10] = x * i + w * n + D * p + C * c, g[11] = x * s + w * o + D * f + C * u, g[12] = M * t + T * a + F * h + E * d, g[13] = M * e + T * r + F * l + E * m, g[14] = M * i + T * n + F * p + E * c, g[15] = M * s + T * o + F * f + E * u, this._identityCalculated = !1, this;
				}
				function y(t) {
					var e = t.props;
					return this.transform(e[0], e[1], e[2], e[3], e[4], e[5], e[6], e[7], e[8], e[9], e[10], e[11], e[12], e[13], e[14], e[15]);
				}
				function v() {
					return this._identityCalculated || (this._identity = !(1 !== this.props[0] || 0 !== this.props[1] || 0 !== this.props[2] || 0 !== this.props[3] || 0 !== this.props[4] || 1 !== this.props[5] || 0 !== this.props[6] || 0 !== this.props[7] || 0 !== this.props[8] || 0 !== this.props[9] || 1 !== this.props[10] || 0 !== this.props[11] || 0 !== this.props[12] || 0 !== this.props[13] || 0 !== this.props[14] || 1 !== this.props[15]), this._identityCalculated = !0), this._identity;
				}
				function b(t) {
					for (var e = 0; e < 16;) {
						if (t.props[e] !== this.props[e]) return !1;
						e += 1;
					}
					return !0;
				}
				function _(t) {
					var e = 0;
					for (; e < 16; e += 1) t.props[e] = this.props[e];
					return t;
				}
				function k(t) {
					var e = 0;
					for (; e < 16; e += 1) this.props[e] = t[e];
				}
				function P(t, e, i) {
					return {
						x: t * this.props[0] + e * this.props[4] + i * this.props[8] + this.props[12],
						y: t * this.props[1] + e * this.props[5] + i * this.props[9] + this.props[13],
						z: t * this.props[2] + e * this.props[6] + i * this.props[10] + this.props[14]
					};
				}
				function A(t, e, i) {
					return t * this.props[0] + e * this.props[4] + i * this.props[8] + this.props[12];
				}
				function S(t, e, i) {
					return t * this.props[1] + e * this.props[5] + i * this.props[9] + this.props[13];
				}
				function x(t, e, i) {
					return t * this.props[2] + e * this.props[6] + i * this.props[10] + this.props[14];
				}
				function w() {
					var t = this.props[0] * this.props[5] - this.props[1] * this.props[4], e = this.props[5] / t, i = -this.props[1] / t, s = -this.props[4] / t, a = this.props[0] / t, r = (this.props[4] * this.props[13] - this.props[5] * this.props[12]) / t, n = -(this.props[0] * this.props[13] - this.props[1] * this.props[12]) / t, o = new Ft();
					return o.props[0] = e, o.props[1] = i, o.props[4] = s, o.props[5] = a, o.props[12] = r, o.props[13] = n, o;
				}
				function D(t) {
					return this.getInverseMatrix().applyToPointArray(t[0], t[1], t[2] || 0);
				}
				function C(t) {
					var e, i = t.length, s = [];
					for (e = 0; e < i; e += 1) s[e] = D(t[e]);
					return s;
				}
				function M(t, e, i) {
					var s = h("float32", 6);
					if (this.isIdentity()) s[0] = t[0], s[1] = t[1], s[2] = e[0], s[3] = e[1], s[4] = i[0], s[5] = i[1];
					else {
						var a = this.props[0], r = this.props[1], n = this.props[4], o = this.props[5], l = this.props[12], p = this.props[13];
						s[0] = t[0] * a + t[1] * n + l, s[1] = t[0] * r + t[1] * o + p, s[2] = e[0] * a + e[1] * n + l, s[3] = e[0] * r + e[1] * o + p, s[4] = i[0] * a + i[1] * n + l, s[5] = i[0] * r + i[1] * o + p;
					}
					return s;
				}
				function T(t, e, i) {
					return this.isIdentity() ? [
						t,
						e,
						i
					] : [
						t * this.props[0] + e * this.props[4] + i * this.props[8] + this.props[12],
						t * this.props[1] + e * this.props[5] + i * this.props[9] + this.props[13],
						t * this.props[2] + e * this.props[6] + i * this.props[10] + this.props[14]
					];
				}
				function F(t, e) {
					if (this.isIdentity()) return t + "," + e;
					var i = this.props;
					return Math.round(100 * (t * i[0] + e * i[4] + i[12])) / 100 + "," + Math.round(100 * (t * i[1] + e * i[5] + i[13])) / 100;
				}
				function E() {
					for (var t = 0, e = this.props, i = "matrix3d("; t < 16;) i += s(1e4 * e[t]) / 1e4, i += 15 === t ? ")" : ",", t += 1;
					return i;
				}
				function I(t) {
					return t < 1e-6 && t > 0 || t > -1e-6 && t < 0 ? s(1e4 * t) / 1e4 : t;
				}
				function L() {
					var t = this.props;
					return "matrix(" + I(t[0]) + "," + I(t[1]) + "," + I(t[4]) + "," + I(t[5]) + "," + I(t[12]) + "," + I(t[13]) + ")";
				}
				return function() {
					this.reset = a, this.rotate = r, this.rotateX = n, this.rotateY = o, this.rotateZ = l, this.skew = f, this.skewFromAxis = d, this.shear = p, this.scale = m, this.setTransform = c, this.translate = u, this.transform = g, this.multiply = y, this.applyToPoint = P, this.applyToX = A, this.applyToY = S, this.applyToZ = x, this.applyToPointArray = T, this.applyToTriplePoints = M, this.applyToPointStringified = F, this.toCSS = E, this.to2dCSS = L, this.clone = _, this.cloneFromProps = k, this.equals = b, this.inversePoints = C, this.inversePoint = D, this.getInverseMatrix = w, this._t = this.transform, this.isIdentity = v, this._identity = !0, this._identityCalculated = !1, this.props = h("float32", 16), this.reset();
				};
			}();
			function Et(t) {
				return Et = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
					return typeof t;
				} : function(t) {
					return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
				}, Et(t);
			}
			var It = {}, Lt = "__[STANDALONE]__";
			function Vt() {
				$.searchAnimations();
			}
			It.play = $.play, It.pause = $.pause, It.setLocationHref = function(e) {
				t = e;
			}, It.togglePause = $.togglePause, It.setSpeed = $.setSpeed, It.setDirection = $.setDirection, It.stop = $.stop, It.searchAnimations = Vt, It.registerAnimation = $.registerAnimation, It.loadAnimation = function(t) {
				return $.loadAnimation(t);
			}, It.setSubframeRendering = function(t) {
				(function(t) {
					f = !!t;
				})(t);
			}, It.resize = $.resize, It.goToAndStop = $.goToAndStop, It.destroy = $.destroy, It.setQuality = function(t) {
				if ("string" == typeof t) switch (t) {
					case "high":
						q(200);
						break;
					default:
					case "medium":
						q(50);
						break;
					case "low": q(10);
				}
				else !isNaN(t) && t > 1 && q(t);
			}, It.inBrowser = function() {
				return "undefined" != typeof navigator;
			}, It.installPlugin = function(t, e) {
				"expressions" === t && (d = e);
			}, It.freeze = $.freeze, It.unfreeze = $.unfreeze, It.setVolume = $.setVolume, It.mute = $.mute, It.unmute = $.unmute, It.getRegisteredAnimations = $.getRegisteredAnimations, It.useWebWorker = function(t) {
				e = !!t;
			}, It.setIDPrefix = function(t) {
				c = t;
			}, It.__getFactory = function(t) {
				switch (t) {
					case "propertyFactory": return vt;
					case "shapePropertyFactory": return Tt;
					case "matrix": return Ft;
					default: return null;
				}
			}, It.version = "5.13.0";
			var Rt = "";
			if (Lt) {
				var zt = document.getElementsByTagName("script"), Ot = zt[zt.length - 1] || { src: "" };
				Rt = Ot.src ? Ot.src.replace(/^[^\?]+\??/, "") : "", function(t) {
					for (var e = Rt.split("&"), i = 0; i < e.length; i += 1) {
						var s = e[i].split("=");
						if (decodeURIComponent(s[0]) == t) return decodeURIComponent(s[1]);
					}
					return null;
				}("renderer");
			}
			var Nt = setInterval((function() {
				"complete" === document.readyState && (clearInterval(Nt), Vt());
			}), 100);
			try {
				"object" === ("undefined" == typeof exports ? "undefined" : Et(exports)) && "undefined" != typeof module || "function" == typeof define && define.amd || (window.bodymovin = It);
			} catch (t) {}
			var Bt = function() {
				var t = {}, e = {};
				return t.registerModifier = function(t, i) {
					e[t] || (e[t] = i);
				}, t.getModifier = function(t, i, s) {
					return new e[t](i, s);
				}, t;
			}();
			function qt() {}
			function jt() {}
			function Wt() {}
			qt.prototype.initModifierProperties = function() {}, qt.prototype.addShapeToModifier = function() {}, qt.prototype.addShape = function(t) {
				if (!this.closed) {
					t.sh.container.addDynamicProperty(t.sh);
					var e = {
						shape: t.sh,
						data: t,
						localShapeCollection: Mt.newShapeCollection()
					};
					this.shapes.push(e), this.addShapeToModifier(e), this._isAnimated && t.setAsAnimated();
				}
			}, qt.prototype.init = function(t, e) {
				this.shapes = [], this.elem = t, this.initDynamicPropertyContainer(t), this.initModifierProperties(t, e), this.frameId = i, this.closed = !1, this.k = !1, this.dynamicProperties.length ? this.k = !0 : this.getValue(!0);
			}, qt.prototype.processKeys = function() {
				this.elem.globalData.frameId !== this.frameId && (this.frameId = this.elem.globalData.frameId, this.iterateDynamicProperties());
			}, r([bt], qt), r([qt], jt), jt.prototype.initModifierProperties = function(t, e) {
				this.s = vt.getProp(t, e.s, 0, .01, this), this.e = vt.getProp(t, e.e, 0, .01, this), this.o = vt.getProp(t, e.o, 0, 0, this), this.sValue = 0, this.eValue = 0, this.getValue = this.processKeys, this.m = e.m, this._isAnimated = !!this.s.effectsSequence.length || !!this.e.effectsSequence.length || !!this.o.effectsSequence.length;
			}, jt.prototype.addShapeToModifier = function(t) {
				t.pathsData = [];
			}, jt.prototype.calculateShapeEdges = function(t, e, i, s, a) {
				var r = [];
				e <= 1 ? r.push({
					s: t,
					e
				}) : t >= 1 ? r.push({
					s: t - 1,
					e: e - 1
				}) : (r.push({
					s: t,
					e: 1
				}), r.push({
					s: 0,
					e: e - 1
				}));
				var n, o, h = [], l = r.length;
				for (n = 0; n < l; n += 1) {
					var p, f;
					if (!((o = r[n]).e * a < s || o.s * a > s + i)) p = o.s * a <= s ? 0 : (o.s * a - s) / i, f = o.e * a >= s + i ? 1 : (o.e * a - s) / i, h.push([p, f]);
				}
				return h.length || h.push([0, 0]), h;
			}, jt.prototype.releasePathsData = function(t) {
				var e, i = t.length;
				for (e = 0; e < i; e += 1) at.release(t[e]);
				return t.length = 0, t;
			}, jt.prototype.processShapes = function(t) {
				var e, i, s, a;
				if (this._mdf || t) {
					var r = this.o.v % 360 / 360;
					if (r < 0 && (r += 1), (e = this.s.v > 1 ? 1 + r : this.s.v < 0 ? 0 + r : this.s.v + r) > (i = this.e.v > 1 ? 1 + r : this.e.v < 0 ? 0 + r : this.e.v + r)) {
						var n = e;
						e = i, i = n;
					}
					e = 1e-4 * Math.round(1e4 * e), i = 1e-4 * Math.round(1e4 * i), this.sValue = e, this.eValue = i;
				} else e = this.sValue, i = this.eValue;
				var o, h, l, p, f, d = this.shapes.length, m = 0;
				if (i === e) for (a = 0; a < d; a += 1) this.shapes[a].localShapeCollection.releaseShapes(), this.shapes[a].shape._mdf = !0, this.shapes[a].shape.paths = this.shapes[a].localShapeCollection, this._mdf && (this.shapes[a].pathsData.length = 0);
				else if (1 === i && 0 === e || 0 === i && 1 === e) {
					if (this._mdf) for (a = 0; a < d; a += 1) this.shapes[a].pathsData.length = 0, this.shapes[a].shape._mdf = !0;
				} else {
					var c, u, g = [];
					for (a = 0; a < d; a += 1) if ((c = this.shapes[a]).shape._mdf || this._mdf || t || 2 === this.m) {
						if (h = (s = c.shape.paths)._length, f = 0, !c.shape._mdf && c.pathsData.length) f = c.totalShapeLength;
						else {
							for (l = this.releasePathsData(c.pathsData), o = 0; o < h; o += 1) p = rt.getSegmentsLength(s.shapes[o]), l.push(p), f += p.totalLength;
							c.totalShapeLength = f, c.pathsData = l;
						}
						m += f, c.shape._mdf = !0;
					} else c.shape.paths = c.localShapeCollection;
					var y, v = e, b = i, _ = 0;
					for (a = d - 1; a >= 0; a -= 1) if ((c = this.shapes[a]).shape._mdf) {
						for ((u = c.localShapeCollection).releaseShapes(), 2 === this.m && d > 1 ? (y = this.calculateShapeEdges(e, i, c.totalShapeLength, _, m), _ += c.totalShapeLength) : y = [[v, b]], h = y.length, o = 0; o < h; o += 1) {
							v = y[o][0], b = y[o][1], g.length = 0, b <= 1 ? g.push({
								s: c.totalShapeLength * v,
								e: c.totalShapeLength * b
							}) : v >= 1 ? g.push({
								s: c.totalShapeLength * (v - 1),
								e: c.totalShapeLength * (b - 1)
							}) : (g.push({
								s: c.totalShapeLength * v,
								e: c.totalShapeLength
							}), g.push({
								s: 0,
								e: c.totalShapeLength * (b - 1)
							}));
							var k = this.addShapes(c, g[0]);
							if (g[0].s !== g[0].e) {
								if (g.length > 1) if (c.shape.paths.shapes[c.shape.paths._length - 1].c) {
									var P = k.pop();
									this.addPaths(k, u), k = this.addShapes(c, g[1], P);
								} else this.addPaths(k, u), k = this.addShapes(c, g[1]);
								this.addPaths(k, u);
							}
						}
						c.shape.paths = u;
					}
				}
			}, jt.prototype.addPaths = function(t, e) {
				var i, s = t.length;
				for (i = 0; i < s; i += 1) e.addShape(t[i]);
			}, jt.prototype.addSegment = function(t, e, i, s, a, r, n) {
				a.setXYAt(e[0], e[1], "o", r), a.setXYAt(i[0], i[1], "i", r + 1), n && a.setXYAt(t[0], t[1], "v", r), a.setXYAt(s[0], s[1], "v", r + 1);
			}, jt.prototype.addSegmentFromArray = function(t, e, i, s) {
				e.setXYAt(t[1], t[5], "o", i), e.setXYAt(t[2], t[6], "i", i + 1), s && e.setXYAt(t[0], t[4], "v", i), e.setXYAt(t[3], t[7], "v", i + 1);
			}, jt.prototype.addShapes = function(t, e, i) {
				var s, a, r, n, o, h, l, p, f = t.pathsData, d = t.shape.paths.shapes, m = t.shape.paths._length, c = 0, u = [], g = !0;
				for (i ? (o = i._length, p = i._length) : (i = At.newElement(), o = 0, p = 0), u.push(i), s = 0; s < m; s += 1) {
					for (h = f[s].lengths, i.c = d[s].c, r = d[s].c ? h.length : h.length + 1, a = 1; a < r; a += 1) if (c + (n = h[a - 1]).addedLength < e.s) c += n.addedLength, i.c = !1;
					else {
						if (c > e.e) {
							i.c = !1;
							break;
						}
						e.s <= c && e.e >= c + n.addedLength ? (this.addSegment(d[s].v[a - 1], d[s].o[a - 1], d[s].i[a], d[s].v[a], i, o, g), g = !1) : (l = rt.getNewSegment(d[s].v[a - 1], d[s].v[a], d[s].o[a - 1], d[s].i[a], (e.s - c) / n.addedLength, (e.e - c) / n.addedLength, h[a - 1]), this.addSegmentFromArray(l, i, o, g), g = !1, i.c = !1), c += n.addedLength, o += 1;
					}
					if (d[s].c && h.length) {
						if (n = h[a - 1], c <= e.e) {
							var y = h[a - 1].addedLength;
							e.s <= c && e.e >= c + y ? (this.addSegment(d[s].v[a - 1], d[s].o[a - 1], d[s].i[0], d[s].v[0], i, o, g), g = !1) : (l = rt.getNewSegment(d[s].v[a - 1], d[s].v[0], d[s].o[a - 1], d[s].i[0], (e.s - c) / y, (e.e - c) / y, h[a - 1]), this.addSegmentFromArray(l, i, o, g), g = !1, i.c = !1);
						} else i.c = !1;
						c += n.addedLength, o += 1;
					}
					if (i._length && (i.setXYAt(i.v[p][0], i.v[p][1], "i", p), i.setXYAt(i.v[i._length - 1][0], i.v[i._length - 1][1], "o", i._length - 1)), c > e.e) break;
					s < m - 1 && (i = At.newElement(), g = !0, u.push(i), o = 0);
				}
				return u;
			}, r([qt], Wt), Wt.prototype.initModifierProperties = function(t, e) {
				this.getValue = this.processKeys, this.amount = vt.getProp(t, e.a, 0, null, this), this._isAnimated = !!this.amount.effectsSequence.length;
			}, Wt.prototype.processPath = function(t, e) {
				var i = e / 100, s = [0, 0], a = t._length, r = 0;
				for (r = 0; r < a; r += 1) s[0] += t.v[r][0], s[1] += t.v[r][1];
				s[0] /= a, s[1] /= a;
				var n, o, h, l, p, f, d = At.newElement();
				for (d.c = t.c, r = 0; r < a; r += 1) n = t.v[r][0] + (s[0] - t.v[r][0]) * i, o = t.v[r][1] + (s[1] - t.v[r][1]) * i, h = t.o[r][0] + (s[0] - t.o[r][0]) * -i, l = t.o[r][1] + (s[1] - t.o[r][1]) * -i, p = t.i[r][0] + (s[0] - t.i[r][0]) * -i, f = t.i[r][1] + (s[1] - t.i[r][1]) * -i, d.setTripleAt(n, o, h, l, p, f, r);
				return d;
			}, Wt.prototype.processShapes = function(t) {
				var e, i, s, a, r, n, o = this.shapes.length, h = this.amount.v;
				if (0 !== h) for (i = 0; i < o; i += 1) {
					if (n = (r = this.shapes[i]).localShapeCollection, r.shape._mdf || this._mdf || t) for (n.releaseShapes(), r.shape._mdf = !0, e = r.shape.paths.shapes, a = r.shape.paths._length, s = 0; s < a; s += 1) n.addShape(this.processPath(e[s], h));
					r.shape.paths = r.localShapeCollection;
				}
				this.dynamicProperties.length || (this._mdf = !1);
			};
			var Xt = function() {
				var t = [0, 0];
				function e(t, e, i) {
					if (this.elem = t, this.frameId = -1, this.propType = "transform", this.data = e, this.v = new Ft(), this.pre = new Ft(), this.appliedTransformations = 0, this.initDynamicPropertyContainer(i || t), e.p && e.p.s ? (this.px = vt.getProp(t, e.p.x, 0, 0, this), this.py = vt.getProp(t, e.p.y, 0, 0, this), e.p.z && (this.pz = vt.getProp(t, e.p.z, 0, 0, this))) : this.p = vt.getProp(t, e.p || { k: [
						0,
						0,
						0
					] }, 1, 0, this), e.rx) {
						if (this.rx = vt.getProp(t, e.rx, 0, P, this), this.ry = vt.getProp(t, e.ry, 0, P, this), this.rz = vt.getProp(t, e.rz, 0, P, this), e.or.k[0].ti) {
							var s, a = e.or.k.length;
							for (s = 0; s < a; s += 1) e.or.k[s].to = null, e.or.k[s].ti = null;
						}
						this.or = vt.getProp(t, e.or, 1, P, this), this.or.sh = !0;
					} else this.r = vt.getProp(t, e.r || { k: 0 }, 0, P, this);
					e.sk && (this.sk = vt.getProp(t, e.sk, 0, P, this), this.sa = vt.getProp(t, e.sa, 0, P, this)), this.a = vt.getProp(t, e.a || { k: [
						0,
						0,
						0
					] }, 1, 0, this), this.s = vt.getProp(t, e.s || { k: [
						100,
						100,
						100
					] }, 1, .01, this), e.o ? this.o = vt.getProp(t, e.o, 0, .01, t) : this.o = {
						_mdf: !1,
						v: 1
					}, this._isDirty = !0, this.dynamicProperties.length || this.getValue(!0);
				}
				return e.prototype = {
					applyToMatrix: function(t) {
						var e = this._mdf;
						this.iterateDynamicProperties(), this._mdf = this._mdf || e, this.a && t.translate(-this.a.v[0], -this.a.v[1], this.a.v[2]), this.s && t.scale(this.s.v[0], this.s.v[1], this.s.v[2]), this.sk && t.skewFromAxis(-this.sk.v, this.sa.v), this.r ? t.rotate(-this.r.v) : t.rotateZ(-this.rz.v).rotateY(this.ry.v).rotateX(this.rx.v).rotateZ(-this.or.v[2]).rotateY(this.or.v[1]).rotateX(this.or.v[0]), this.data.p.s ? this.data.p.z ? t.translate(this.px.v, this.py.v, -this.pz.v) : t.translate(this.px.v, this.py.v, 0) : t.translate(this.p.v[0], this.p.v[1], -this.p.v[2]);
					},
					getValue: function(e) {
						if (this.elem.globalData.frameId !== this.frameId) {
							if (this._isDirty && (this.precalculateMatrix(), this._isDirty = !1), this.iterateDynamicProperties(), this._mdf || e) {
								var i;
								if (this.v.cloneFromProps(this.pre.props), this.appliedTransformations < 1 && this.v.translate(-this.a.v[0], -this.a.v[1], this.a.v[2]), this.appliedTransformations < 2 && this.v.scale(this.s.v[0], this.s.v[1], this.s.v[2]), this.sk && this.appliedTransformations < 3 && this.v.skewFromAxis(-this.sk.v, this.sa.v), this.r && this.appliedTransformations < 4 ? this.v.rotate(-this.r.v) : !this.r && this.appliedTransformations < 4 && this.v.rotateZ(-this.rz.v).rotateY(this.ry.v).rotateX(this.rx.v).rotateZ(-this.or.v[2]).rotateY(this.or.v[1]).rotateX(this.or.v[0]), this.autoOriented) {
									var s, a;
									if (i = this.elem.globalData.frameRate, this.p && this.p.keyframes && this.p.getValueAtTime) this.p._caching.lastFrame + this.p.offsetTime <= this.p.keyframes[0].t ? (s = this.p.getValueAtTime((this.p.keyframes[0].t + .01) / i, 0), a = this.p.getValueAtTime(this.p.keyframes[0].t / i, 0)) : this.p._caching.lastFrame + this.p.offsetTime >= this.p.keyframes[this.p.keyframes.length - 1].t ? (s = this.p.getValueAtTime(this.p.keyframes[this.p.keyframes.length - 1].t / i, 0), a = this.p.getValueAtTime((this.p.keyframes[this.p.keyframes.length - 1].t - .05) / i, 0)) : (s = this.p.pv, a = this.p.getValueAtTime((this.p._caching.lastFrame + this.p.offsetTime - .01) / i, this.p.offsetTime));
									else if (this.px && this.px.keyframes && this.py.keyframes && this.px.getValueAtTime && this.py.getValueAtTime) {
										s = [], a = [];
										var r = this.px, n = this.py;
										r._caching.lastFrame + r.offsetTime <= r.keyframes[0].t ? (s[0] = r.getValueAtTime((r.keyframes[0].t + .01) / i, 0), s[1] = n.getValueAtTime((n.keyframes[0].t + .01) / i, 0), a[0] = r.getValueAtTime(r.keyframes[0].t / i, 0), a[1] = n.getValueAtTime(n.keyframes[0].t / i, 0)) : r._caching.lastFrame + r.offsetTime >= r.keyframes[r.keyframes.length - 1].t ? (s[0] = r.getValueAtTime(r.keyframes[r.keyframes.length - 1].t / i, 0), s[1] = n.getValueAtTime(n.keyframes[n.keyframes.length - 1].t / i, 0), a[0] = r.getValueAtTime((r.keyframes[r.keyframes.length - 1].t - .01) / i, 0), a[1] = n.getValueAtTime((n.keyframes[n.keyframes.length - 1].t - .01) / i, 0)) : (s = [r.pv, n.pv], a[0] = r.getValueAtTime((r._caching.lastFrame + r.offsetTime - .01) / i, r.offsetTime), a[1] = n.getValueAtTime((n._caching.lastFrame + n.offsetTime - .01) / i, n.offsetTime));
									} else s = a = t;
									this.v.rotate(-Math.atan2(s[1] - a[1], s[0] - a[0]));
								}
								this.data.p && this.data.p.s ? this.data.p.z ? this.v.translate(this.px.v, this.py.v, -this.pz.v) : this.v.translate(this.px.v, this.py.v, 0) : this.v.translate(this.p.v[0], this.p.v[1], -this.p.v[2]);
							}
							this.frameId = this.elem.globalData.frameId;
						}
					},
					precalculateMatrix: function() {
						if (this.appliedTransformations = 0, this.pre.reset(), !this.a.effectsSequence.length && (this.pre.translate(-this.a.v[0], -this.a.v[1], this.a.v[2]), this.appliedTransformations = 1, !this.s.effectsSequence.length)) {
							if (this.pre.scale(this.s.v[0], this.s.v[1], this.s.v[2]), this.appliedTransformations = 2, this.sk) {
								if (this.sk.effectsSequence.length || this.sa.effectsSequence.length) return;
								this.pre.skewFromAxis(-this.sk.v, this.sa.v), this.appliedTransformations = 3;
							}
							this.r ? this.r.effectsSequence.length || (this.pre.rotate(-this.r.v), this.appliedTransformations = 4) : this.rz.effectsSequence.length || this.ry.effectsSequence.length || this.rx.effectsSequence.length || this.or.effectsSequence.length || (this.pre.rotateZ(-this.rz.v).rotateY(this.ry.v).rotateX(this.rx.v).rotateZ(-this.or.v[2]).rotateY(this.or.v[1]).rotateX(this.or.v[0]), this.appliedTransformations = 4);
						}
					},
					autoOrient: function() {}
				}, r([bt], e), e.prototype.addDynamicProperty = function(t) {
					this._addDynamicProperty(t), this.elem.addDynamicProperty(t), this._isDirty = !0;
				}, e.prototype._addDynamicProperty = bt.prototype.addDynamicProperty, { getTransformProperty: function(t, i, s) {
					return new e(t, i, s);
				} };
			}();
			function Ht() {}
			function Yt() {}
			function Gt(t, e) {
				return 1e5 * Math.abs(t - e) <= Math.min(Math.abs(t), Math.abs(e));
			}
			function Kt(t) {
				return Math.abs(t) <= 1e-5;
			}
			function Jt(t, e, i) {
				return t * (1 - i) + e * i;
			}
			function Ut(t, e, i) {
				return [Jt(t[0], e[0], i), Jt(t[1], e[1], i)];
			}
			function Zt(t, e, i, s) {
				return [
					3 * e - t - 3 * i + s,
					3 * t - 6 * e + 3 * i,
					-3 * t + 3 * e,
					t
				];
			}
			function Qt(t) {
				return new $t(t, t, t, t, !1);
			}
			function $t(t, e, i, s, a) {
				a && he(t, e) && (e = Ut(t, s, 1 / 3)), a && he(i, s) && (i = Ut(t, s, 2 / 3));
				var r = Zt(t[0], e[0], i[0], s[0]), n = Zt(t[1], e[1], i[1], s[1]);
				this.a = [r[0], n[0]], this.b = [r[1], n[1]], this.c = [r[2], n[2]], this.d = [r[3], n[3]], this.points = [
					t,
					e,
					i,
					s
				];
			}
			function te(t, e) {
				var i = t.points[0][e], s = t.points[t.points.length - 1][e];
				if (i > s) {
					var a = s;
					s = i, i = a;
				}
				for (var r = function(t, e, i) {
					if (0 === t) return [];
					var s = e * e - 4 * t * i;
					if (s < 0) return [];
					var a = -e / (2 * t);
					if (0 === s) return [a];
					var r = Math.sqrt(s) / (2 * t);
					return [a - r, a + r];
				}(3 * t.a[e], 2 * t.b[e], t.c[e]), n = 0; n < r.length; n += 1) if (r[n] > 0 && r[n] < 1) {
					var o = t.point(r[n])[e];
					o < i ? i = o : o > s && (s = o);
				}
				return {
					min: i,
					max: s
				};
			}
			function ee(t, e, i) {
				var s = t.boundingBox();
				return {
					cx: s.cx,
					cy: s.cy,
					width: s.width,
					height: s.height,
					bez: t,
					t: (e + i) / 2,
					t1: e,
					t2: i
				};
			}
			function ie(t) {
				var e = t.bez.split(.5);
				return [ee(e[0], t.t1, t.t), ee(e[1], t.t, t.t2)];
			}
			function se(t, e, i, s, a, r) {
				var n = t, o = e;
				if (2 * Math.abs(n.cx - o.cx) < n.width + o.width && 2 * Math.abs(n.cy - o.cy) < n.height + o.height) if (i >= r || t.width <= s && t.height <= s && e.width <= s && e.height <= s) a.push([t.t, e.t]);
				else {
					var h = ie(t), l = ie(e);
					se(h[0], l[0], i + 1, s, a, r), se(h[0], l[1], i + 1, s, a, r), se(h[1], l[0], i + 1, s, a, r), se(h[1], l[1], i + 1, s, a, r);
				}
			}
			function ae(t, e) {
				return [
					t[1] * e[2] - t[2] * e[1],
					t[2] * e[0] - t[0] * e[2],
					t[0] * e[1] - t[1] * e[0]
				];
			}
			function re(t, e, i, s) {
				var a = [
					t[0],
					t[1],
					1
				], r = [
					e[0],
					e[1],
					1
				], n = [
					i[0],
					i[1],
					1
				], o = [
					s[0],
					s[1],
					1
				], h = ae(ae(a, r), ae(n, o));
				return Kt(h[2]) ? null : [h[0] / h[2], h[1] / h[2]];
			}
			function ne(t, e, i) {
				return [t[0] + Math.cos(e) * i, t[1] - Math.sin(e) * i];
			}
			function oe(t, e) {
				return Math.hypot(t[0] - e[0], t[1] - e[1]);
			}
			function he(t, e) {
				return Gt(t[0], e[0]) && Gt(t[1], e[1]);
			}
			function le() {}
			function pe(t, e, i, s, a, r, n) {
				var o = i - Math.PI / 2, h = i + Math.PI / 2, l = e[0] + Math.cos(i) * s * a, p = e[1] - Math.sin(i) * s * a;
				t.setTripleAt(l, p, l + Math.cos(o) * r, p - Math.sin(o) * r, l + Math.cos(h) * n, p - Math.sin(h) * n, t.length());
			}
			function fe(t, e) {
				var i, s, a, r, n = 0 === e ? t.length() - 1 : e - 1, o = (e + 1) % t.length(), h = t.v[n], l = t.v[o], p = (i = h, a = [(s = l)[0] - i[0], s[1] - i[1]], r = .5 * -Math.PI, [Math.cos(r) * a[0] - Math.sin(r) * a[1], Math.sin(r) * a[0] + Math.cos(r) * a[1]]);
				return Math.atan2(0, 1) - Math.atan2(p[1], p[0]);
			}
			function de(t, e, i, s, a, r, n) {
				var o = fe(e, i), h = e.v[i % e._length], l = e.v[0 === i ? e._length - 1 : i - 1], p = e.v[(i + 1) % e._length], f = 2 === r ? Math.sqrt(Math.pow(h[0] - l[0], 2) + Math.pow(h[1] - l[1], 2)) : 0, d = 2 === r ? Math.sqrt(Math.pow(h[0] - p[0], 2) + Math.pow(h[1] - p[1], 2)) : 0;
				pe(t, e.v[i % e._length], o, n, s, d / (2 * (a + 1)), f / (2 * (a + 1)));
			}
			function me(t, e, i, s, a, r) {
				for (var n = 0; n < s; n += 1) {
					var o = (n + 1) / (s + 1), h = 2 === a ? Math.sqrt(Math.pow(e.points[3][0] - e.points[0][0], 2) + Math.pow(e.points[3][1] - e.points[0][1], 2)) : 0, l = e.normalAngle(o);
					pe(t, e.point(o), l, r, i, h / (2 * (s + 1)), h / (2 * (s + 1))), r = -r;
				}
				return r;
			}
			function ce(t, e, i) {
				var s = Math.atan2(e[0] - t[0], e[1] - t[1]);
				return [ne(t, s, i), ne(e, s, i)];
			}
			function ue(t, e) {
				var i = (h = ce(t.points[0], t.points[1], e))[0], s = h[1], a = (h = ce(t.points[1], t.points[2], e))[0], r = h[1], n = (h = ce(t.points[2], t.points[3], e))[0], o = h[1], h;
				var l = re(i, s, a, r);
				null === l && (l = s);
				var p = re(n, o, a, r);
				return null === p && (p = n), new $t(i, l, p, o);
			}
			function ge(t, e, i, s, a) {
				var r = e.points[3], n = i.points[0];
				if (3 === s) return r;
				if (he(r, n)) return r;
				if (2 === s) {
					var o = -e.tangentAngle(1), h = -i.tangentAngle(0) + Math.PI, l = re(r, ne(r, o + Math.PI / 2, 100), n, ne(n, o + Math.PI / 2, 100)), p = l ? oe(l, r) : oe(r, n) / 2, f = ne(r, o, 2 * p * A);
					return t.setXYAt(f[0], f[1], "o", t.length() - 1), f = ne(n, h, 2 * p * A), t.setTripleAt(n[0], n[1], n[0], n[1], f[0], f[1], t.length()), n;
				}
				var d = re(he(r, e.points[2]) ? e.points[0] : e.points[2], r, n, he(n, i.points[1]) ? i.points[3] : i.points[1]);
				return d && oe(d, r) < a ? (t.setTripleAt(d[0], d[1], d[0], d[1], d[0], d[1], t.length()), d) : r;
			}
			function ye(t, e) {
				var i = t.intersections(e);
				return i.length && Gt(i[0][0], 1) && i.shift(), i.length ? i[0] : null;
			}
			function ve(t, e) {
				var i = t.slice(), s = e.slice(), a = ye(t[t.length - 1], e[0]);
				return a && (i[t.length - 1] = t[t.length - 1].split(a[0])[0], s[0] = e[0].split(a[1])[1]), t.length > 1 && e.length > 1 && (a = ye(t[0], e[e.length - 1])) ? [[t[0].split(a[0])[0]], [e[e.length - 1].split(a[1])[1]]] : [i, s];
			}
			function be(t, e) {
				var i, s, a, r, n = t.inflectionPoints();
				if (0 === n.length) return [ue(t, e)];
				if (1 === n.length || Gt(n[1], 1)) return i = (a = t.split(n[0]))[0], s = a[1], [ue(i, e), ue(s, e)];
				i = (a = t.split(n[0]))[0];
				var o = (n[1] - n[0]) / (1 - n[0]);
				return r = (a = a[1].split(o))[0], s = a[1], [
					ue(i, e),
					ue(r, e),
					ue(s, e)
				];
			}
			function _e() {}
			function ke(t) {
				for (var e = t.fStyle ? t.fStyle.split(" ") : [], i = "normal", s = "normal", a = e.length, r = 0; r < a; r += 1) switch (e[r].toLowerCase()) {
					case "italic":
						s = "italic";
						break;
					case "bold":
						i = "700";
						break;
					case "black":
						i = "900";
						break;
					case "medium":
						i = "500";
						break;
					case "regular":
					case "normal":
						i = "400";
						break;
					case "light":
					case "thin": i = "200";
				}
				return {
					style: s,
					weight: t.fWeight || i
				};
			}
			r([qt], Ht), Ht.prototype.initModifierProperties = function(t, e) {
				this.getValue = this.processKeys, this.c = vt.getProp(t, e.c, 0, null, this), this.o = vt.getProp(t, e.o, 0, null, this), this.tr = Xt.getTransformProperty(t, e.tr, this), this.so = vt.getProp(t, e.tr.so, 0, .01, this), this.eo = vt.getProp(t, e.tr.eo, 0, .01, this), this.data = e, this.dynamicProperties.length || this.getValue(!0), this._isAnimated = !!this.dynamicProperties.length, this.pMatrix = new Ft(), this.rMatrix = new Ft(), this.sMatrix = new Ft(), this.tMatrix = new Ft(), this.matrix = new Ft();
			}, Ht.prototype.applyTransforms = function(t, e, i, s, a, r) {
				var n = r ? -1 : 1, o = s.s.v[0] + (1 - s.s.v[0]) * (1 - a), h = s.s.v[1] + (1 - s.s.v[1]) * (1 - a);
				t.translate(s.p.v[0] * n * a, s.p.v[1] * n * a, s.p.v[2]), e.translate(-s.a.v[0], -s.a.v[1], s.a.v[2]), e.rotate(-s.r.v * n * a), e.translate(s.a.v[0], s.a.v[1], s.a.v[2]), i.translate(-s.a.v[0], -s.a.v[1], s.a.v[2]), i.scale(r ? 1 / o : o, r ? 1 / h : h), i.translate(s.a.v[0], s.a.v[1], s.a.v[2]);
			}, Ht.prototype.init = function(t, e, i, s) {
				for (this.elem = t, this.arr = e, this.pos = i, this.elemsData = s, this._currentCopies = 0, this._elements = [], this._groups = [], this.frameId = -1, this.initDynamicPropertyContainer(t), this.initModifierProperties(t, e[i]); i > 0;) i -= 1, this._elements.unshift(e[i]);
				this.dynamicProperties.length ? this.k = !0 : this.getValue(!0);
			}, Ht.prototype.resetElements = function(t) {
				var e, i = t.length;
				for (e = 0; e < i; e += 1) t[e]._processed = !1, "gr" === t[e].ty && this.resetElements(t[e].it);
			}, Ht.prototype.cloneElements = function(t) {
				var e = JSON.parse(JSON.stringify(t));
				return this.resetElements(e), e;
			}, Ht.prototype.changeGroupRender = function(t, e) {
				var i, s = t.length;
				for (i = 0; i < s; i += 1) t[i]._render = e, "gr" === t[i].ty && this.changeGroupRender(t[i].it, e);
			}, Ht.prototype.processShapes = function(t) {
				var e, i, s, a, r, n = !1;
				if (this._mdf || t) {
					var o, h = Math.ceil(this.c.v);
					if (this._groups.length < h) {
						for (; this._groups.length < h;) {
							var l = {
								it: this.cloneElements(this._elements),
								ty: "gr"
							};
							l.it.push({
								a: {
									a: 0,
									ix: 1,
									k: [0, 0]
								},
								nm: "Transform",
								o: {
									a: 0,
									ix: 7,
									k: 100
								},
								p: {
									a: 0,
									ix: 2,
									k: [0, 0]
								},
								r: {
									a: 1,
									ix: 6,
									k: [{
										s: 0,
										e: 0,
										t: 0
									}, {
										s: 0,
										e: 0,
										t: 1
									}]
								},
								s: {
									a: 0,
									ix: 3,
									k: [100, 100]
								},
								sa: {
									a: 0,
									ix: 5,
									k: 0
								},
								sk: {
									a: 0,
									ix: 4,
									k: 0
								},
								ty: "tr"
							}), this.arr.splice(0, 0, l), this._groups.splice(0, 0, l), this._currentCopies += 1;
						}
						this.elem.reloadShapes(), n = !0;
					}
					for (r = 0, s = 0; s <= this._groups.length - 1; s += 1) {
						if (o = r < h, this._groups[s]._render = o, this.changeGroupRender(this._groups[s].it, o), !o) {
							var p = this.elemsData[s].it, f = p[p.length - 1];
							0 !== f.transform.op.v ? (f.transform.op._mdf = !0, f.transform.op.v = 0) : f.transform.op._mdf = !1;
						}
						r += 1;
					}
					this._currentCopies = h;
					var d = this.o.v, m = d % 1, c = d > 0 ? Math.floor(d) : Math.ceil(d), u = this.pMatrix.props, g = this.rMatrix.props, y = this.sMatrix.props;
					this.pMatrix.reset(), this.rMatrix.reset(), this.sMatrix.reset(), this.tMatrix.reset(), this.matrix.reset();
					var v, b, _ = 0;
					if (d > 0) {
						for (; _ < c;) this.applyTransforms(this.pMatrix, this.rMatrix, this.sMatrix, this.tr, 1, !1), _ += 1;
						m && (this.applyTransforms(this.pMatrix, this.rMatrix, this.sMatrix, this.tr, m, !1), _ += m);
					} else if (d < 0) {
						for (; _ > c;) this.applyTransforms(this.pMatrix, this.rMatrix, this.sMatrix, this.tr, 1, !0), _ -= 1;
						m && (this.applyTransforms(this.pMatrix, this.rMatrix, this.sMatrix, this.tr, -m, !0), _ -= m);
					}
					for (s = 1 === this.data.m ? 0 : this._currentCopies - 1, a = 1 === this.data.m ? 1 : -1, r = this._currentCopies; r;) {
						if (b = (i = (e = this.elemsData[s].it)[e.length - 1].transform.mProps.v.props).length, e[e.length - 1].transform.mProps._mdf = !0, e[e.length - 1].transform.op._mdf = !0, e[e.length - 1].transform.op.v = 1 === this._currentCopies ? this.so.v : this.so.v + (this.eo.v - this.so.v) * (s / (this._currentCopies - 1)), 0 !== _) {
							for ((0 !== s && 1 === a || s !== this._currentCopies - 1 && -1 === a) && this.applyTransforms(this.pMatrix, this.rMatrix, this.sMatrix, this.tr, 1, !1), this.matrix.transform(g[0], g[1], g[2], g[3], g[4], g[5], g[6], g[7], g[8], g[9], g[10], g[11], g[12], g[13], g[14], g[15]), this.matrix.transform(y[0], y[1], y[2], y[3], y[4], y[5], y[6], y[7], y[8], y[9], y[10], y[11], y[12], y[13], y[14], y[15]), this.matrix.transform(u[0], u[1], u[2], u[3], u[4], u[5], u[6], u[7], u[8], u[9], u[10], u[11], u[12], u[13], u[14], u[15]), v = 0; v < b; v += 1) i[v] = this.matrix.props[v];
							this.matrix.reset();
						} else for (this.matrix.reset(), v = 0; v < b; v += 1) i[v] = this.matrix.props[v];
						_ += 1, r -= 1, s += a;
					}
				} else for (r = this._currentCopies, s = 0, a = 1; r;) i = (e = this.elemsData[s].it)[e.length - 1].transform.mProps.v.props, e[e.length - 1].transform.mProps._mdf = !1, e[e.length - 1].transform.op._mdf = !1, r -= 1, s += a;
				return n;
			}, Ht.prototype.addShape = function() {}, r([qt], Yt), Yt.prototype.initModifierProperties = function(t, e) {
				this.getValue = this.processKeys, this.rd = vt.getProp(t, e.r, 0, null, this), this._isAnimated = !!this.rd.effectsSequence.length;
			}, Yt.prototype.processPath = function(t, e) {
				var i, s = At.newElement();
				s.c = t.c;
				var a, r, n, o, h, l, p, f, d, m, c, u, g = t._length, y = 0;
				for (i = 0; i < g; i += 1) a = t.v[i], n = t.o[i], r = t.i[i], a[0] === n[0] && a[1] === n[1] && a[0] === r[0] && a[1] === r[1] ? 0 !== i && i !== g - 1 || t.c ? (o = 0 === i ? t.v[g - 1] : t.v[i - 1], l = (h = Math.sqrt(Math.pow(a[0] - o[0], 2) + Math.pow(a[1] - o[1], 2))) ? Math.min(h / 2, e) / h : 0, p = c = a[0] + (o[0] - a[0]) * l, f = u = a[1] - (a[1] - o[1]) * l, d = p - (p - a[0]) * A, m = f - (f - a[1]) * A, s.setTripleAt(p, f, d, m, c, u, y), y += 1, o = i === g - 1 ? t.v[0] : t.v[i + 1], l = (h = Math.sqrt(Math.pow(a[0] - o[0], 2) + Math.pow(a[1] - o[1], 2))) ? Math.min(h / 2, e) / h : 0, p = d = a[0] + (o[0] - a[0]) * l, f = m = a[1] + (o[1] - a[1]) * l, c = p - (p - a[0]) * A, u = f - (f - a[1]) * A, s.setTripleAt(p, f, d, m, c, u, y), y += 1) : (s.setTripleAt(a[0], a[1], n[0], n[1], r[0], r[1], y), y += 1) : (s.setTripleAt(t.v[i][0], t.v[i][1], t.o[i][0], t.o[i][1], t.i[i][0], t.i[i][1], y), y += 1);
				return s;
			}, Yt.prototype.processShapes = function(t) {
				var e, i, s, a, r, n, o = this.shapes.length, h = this.rd.v;
				if (0 !== h) for (i = 0; i < o; i += 1) {
					if (n = (r = this.shapes[i]).localShapeCollection, r.shape._mdf || this._mdf || t) for (n.releaseShapes(), r.shape._mdf = !0, e = r.shape.paths.shapes, a = r.shape.paths._length, s = 0; s < a; s += 1) n.addShape(this.processPath(e[s], h));
					r.shape.paths = r.localShapeCollection;
				}
				this.dynamicProperties.length || (this._mdf = !1);
			}, $t.prototype.point = function(t) {
				return [((this.a[0] * t + this.b[0]) * t + this.c[0]) * t + this.d[0], ((this.a[1] * t + this.b[1]) * t + this.c[1]) * t + this.d[1]];
			}, $t.prototype.derivative = function(t) {
				return [(3 * t * this.a[0] + 2 * this.b[0]) * t + this.c[0], (3 * t * this.a[1] + 2 * this.b[1]) * t + this.c[1]];
			}, $t.prototype.tangentAngle = function(t) {
				var e = this.derivative(t);
				return Math.atan2(e[1], e[0]);
			}, $t.prototype.normalAngle = function(t) {
				var e = this.derivative(t);
				return Math.atan2(e[0], e[1]);
			}, $t.prototype.inflectionPoints = function() {
				var t = this.a[1] * this.b[0] - this.a[0] * this.b[1];
				if (Kt(t)) return [];
				var e = -.5 * (this.a[1] * this.c[0] - this.a[0] * this.c[1]) / t, i = e * e - 1 / 3 * (this.b[1] * this.c[0] - this.b[0] * this.c[1]) / t;
				if (i < 0) return [];
				var s = Math.sqrt(i);
				return Kt(s) ? s > 0 && s < 1 ? [e] : [] : [e - s, e + s].filter((function(t) {
					return t > 0 && t < 1;
				}));
			}, $t.prototype.split = function(t) {
				if (t <= 0) return [Qt(this.points[0]), this];
				if (t >= 1) return [this, Qt(this.points[this.points.length - 1])];
				var e = Ut(this.points[0], this.points[1], t), i = Ut(this.points[1], this.points[2], t), s = Ut(this.points[2], this.points[3], t), a = Ut(e, i, t), r = Ut(i, s, t), n = Ut(a, r, t);
				return [new $t(this.points[0], e, a, n, !0), new $t(n, r, s, this.points[3], !0)];
			}, $t.prototype.bounds = function() {
				return {
					x: te(this, 0),
					y: te(this, 1)
				};
			}, $t.prototype.boundingBox = function() {
				var t = this.bounds();
				return {
					left: t.x.min,
					right: t.x.max,
					top: t.y.min,
					bottom: t.y.max,
					width: t.x.max - t.x.min,
					height: t.y.max - t.y.min,
					cx: (t.x.max + t.x.min) / 2,
					cy: (t.y.max + t.y.min) / 2
				};
			}, $t.prototype.intersections = function(t, e, i) {
				void 0 === e && (e = 2), void 0 === i && (i = 7);
				var s = [];
				return se(ee(this, 0, 1), ee(t, 0, 1), 0, e, s, i), s;
			}, $t.shapeSegment = function(t, e) {
				var i = (e + 1) % t.length();
				return new $t(t.v[e], t.o[e], t.i[i], t.v[i], !0);
			}, $t.shapeSegmentInverted = function(t, e) {
				var i = (e + 1) % t.length();
				return new $t(t.v[i], t.i[i], t.o[e], t.v[e], !0);
			}, r([qt], le), le.prototype.initModifierProperties = function(t, e) {
				this.getValue = this.processKeys, this.amplitude = vt.getProp(t, e.s, 0, null, this), this.frequency = vt.getProp(t, e.r, 0, null, this), this.pointsType = vt.getProp(t, e.pt, 0, null, this), this._isAnimated = 0 !== this.amplitude.effectsSequence.length || 0 !== this.frequency.effectsSequence.length || 0 !== this.pointsType.effectsSequence.length;
			}, le.prototype.processPath = function(t, e, i, s) {
				var a = t._length, r = At.newElement();
				if (r.c = t.c, t.c || (a -= 1), 0 === a) return r;
				var n = -1, o = $t.shapeSegment(t, 0);
				de(r, t, 0, e, i, s, n);
				for (var h = 0; h < a; h += 1) n = me(r, o, e, i, s, -n), o = h !== a - 1 || t.c ? $t.shapeSegment(t, (h + 1) % a) : null, de(r, t, h + 1, e, i, s, n);
				return r;
			}, le.prototype.processShapes = function(t) {
				var e, i, s, a, r, n, o = this.shapes.length, h = this.amplitude.v, l = Math.max(0, Math.round(this.frequency.v)), p = this.pointsType.v;
				if (0 !== h) for (i = 0; i < o; i += 1) {
					if (n = (r = this.shapes[i]).localShapeCollection, r.shape._mdf || this._mdf || t) for (n.releaseShapes(), r.shape._mdf = !0, e = r.shape.paths.shapes, a = r.shape.paths._length, s = 0; s < a; s += 1) n.addShape(this.processPath(e[s], h, l, p));
					r.shape.paths = r.localShapeCollection;
				}
				this.dynamicProperties.length || (this._mdf = !1);
			}, r([qt], _e), _e.prototype.initModifierProperties = function(t, e) {
				this.getValue = this.processKeys, this.amount = vt.getProp(t, e.a, 0, null, this), this.miterLimit = vt.getProp(t, e.ml, 0, null, this), this.lineJoin = e.lj, this._isAnimated = 0 !== this.amount.effectsSequence.length;
			}, _e.prototype.processPath = function(t, e, i, s) {
				var a = At.newElement();
				a.c = t.c;
				var r, n, o, h = t.length();
				t.c || (h -= 1);
				var l = [];
				for (r = 0; r < h; r += 1) o = $t.shapeSegment(t, r), l.push(be(o, e));
				if (!t.c) for (r = h - 1; r >= 0; r -= 1) o = $t.shapeSegmentInverted(t, r), l.push(be(o, e));
				l = function(t) {
					for (var e, i = 1; i < t.length; i += 1) e = ve(t[i - 1], t[i]), t[i - 1] = e[0], t[i] = e[1];
					return t.length > 1 && (e = ve(t[t.length - 1], t[0]), t[t.length - 1] = e[0], t[0] = e[1]), t;
				}(l);
				var p = null, f = null;
				for (r = 0; r < l.length; r += 1) {
					var d = l[r];
					for (f && (p = ge(a, f, d[0], i, s)), f = d[d.length - 1], n = 0; n < d.length; n += 1) o = d[n], p && he(o.points[0], p) ? a.setXYAt(o.points[1][0], o.points[1][1], "o", a.length() - 1) : a.setTripleAt(o.points[0][0], o.points[0][1], o.points[1][0], o.points[1][1], o.points[0][0], o.points[0][1], a.length()), a.setTripleAt(o.points[3][0], o.points[3][1], o.points[3][0], o.points[3][1], o.points[2][0], o.points[2][1], a.length()), p = o.points[3];
				}
				return l.length && ge(a, f, l[0][0], i, s), a;
			}, _e.prototype.processShapes = function(t) {
				var e, i, s, a, r, n, o = this.shapes.length, h = this.amount.v, l = this.miterLimit.v, p = this.lineJoin;
				if (0 !== h) for (i = 0; i < o; i += 1) {
					if (n = (r = this.shapes[i]).localShapeCollection, r.shape._mdf || this._mdf || t) for (n.releaseShapes(), r.shape._mdf = !0, e = r.shape.paths.shapes, a = r.shape.paths._length, s = 0; s < a; s += 1) n.addShape(this.processPath(e[s], h, p, l));
					r.shape.paths = r.localShapeCollection;
				}
				this.dynamicProperties.length || (this._mdf = !1);
			};
			var Pe = function() {
				var t = {
					w: 0,
					size: 0,
					shapes: [],
					data: { shapes: [] }
				}, e = [];
				e = e.concat([
					2304,
					2305,
					2306,
					2307,
					2362,
					2363,
					2364,
					2364,
					2366,
					2367,
					2368,
					2369,
					2370,
					2371,
					2372,
					2373,
					2374,
					2375,
					2376,
					2377,
					2378,
					2379,
					2380,
					2381,
					2382,
					2383,
					2387,
					2388,
					2389,
					2390,
					2391,
					2402,
					2403
				]);
				var i = 127988, s = [
					"d83cdffb",
					"d83cdffc",
					"d83cdffd",
					"d83cdffe",
					"d83cdfff"
				];
				function r(t, e) {
					var i = a("span");
					i.setAttribute("aria-hidden", !0), i.style.fontFamily = e;
					var s = a("span");
					s.innerText = "giItT1WQy@!-/#", i.style.position = "absolute", i.style.left = "-10000px", i.style.top = "-10000px", i.style.fontSize = "300px", i.style.fontVariant = "normal", i.style.fontStyle = "normal", i.style.fontWeight = "normal", i.style.letterSpacing = "0", i.appendChild(s), document.body.appendChild(i);
					var r = s.offsetWidth;
					return s.style.fontFamily = function(t) {
						var e, i = t.split(","), s = i.length, a = [];
						for (e = 0; e < s; e += 1) "sans-serif" !== i[e] && "monospace" !== i[e] && a.push(i[e]);
						return a.join(",");
					}(t) + ", " + e, {
						node: s,
						w: r,
						parent: i
					};
				}
				function n(t, e) {
					var i, s = document.body && e ? "svg" : "canvas", a = ke(t);
					if ("svg" === s) {
						var r = W("text");
						r.style.fontSize = "100px", r.setAttribute("font-family", t.fFamily), r.setAttribute("font-style", a.style), r.setAttribute("font-weight", a.weight), r.textContent = "1", t.fClass ? (r.style.fontFamily = "inherit", r.setAttribute("class", t.fClass)) : r.style.fontFamily = t.fFamily, e.appendChild(r), i = r;
					} else {
						var n = new OffscreenCanvas(500, 500).getContext("2d");
						n.font = a.style + " " + a.weight + " 100px " + t.fFamily, i = n;
					}
					return { measureText: function(t) {
						return "svg" === s ? (i.textContent = t, i.getComputedTextLength()) : i.measureText(t).width;
					} };
				}
				function o(t) {
					var e = 0, i = t.charCodeAt(0);
					if (i >= 55296 && i <= 56319) {
						var s = t.charCodeAt(1);
						s >= 56320 && s <= 57343 && (e = 1024 * (i - 55296) + s - 56320 + 65536);
					}
					return e;
				}
				function h(t) {
					var e = o(t);
					return e >= 127462 && e <= 127487;
				}
				var l = function() {
					this.fonts = [], this.chars = null, this.typekitLoaded = 0, this.isLoaded = !1, this._warned = !1, this.initTime = Date.now(), this.setIsLoadedBinded = this.setIsLoaded.bind(this), this.checkLoadedFontsBinded = this.checkLoadedFonts.bind(this);
				};
				l.isModifier = function(t, e) {
					var i = t.toString(16) + e.toString(16);
					return -1 !== s.indexOf(i);
				}, l.isZeroWidthJoiner = function(t) {
					return 8205 === t;
				}, l.isFlagEmoji = function(t) {
					return h(t.substr(0, 2)) && h(t.substr(2, 2));
				}, l.isRegionalCode = h, l.isCombinedCharacter = function(t) {
					return -1 !== e.indexOf(t);
				}, l.isRegionalFlag = function(t, e) {
					var s = o(t.substr(e, 2));
					if (s !== i) return !1;
					var a = 0;
					for (e += 2; a < 5;) {
						if ((s = o(t.substr(e, 2))) < 917601 || s > 917626) return !1;
						a += 1, e += 2;
					}
					return 917631 === o(t.substr(e, 2));
				}, l.isVariationSelector = function(t) {
					return 65039 === t;
				}, l.BLACK_FLAG_CODE_POINT = i;
				return l.prototype = {
					addChars: function(t) {
						if (t) {
							var e;
							this.chars || (this.chars = []);
							var i, s, a = t.length, r = this.chars.length;
							for (e = 0; e < a; e += 1) {
								for (i = 0, s = !1; i < r;) this.chars[i].style === t[e].style && this.chars[i].fFamily === t[e].fFamily && this.chars[i].ch === t[e].ch && (s = !0), i += 1;
								s || (this.chars.push(t[e]), r += 1);
							}
						}
					},
					addFonts: function(t, e) {
						if (t) {
							if (this.chars) return this.isLoaded = !0, void (this.fonts = t.list);
							if (!document.body) return this.isLoaded = !0, t.list.forEach((function(t) {
								t.helper = n(t), t.cache = {};
							})), void (this.fonts = t.list);
							var i, s = t.list, o = s.length, h = o;
							for (i = 0; i < o; i += 1) {
								var l, p, f = !0;
								if (s[i].loaded = !1, s[i].monoCase = r(s[i].fFamily, "monospace"), s[i].sansCase = r(s[i].fFamily, "sans-serif"), s[i].fPath) {
									if ("p" === s[i].fOrigin || 3 === s[i].origin) {
										if ((l = document.querySelectorAll("style[f-forigin=\"p\"][f-family=\"" + s[i].fFamily + "\"], style[f-origin=\"3\"][f-family=\"" + s[i].fFamily + "\"]")).length > 0 && (f = !1), f) {
											var d = a("style");
											d.setAttribute("f-forigin", s[i].fOrigin), d.setAttribute("f-origin", s[i].origin), d.setAttribute("f-family", s[i].fFamily), d.type = "text/css", d.innerText = "@font-face {font-family: " + s[i].fFamily + "; font-style: normal; src: url('" + s[i].fPath + "');}", e.appendChild(d);
										}
									} else if ("g" === s[i].fOrigin || 1 === s[i].origin) {
										for (l = document.querySelectorAll("link[f-forigin=\"g\"], link[f-origin=\"1\"]"), p = 0; p < l.length; p += 1) -1 !== l[p].href.indexOf(s[i].fPath) && (f = !1);
										if (f) {
											var m = a("link");
											m.setAttribute("f-forigin", s[i].fOrigin), m.setAttribute("f-origin", s[i].origin), m.type = "text/css", m.rel = "stylesheet", m.href = s[i].fPath, document.body.appendChild(m);
										}
									} else if ("t" === s[i].fOrigin || 2 === s[i].origin) {
										for (l = document.querySelectorAll("script[f-forigin=\"t\"], script[f-origin=\"2\"]"), p = 0; p < l.length; p += 1) s[i].fPath === l[p].src && (f = !1);
										if (f) {
											var c = a("link");
											c.setAttribute("f-forigin", s[i].fOrigin), c.setAttribute("f-origin", s[i].origin), c.setAttribute("rel", "stylesheet"), c.setAttribute("href", s[i].fPath), e.appendChild(c);
										}
									}
								} else s[i].loaded = !0, h -= 1;
								s[i].helper = n(s[i], e), s[i].cache = {}, this.fonts.push(s[i]);
							}
							0 === h ? this.isLoaded = !0 : setTimeout(this.checkLoadedFonts.bind(this), 100);
						} else this.isLoaded = !0;
					},
					getCharData: function(e, i, s) {
						for (var a = 0, r = this.chars.length; a < r;) {
							if (this.chars[a].ch === e && this.chars[a].style === i && this.chars[a].fFamily === s) return this.chars[a];
							a += 1;
						}
						return ("string" == typeof e && 13 !== e.charCodeAt(0) || !e) && console && console.warn && !this._warned && (this._warned = !0, console.warn("Missing character from exported characters list: ", e, i, s)), t;
					},
					getFontByName: function(t) {
						for (var e = 0, i = this.fonts.length; e < i;) {
							if (this.fonts[e].fName === t) return this.fonts[e];
							e += 1;
						}
						return this.fonts[0];
					},
					measureText: function(t, e, i) {
						var s = this.getFontByName(e), a = t;
						if (!s.cache[a]) {
							var r = s.helper;
							if (" " === t) {
								var n = r.measureText("|" + t + "|"), o = r.measureText("||");
								s.cache[a] = (n - o) / 100;
							} else s.cache[a] = r.measureText(t) / 100;
						}
						return s.cache[a] * i;
					},
					checkLoadedFonts: function() {
						var t, e, i, s = this.fonts.length, a = s;
						for (t = 0; t < s; t += 1) this.fonts[t].loaded ? a -= 1 : "n" === this.fonts[t].fOrigin || 0 === this.fonts[t].origin ? this.fonts[t].loaded = !0 : (e = this.fonts[t].monoCase.node, i = this.fonts[t].monoCase.w, e.offsetWidth !== i ? (a -= 1, this.fonts[t].loaded = !0) : (e = this.fonts[t].sansCase.node, i = this.fonts[t].sansCase.w, e.offsetWidth !== i && (a -= 1, this.fonts[t].loaded = !0)), this.fonts[t].loaded && (this.fonts[t].sansCase.parent.parentNode.removeChild(this.fonts[t].sansCase.parent), this.fonts[t].monoCase.parent.parentNode.removeChild(this.fonts[t].monoCase.parent)));
						0 !== a && Date.now() - this.initTime < 5e3 ? setTimeout(this.checkLoadedFontsBinded, 20) : setTimeout(this.setIsLoadedBinded, 10);
					},
					setIsLoaded: function() {
						this.isLoaded = !0;
					}
				}, l;
			}();
			function Ae(t) {
				this.animationData = t;
			}
			function Se() {}
			Ae.prototype.getProp = function(t) {
				return this.animationData.slots && this.animationData.slots[t.sid] ? Object.assign(t, this.animationData.slots[t.sid].p) : t;
			}, Se.prototype = {
				initRenderable: function() {
					this.isInRange = !1, this.hidden = !1, this.isTransparent = !1, this.renderableComponents = [];
				},
				addRenderableComponent: function(t) {
					-1 === this.renderableComponents.indexOf(t) && this.renderableComponents.push(t);
				},
				removeRenderableComponent: function(t) {
					-1 !== this.renderableComponents.indexOf(t) && this.renderableComponents.splice(this.renderableComponents.indexOf(t), 1);
				},
				prepareRenderableFrame: function(t) {
					this.checkLayerLimits(t);
				},
				checkTransparency: function() {
					this.finalTransform.mProp.o.v <= 0 ? !this.isTransparent && this.globalData.renderConfig.hideOnTransparent && (this.isTransparent = !0, this.hide()) : this.isTransparent && (this.isTransparent = !1, this.show());
				},
				checkLayerLimits: function(t) {
					this.data.ip - this.data.st <= t && this.data.op - this.data.st > t ? !0 !== this.isInRange && (this.globalData._mdf = !0, this._mdf = !0, this.isInRange = !0, this.show()) : !1 !== this.isInRange && (this.globalData._mdf = !0, this.isInRange = !1, this.hide());
				},
				renderRenderable: function() {
					var t, e = this.renderableComponents.length;
					for (t = 0; t < e; t += 1) this.renderableComponents[t].renderFrame(this._isFirstFrame);
				},
				sourceRectAtTime: function() {
					return {
						top: 0,
						left: 0,
						width: 100,
						height: 100
					};
				},
				getLayerSize: function() {
					return 5 === this.data.ty ? {
						w: this.data.textData.width,
						h: this.data.textData.height
					} : {
						w: this.data.width,
						h: this.data.height
					};
				}
			};
			var xe, we = (xe = {
				0: "source-over",
				1: "multiply",
				2: "screen",
				3: "overlay",
				4: "darken",
				5: "lighten",
				6: "color-dodge",
				7: "color-burn",
				8: "hard-light",
				9: "soft-light",
				10: "difference",
				11: "exclusion",
				12: "hue",
				13: "saturation",
				14: "color",
				15: "luminosity"
			}, function(t) {
				return xe[t] || "";
			});
			function De(t, e, i) {
				this.p = vt.getProp(e, t.v, 0, 0, i);
			}
			function Ce(t, e, i) {
				this.p = vt.getProp(e, t.v, 0, 0, i);
			}
			function Me(t, e, i) {
				this.p = vt.getProp(e, t.v, 1, 0, i);
			}
			function Te(t, e, i) {
				this.p = vt.getProp(e, t.v, 1, 0, i);
			}
			function Fe(t, e, i) {
				this.p = vt.getProp(e, t.v, 0, 0, i);
			}
			function Ee(t, e, i) {
				this.p = vt.getProp(e, t.v, 0, 0, i);
			}
			function Ie(t, e, i) {
				this.p = vt.getProp(e, t.v, 0, 0, i);
			}
			function Le() {
				this.p = {};
			}
			function Ve(t, e) {
				var i, s = t.ef || [];
				this.effectElements = [];
				var a, r = s.length;
				for (i = 0; i < r; i += 1) a = new Re(s[i], e), this.effectElements.push(a);
			}
			function Re(t, e) {
				this.init(t, e);
			}
			function ze() {}
			function Oe() {}
			function Ne(t, e, i) {
				this.initFrame(), this.initRenderable(), this.assetData = e.getAssetData(t.refId), this.footageData = e.imageLoader.getAsset(this.assetData), this.initBaseData(t, e, i);
			}
			function Be(t, e, i) {
				this.initFrame(), this.initRenderable(), this.assetData = e.getAssetData(t.refId), this.initBaseData(t, e, i), this._isPlaying = !1, this._canPlay = !1;
				var s = this.globalData.getAssetsPath(this.assetData);
				this.audio = this.globalData.audioController.createAudio(s), this._currentTime = 0, this.globalData.audioController.addAudio(this), this._volumeMultiplier = 1, this._volume = 1, this._previousVolume = null, this.tm = t.tm ? vt.getProp(this, t.tm, 0, e.frameRate, this) : { _placeholder: !0 }, this.lv = vt.getProp(this, t.au && t.au.lv ? t.au.lv : { k: [100] }, 1, .01, this);
			}
			function qe() {}
			r([bt], Re), Re.prototype.getValue = Re.prototype.iterateDynamicProperties, Re.prototype.init = function(t, e) {
				var i;
				this.data = t, this.effectElements = [], this.initDynamicPropertyContainer(e);
				var s, a = this.data.ef.length, r = this.data.ef;
				for (i = 0; i < a; i += 1) {
					switch (s = null, r[i].ty) {
						case 0:
							s = new De(r[i], e, this);
							break;
						case 1:
							s = new Ce(r[i], e, this);
							break;
						case 2:
							s = new Me(r[i], e, this);
							break;
						case 3:
							s = new Te(r[i], e, this);
							break;
						case 4:
						case 7:
							s = new Ie(r[i], e, this);
							break;
						case 10:
							s = new Fe(r[i], e, this);
							break;
						case 11:
							s = new Ee(r[i], e, this);
							break;
						case 5:
							s = new Ve(r[i], e, this);
							break;
						default: s = new Le(r[i], e, this);
					}
					s && this.effectElements.push(s);
				}
			}, ze.prototype = {
				checkMasks: function() {
					if (!this.data.hasMask) return !1;
					for (var t = 0, e = this.data.masksProperties.length; t < e;) {
						if ("n" !== this.data.masksProperties[t].mode && !1 !== this.data.masksProperties[t].cl) return !0;
						t += 1;
					}
					return !1;
				},
				initExpressions: function() {
					var t = B();
					if (t) {
						var e = t("layer"), i = t("effects"), s = t("shape"), a = t("text"), r = t("comp");
						this.layerInterface = e(this), this.data.hasMask && this.maskManager && this.layerInterface.registerMaskInterface(this.maskManager);
						var n = i.createEffectsInterface(this, this.layerInterface);
						this.layerInterface.registerEffectsInterface(n), 0 === this.data.ty || this.data.xt ? this.compInterface = r(this) : 4 === this.data.ty ? (this.layerInterface.shapeInterface = s(this.shapesData, this.itemsData, this.layerInterface), this.layerInterface.content = this.layerInterface.shapeInterface) : 5 === this.data.ty && (this.layerInterface.textInterface = a(this), this.layerInterface.text = this.layerInterface.textInterface);
					}
				},
				setBlendMode: function() {
					var t = we(this.data.bm);
					(this.baseElement || this.layerElement).style["mix-blend-mode"] = t;
				},
				initBaseData: function(t, e, i) {
					this.globalData = e, this.comp = i, this.data = t, this.layerId = I(), this.data.sr || (this.data.sr = 1), this.effectsManager = new Ve(this.data, this, this.dynamicProperties);
				},
				getType: function() {
					return this.type;
				},
				sourceRectAtTime: function() {}
			}, Oe.prototype = {
				initFrame: function() {
					this._isFirstFrame = !1, this.dynamicProperties = [], this._mdf = !1;
				},
				prepareProperties: function(t, e) {
					var i, s = this.dynamicProperties.length;
					for (i = 0; i < s; i += 1) (e || this._isParent && "transform" === this.dynamicProperties[i].propType) && (this.dynamicProperties[i].getValue(), this.dynamicProperties[i]._mdf && (this.globalData._mdf = !0, this._mdf = !0));
				},
				addDynamicProperty: function(t) {
					-1 === this.dynamicProperties.indexOf(t) && this.dynamicProperties.push(t);
				}
			}, Ne.prototype.prepareFrame = function() {}, r([
				Se,
				ze,
				Oe
			], Ne), Ne.prototype.getBaseElement = function() {
				return null;
			}, Ne.prototype.renderFrame = function() {}, Ne.prototype.destroy = function() {}, Ne.prototype.initExpressions = function() {
				var t = B();
				if (t) {
					var e = t("footage");
					this.layerInterface = e(this);
				}
			}, Ne.prototype.getFootageData = function() {
				return this.footageData;
			}, Be.prototype.prepareFrame = function(t) {
				if (this.prepareRenderableFrame(t, !0), this.prepareProperties(t, !0), this.tm._placeholder) this._currentTime = t / this.data.sr;
				else {
					var e = this.tm.v;
					this._currentTime = e;
				}
				this._volume = this.lv.v[0];
				var i = this._volume * this._volumeMultiplier;
				this._previousVolume !== i && (this._previousVolume = i, this.audio.volume(i));
			}, r([
				Se,
				ze,
				Oe
			], Be), Be.prototype.renderFrame = function() {
				this.isInRange && this._canPlay && (this._isPlaying ? (!this.audio.playing() || Math.abs(this._currentTime / this.globalData.frameRate - this.audio.seek()) > .1) && this.audio.seek(this._currentTime / this.globalData.frameRate) : (this.audio.play(), this.audio.seek(this._currentTime / this.globalData.frameRate), this._isPlaying = !0));
			}, Be.prototype.show = function() {}, Be.prototype.hide = function() {
				this.audio.pause(), this._isPlaying = !1;
			}, Be.prototype.pause = function() {
				this.audio.pause(), this._isPlaying = !1, this._canPlay = !1;
			}, Be.prototype.resume = function() {
				this._canPlay = !0;
			}, Be.prototype.setRate = function(t) {
				this.audio.rate(t);
			}, Be.prototype.volume = function(t) {
				this._volumeMultiplier = t, this._previousVolume = t * this._volume, this.audio.volume(this._previousVolume);
			}, Be.prototype.getBaseElement = function() {
				return null;
			}, Be.prototype.destroy = function() {}, Be.prototype.sourceRectAtTime = function() {}, Be.prototype.initExpressions = function() {}, qe.prototype.checkLayers = function(t) {
				var e, i, s = this.layers.length;
				for (this.completeLayers = !0, e = s - 1; e >= 0; e -= 1) this.elements[e] || (i = this.layers[e]).ip - i.st <= t - this.layers[e].st && i.op - i.st > t - this.layers[e].st && this.buildItem(e), this.completeLayers = !!this.elements[e] && this.completeLayers;
				this.checkPendingElements();
			}, qe.prototype.createItem = function(t) {
				switch (t.ty) {
					case 2: return this.createImage(t);
					case 0: return this.createComp(t);
					case 1: return this.createSolid(t);
					case 3:
					default: return this.createNull(t);
					case 4: return this.createShape(t);
					case 5: return this.createText(t);
					case 6: return this.createAudio(t);
					case 13: return this.createCamera(t);
					case 15: return this.createFootage(t);
				}
			}, qe.prototype.createCamera = function() {
				throw new Error("You're using a 3d camera. Try the html renderer.");
			}, qe.prototype.createAudio = function(t) {
				return new Be(t, this.globalData, this);
			}, qe.prototype.createFootage = function(t) {
				return new Ne(t, this.globalData, this);
			}, qe.prototype.buildAllItems = function() {
				var t, e = this.layers.length;
				for (t = 0; t < e; t += 1) this.buildItem(t);
				this.checkPendingElements();
			}, qe.prototype.includeLayers = function(t) {
				var e;
				this.completeLayers = !1;
				var i, s = t.length, a = this.layers.length;
				for (e = 0; e < s; e += 1) for (i = 0; i < a;) {
					if (this.layers[i].id === t[e].id) {
						this.layers[i] = t[e];
						break;
					}
					i += 1;
				}
			}, qe.prototype.setProjectInterface = function(t) {
				this.globalData.projectInterface = t;
			}, qe.prototype.initItems = function() {
				this.globalData.progressiveLoad || this.buildAllItems();
			}, qe.prototype.buildElementParenting = function(t, e, i) {
				for (var s = this.elements, a = this.layers, r = 0, n = a.length; r < n;) a[r].ind == e && (s[r] && !0 !== s[r] ? (i.push(s[r]), s[r].setAsParent(), void 0 !== a[r].parent ? this.buildElementParenting(t, a[r].parent, i) : t.setHierarchy(i)) : (this.buildItem(r), this.addPendingElement(t))), r += 1;
			}, qe.prototype.addPendingElement = function(t) {
				this.pendingElements.push(t);
			}, qe.prototype.searchExtraCompositions = function(t) {
				var e, i = t.length;
				for (e = 0; e < i; e += 1) if (t[e].xt) {
					var s = this.createComp(t[e]);
					s.initExpressions(), this.globalData.projectInterface.registerComposition(s);
				}
			}, qe.prototype.getElementById = function(t) {
				var e, i = this.elements.length;
				for (e = 0; e < i; e += 1) if (this.elements[e].data.ind === t) return this.elements[e];
				return null;
			}, qe.prototype.getElementByPath = function(t) {
				var e, i = t.shift();
				if ("number" == typeof i) e = this.elements[i];
				else {
					var s, a = this.elements.length;
					for (s = 0; s < a; s += 1) if (this.elements[s].data.nm === i) {
						e = this.elements[s];
						break;
					}
				}
				return 0 === t.length ? e : e.getElementByPath(t);
			}, qe.prototype.setupGlobalData = function(t, e) {
				this.globalData.fontManager = new Pe(), this.globalData.slotManager = function(t) {
					return new Ae(t);
				}(t), this.globalData.fontManager.addChars(t.chars), this.globalData.fontManager.addFonts(t.fonts, e), this.globalData.getAssetData = this.animationItem.getAssetData.bind(this.animationItem), this.globalData.getAssetsPath = this.animationItem.getAssetsPath.bind(this.animationItem), this.globalData.imageLoader = this.animationItem.imagePreloader, this.globalData.audioController = this.animationItem.audioController, this.globalData.frameId = 0, this.globalData.frameRate = t.fr, this.globalData.nm = t.nm, this.globalData.compSize = {
					w: t.w,
					h: t.h
				};
			};
			var je = "transformEFfect";
			function We() {}
			function Xe(t, e, i) {
				this.data = t, this.element = e, this.globalData = i, this.storedData = [], this.masksProperties = this.data.masksProperties || [], this.maskElement = null;
				var a, r, n = this.globalData.defs, o = this.masksProperties ? this.masksProperties.length : 0;
				this.viewData = l(o), this.solidPath = "";
				var h, p, f, d, m, c, u = this.masksProperties, g = 0, y = [], v = I(), b = "clipPath", _ = "clip-path";
				for (a = 0; a < o; a += 1) if (("a" !== u[a].mode && "n" !== u[a].mode || u[a].inv || 100 !== u[a].o.k || u[a].o.x) && (b = "mask", _ = "mask"), "s" !== u[a].mode && "i" !== u[a].mode || 0 !== g ? f = null : ((f = W("rect")).setAttribute("fill", "#ffffff"), f.setAttribute("width", this.element.comp.data.w || 0), f.setAttribute("height", this.element.comp.data.h || 0), y.push(f)), r = W("path"), "n" === u[a].mode) this.viewData[a] = {
					op: vt.getProp(this.element, u[a].o, 0, .01, this.element),
					prop: Tt.getShapeProp(this.element, u[a], 3),
					elem: r,
					lastPath: ""
				}, n.appendChild(r);
				else {
					var k;
					if (g += 1, r.setAttribute("fill", "s" === u[a].mode ? "#000000" : "#ffffff"), r.setAttribute("clip-rule", "nonzero"), 0 !== u[a].x.k ? (b = "mask", _ = "mask", c = vt.getProp(this.element, u[a].x, 0, null, this.element), k = I(), (d = W("filter")).setAttribute("id", k), (m = W("feMorphology")).setAttribute("operator", "erode"), m.setAttribute("in", "SourceGraphic"), m.setAttribute("radius", "0"), d.appendChild(m), n.appendChild(d), r.setAttribute("stroke", "s" === u[a].mode ? "#000000" : "#ffffff")) : (m = null, c = null), this.storedData[a] = {
						elem: r,
						x: c,
						expan: m,
						lastPath: "",
						lastOperator: "",
						filterId: k,
						lastRadius: 0
					}, "i" === u[a].mode) {
						p = y.length;
						var P = W("g");
						for (h = 0; h < p; h += 1) P.appendChild(y[h]);
						var A = W("mask");
						A.setAttribute("mask-type", "alpha"), A.setAttribute("id", v + "_" + g), A.appendChild(r), n.appendChild(A), P.setAttribute("mask", "url(" + s() + "#" + v + "_" + g + ")"), y.length = 0, y.push(P);
					} else y.push(r);
					u[a].inv && !this.solidPath && (this.solidPath = this.createLayerSolidPath()), this.viewData[a] = {
						elem: r,
						lastPath: "",
						op: vt.getProp(this.element, u[a].o, 0, .01, this.element),
						prop: Tt.getShapeProp(this.element, u[a], 3),
						invRect: f
					}, this.viewData[a].prop.k || this.drawPath(u[a], this.viewData[a].prop.v, this.viewData[a]);
				}
				for (this.maskElement = W(b), o = y.length, a = 0; a < o; a += 1) this.maskElement.appendChild(y[a]);
				g > 0 && (this.maskElement.setAttribute("id", v), this.element.maskedElement.setAttribute(_, "url(" + s() + "#" + v + ")"), n.appendChild(this.maskElement)), this.viewData.length && this.element.addRenderableComponent(this);
			}
			We.prototype = {
				initTransform: function() {
					var t = new Ft();
					this.finalTransform = {
						mProp: this.data.ks ? Xt.getTransformProperty(this, this.data.ks, this) : { o: 0 },
						_matMdf: !1,
						_localMatMdf: !1,
						_opMdf: !1,
						mat: t,
						localMat: t,
						localOpacity: 1
					}, this.data.ao && (this.finalTransform.mProp.autoOriented = !0), this.data.ty;
				},
				renderTransform: function() {
					if (this.finalTransform._opMdf = this.finalTransform.mProp.o._mdf || this._isFirstFrame, this.finalTransform._matMdf = this.finalTransform.mProp._mdf || this._isFirstFrame, this.hierarchy) {
						var t, e = this.finalTransform.mat, i = 0, s = this.hierarchy.length;
						if (!this.finalTransform._matMdf) for (; i < s;) {
							if (this.hierarchy[i].finalTransform.mProp._mdf) {
								this.finalTransform._matMdf = !0;
								break;
							}
							i += 1;
						}
						if (this.finalTransform._matMdf) for (t = this.finalTransform.mProp.v.props, e.cloneFromProps(t), i = 0; i < s; i += 1) e.multiply(this.hierarchy[i].finalTransform.mProp.v);
					}
					this.localTransforms && !this.finalTransform._matMdf || (this.finalTransform._localMatMdf = this.finalTransform._matMdf), this.finalTransform._opMdf && (this.finalTransform.localOpacity = this.finalTransform.mProp.o.v);
				},
				renderLocalTransform: function() {
					if (this.localTransforms) {
						var t = 0, e = this.localTransforms.length;
						if (this.finalTransform._localMatMdf = this.finalTransform._matMdf, !this.finalTransform._localMatMdf || !this.finalTransform._opMdf) for (; t < e;) this.localTransforms[t]._mdf && (this.finalTransform._localMatMdf = !0), this.localTransforms[t]._opMdf && !this.finalTransform._opMdf && (this.finalTransform.localOpacity = this.finalTransform.mProp.o.v, this.finalTransform._opMdf = !0), t += 1;
						if (this.finalTransform._localMatMdf) {
							var i = this.finalTransform.localMat;
							for (this.localTransforms[0].matrix.clone(i), t = 1; t < e; t += 1) {
								var s = this.localTransforms[t].matrix;
								i.multiply(s);
							}
							i.multiply(this.finalTransform.mat);
						}
						if (this.finalTransform._opMdf) {
							var a = this.finalTransform.localOpacity;
							for (t = 0; t < e; t += 1) a *= .01 * this.localTransforms[t].opacity;
							this.finalTransform.localOpacity = a;
						}
					}
				},
				searchEffectTransforms: function() {
					if (this.renderableEffectsManager) {
						var t = this.renderableEffectsManager.getEffects(je);
						if (t.length) {
							this.localTransforms = [], this.finalTransform.localMat = new Ft();
							var e = 0, i = t.length;
							for (e = 0; e < i; e += 1) this.localTransforms.push(t[e]);
						}
					}
				},
				globalToLocal: function(t) {
					var e = [];
					e.push(this.finalTransform);
					for (var i, s = !0, a = this.comp; s;) a.finalTransform ? (a.data.hasMask && e.splice(0, 0, a.finalTransform), a = a.comp) : s = !1;
					var r, n = e.length;
					for (i = 0; i < n; i += 1) r = e[i].mat.applyToPointArray(0, 0, 0), t = [
						t[0] - r[0],
						t[1] - r[1],
						0
					];
					return t;
				},
				mHelper: new Ft()
			}, Xe.prototype.getMaskProperty = function(t) {
				return this.viewData[t].prop;
			}, Xe.prototype.renderFrame = function(t) {
				var e, i = this.element.finalTransform.mat, a = this.masksProperties.length;
				for (e = 0; e < a; e += 1) if ((this.viewData[e].prop._mdf || t) && this.drawPath(this.masksProperties[e], this.viewData[e].prop.v, this.viewData[e]), (this.viewData[e].op._mdf || t) && this.viewData[e].elem.setAttribute("fill-opacity", this.viewData[e].op.v), "n" !== this.masksProperties[e].mode && (this.viewData[e].invRect && (this.element.finalTransform.mProp._mdf || t) && this.viewData[e].invRect.setAttribute("transform", i.getInverseMatrix().to2dCSS()), this.storedData[e].x && (this.storedData[e].x._mdf || t))) {
					var r = this.storedData[e].expan;
					this.storedData[e].x.v < 0 ? ("erode" !== this.storedData[e].lastOperator && (this.storedData[e].lastOperator = "erode", this.storedData[e].elem.setAttribute("filter", "url(" + s() + "#" + this.storedData[e].filterId + ")")), r.setAttribute("radius", -this.storedData[e].x.v)) : ("dilate" !== this.storedData[e].lastOperator && (this.storedData[e].lastOperator = "dilate", this.storedData[e].elem.setAttribute("filter", null)), this.storedData[e].elem.setAttribute("stroke-width", 2 * this.storedData[e].x.v));
				}
			}, Xe.prototype.getMaskelement = function() {
				return this.maskElement;
			}, Xe.prototype.createLayerSolidPath = function() {
				var t = "M0,0 ";
				return t += " h" + this.globalData.compSize.w, t += " v" + this.globalData.compSize.h, t += " h-" + this.globalData.compSize.w, t += " v-" + this.globalData.compSize.h + " ";
			}, Xe.prototype.drawPath = function(t, e, i) {
				var s, a, r = " M" + e.v[0][0] + "," + e.v[0][1];
				for (a = e._length, s = 1; s < a; s += 1) r += " C" + e.o[s - 1][0] + "," + e.o[s - 1][1] + " " + e.i[s][0] + "," + e.i[s][1] + " " + e.v[s][0] + "," + e.v[s][1];
				if (e.c && a > 1 && (r += " C" + e.o[s - 1][0] + "," + e.o[s - 1][1] + " " + e.i[0][0] + "," + e.i[0][1] + " " + e.v[0][0] + "," + e.v[0][1]), i.lastPath !== r) {
					var n = "";
					i.elem && (e.c && (n = t.inv ? this.solidPath + r : r), i.elem.setAttribute("d", n)), i.lastPath = r;
				}
			}, Xe.prototype.destroy = function() {
				this.element = null, this.globalData = null, this.maskElement = null, this.data = null, this.masksProperties = null;
			};
			var He = function() {
				var t = {};
				return t.createFilter = function(t, e) {
					var i = W("filter");
					i.setAttribute("id", t), !0 !== e && (i.setAttribute("filterUnits", "objectBoundingBox"), i.setAttribute("x", "0%"), i.setAttribute("y", "0%"), i.setAttribute("width", "100%"), i.setAttribute("height", "100%"));
					return i;
				}, t.createAlphaToLuminanceFilter = function() {
					var t = W("feColorMatrix");
					return t.setAttribute("type", "matrix"), t.setAttribute("color-interpolation-filters", "sRGB"), t.setAttribute("values", "0 0 0 1 0  0 0 0 1 0  0 0 0 1 0  0 0 0 1 1"), t;
				}, t;
			}(), Ye = function() {
				var t = {
					maskType: !0,
					svgLumaHidden: !0,
					offscreenCanvas: "undefined" != typeof OffscreenCanvas
				};
				return (/MSIE 10/i.test(navigator.userAgent) || /MSIE 9/i.test(navigator.userAgent) || /rv:11.0/i.test(navigator.userAgent) || /Edge\/\d./i.test(navigator.userAgent)) && (t.maskType = !1), /firefox/i.test(navigator.userAgent) && (t.svgLumaHidden = !1), t;
			}(), Ge = {}, Ke = "filter_result_";
			function Je(t) {
				var e, i, a = "SourceGraphic", r = t.data.ef ? t.data.ef.length : 0, n = I(), o = He.createFilter(n, !0), h = 0;
				for (this.filters = [], e = 0; e < r; e += 1) {
					i = null;
					var l = t.data.ef[e].ty;
					if (Ge[l]) i = new Ge[l].effect(o, t.effectsManager.effectElements[e], t, Ke + h, a), a = Ke + h, Ge[l].countsAsEffect && (h += 1);
					i && this.filters.push(i);
				}
				h && (t.globalData.defs.appendChild(o), t.layerElement.setAttribute("filter", "url(" + s() + "#" + n + ")")), this.filters.length && t.addRenderableComponent(this);
			}
			function Ue() {}
			function Ze() {}
			function Qe() {}
			function $e(t, e, i) {
				this.assetData = e.getAssetData(t.refId), this.assetData && this.assetData.sid && (this.assetData = e.slotManager.getProp(this.assetData)), this.initElement(t, e, i), this.sourceRect = {
					top: 0,
					left: 0,
					width: this.assetData.w,
					height: this.assetData.h
				};
			}
			function ti(t, e) {
				this.elem = t, this.pos = e;
			}
			function ei() {}
			Je.prototype.renderFrame = function(t) {
				var e, i = this.filters.length;
				for (e = 0; e < i; e += 1) this.filters[e].renderFrame(t);
			}, Je.prototype.getEffects = function(t) {
				var e, i = this.filters.length, s = [];
				for (e = 0; e < i; e += 1) this.filters[e].type === t && s.push(this.filters[e]);
				return s;
			}, Ue.prototype = {
				initRendererElement: function() {
					this.layerElement = W("g");
				},
				createContainerElements: function() {
					this.matteElement = W("g"), this.transformedElement = this.layerElement, this.maskedElement = this.layerElement, this._sizeChanged = !1;
					var t = null;
					if (this.data.td) {
						this.matteMasks = {};
						var e = W("g");
						e.setAttribute("id", this.layerId), e.appendChild(this.layerElement), t = e, this.globalData.defs.appendChild(e);
					} else this.data.tt ? (this.matteElement.appendChild(this.layerElement), t = this.matteElement, this.baseElement = this.matteElement) : this.baseElement = this.layerElement;
					if (this.data.ln && this.layerElement.setAttribute("id", this.data.ln), this.data.cl && this.layerElement.setAttribute("class", this.data.cl), 0 === this.data.ty && !this.data.hd) {
						var i = W("clipPath"), a = W("path");
						a.setAttribute("d", "M0,0 L" + this.data.w + ",0 L" + this.data.w + "," + this.data.h + " L0," + this.data.h + "z");
						var r = I();
						if (i.setAttribute("id", r), i.appendChild(a), this.globalData.defs.appendChild(i), this.checkMasks()) {
							var n = W("g");
							n.setAttribute("clip-path", "url(" + s() + "#" + r + ")"), n.appendChild(this.layerElement), this.transformedElement = n, t ? t.appendChild(this.transformedElement) : this.baseElement = this.transformedElement;
						} else this.layerElement.setAttribute("clip-path", "url(" + s() + "#" + r + ")");
					}
					0 !== this.data.bm && this.setBlendMode();
				},
				renderElement: function() {
					this.finalTransform._localMatMdf && this.transformedElement.setAttribute("transform", this.finalTransform.localMat.to2dCSS()), this.finalTransform._opMdf && this.transformedElement.setAttribute("opacity", this.finalTransform.localOpacity);
				},
				destroyBaseElement: function() {
					this.layerElement = null, this.matteElement = null, this.maskManager.destroy();
				},
				getBaseElement: function() {
					return this.data.hd ? null : this.baseElement;
				},
				createRenderableComponents: function() {
					this.maskManager = new Xe(this.data, this, this.globalData), this.renderableEffectsManager = new Je(this), this.searchEffectTransforms();
				},
				getMatte: function(t) {
					if (this.matteMasks || (this.matteMasks = {}), !this.matteMasks[t]) {
						var e, i, a, r, n = this.layerId + "_" + t;
						if (1 === t || 3 === t) {
							var o = W("mask");
							o.setAttribute("id", n), o.setAttribute("mask-type", 3 === t ? "luminance" : "alpha"), (a = W("use")).setAttributeNS("http://www.w3.org/1999/xlink", "href", "#" + this.layerId), o.appendChild(a), this.globalData.defs.appendChild(o), Ye.maskType || 1 !== t || (o.setAttribute("mask-type", "luminance"), e = I(), i = He.createFilter(e), this.globalData.defs.appendChild(i), i.appendChild(He.createAlphaToLuminanceFilter()), (r = W("g")).appendChild(a), o.appendChild(r), r.setAttribute("filter", "url(" + s() + "#" + e + ")"));
						} else if (2 === t) {
							var h = W("mask");
							h.setAttribute("id", n), h.setAttribute("mask-type", "alpha");
							var l = W("g");
							h.appendChild(l), e = I(), i = He.createFilter(e);
							var p = W("feComponentTransfer");
							p.setAttribute("in", "SourceGraphic"), i.appendChild(p);
							var f = W("feFuncA");
							f.setAttribute("type", "table"), f.setAttribute("tableValues", "1.0 0.0"), p.appendChild(f), this.globalData.defs.appendChild(i);
							var d = W("rect");
							d.setAttribute("width", this.comp.data.w), d.setAttribute("height", this.comp.data.h), d.setAttribute("x", "0"), d.setAttribute("y", "0"), d.setAttribute("fill", "#ffffff"), d.setAttribute("opacity", "0"), l.setAttribute("filter", "url(" + s() + "#" + e + ")"), l.appendChild(d), (a = W("use")).setAttributeNS("http://www.w3.org/1999/xlink", "href", "#" + this.layerId), l.appendChild(a), Ye.maskType || (h.setAttribute("mask-type", "luminance"), i.appendChild(He.createAlphaToLuminanceFilter()), r = W("g"), l.appendChild(d), r.appendChild(this.layerElement), l.appendChild(r)), this.globalData.defs.appendChild(h);
						}
						this.matteMasks[t] = n;
					}
					return this.matteMasks[t];
				},
				setMatte: function(t) {
					this.matteElement && this.matteElement.setAttribute("mask", "url(" + s() + "#" + t + ")");
				}
			}, Ze.prototype = {
				initHierarchy: function() {
					this.hierarchy = [], this._isParent = !1, this.checkParenting();
				},
				setHierarchy: function(t) {
					this.hierarchy = t;
				},
				setAsParent: function() {
					this._isParent = !0;
				},
				checkParenting: function() {
					void 0 !== this.data.parent && this.comp.buildElementParenting(this, this.data.parent, []);
				}
			}, r([Se, n({
				initElement: function(t, e, i) {
					this.initFrame(), this.initBaseData(t, e, i), this.initTransform(t, e, i), this.initHierarchy(), this.initRenderable(), this.initRendererElement(), this.createContainerElements(), this.createRenderableComponents(), this.createContent(), this.hide();
				},
				hide: function() {
					this.hidden || this.isInRange && !this.isTransparent || ((this.baseElement || this.layerElement).style.display = "none", this.hidden = !0);
				},
				show: function() {
					this.isInRange && !this.isTransparent && (this.data.hd || ((this.baseElement || this.layerElement).style.display = "block"), this.hidden = !1, this._isFirstFrame = !0);
				},
				renderFrame: function() {
					this.data.hd || this.hidden || (this.renderTransform(), this.renderRenderable(), this.renderLocalTransform(), this.renderElement(), this.renderInnerContent(), this._isFirstFrame && (this._isFirstFrame = !1));
				},
				renderInnerContent: function() {},
				prepareFrame: function(t) {
					this._mdf = !1, this.prepareRenderableFrame(t), this.prepareProperties(t, this.isInRange), this.checkTransparency();
				},
				destroy: function() {
					this.innerElem = null, this.destroyBaseElement();
				}
			})], Qe), r([
				ze,
				We,
				Ue,
				Ze,
				Oe,
				Qe
			], $e), $e.prototype.createContent = function() {
				var t = this.globalData.getAssetsPath(this.assetData);
				this.innerElem = W("image"), this.innerElem.setAttribute("width", this.assetData.w + "px"), this.innerElem.setAttribute("height", this.assetData.h + "px"), this.innerElem.setAttribute("preserveAspectRatio", this.assetData.pr || this.globalData.renderConfig.imagePreserveAspectRatio), this.innerElem.setAttributeNS("http://www.w3.org/1999/xlink", "href", t), this.layerElement.appendChild(this.innerElem);
			}, $e.prototype.sourceRectAtTime = function() {
				return this.sourceRect;
			}, ei.prototype = {
				addShapeToModifiers: function(t) {
					var e, i = this.shapeModifiers.length;
					for (e = 0; e < i; e += 1) this.shapeModifiers[e].addShape(t);
				},
				isShapeInAnimatedModifiers: function(t) {
					for (var e = this.shapeModifiers.length; 0 < e;) if (this.shapeModifiers[0].isAnimatedWithShape(t)) return !0;
					return !1;
				},
				renderModifiers: function() {
					if (this.shapeModifiers.length) {
						var t, e = this.shapes.length;
						for (t = 0; t < e; t += 1) this.shapes[t].sh.reset();
						for (t = (e = this.shapeModifiers.length) - 1; t >= 0 && !this.shapeModifiers[t].processShapes(this._isFirstFrame); t -= 1);
					}
				},
				searchProcessedElement: function(t) {
					for (var e = this.processedElements, i = 0, s = e.length; i < s;) {
						if (e[i].elem === t) return e[i].pos;
						i += 1;
					}
					return 0;
				},
				addProcessedElement: function(t, e) {
					for (var i = this.processedElements, s = i.length; s;) if (i[s -= 1].elem === t) return void (i[s].pos = e);
					i.push(new ti(t, e));
				},
				prepareFrame: function(t) {
					this.prepareRenderableFrame(t), this.prepareProperties(t, this.isInRange);
				}
			};
			var ii = {
				1: "butt",
				2: "round",
				3: "square"
			}, si = {
				1: "miter",
				2: "round",
				3: "bevel"
			};
			function ai(t, e, i) {
				this.caches = [], this.styles = [], this.transformers = t, this.lStr = "", this.sh = i, this.lvl = e, this._isAnimated = !!i.k;
				for (var s = 0, a = t.length; s < a;) {
					if (t[s].mProps.dynamicProperties.length) {
						this._isAnimated = !0;
						break;
					}
					s += 1;
				}
			}
			function ri(t, e) {
				this.data = t, this.type = t.ty, this.d = "", this.lvl = e, this._mdf = !1, this.closed = !0 === t.hd, this.pElem = W("path"), this.msElem = null;
			}
			function ni(t, e, i, s) {
				var a;
				this.elem = t, this.frameId = -1, this.dataProps = l(e.length), this.renderer = i, this.k = !1, this.dashStr = "", this.dashArray = h("float32", e.length ? e.length - 1 : 0), this.dashoffset = h("float32", 1), this.initDynamicPropertyContainer(s);
				var r, n = e.length || 0;
				for (a = 0; a < n; a += 1) r = vt.getProp(t, e[a].v, 0, 0, this), this.k = r.k || this.k, this.dataProps[a] = {
					n: e[a].n,
					p: r
				};
				this.k || this.getValue(!0), this._isAnimated = this.k;
			}
			function oi(t, e, i) {
				this.initDynamicPropertyContainer(t), this.getValue = this.iterateDynamicProperties, this.o = vt.getProp(t, e.o, 0, .01, this), this.w = vt.getProp(t, e.w, 0, null, this), this.d = new ni(t, e.d || {}, "svg", this), this.c = vt.getProp(t, e.c, 1, 255, this), this.style = i, this._isAnimated = !!this._isAnimated;
			}
			function hi(t, e, i) {
				this.initDynamicPropertyContainer(t), this.getValue = this.iterateDynamicProperties, this.o = vt.getProp(t, e.o, 0, .01, this), this.c = vt.getProp(t, e.c, 1, 255, this), this.style = i;
			}
			function li(t, e, i) {
				this.initDynamicPropertyContainer(t), this.getValue = this.iterateDynamicProperties, this.style = i;
			}
			function pi(t, e, i) {
				this.data = e, this.c = h("uint8c", 4 * e.p);
				var s = e.k.k[0].s ? e.k.k[0].s.length - 4 * e.p : e.k.k.length - 4 * e.p;
				this.o = h("float32", s), this._cmdf = !1, this._omdf = !1, this._collapsable = this.checkCollapsable(), this._hasOpacity = s, this.initDynamicPropertyContainer(i), this.prop = vt.getProp(t, e.k, 1, null, this), this.k = this.prop.k, this.getValue(!0);
			}
			function fi(t, e, i) {
				this.initDynamicPropertyContainer(t), this.getValue = this.iterateDynamicProperties, this.initGradientData(t, e, i);
			}
			function di(t, e, i) {
				this.initDynamicPropertyContainer(t), this.getValue = this.iterateDynamicProperties, this.w = vt.getProp(t, e.w, 0, null, this), this.d = new ni(t, e.d || {}, "svg", this), this.initGradientData(t, e, i), this._isAnimated = !!this._isAnimated;
			}
			function mi() {
				this.it = [], this.prevViewData = [], this.gr = W("g");
			}
			function ci(t, e, i) {
				this.transform = {
					mProps: t,
					op: e,
					container: i
				}, this.elements = [], this._isAnimated = this.transform.mProps.dynamicProperties.length || this.transform.op.effectsSequence.length;
			}
			ai.prototype.setAsAnimated = function() {
				this._isAnimated = !0;
			}, ri.prototype.reset = function() {
				this.d = "", this._mdf = !1;
			}, ni.prototype.getValue = function(t) {
				if ((this.elem.globalData.frameId !== this.frameId || t) && (this.frameId = this.elem.globalData.frameId, this.iterateDynamicProperties(), this._mdf = this._mdf || t, this._mdf)) {
					var e = 0, i = this.dataProps.length;
					for ("svg" === this.renderer && (this.dashStr = ""), e = 0; e < i; e += 1) "o" !== this.dataProps[e].n ? "svg" === this.renderer ? this.dashStr += " " + this.dataProps[e].p.v : this.dashArray[e] = this.dataProps[e].p.v : this.dashoffset[0] = this.dataProps[e].p.v;
				}
			}, r([bt], ni), r([bt], oi), r([bt], hi), r([bt], li), pi.prototype.comparePoints = function(t, e) {
				for (var i = 0, s = this.o.length / 2; i < s;) {
					if (Math.abs(t[4 * i] - t[4 * e + 2 * i]) > .01) return !1;
					i += 1;
				}
				return !0;
			}, pi.prototype.checkCollapsable = function() {
				if (this.o.length / 2 != this.c.length / 4) return !1;
				if (this.data.k.k[0].s) for (var t = 0, e = this.data.k.k.length; t < e;) {
					if (!this.comparePoints(this.data.k.k[t].s, this.data.p)) return !1;
					t += 1;
				}
				else if (!this.comparePoints(this.data.k.k, this.data.p)) return !1;
				return !0;
			}, pi.prototype.getValue = function(t) {
				if (this.prop.getValue(), this._mdf = !1, this._cmdf = !1, this._omdf = !1, this.prop._mdf || t) {
					var e, i, s, a = 4 * this.data.p;
					for (e = 0; e < a; e += 1) i = e % 4 == 0 ? 100 : 255, s = Math.round(this.prop.v[e] * i), this.c[e] !== s && (this.c[e] = s, this._cmdf = !t);
					if (this.o.length) for (a = this.prop.v.length, e = 4 * this.data.p; e < a; e += 1) i = e % 2 == 0 ? 100 : 1, s = e % 2 == 0 ? Math.round(100 * this.prop.v[e]) : this.prop.v[e], this.o[e - 4 * this.data.p] !== s && (this.o[e - 4 * this.data.p] = s, this._omdf = !t);
					this._mdf = !t;
				}
			}, r([bt], pi), fi.prototype.initGradientData = function(t, e, i) {
				this.o = vt.getProp(t, e.o, 0, .01, this), this.s = vt.getProp(t, e.s, 1, null, this), this.e = vt.getProp(t, e.e, 1, null, this), this.h = vt.getProp(t, e.h || { k: 0 }, 0, .01, this), this.a = vt.getProp(t, e.a || { k: 0 }, 0, P, this), this.g = new pi(t, e.g, this), this.style = i, this.stops = [], this.setGradientData(i.pElem, e), this.setGradientOpacity(e, i), this._isAnimated = !!this._isAnimated;
			}, fi.prototype.setGradientData = function(t, e) {
				var i = I(), a = W(1 === e.t ? "linearGradient" : "radialGradient");
				a.setAttribute("id", i), a.setAttribute("spreadMethod", "pad"), a.setAttribute("gradientUnits", "userSpaceOnUse");
				var r, n, o, h = [];
				for (o = 4 * e.g.p, n = 0; n < o; n += 4) r = W("stop"), a.appendChild(r), h.push(r);
				t.setAttribute("gf" === e.ty ? "fill" : "stroke", "url(" + s() + "#" + i + ")"), this.gf = a, this.cst = h;
			}, fi.prototype.setGradientOpacity = function(t, e) {
				if (this.g._hasOpacity && !this.g._collapsable) {
					var i, a, r, n = W("mask"), o = W("path");
					n.appendChild(o);
					var h = I(), l = I();
					n.setAttribute("id", l);
					var p = W(1 === t.t ? "linearGradient" : "radialGradient");
					p.setAttribute("id", h), p.setAttribute("spreadMethod", "pad"), p.setAttribute("gradientUnits", "userSpaceOnUse"), r = t.g.k.k[0].s ? t.g.k.k[0].s.length : t.g.k.k.length;
					var f = this.stops;
					for (a = 4 * t.g.p; a < r; a += 2) (i = W("stop")).setAttribute("stop-color", "rgb(255,255,255)"), p.appendChild(i), f.push(i);
					o.setAttribute("gf" === t.ty ? "fill" : "stroke", "url(" + s() + "#" + h + ")"), "gs" === t.ty && (o.setAttribute("stroke-linecap", ii[t.lc || 2]), o.setAttribute("stroke-linejoin", si[t.lj || 2]), 1 === t.lj && o.setAttribute("stroke-miterlimit", t.ml)), this.of = p, this.ms = n, this.ost = f, this.maskId = l, e.msElem = o;
				}
			}, r([bt], fi), r([fi, bt], di);
			var ui = function(t, e, i, s) {
				if (0 === e) return "";
				var a, r = t.o, n = t.i, o = t.v, h = " M" + s.applyToPointStringified(o[0][0], o[0][1]);
				for (a = 1; a < e; a += 1) h += " C" + s.applyToPointStringified(r[a - 1][0], r[a - 1][1]) + " " + s.applyToPointStringified(n[a][0], n[a][1]) + " " + s.applyToPointStringified(o[a][0], o[a][1]);
				return i && e && (h += " C" + s.applyToPointStringified(r[a - 1][0], r[a - 1][1]) + " " + s.applyToPointStringified(n[0][0], n[0][1]) + " " + s.applyToPointStringified(o[0][0], o[0][1]), h += "z"), h;
			}, gi = function() {
				var t = new Ft(), e = new Ft();
				function i(t, e, i) {
					(i || e.transform.op._mdf) && e.transform.container.setAttribute("opacity", e.transform.op.v), (i || e.transform.mProps._mdf) && e.transform.container.setAttribute("transform", e.transform.mProps.v.to2dCSS());
				}
				function s() {}
				function a(i, s, a) {
					var r, n, o, h, l, p, f, d, m, c, u = s.styles.length, g = s.lvl;
					for (p = 0; p < u; p += 1) {
						if (h = s.sh._mdf || a, s.styles[p].lvl < g) {
							for (d = e.reset(), m = g - s.styles[p].lvl, c = s.transformers.length - 1; !h && m > 0;) h = s.transformers[c].mProps._mdf || h, m -= 1, c -= 1;
							if (h) for (m = g - s.styles[p].lvl, c = s.transformers.length - 1; m > 0;) d.multiply(s.transformers[c].mProps.v), m -= 1, c -= 1;
						} else d = t;
						if (n = (f = s.sh.paths)._length, h) {
							for (o = "", r = 0; r < n; r += 1) (l = f.shapes[r]) && l._length && (o += ui(l, l._length, l.c, d));
							s.caches[p] = o;
						} else o = s.caches[p];
						s.styles[p].d += !0 === i.hd ? "" : o, s.styles[p]._mdf = h || s.styles[p]._mdf;
					}
				}
				function r(t, e, i) {
					var s = e.style;
					(e.c._mdf || i) && s.pElem.setAttribute("fill", "rgb(" + v(e.c.v[0]) + "," + v(e.c.v[1]) + "," + v(e.c.v[2]) + ")"), (e.o._mdf || i) && s.pElem.setAttribute("fill-opacity", e.o.v);
				}
				function n(t, e, i) {
					o(t, e, i), h(t, e, i);
				}
				function o(t, e, i) {
					var s, a, r, n, o, h = e.gf, l = e.g._hasOpacity, p = e.s.v, f = e.e.v;
					if (e.o._mdf || i) {
						var d = "gf" === t.ty ? "fill-opacity" : "stroke-opacity";
						e.style.pElem.setAttribute(d, e.o.v);
					}
					if (e.s._mdf || i) {
						var m = 1 === t.t ? "x1" : "cx", c = "x1" === m ? "y1" : "cy";
						h.setAttribute(m, p[0]), h.setAttribute(c, p[1]), l && !e.g._collapsable && (e.of.setAttribute(m, p[0]), e.of.setAttribute(c, p[1]));
					}
					if (e.g._cmdf || i) {
						s = e.cst;
						var u = e.g.c;
						for (r = s.length, a = 0; a < r; a += 1) (n = s[a]).setAttribute("offset", u[4 * a] + "%"), n.setAttribute("stop-color", "rgb(" + u[4 * a + 1] + "," + u[4 * a + 2] + "," + u[4 * a + 3] + ")");
					}
					if (l && (e.g._omdf || i)) {
						var g = e.g.o;
						for (r = (s = e.g._collapsable ? e.cst : e.ost).length, a = 0; a < r; a += 1) n = s[a], e.g._collapsable || n.setAttribute("offset", g[2 * a] + "%"), n.setAttribute("stop-opacity", g[2 * a + 1]);
					}
					if (1 === t.t) (e.e._mdf || i) && (h.setAttribute("x2", f[0]), h.setAttribute("y2", f[1]), l && !e.g._collapsable && (e.of.setAttribute("x2", f[0]), e.of.setAttribute("y2", f[1])));
					else if ((e.s._mdf || e.e._mdf || i) && (o = Math.sqrt(Math.pow(p[0] - f[0], 2) + Math.pow(p[1] - f[1], 2)), h.setAttribute("r", o), l && !e.g._collapsable && e.of.setAttribute("r", o)), e.s._mdf || e.e._mdf || e.h._mdf || e.a._mdf || i) {
						o || (o = Math.sqrt(Math.pow(p[0] - f[0], 2) + Math.pow(p[1] - f[1], 2)));
						var y = Math.atan2(f[1] - p[1], f[0] - p[0]), v = e.h.v;
						v >= 1 ? v = .99 : v <= -1 && (v = -.99);
						var b = o * v, _ = Math.cos(y + e.a.v) * b + p[0], k = Math.sin(y + e.a.v) * b + p[1];
						h.setAttribute("fx", _), h.setAttribute("fy", k), l && !e.g._collapsable && (e.of.setAttribute("fx", _), e.of.setAttribute("fy", k));
					}
				}
				function h(t, e, i) {
					var s = e.style, a = e.d;
					a && (a._mdf || i) && a.dashStr && (s.pElem.setAttribute("stroke-dasharray", a.dashStr), s.pElem.setAttribute("stroke-dashoffset", a.dashoffset[0])), e.c && (e.c._mdf || i) && s.pElem.setAttribute("stroke", "rgb(" + v(e.c.v[0]) + "," + v(e.c.v[1]) + "," + v(e.c.v[2]) + ")"), (e.o._mdf || i) && s.pElem.setAttribute("stroke-opacity", e.o.v), (e.w._mdf || i) && (s.pElem.setAttribute("stroke-width", e.w.v), s.msElem && s.msElem.setAttribute("stroke-width", e.w.v));
				}
				return { createRenderFunction: function(t) {
					switch (t.ty) {
						case "fl": return r;
						case "gf": return o;
						case "gs": return n;
						case "st": return h;
						case "sh":
						case "el":
						case "rc":
						case "sr": return a;
						case "tr": return i;
						case "no": return s;
						default: return null;
					}
				} };
			}();
			function yi(t, e, i) {
				this.shapes = [], this.shapesData = t.shapes, this.stylesList = [], this.shapeModifiers = [], this.itemsData = [], this.processedElements = [], this.animatedContents = [], this.initElement(t, e, i), this.prevViewData = [];
			}
			function vi(t, e, i, s, a, r) {
				this.o = t, this.sw = e, this.sc = i, this.fc = s, this.m = a, this.p = r, this._mdf = {
					o: !0,
					sw: !!e,
					sc: !!i,
					fc: !!s,
					m: !0,
					p: !0
				};
			}
			function bi(t, e) {
				this._frameId = i, this.pv = "", this.v = "", this.kf = !1, this._isFirstFrame = !0, this._mdf = !1, e.d && e.d.sid && (e.d = t.globalData.slotManager.getProp(e.d)), this.data = e, this.elem = t, this.comp = this.elem.comp, this.keysIndex = 0, this.canResize = !1, this.minimumFontSize = 1, this.effectsSequence = [], this.currentData = {
					ascent: 0,
					boxWidth: this.defaultBoxWidth,
					f: "",
					fStyle: "",
					fWeight: "",
					fc: "",
					j: "",
					justifyOffset: "",
					l: [],
					lh: 0,
					lineWidths: [],
					ls: "",
					of: "",
					s: "",
					sc: "",
					sw: 0,
					t: 0,
					tr: 0,
					sz: 0,
					ps: null,
					fillColorAnim: !1,
					strokeColorAnim: !1,
					strokeWidthAnim: !1,
					yOffset: 0,
					finalSize: 0,
					finalText: [],
					finalLineHeight: 0,
					__complete: !1
				}, this.copyData(this.currentData, this.data.d.k[0].s), this.searchProperty() || this.completeTextData(this.currentData);
			}
			r([
				ze,
				We,
				Ue,
				ei,
				Ze,
				Oe,
				Qe
			], yi), yi.prototype.initSecondaryElement = function() {}, yi.prototype.identityMatrix = new Ft(), yi.prototype.buildExpressionInterface = function() {}, yi.prototype.createContent = function() {
				this.searchShapes(this.shapesData, this.itemsData, this.prevViewData, this.layerElement, 0, [], !0), this.filterUniqueShapes();
			}, yi.prototype.filterUniqueShapes = function() {
				var t, e, i, s, a = this.shapes.length, r = this.stylesList.length, n = [], o = !1;
				for (i = 0; i < r; i += 1) {
					for (s = this.stylesList[i], o = !1, n.length = 0, t = 0; t < a; t += 1) -1 !== (e = this.shapes[t]).styles.indexOf(s) && (n.push(e), o = e._isAnimated || o);
					n.length > 1 && o && this.setShapesAsAnimated(n);
				}
			}, yi.prototype.setShapesAsAnimated = function(t) {
				var e, i = t.length;
				for (e = 0; e < i; e += 1) t[e].setAsAnimated();
			}, yi.prototype.createStyleElement = function(t, e) {
				var i, a = new ri(t, e), r = a.pElem;
				if ("st" === t.ty) i = new oi(this, t, a);
				else if ("fl" === t.ty) i = new hi(this, t, a);
				else if ("gf" === t.ty || "gs" === t.ty) i = new ("gf" === t.ty ? fi : di)(this, t, a), this.globalData.defs.appendChild(i.gf), i.maskId && (this.globalData.defs.appendChild(i.ms), this.globalData.defs.appendChild(i.of), r.setAttribute("mask", "url(" + s() + "#" + i.maskId + ")"));
				else "no" === t.ty && (i = new li(this, t, a));
				return "st" !== t.ty && "gs" !== t.ty || (r.setAttribute("stroke-linecap", ii[t.lc || 2]), r.setAttribute("stroke-linejoin", si[t.lj || 2]), r.setAttribute("fill-opacity", "0"), 1 === t.lj && r.setAttribute("stroke-miterlimit", t.ml)), 2 === t.r && r.setAttribute("fill-rule", "evenodd"), t.ln && r.setAttribute("id", t.ln), t.cl && r.setAttribute("class", t.cl), t.bm && (r.style["mix-blend-mode"] = we(t.bm)), this.stylesList.push(a), this.addToAnimatedContents(t, i), i;
			}, yi.prototype.createGroupElement = function(t) {
				var e = new mi();
				return t.ln && e.gr.setAttribute("id", t.ln), t.cl && e.gr.setAttribute("class", t.cl), t.bm && (e.gr.style["mix-blend-mode"] = we(t.bm)), e;
			}, yi.prototype.createTransformElement = function(t, e) {
				var i = Xt.getTransformProperty(this, t, this), s = new ci(i, i.o, e);
				return this.addToAnimatedContents(t, s), s;
			}, yi.prototype.createShapeElement = function(t, e, i) {
				var s = 4;
				"rc" === t.ty ? s = 5 : "el" === t.ty ? s = 6 : "sr" === t.ty && (s = 7);
				var a = new ai(e, i, Tt.getShapeProp(this, t, s, this));
				return this.shapes.push(a), this.addShapeToModifiers(a), this.addToAnimatedContents(t, a), a;
			}, yi.prototype.addToAnimatedContents = function(t, e) {
				for (var i = 0, s = this.animatedContents.length; i < s;) {
					if (this.animatedContents[i].element === e) return;
					i += 1;
				}
				this.animatedContents.push({
					fn: gi.createRenderFunction(t),
					element: e,
					data: t
				});
			}, yi.prototype.setElementStyles = function(t) {
				var e, i = t.styles, s = this.stylesList.length;
				for (e = 0; e < s; e += 1) -1 !== i.indexOf(this.stylesList[e]) || this.stylesList[e].closed || i.push(this.stylesList[e]);
			}, yi.prototype.reloadShapes = function() {
				var t;
				this._isFirstFrame = !0;
				var e = this.itemsData.length;
				for (t = 0; t < e; t += 1) this.prevViewData[t] = this.itemsData[t];
				for (this.searchShapes(this.shapesData, this.itemsData, this.prevViewData, this.layerElement, 0, [], !0), this.filterUniqueShapes(), e = this.dynamicProperties.length, t = 0; t < e; t += 1) this.dynamicProperties[t].getValue();
				this.renderModifiers();
			}, yi.prototype.searchShapes = function(t, e, i, s, a, r, n) {
				var o, h, l, p, f, d, m = [].concat(r), c = t.length - 1, u = [], g = [];
				for (o = c; o >= 0; o -= 1) {
					if ((d = this.searchProcessedElement(t[o])) ? e[o] = i[d - 1] : t[o]._render = n, "fl" === t[o].ty || "st" === t[o].ty || "gf" === t[o].ty || "gs" === t[o].ty || "no" === t[o].ty) d ? e[o].style.closed = t[o].hd : e[o] = this.createStyleElement(t[o], a), t[o]._render && e[o].style.pElem.parentNode !== s && s.appendChild(e[o].style.pElem), u.push(e[o].style);
					else if ("gr" === t[o].ty) {
						if (d) for (l = e[o].it.length, h = 0; h < l; h += 1) e[o].prevViewData[h] = e[o].it[h];
						else e[o] = this.createGroupElement(t[o]);
						this.searchShapes(t[o].it, e[o].it, e[o].prevViewData, e[o].gr, a + 1, m, n), t[o]._render && e[o].gr.parentNode !== s && s.appendChild(e[o].gr);
					} else "tr" === t[o].ty ? (d || (e[o] = this.createTransformElement(t[o], s)), p = e[o].transform, m.push(p)) : "sh" === t[o].ty || "rc" === t[o].ty || "el" === t[o].ty || "sr" === t[o].ty ? (d || (e[o] = this.createShapeElement(t[o], m, a)), this.setElementStyles(e[o])) : "tm" === t[o].ty || "rd" === t[o].ty || "ms" === t[o].ty || "pb" === t[o].ty || "zz" === t[o].ty || "op" === t[o].ty ? (d ? (f = e[o]).closed = !1 : ((f = Bt.getModifier(t[o].ty)).init(this, t[o]), e[o] = f, this.shapeModifiers.push(f)), g.push(f)) : "rp" === t[o].ty && (d ? (f = e[o]).closed = !0 : (f = Bt.getModifier(t[o].ty), e[o] = f, f.init(this, t, o, e), this.shapeModifiers.push(f), n = !1), g.push(f));
					this.addProcessedElement(t[o], o + 1);
				}
				for (c = u.length, o = 0; o < c; o += 1) u[o].closed = !0;
				for (c = g.length, o = 0; o < c; o += 1) g[o].closed = !0;
			}, yi.prototype.renderInnerContent = function() {
				var t;
				this.renderModifiers();
				var e = this.stylesList.length;
				for (t = 0; t < e; t += 1) this.stylesList[t].reset();
				for (this.renderShape(), t = 0; t < e; t += 1) (this.stylesList[t]._mdf || this._isFirstFrame) && (this.stylesList[t].msElem && (this.stylesList[t].msElem.setAttribute("d", this.stylesList[t].d), this.stylesList[t].d = "M0 0" + this.stylesList[t].d), this.stylesList[t].pElem.setAttribute("d", this.stylesList[t].d || "M0 0"));
			}, yi.prototype.renderShape = function() {
				var t, e, i = this.animatedContents.length;
				for (t = 0; t < i; t += 1) e = this.animatedContents[t], (this._isFirstFrame || e.element._isAnimated) && !0 !== e.data && e.fn(e.data, e.element, this._isFirstFrame);
			}, yi.prototype.destroy = function() {
				this.destroyBaseElement(), this.shapesData = null, this.itemsData = null;
			}, vi.prototype.update = function(t, e, i, s, a, r) {
				this._mdf.o = !1, this._mdf.sw = !1, this._mdf.sc = !1, this._mdf.fc = !1, this._mdf.m = !1, this._mdf.p = !1;
				var n = !1;
				return this.o !== t && (this.o = t, this._mdf.o = !0, n = !0), this.sw !== e && (this.sw = e, this._mdf.sw = !0, n = !0), this.sc !== i && (this.sc = i, this._mdf.sc = !0, n = !0), this.fc !== s && (this.fc = s, this._mdf.fc = !0, n = !0), this.m !== a && (this.m = a, this._mdf.m = !0, n = !0), !r.length || this.p[0] === r[0] && this.p[1] === r[1] && this.p[4] === r[4] && this.p[5] === r[5] && this.p[12] === r[12] && this.p[13] === r[13] || (this.p = r, this._mdf.p = !0, n = !0), n;
			}, bi.prototype.defaultBoxWidth = [0, 0], bi.prototype.copyData = function(t, e) {
				for (var i in e) Object.prototype.hasOwnProperty.call(e, i) && (t[i] = e[i]);
				return t;
			}, bi.prototype.setCurrentData = function(t) {
				t.__complete || this.completeTextData(t), this.currentData = t, this.currentData.boxWidth = this.currentData.boxWidth || this.defaultBoxWidth, this._mdf = !0;
			}, bi.prototype.searchProperty = function() {
				return this.searchKeyframes();
			}, bi.prototype.searchKeyframes = function() {
				return this.kf = this.data.d.k.length > 1, this.kf && this.addEffect(this.getKeyframeValue.bind(this)), this.kf;
			}, bi.prototype.addEffect = function(t) {
				this.effectsSequence.push(t), this.elem.addDynamicProperty(this);
			}, bi.prototype.getValue = function(t) {
				if (this.elem.globalData.frameId !== this.frameId && this.effectsSequence.length || t) {
					this.currentData.t = this.data.d.k[this.keysIndex].s.t;
					var e = this.currentData, i = this.keysIndex;
					if (this.lock) this.setCurrentData(this.currentData);
					else {
						var s;
						this.lock = !0, this._mdf = !1;
						var a = this.effectsSequence.length, r = t || this.data.d.k[this.keysIndex].s;
						for (s = 0; s < a; s += 1) r = i !== this.keysIndex ? this.effectsSequence[s](r, r.t) : this.effectsSequence[s](this.currentData, r.t);
						e !== r && this.setCurrentData(r), this.v = this.currentData, this.pv = this.v, this.lock = !1, this.frameId = this.elem.globalData.frameId;
					}
				}
			}, bi.prototype.getKeyframeValue = function() {
				for (var t = this.data.d.k, e = this.elem.comp.renderedFrame, i = 0, s = t.length; i <= s - 1 && !(i === s - 1 || t[i + 1].t > e);) i += 1;
				return this.keysIndex !== i && (this.keysIndex = i), this.data.d.k[this.keysIndex].s;
			}, bi.prototype.buildFinalText = function(t) {
				for (var e, i, s = [], a = 0, r = t.length, n = !1, o = !1, h = ""; a < r;) n = o, o = !1, e = t.charCodeAt(a), h = t.charAt(a), Pe.isCombinedCharacter(e) ? n = !0 : e >= 55296 && e <= 56319 ? Pe.isRegionalFlag(t, a) ? h = t.substr(a, 14) : (i = t.charCodeAt(a + 1)) >= 56320 && i <= 57343 && (Pe.isModifier(e, i) ? (h = t.substr(a, 2), n = !0) : h = Pe.isFlagEmoji(t.substr(a, 4)) ? t.substr(a, 4) : t.substr(a, 2)) : e > 56319 ? (i = t.charCodeAt(a + 1), Pe.isVariationSelector(e) && (n = !0)) : Pe.isZeroWidthJoiner(e) && (n = !0, o = !0), n ? (s[s.length - 1] += h, n = !1) : s.push(h), a += h.length;
				return s;
			}, bi.prototype.completeTextData = function(t) {
				t.__complete = !0;
				var e, i, s, a, r, n, o, h = this.elem.globalData.fontManager, l = this.data, p = [], f = 0, d = l.m.g, m = 0, c = 0, u = 0, g = [], y = 0, v = 0, b = h.getFontByName(t.f), _ = 0, k = ke(b);
				t.fWeight = k.weight, t.fStyle = k.style, t.finalSize = t.s, t.finalText = this.buildFinalText(t.t), i = t.finalText.length, t.finalLineHeight = t.lh;
				var P, A = t.tr / 1e3 * t.finalSize;
				if (t.sz) for (var S, x, w = !0, D = t.sz[0], C = t.sz[1]; w;) {
					S = 0, y = 0, i = (x = this.buildFinalText(t.t)).length, A = t.tr / 1e3 * t.finalSize;
					var M = -1;
					for (e = 0; e < i; e += 1) P = x[e].charCodeAt(0), s = !1, " " === x[e] ? M = e : 13 !== P && 3 !== P || (y = 0, s = !0, S += t.finalLineHeight || 1.2 * t.finalSize), h.chars ? (o = h.getCharData(x[e], b.fStyle, b.fFamily), _ = s ? 0 : o.w * t.finalSize / 100) : _ = h.measureText(x[e], t.f, t.finalSize), y + _ > D && " " !== x[e] ? (-1 === M ? i += 1 : e = M, S += t.finalLineHeight || 1.2 * t.finalSize, x.splice(e, M === e ? 1 : 0, "\r"), M = -1, y = 0) : (y += _, y += A);
					S += b.ascent * t.finalSize / 100, this.canResize && t.finalSize > this.minimumFontSize && C < S ? (t.finalSize -= 1, t.finalLineHeight = t.finalSize * t.lh / t.s) : (t.finalText = x, i = t.finalText.length, w = !1);
				}
				y = -A, _ = 0;
				var T, F = 0;
				for (e = 0; e < i; e += 1) if (s = !1, 13 === (P = (T = t.finalText[e]).charCodeAt(0)) || 3 === P ? (F = 0, g.push(y), v = y > v ? y : v, y = -2 * A, a = "", s = !0, u += 1) : a = T, h.chars ? (o = h.getCharData(T, b.fStyle, h.getFontByName(t.f).fFamily), _ = s ? 0 : o.w * t.finalSize / 100) : _ = h.measureText(a, t.f, t.finalSize), " " === T ? F += _ + A : (y += _ + A + F, F = 0), p.push({
					l: _,
					an: _,
					add: m,
					n: s,
					anIndexes: [],
					val: a,
					line: u,
					animatorJustifyOffset: 0
				}), 2 == d) {
					if (m += _, "" === a || " " === a || e === i - 1) {
						for ("" !== a && " " !== a || (m -= _); c <= e;) p[c].an = m, p[c].ind = f, p[c].extra = _, c += 1;
						f += 1, m = 0;
					}
				} else if (3 == d) {
					if (m += _, "" === a || e === i - 1) {
						for ("" === a && (m -= _); c <= e;) p[c].an = m, p[c].ind = f, p[c].extra = _, c += 1;
						m = 0, f += 1;
					}
				} else p[f].ind = f, p[f].extra = 0, f += 1;
				if (t.l = p, v = y > v ? y : v, g.push(y), t.sz) t.boxWidth = t.sz[0], t.justifyOffset = 0;
				else switch (t.boxWidth = v, t.j) {
					case 1:
						t.justifyOffset = -t.boxWidth;
						break;
					case 2:
						t.justifyOffset = -t.boxWidth / 2;
						break;
					default: t.justifyOffset = 0;
				}
				t.lineWidths = g;
				var E, I, L, V, R = l.a;
				n = R.length;
				var z = [];
				for (r = 0; r < n; r += 1) {
					for ((E = R[r]).a.sc && (t.strokeColorAnim = !0), E.a.sw && (t.strokeWidthAnim = !0), (E.a.fc || E.a.fh || E.a.fs || E.a.fb) && (t.fillColorAnim = !0), V = 0, L = E.s.b, e = 0; e < i; e += 1) (I = p[e]).anIndexes[r] = V, (1 == L && "" !== I.val || 2 == L && "" !== I.val && " " !== I.val || 3 == L && (I.n || " " == I.val || e == i - 1) || 4 == L && (I.n || e == i - 1)) && (1 === E.s.rn && z.push(V), V += 1);
					l.a[r].s.totalChars = V;
					var O, N = -1;
					if (1 === E.s.rn) for (e = 0; e < i; e += 1) N != (I = p[e]).anIndexes[r] && (N = I.anIndexes[r], O = z.splice(Math.floor(Math.random() * z.length), 1)[0]), I.anIndexes[r] = O;
				}
				t.yOffset = t.finalLineHeight || 1.2 * t.finalSize, t.ls = t.ls || 0, t.ascent = b.ascent * t.finalSize / 100;
			}, bi.prototype.updateDocumentData = function(t, e) {
				e = void 0 === e ? this.keysIndex : e;
				var i = this.copyData({}, this.data.d.k[e].s);
				i = this.copyData(i, t), this.data.d.k[e].s = i, this.recalculate(e), this.setCurrentData(i), this.elem.addDynamicProperty(this);
			}, bi.prototype.recalculate = function(t) {
				var e = this.data.d.k[t].s;
				e.__complete = !1, this.keysIndex = 0, this._isFirstFrame = !0, this.getValue(e);
			}, bi.prototype.canResizeFont = function(t) {
				this.canResize = t, this.recalculate(this.keysIndex), this.elem.addDynamicProperty(this);
			}, bi.prototype.setMinimumFontSize = function(t) {
				this.minimumFontSize = Math.floor(t) || 1, this.recalculate(this.keysIndex), this.elem.addDynamicProperty(this);
			};
			var _i = function() {
				var t = Math.max, e = Math.min, i = Math.floor;
				function s(t, e) {
					this._currentTextLength = -1, this.k = !1, this.data = e, this.elem = t, this.comp = t.comp, this.finalS = 0, this.finalE = 0, this.initDynamicPropertyContainer(t), this.s = vt.getProp(t, e.s || { k: 0 }, 0, 0, this), this.e = "e" in e ? vt.getProp(t, e.e, 0, 0, this) : { v: 100 }, this.o = vt.getProp(t, e.o || { k: 0 }, 0, 0, this), this.xe = vt.getProp(t, e.xe || { k: 0 }, 0, 0, this), this.ne = vt.getProp(t, e.ne || { k: 0 }, 0, 0, this), this.sm = vt.getProp(t, e.sm || { k: 100 }, 0, 0, this), this.a = vt.getProp(t, e.a, 0, .01, this), this.dynamicProperties.length || this.getValue();
				}
				return s.prototype = {
					getMult: function(s) {
						this._currentTextLength !== this.elem.textProperty.currentData.l.length && this.getValue();
						var a = 0, r = 0, n = 1, o = 1;
						this.ne.v > 0 ? a = this.ne.v / 100 : r = -this.ne.v / 100, this.xe.v > 0 ? n = 1 - this.xe.v / 100 : o = 1 + this.xe.v / 100;
						var h = tt.getBezierEasing(a, r, n, o).get, l = 0, p = this.finalS, f = this.finalE, d = this.data.sh;
						if (2 === d) l = h(l = f === p ? s >= f ? 1 : 0 : t(0, e(.5 / (f - p) + (s - p) / (f - p), 1)));
						else if (3 === d) l = h(l = f === p ? s >= f ? 0 : 1 : 1 - t(0, e(.5 / (f - p) + (s - p) / (f - p), 1)));
						else if (4 === d) f === p ? l = 0 : (l = t(0, e(.5 / (f - p) + (s - p) / (f - p), 1))) < .5 ? l *= 2 : l = 1 - 2 * (l - .5), l = h(l);
						else if (5 === d) {
							if (f === p) l = 0;
							else {
								var m = f - p, c = -m / 2 + (s = e(t(0, s + .5 - p), f - p)), u = m / 2;
								l = Math.sqrt(1 - c * c / (u * u));
							}
							l = h(l);
						} else 6 === d ? (f === p ? l = 0 : (s = e(t(0, s + .5 - p), f - p), l = (1 + Math.cos(Math.PI + 2 * Math.PI * s / (f - p))) / 2), l = h(l)) : (s >= i(p) && (l = t(0, e(s - p < 0 ? e(f, 1) - (p - s) : f - s, 1))), l = h(l));
						if (100 !== this.sm.v) {
							var g = .01 * this.sm.v;
							0 === g && (g = 1e-8);
							var y = .5 - .5 * g;
							l < y ? l = 0 : (l = (l - y) / g) > 1 && (l = 1);
						}
						return l * this.a.v;
					},
					getValue: function(t) {
						this.iterateDynamicProperties(), this._mdf = t || this._mdf, this._currentTextLength = this.elem.textProperty.currentData.l.length || 0, t && 2 === this.data.r && (this.e.v = this._currentTextLength);
						var e = 2 === this.data.r ? 1 : 100 / this.data.totalChars, i = this.o.v / e, s = this.s.v / e + i, a = this.e.v / e + i;
						if (s > a) {
							var r = s;
							s = a, a = r;
						}
						this.finalS = s, this.finalE = a;
					}
				}, r([bt], s), { getTextSelectorProp: function(t, e, i) {
					return new s(t, e, i);
				} };
			}();
			function ki(t, e, i) {
				var s = { propType: !1 }, a = vt.getProp, r = e.a;
				this.a = {
					r: r.r ? a(t, r.r, 0, P, i) : s,
					rx: r.rx ? a(t, r.rx, 0, P, i) : s,
					ry: r.ry ? a(t, r.ry, 0, P, i) : s,
					sk: r.sk ? a(t, r.sk, 0, P, i) : s,
					sa: r.sa ? a(t, r.sa, 0, P, i) : s,
					s: r.s ? a(t, r.s, 1, .01, i) : s,
					a: r.a ? a(t, r.a, 1, 0, i) : s,
					o: r.o ? a(t, r.o, 0, .01, i) : s,
					p: r.p ? a(t, r.p, 1, 0, i) : s,
					sw: r.sw ? a(t, r.sw, 0, 0, i) : s,
					sc: r.sc ? a(t, r.sc, 1, 0, i) : s,
					fc: r.fc ? a(t, r.fc, 1, 0, i) : s,
					fh: r.fh ? a(t, r.fh, 0, 0, i) : s,
					fs: r.fs ? a(t, r.fs, 0, .01, i) : s,
					fb: r.fb ? a(t, r.fb, 0, .01, i) : s,
					t: r.t ? a(t, r.t, 0, 0, i) : s
				}, this.s = _i.getTextSelectorProp(t, e.s, i), this.s.t = e.s.t;
			}
			function Pi(t, e, i) {
				this._isFirstFrame = !0, this._hasMaskedPath = !1, this._frameId = -1, this._textData = t, this._renderType = e, this._elem = i, this._animatorsData = l(this._textData.a.length), this._pathData = {}, this._moreOptions = { alignment: {} }, this.renderedLetters = [], this.lettersChangedFlag = !1, this.initDynamicPropertyContainer(i);
			}
			function Ai() {}
			Pi.prototype.searchProperties = function() {
				var t, e, i = this._textData.a.length, s = vt.getProp;
				for (t = 0; t < i; t += 1) e = this._textData.a[t], this._animatorsData[t] = new ki(this._elem, e, this);
				this._textData.p && "m" in this._textData.p ? (this._pathData = {
					a: s(this._elem, this._textData.p.a, 0, 0, this),
					f: s(this._elem, this._textData.p.f, 0, 0, this),
					l: s(this._elem, this._textData.p.l, 0, 0, this),
					r: s(this._elem, this._textData.p.r, 0, 0, this),
					p: s(this._elem, this._textData.p.p, 0, 0, this),
					m: this._elem.maskManager.getMaskProperty(this._textData.p.m)
				}, this._hasMaskedPath = !0) : this._hasMaskedPath = !1, this._moreOptions.alignment = s(this._elem, this._textData.m.a, 1, 0, this);
			}, Pi.prototype.getMeasures = function(t, e) {
				if (this.lettersChangedFlag = e, this._mdf || this._isFirstFrame || e || this._hasMaskedPath && this._pathData.m._mdf) {
					this._isFirstFrame = !1;
					var i, s, a, r, n, o, h, l, p, f, d, m, c, u, g, y, v, b, _, k = this._moreOptions.alignment.v, P = this._animatorsData, A = this._textData, S = this.mHelper, x = this._renderType, w = this.renderedLetters.length, D = t.l;
					if (this._hasMaskedPath) {
						if (_ = this._pathData.m, !this._pathData.n || this._pathData._mdf) {
							var C, M = _.v;
							for (this._pathData.r.v && (M = M.reverse()), n = {
								tLength: 0,
								segments: []
							}, r = M._length - 1, y = 0, a = 0; a < r; a += 1) C = rt.buildBezierData(M.v[a], M.v[a + 1], [M.o[a][0] - M.v[a][0], M.o[a][1] - M.v[a][1]], [M.i[a + 1][0] - M.v[a + 1][0], M.i[a + 1][1] - M.v[a + 1][1]]), n.tLength += C.segmentLength, n.segments.push(C), y += C.segmentLength;
							a = r, _.v.c && (C = rt.buildBezierData(M.v[a], M.v[0], [M.o[a][0] - M.v[a][0], M.o[a][1] - M.v[a][1]], [M.i[0][0] - M.v[0][0], M.i[0][1] - M.v[0][1]]), n.tLength += C.segmentLength, n.segments.push(C), y += C.segmentLength), this._pathData.pi = n;
						}
						if (n = this._pathData.pi, o = this._pathData.f.v, d = 0, f = 1, l = 0, p = !0, u = n.segments, o < 0 && _.v.c) for (n.tLength < Math.abs(o) && (o = -Math.abs(o) % n.tLength), f = (c = u[d = u.length - 1].points).length - 1; o < 0;) o += c[f].partialLength, (f -= 1) < 0 && (f = (c = u[d -= 1].points).length - 1);
						m = (c = u[d].points)[f - 1], g = (h = c[f]).partialLength;
					}
					r = D.length, i = 0, s = 0;
					var T, F, E, I, L, V = 1.2 * t.finalSize * .714, N = !0;
					E = P.length;
					var B, q, j, W, X, H, Y, G, K, J, U, Z, Q = -1, $ = o, tt = d, et = f, it = -1, st = "", at = this.defaultPropsArray;
					if (2 === t.j || 1 === t.j) {
						var nt = 0, ot = 0, ht = 2 === t.j ? -.5 : -1, lt = 0, pt = !0;
						for (a = 0; a < r; a += 1) if (D[a].n) {
							for (nt && (nt += ot); lt < a;) D[lt].animatorJustifyOffset = nt, lt += 1;
							nt = 0, pt = !0;
						} else {
							for (F = 0; F < E; F += 1) (T = P[F].a).t.propType && (pt && 2 === t.j && (ot += T.t.v * ht), (L = P[F].s.getMult(D[a].anIndexes[F], A.a[F].s.totalChars)).length ? nt += T.t.v * L[0] * ht : nt += T.t.v * L * ht);
							pt = !1;
						}
						for (nt && (nt += ot); lt < a;) D[lt].animatorJustifyOffset = nt, lt += 1;
					}
					for (a = 0; a < r; a += 1) {
						if (S.reset(), W = 1, D[a].n) i = 0, s += t.yOffset, s += N ? 1 : 0, o = $, N = !1, this._hasMaskedPath && (f = et, m = (c = u[d = tt].points)[f - 1], g = (h = c[f]).partialLength, l = 0), st = "", U = "", K = "", Z = "", at = this.defaultPropsArray;
						else {
							if (this._hasMaskedPath) {
								if (it !== D[a].line) {
									switch (t.j) {
										case 1:
											o += y - t.lineWidths[D[a].line];
											break;
										case 2: o += (y - t.lineWidths[D[a].line]) / 2;
									}
									it = D[a].line;
								}
								Q !== D[a].ind && (D[Q] && (o += D[Q].extra), o += D[a].an / 2, Q = D[a].ind), o += k[0] * D[a].an * .005;
								var ft = 0;
								for (F = 0; F < E; F += 1) (T = P[F].a).p.propType && ((L = P[F].s.getMult(D[a].anIndexes[F], A.a[F].s.totalChars)).length ? ft += T.p.v[0] * L[0] : ft += T.p.v[0] * L), T.a.propType && ((L = P[F].s.getMult(D[a].anIndexes[F], A.a[F].s.totalChars)).length ? ft += T.a.v[0] * L[0] : ft += T.a.v[0] * L);
								for (p = !0, this._pathData.a.v && (o = .5 * D[0].an + (y - this._pathData.f.v - .5 * D[0].an - .5 * D[D.length - 1].an) * Q / (r - 1), o += this._pathData.f.v); p;) l + g >= o + ft || !c ? (v = (o + ft - l) / h.partialLength, q = m.point[0] + (h.point[0] - m.point[0]) * v, j = m.point[1] + (h.point[1] - m.point[1]) * v, S.translate(-k[0] * D[a].an * .005, -k[1] * V * .01), p = !1) : c && (l += h.partialLength, (f += 1) >= c.length && (f = 0, u[d += 1] ? c = u[d].points : _.v.c ? (f = 0, c = u[d = 0].points) : (l -= h.partialLength, c = null)), c && (m = h, g = (h = c[f]).partialLength));
								B = D[a].an / 2 - D[a].add, S.translate(-B, 0, 0);
							} else B = D[a].an / 2 - D[a].add, S.translate(-B, 0, 0), S.translate(-k[0] * D[a].an * .005, -k[1] * V * .01, 0);
							for (F = 0; F < E; F += 1) (T = P[F].a).t.propType && (L = P[F].s.getMult(D[a].anIndexes[F], A.a[F].s.totalChars), 0 === i && 0 === t.j || (this._hasMaskedPath ? L.length ? o += T.t.v * L[0] : o += T.t.v * L : L.length ? i += T.t.v * L[0] : i += T.t.v * L));
							for (t.strokeWidthAnim && (H = t.sw || 0), t.strokeColorAnim && (X = t.sc ? [
								t.sc[0],
								t.sc[1],
								t.sc[2]
							] : [
								0,
								0,
								0
							]), t.fillColorAnim && t.fc && (Y = [
								t.fc[0],
								t.fc[1],
								t.fc[2]
							]), F = 0; F < E; F += 1) (T = P[F].a).a.propType && ((L = P[F].s.getMult(D[a].anIndexes[F], A.a[F].s.totalChars)).length ? S.translate(-T.a.v[0] * L[0], -T.a.v[1] * L[1], T.a.v[2] * L[2]) : S.translate(-T.a.v[0] * L, -T.a.v[1] * L, T.a.v[2] * L));
							for (F = 0; F < E; F += 1) (T = P[F].a).s.propType && ((L = P[F].s.getMult(D[a].anIndexes[F], A.a[F].s.totalChars)).length ? S.scale(1 + (T.s.v[0] - 1) * L[0], 1 + (T.s.v[1] - 1) * L[1], 1) : S.scale(1 + (T.s.v[0] - 1) * L, 1 + (T.s.v[1] - 1) * L, 1));
							for (F = 0; F < E; F += 1) {
								if (T = P[F].a, L = P[F].s.getMult(D[a].anIndexes[F], A.a[F].s.totalChars), T.sk.propType && (L.length ? S.skewFromAxis(-T.sk.v * L[0], T.sa.v * L[1]) : S.skewFromAxis(-T.sk.v * L, T.sa.v * L)), T.r.propType && (L.length ? S.rotateZ(-T.r.v * L[2]) : S.rotateZ(-T.r.v * L)), T.ry.propType && (L.length ? S.rotateY(T.ry.v * L[1]) : S.rotateY(T.ry.v * L)), T.rx.propType && (L.length ? S.rotateX(T.rx.v * L[0]) : S.rotateX(T.rx.v * L)), T.o.propType && (L.length ? W += (T.o.v * L[0] - W) * L[0] : W += (T.o.v * L - W) * L), t.strokeWidthAnim && T.sw.propType && (L.length ? H += T.sw.v * L[0] : H += T.sw.v * L), t.strokeColorAnim && T.sc.propType) for (G = 0; G < 3; G += 1) L.length ? X[G] += (T.sc.v[G] - X[G]) * L[0] : X[G] += (T.sc.v[G] - X[G]) * L;
								if (t.fillColorAnim && t.fc) {
									if (T.fc.propType) for (G = 0; G < 3; G += 1) L.length ? Y[G] += (T.fc.v[G] - Y[G]) * L[0] : Y[G] += (T.fc.v[G] - Y[G]) * L;
									T.fh.propType && (Y = L.length ? O(Y, T.fh.v * L[0]) : O(Y, T.fh.v * L)), T.fs.propType && (Y = L.length ? R(Y, T.fs.v * L[0]) : R(Y, T.fs.v * L)), T.fb.propType && (Y = L.length ? z(Y, T.fb.v * L[0]) : z(Y, T.fb.v * L));
								}
							}
							for (F = 0; F < E; F += 1) (T = P[F].a).p.propType && (L = P[F].s.getMult(D[a].anIndexes[F], A.a[F].s.totalChars), this._hasMaskedPath ? L.length ? S.translate(0, T.p.v[1] * L[0], -T.p.v[2] * L[1]) : S.translate(0, T.p.v[1] * L, -T.p.v[2] * L) : L.length ? S.translate(T.p.v[0] * L[0], T.p.v[1] * L[1], -T.p.v[2] * L[2]) : S.translate(T.p.v[0] * L, T.p.v[1] * L, -T.p.v[2] * L));
							if (t.strokeWidthAnim && (K = H < 0 ? 0 : H), t.strokeColorAnim && (J = "rgb(" + Math.round(255 * X[0]) + "," + Math.round(255 * X[1]) + "," + Math.round(255 * X[2]) + ")"), t.fillColorAnim && t.fc && (U = "rgb(" + Math.round(255 * Y[0]) + "," + Math.round(255 * Y[1]) + "," + Math.round(255 * Y[2]) + ")"), this._hasMaskedPath) {
								if (S.translate(0, -t.ls), S.translate(0, k[1] * V * .01 + s, 0), this._pathData.p.v) {
									b = (h.point[1] - m.point[1]) / (h.point[0] - m.point[0]);
									var dt = 180 * Math.atan(b) / Math.PI;
									h.point[0] < m.point[0] && (dt += 180), S.rotate(-dt * Math.PI / 180);
								}
								S.translate(q, j, 0), o -= k[0] * D[a].an * .005, D[a + 1] && Q !== D[a + 1].ind && (o += D[a].an / 2, o += .001 * t.tr * t.finalSize);
							} else {
								switch (S.translate(i, s, 0), t.ps && S.translate(t.ps[0], t.ps[1] + t.ascent, 0), t.j) {
									case 1:
										S.translate(D[a].animatorJustifyOffset + t.justifyOffset + (t.boxWidth - t.lineWidths[D[a].line]), 0, 0);
										break;
									case 2: S.translate(D[a].animatorJustifyOffset + t.justifyOffset + (t.boxWidth - t.lineWidths[D[a].line]) / 2, 0, 0);
								}
								S.translate(0, -t.ls), S.translate(B, 0, 0), S.translate(k[0] * D[a].an * .005, k[1] * V * .01, 0), i += D[a].l + .001 * t.tr * t.finalSize;
							}
							"html" === x ? st = S.toCSS() : "svg" === x ? st = S.to2dCSS() : at = [
								S.props[0],
								S.props[1],
								S.props[2],
								S.props[3],
								S.props[4],
								S.props[5],
								S.props[6],
								S.props[7],
								S.props[8],
								S.props[9],
								S.props[10],
								S.props[11],
								S.props[12],
								S.props[13],
								S.props[14],
								S.props[15]
							], Z = W;
						}
						w <= a ? (I = new vi(Z, K, J, U, st, at), this.renderedLetters.push(I), w += 1, this.lettersChangedFlag = !0) : (I = this.renderedLetters[a], this.lettersChangedFlag = I.update(Z, K, J, U, st, at) || this.lettersChangedFlag);
					}
				}
			}, Pi.prototype.getValue = function() {
				this._elem.globalData.frameId !== this._frameId && (this._frameId = this._elem.globalData.frameId, this.iterateDynamicProperties());
			}, Pi.prototype.mHelper = new Ft(), Pi.prototype.defaultPropsArray = [], r([bt], Pi), Ai.prototype.initElement = function(t, e, i) {
				this.lettersChangedFlag = !0, this.initFrame(), this.initBaseData(t, e, i), this.textProperty = new bi(this, t.t, this.dynamicProperties), this.textAnimator = new Pi(t.t, this.renderType, this), this.initTransform(t, e, i), this.initHierarchy(), this.initRenderable(), this.initRendererElement(), this.createContainerElements(), this.createRenderableComponents(), this.createContent(), this.hide(), this.textAnimator.searchProperties(this.dynamicProperties);
			}, Ai.prototype.prepareFrame = function(t) {
				this._mdf = !1, this.prepareRenderableFrame(t), this.prepareProperties(t, this.isInRange);
			}, Ai.prototype.createPathShape = function(t, e) {
				var i, s, a = e.length, r = "";
				for (i = 0; i < a; i += 1) "sh" === e[i].ty && (s = e[i].ks.k, r += ui(s, s.i.length, !0, t));
				return r;
			}, Ai.prototype.updateDocumentData = function(t, e) {
				this.textProperty.updateDocumentData(t, e);
			}, Ai.prototype.canResizeFont = function(t) {
				this.textProperty.canResizeFont(t);
			}, Ai.prototype.setMinimumFontSize = function(t) {
				this.textProperty.setMinimumFontSize(t);
			}, Ai.prototype.applyTextPropertiesToMatrix = function(t, e, i, s, a) {
				switch (t.ps && e.translate(t.ps[0], t.ps[1] + t.ascent, 0), e.translate(0, -t.ls, 0), t.j) {
					case 1:
						e.translate(t.justifyOffset + (t.boxWidth - t.lineWidths[i]), 0, 0);
						break;
					case 2: e.translate(t.justifyOffset + (t.boxWidth - t.lineWidths[i]) / 2, 0, 0);
				}
				e.translate(s, a, 0);
			}, Ai.prototype.buildColor = function(t) {
				return "rgb(" + Math.round(255 * t[0]) + "," + Math.round(255 * t[1]) + "," + Math.round(255 * t[2]) + ")";
			}, Ai.prototype.emptyProp = new vi(), Ai.prototype.destroy = function() {}, Ai.prototype.validateText = function() {
				(this.textProperty._mdf || this.textProperty._isFirstFrame) && (this.buildNewText(), this.textProperty._isFirstFrame = !1, this.textProperty._mdf = !1);
			};
			var Si, xi = { shapes: [] };
			function wi(t, e, i) {
				this.textSpans = [], this.renderType = "svg", this.initElement(t, e, i);
			}
			function Di(t, e, i) {
				this.initElement(t, e, i);
			}
			function Ci(t, e, i) {
				this.initFrame(), this.initBaseData(t, e, i), this.initFrame(), this.initTransform(t, e, i), this.initHierarchy();
			}
			function Mi() {}
			function Ti() {}
			function Fi(t, e, i) {
				this.layers = t.layers, this.supports3d = !0, this.completeLayers = !1, this.pendingElements = [], this.elements = this.layers ? l(this.layers.length) : [], this.initElement(t, e, i), this.tm = t.tm ? vt.getProp(this, t.tm, 0, e.frameRate, this) : { _placeholder: !0 };
			}
			function Ei(t, e) {
				this.animationItem = t, this.layers = null, this.renderedFrame = -1, this.svgElement = W("svg");
				var i = "";
				if (e && e.title) {
					var s = W("title"), a = I();
					s.setAttribute("id", a), s.textContent = e.title, this.svgElement.appendChild(s), i += a;
				}
				if (e && e.description) {
					var r = W("desc"), n = I();
					r.setAttribute("id", n), r.textContent = e.description, this.svgElement.appendChild(r), i += " " + n;
				}
				i && this.svgElement.setAttribute("aria-labelledby", i);
				var o = W("defs");
				this.svgElement.appendChild(o);
				var h = W("g");
				this.svgElement.appendChild(h), this.layerElement = h, this.renderConfig = {
					preserveAspectRatio: e && e.preserveAspectRatio || "xMidYMid meet",
					imagePreserveAspectRatio: e && e.imagePreserveAspectRatio || "xMidYMid slice",
					contentVisibility: e && e.contentVisibility || "visible",
					progressiveLoad: e && e.progressiveLoad || !1,
					hideOnTransparent: !(e && !1 === e.hideOnTransparent),
					viewBoxOnly: e && e.viewBoxOnly || !1,
					viewBoxSize: e && e.viewBoxSize || !1,
					className: e && e.className || "",
					id: e && e.id || "",
					focusable: e && e.focusable,
					filterSize: {
						width: e && e.filterSize && e.filterSize.width || "100%",
						height: e && e.filterSize && e.filterSize.height || "100%",
						x: e && e.filterSize && e.filterSize.x || "0%",
						y: e && e.filterSize && e.filterSize.y || "0%"
					},
					width: e && e.width,
					height: e && e.height,
					runExpressions: !e || void 0 === e.runExpressions || e.runExpressions
				}, this.globalData = {
					_mdf: !1,
					frameNum: -1,
					defs: o,
					renderConfig: this.renderConfig
				}, this.elements = [], this.pendingElements = [], this.destroyed = !1, this.rendererType = "svg";
			}
			return r([
				ze,
				We,
				Ue,
				Ze,
				Oe,
				Qe,
				Ai
			], wi), wi.prototype.createContent = function() {
				this.data.singleShape && !this.globalData.fontManager.chars && (this.textContainer = W("text"));
			}, wi.prototype.buildTextContents = function(t) {
				for (var e = 0, i = t.length, s = [], a = ""; e < i;) t[e] === String.fromCharCode(13) || t[e] === String.fromCharCode(3) ? (s.push(a), a = "") : a += t[e], e += 1;
				return s.push(a), s;
			}, wi.prototype.buildShapeData = function(t, e) {
				if (t.shapes && t.shapes.length) {
					var i = t.shapes[0];
					if (i.it) {
						var s = i.it[i.it.length - 1];
						s.s && (s.s.k[0] = e, s.s.k[1] = e);
					}
				}
				return t;
			}, wi.prototype.buildNewText = function() {
				var t, e;
				this.addDynamicProperty(this);
				var i = this.textProperty.currentData;
				this.renderedLetters = l(i ? i.l.length : 0), i.fc ? this.layerElement.setAttribute("fill", this.buildColor(i.fc)) : this.layerElement.setAttribute("fill", "rgba(0,0,0,0)"), i.sc && (this.layerElement.setAttribute("stroke", this.buildColor(i.sc)), this.layerElement.setAttribute("stroke-width", i.sw)), this.layerElement.setAttribute("font-size", i.finalSize);
				var s = this.globalData.fontManager.getFontByName(i.f);
				if (s.fClass) this.layerElement.setAttribute("class", s.fClass);
				else {
					this.layerElement.setAttribute("font-family", s.fFamily);
					var a = i.fWeight, r = i.fStyle;
					this.layerElement.setAttribute("font-style", r), this.layerElement.setAttribute("font-weight", a);
				}
				this.layerElement.setAttribute("aria-label", i.t);
				var n, o = i.l || [], h = !!this.globalData.fontManager.chars;
				e = o.length;
				var p = this.mHelper, f = this.data.singleShape, d = 0, m = 0, c = !0, u = .001 * i.tr * i.finalSize;
				if (!f || h || i.sz) {
					var g, y = this.textSpans.length;
					for (t = 0; t < e; t += 1) {
						if (this.textSpans[t] || (this.textSpans[t] = {
							span: null,
							childSpan: null,
							glyph: null
						}), !h || !f || 0 === t) {
							if (n = y > t ? this.textSpans[t].span : W(h ? "g" : "text"), y <= t) {
								if (n.setAttribute("stroke-linecap", "butt"), n.setAttribute("stroke-linejoin", "round"), n.setAttribute("stroke-miterlimit", "4"), this.textSpans[t].span = n, h) {
									var v = W("g");
									n.appendChild(v), this.textSpans[t].childSpan = v;
								}
								this.textSpans[t].span = n, this.layerElement.appendChild(n);
							}
							n.style.display = "inherit";
						}
						if (p.reset(), f && (o[t].n && (d = -u, m += i.yOffset, m += c ? 1 : 0, c = !1), this.applyTextPropertiesToMatrix(i, p, o[t].line, d, m), d += o[t].l || 0, d += u), h) {
							var b;
							if (1 === (g = this.globalData.fontManager.getCharData(i.finalText[t], s.fStyle, this.globalData.fontManager.getFontByName(i.f).fFamily)).t) b = new Fi(g.data, this.globalData, this);
							else {
								var _ = xi;
								g.data && g.data.shapes && (_ = this.buildShapeData(g.data, i.finalSize)), b = new yi(_, this.globalData, this);
							}
							if (this.textSpans[t].glyph) {
								var k = this.textSpans[t].glyph;
								this.textSpans[t].childSpan.removeChild(k.layerElement), k.destroy();
							}
							this.textSpans[t].glyph = b, b._debug = !0, b.prepareFrame(0), b.renderFrame(), this.textSpans[t].childSpan.appendChild(b.layerElement), 1 === g.t && this.textSpans[t].childSpan.setAttribute("transform", "scale(" + i.finalSize / 100 + "," + i.finalSize / 100 + ")");
						} else f && n.setAttribute("transform", "translate(" + p.props[12] + "," + p.props[13] + ")"), n.textContent = o[t].val, n.setAttributeNS("http://www.w3.org/XML/1998/namespace", "xml:space", "preserve");
					}
					f && n && n.setAttribute("d", "");
				} else {
					var P = this.textContainer, A = "start";
					switch (i.j) {
						case 1:
							A = "end";
							break;
						case 2:
							A = "middle";
							break;
						default: A = "start";
					}
					P.setAttribute("text-anchor", A), P.setAttribute("letter-spacing", u);
					var S = this.buildTextContents(i.finalText);
					for (e = S.length, m = i.ps ? i.ps[1] + i.ascent : 0, t = 0; t < e; t += 1) (n = this.textSpans[t].span || W("tspan")).textContent = S[t], n.setAttribute("x", 0), n.setAttribute("y", m), n.style.display = "inherit", P.appendChild(n), this.textSpans[t] || (this.textSpans[t] = {
						span: null,
						glyph: null
					}), this.textSpans[t].span = n, m += i.finalLineHeight;
					this.layerElement.appendChild(P);
				}
				for (; t < this.textSpans.length;) this.textSpans[t].span.style.display = "none", t += 1;
				this._sizeChanged = !0;
			}, wi.prototype.sourceRectAtTime = function() {
				if (this.prepareFrame(this.comp.renderedFrame - this.data.st), this.renderInnerContent(), this._sizeChanged) {
					this._sizeChanged = !1;
					var t = this.layerElement.getBBox();
					this.bbox = {
						top: t.y,
						left: t.x,
						width: t.width,
						height: t.height
					};
				}
				return this.bbox;
			}, wi.prototype.getValue = function() {
				var t, e, i = this.textSpans.length;
				for (this.renderedFrame = this.comp.renderedFrame, t = 0; t < i; t += 1) (e = this.textSpans[t].glyph) && (e.prepareFrame(this.comp.renderedFrame - this.data.st), e._mdf && (this._mdf = !0));
			}, wi.prototype.renderInnerContent = function() {
				if (this.validateText(), (!this.data.singleShape || this._mdf) && (this.textAnimator.getMeasures(this.textProperty.currentData, this.lettersChangedFlag), this.lettersChangedFlag || this.textAnimator.lettersChangedFlag)) {
					var t, e;
					this._sizeChanged = !0;
					var i, s, a, r = this.textAnimator.renderedLetters, n = this.textProperty.currentData.l;
					for (e = n.length, t = 0; t < e; t += 1) n[t].n || (i = r[t], s = this.textSpans[t].span, (a = this.textSpans[t].glyph) && a.renderFrame(), i._mdf.m && s.setAttribute("transform", i.m), i._mdf.o && s.setAttribute("opacity", i.o), i._mdf.sw && s.setAttribute("stroke-width", i.sw), i._mdf.sc && s.setAttribute("stroke", i.sc), i._mdf.fc && s.setAttribute("fill", i.fc));
				}
			}, r([$e], Di), Di.prototype.createContent = function() {
				var t = W("rect");
				t.setAttribute("width", this.data.sw), t.setAttribute("height", this.data.sh), t.setAttribute("fill", this.data.sc), this.layerElement.appendChild(t);
			}, Ci.prototype.prepareFrame = function(t) {
				this.prepareProperties(t, !0);
			}, Ci.prototype.renderFrame = function() {}, Ci.prototype.getBaseElement = function() {
				return null;
			}, Ci.prototype.destroy = function() {}, Ci.prototype.sourceRectAtTime = function() {}, Ci.prototype.hide = function() {}, r([
				ze,
				We,
				Ze,
				Oe
			], Ci), r([qe], Mi), Mi.prototype.createNull = function(t) {
				return new Ci(t, this.globalData, this);
			}, Mi.prototype.createShape = function(t) {
				return new yi(t, this.globalData, this);
			}, Mi.prototype.createText = function(t) {
				return new wi(t, this.globalData, this);
			}, Mi.prototype.createImage = function(t) {
				return new $e(t, this.globalData, this);
			}, Mi.prototype.createSolid = function(t) {
				return new Di(t, this.globalData, this);
			}, Mi.prototype.configAnimation = function(t) {
				this.svgElement.setAttribute("xmlns", "http://www.w3.org/2000/svg"), this.svgElement.setAttribute("xmlns:xlink", "http://www.w3.org/1999/xlink"), this.renderConfig.viewBoxSize ? this.svgElement.setAttribute("viewBox", this.renderConfig.viewBoxSize) : this.svgElement.setAttribute("viewBox", "0 0 " + t.w + " " + t.h), this.renderConfig.viewBoxOnly || (this.svgElement.setAttribute("width", t.w), this.svgElement.setAttribute("height", t.h), this.svgElement.style.width = "100%", this.svgElement.style.height = "100%", this.svgElement.style.transform = "translate3d(0,0,0)", this.svgElement.style.contentVisibility = this.renderConfig.contentVisibility), this.renderConfig.width && this.svgElement.setAttribute("width", this.renderConfig.width), this.renderConfig.height && this.svgElement.setAttribute("height", this.renderConfig.height), this.renderConfig.className && this.svgElement.setAttribute("class", this.renderConfig.className), this.renderConfig.id && this.svgElement.setAttribute("id", this.renderConfig.id), void 0 !== this.renderConfig.focusable && this.svgElement.setAttribute("focusable", this.renderConfig.focusable), this.svgElement.setAttribute("preserveAspectRatio", this.renderConfig.preserveAspectRatio), this.animationItem.wrapper.appendChild(this.svgElement);
				var e = this.globalData.defs;
				this.setupGlobalData(t, e), this.globalData.progressiveLoad = this.renderConfig.progressiveLoad, this.data = t;
				var i = W("clipPath"), a = W("rect");
				a.setAttribute("width", t.w), a.setAttribute("height", t.h), a.setAttribute("x", 0), a.setAttribute("y", 0);
				var r = I();
				i.setAttribute("id", r), i.appendChild(a), this.layerElement.setAttribute("clip-path", "url(" + s() + "#" + r + ")"), e.appendChild(i), this.layers = t.layers, this.elements = l(t.layers.length);
			}, Mi.prototype.destroy = function() {
				var t;
				this.animationItem.wrapper && (this.animationItem.wrapper.innerText = ""), this.layerElement = null, this.globalData.defs = null;
				var e = this.layers ? this.layers.length : 0;
				for (t = 0; t < e; t += 1) this.elements[t] && this.elements[t].destroy && this.elements[t].destroy();
				this.elements.length = 0, this.destroyed = !0, this.animationItem = null;
			}, Mi.prototype.updateContainerSize = function() {}, Mi.prototype.findIndexByInd = function(t) {
				var e = 0, i = this.layers.length;
				for (e = 0; e < i; e += 1) if (this.layers[e].ind === t) return e;
				return -1;
			}, Mi.prototype.buildItem = function(t) {
				var e = this.elements;
				if (!e[t] && 99 !== this.layers[t].ty) {
					e[t] = !0;
					var i = this.createItem(this.layers[t]);
					if (e[t] = i, N() && (0 === this.layers[t].ty && this.globalData.projectInterface.registerComposition(i), i.initExpressions()), this.appendElementInPos(i, t), this.layers[t].tt) {
						var s = "tp" in this.layers[t] ? this.findIndexByInd(this.layers[t].tp) : t - 1;
						if (-1 === s) return;
						if (this.elements[s] && !0 !== this.elements[s]) {
							var a = e[s].getMatte(this.layers[t].tt);
							i.setMatte(a);
						} else this.buildItem(s), this.addPendingElement(i);
					}
				}
			}, Mi.prototype.checkPendingElements = function() {
				for (; this.pendingElements.length;) {
					var t = this.pendingElements.pop();
					if (t.checkParenting(), t.data.tt) for (var e = 0, i = this.elements.length; e < i;) {
						if (this.elements[e] === t) {
							var s = "tp" in t.data ? this.findIndexByInd(t.data.tp) : e - 1, a = this.elements[s].getMatte(this.layers[e].tt);
							t.setMatte(a);
							break;
						}
						e += 1;
					}
				}
			}, Mi.prototype.renderFrame = function(t) {
				if (this.renderedFrame !== t && !this.destroyed) {
					var e;
					null === t ? t = this.renderedFrame : this.renderedFrame = t, this.globalData.frameNum = t, this.globalData.frameId += 1, this.globalData.projectInterface.currentFrame = t, this.globalData._mdf = !1;
					var i = this.layers.length;
					for (this.completeLayers || this.checkLayers(t), e = i - 1; e >= 0; e -= 1) (this.completeLayers || this.elements[e]) && this.elements[e].prepareFrame(t - this.layers[e].st);
					if (this.globalData._mdf) for (e = 0; e < i; e += 1) (this.completeLayers || this.elements[e]) && this.elements[e].renderFrame();
				}
			}, Mi.prototype.appendElementInPos = function(t, e) {
				var i = t.getBaseElement();
				if (i) {
					for (var s, a = 0; a < e;) this.elements[a] && !0 !== this.elements[a] && this.elements[a].getBaseElement() && (s = this.elements[a].getBaseElement()), a += 1;
					s ? this.layerElement.insertBefore(i, s) : this.layerElement.appendChild(i);
				}
			}, Mi.prototype.hide = function() {
				this.layerElement.style.display = "none";
			}, Mi.prototype.show = function() {
				this.layerElement.style.display = "block";
			}, r([
				ze,
				We,
				Ze,
				Oe,
				Qe
			], Ti), Ti.prototype.initElement = function(t, e, i) {
				this.initFrame(), this.initBaseData(t, e, i), this.initTransform(t, e, i), this.initRenderable(), this.initHierarchy(), this.initRendererElement(), this.createContainerElements(), this.createRenderableComponents(), !this.data.xt && e.progressiveLoad || this.buildAllItems(), this.hide();
			}, Ti.prototype.prepareFrame = function(t) {
				if (this._mdf = !1, this.prepareRenderableFrame(t), this.prepareProperties(t, this.isInRange), this.isInRange || this.data.xt) {
					if (this.tm._placeholder) this.renderedFrame = t / this.data.sr;
					else {
						var e = this.tm.v;
						e === this.data.op && (e = this.data.op - 1), this.renderedFrame = e;
					}
					var i, s = this.elements.length;
					for (this.completeLayers || this.checkLayers(this.renderedFrame), i = s - 1; i >= 0; i -= 1) (this.completeLayers || this.elements[i]) && (this.elements[i].prepareFrame(this.renderedFrame - this.layers[i].st), this.elements[i]._mdf && (this._mdf = !0));
				}
			}, Ti.prototype.renderInnerContent = function() {
				var t, e = this.layers.length;
				for (t = 0; t < e; t += 1) (this.completeLayers || this.elements[t]) && this.elements[t].renderFrame();
			}, Ti.prototype.setElements = function(t) {
				this.elements = t;
			}, Ti.prototype.getElements = function() {
				return this.elements;
			}, Ti.prototype.destroyElements = function() {
				var t, e = this.layers.length;
				for (t = 0; t < e; t += 1) this.elements[t] && this.elements[t].destroy();
			}, Ti.prototype.destroy = function() {
				this.destroyElements(), this.destroyBaseElement();
			}, r([
				Mi,
				Ti,
				Ue
			], Fi), Fi.prototype.createComp = function(t) {
				return new Fi(t, this.globalData, this);
			}, r([Mi], Ei), Ei.prototype.createComp = function(t) {
				return new Fi(t, this.globalData, this);
			}, Si = Ei, U["svg"] = Si, Bt.registerModifier("tm", jt), Bt.registerModifier("pb", Wt), Bt.registerModifier("rp", Ht), Bt.registerModifier("rd", Yt), Bt.registerModifier("zz", le), Bt.registerModifier("op", _e), It;
		}));
	}));

//#endregion
//#region src/content/coach/layers.ts
	var import_lottie_light_min = /* @__PURE__ */ __toESM(require_lottie_light_min(), 1);
	function play(box, animationData) {
		const container = createElement("span");
		box.append(container);
		return import_lottie_light_min.default.loadAnimation({
			container,
			renderer: "svg",
			loop: false,
			autoplay: false,
			animationData,
			rendererSettings: { preserveAspectRatio: "xMidYMax meet" }
		});
	}
	function playLayers(box, data) {
		return {
			lids: play(box, data.lids),
			blink: play(box, data.blink),
			face: play(box, data.face)
		};
	}
	const loaded = (animation) => new Promise((resolve) => {
		if (animation.isLoaded) resolve();
		else animation.addEventListener("DOMLoaded", () => resolve());
	});
	async function whenLoaded({ lids, blink, face }) {
		await Promise.all([
			loaded(lids),
			loaded(blink),
			loaded(face)
		]);
	}

//#endregion
//#region src/content/coach/lottie/constants.ts
	const INSIDE_COLOR = "#5b1f22";
	const TONGUE_COLOR = "#d9716f";
	/** For the coaches whose portrait doesn't show their teeth. */
	const TEETH_COLOR = "#fdf6f1";
	/** A shut eye's lash line. */
	const LASH_COLOR = "#3a2019";
	const LASH_WIDTH = 1.1;
	/** Coach 2's lids are set by hand: her glasses sit where they'd be sampled. */
	const LID_SKIN = /* @__PURE__ */ new Map([[2, ["#f9b393", "#fcbb95"]]]);
	const CURLS = /* @__PURE__ */ new Map([[1, {
		inner: 2.2,
		outer: .8,
		rise: .6,
		width: .8,
		color: "#8b492b"
	}], [3, {
		inner: 3,
		outer: 1.5,
		rise: 1.2,
		width: .9,
		color: "#8d3c23"
	}]]);
	/**
	* A talking loop's syllables: frames, and how wide the mouth opens. Each ends
	* back on the pose, so talking can stop after any of them.
	*/
	const SYLLABLES = [
		[10, .7],
		[12, 1],
		[9, .4],
		[14, 1.2],
		[11, .6],
		[15, .9]
	];
	const BLINKS = [
		[84, 1],
		[310, 2],
		[520, 1]
	];

//#endregion
//#region src/content/coach/lottie/geometry.ts
	const lerp = (from, to, share) => from + (to - from) * share;
	const roundPoints = (points) => points.map(([x, y]) => [roundTenth(x), roundTenth(y)]);
	/** An item of a list whose length the rig's schema has checked. */
	function valueAt(list, index) {
		const value = list[index];
		if (value === void 0) throw new RangeError(`no item ${index} in a list of ${list.length}`);
		return value;
	}
	/** A `#rrggbb` color's channels, 0 to 1. */
	function hexToRgb(hex) {
		const channel = (start) => Number.parseInt(hex.slice(start, start + 2), 16) / 255;
		return [
			channel(1),
			channel(3),
			channel(5)
		];
	}
	const mixRgb = ([red, green, blue], [toRed, toGreen, toBlue], share) => [
		lerp(red, toRed, share),
		lerp(green, toGreen, share),
		lerp(blue, toBlue, share)
	];
	/** Catmull-Rom tangents through an open curve's points; its ends stay sharp. */
	function spline(points) {
		const last = points.length - 1;
		const tangents = points.map(([x, y], k) => {
			if (k === 0 || k === last) return [0, 0];
			const [beforeX, beforeY] = points[k - 1] ?? [x, y];
			const [afterX, afterY] = points[k + 1] ?? [x, y];
			return [(afterX - beforeX) / 6, (afterY - beforeY) / 6];
		});
		return {
			ins: tangents.map(([x, y]) => [-x, -y]),
			outs: tangents
		};
	}
	const bezierPath = ({ vertices, ins, outs, closed }) => ({
		i: roundPoints(ins),
		o: roundPoints(outs),
		v: roundPoints(vertices),
		c: closed
	});
	/**
	* A closed shape from a top curve (left to right) and a bottom curve sharing
	* its ends, the corners. Each curve is smooth, and the corners are sharp.
	*/
	function outline(top, bottom) {
		const back = bottom.toReversed();
		const topTangents = spline(top);
		const backTangents = spline(back);
		return bezierPath({
			vertices: [...top, ...back.slice(1, -1)],
			ins: [...topTangents.ins, ...backTangents.ins.slice(1, -1)],
			outs: [...topTangents.outs, ...backTangents.outs.slice(1, -1)],
			closed: true
		});
	}
	function openPath(points) {
		return bezierPath({
			vertices: points,
			...spline(points),
			closed: false
		});
	}

//#endregion
//#region src/content/coach/lottie/track.ts
	const easeInOut = () => ({
		o: {
			x: [.42],
			y: [0]
		},
		i: {
			x: [.58],
			y: [1]
		}
	});
	const easeOut = () => ({
		o: {
			x: [.2],
			y: [.6]
		},
		i: {
			x: [.4],
			y: [1]
		}
	});
	const still = (value) => ({
		a: 0,
		k: value
	});
	/**
	* Keys sorted by frame (rounded to a hundredth), one per frame, where the last
	* one written wins. A property that never changes is written as still.
	*/
	function track(keys, keyframeValue, easing) {
		const byFrame = /* @__PURE__ */ new Map();
		for (const [frame, value] of keys) byFrame.set(Math.round(frame * 100) / 100, value);
		const sorted = [...byFrame].toSorted(([first], [second]) => first - second);
		const [head] = sorted;
		if (head === void 0) throw new RangeError("a track needs a key");
		if (new Set(sorted.map(([, value]) => JSON.stringify(value))).size === 1) return still(head[1]);
		const last = sorted.length - 1;
		return {
			a: 1,
			k: sorted.map(([frame, value], index) => {
				if (index === last) return {
					t: frame,
					s: keyframeValue(value)
				};
				const handles = easing();
				return {
					t: frame,
					s: keyframeValue(value),
					o: handles.o,
					i: handles.i
				};
			})
		};
	}
	const numberTrack = (keys, easing = easeInOut) => track(keys, (value) => [value], easing);
	const vectorTrack = (keys, easing = easeInOut) => track(keys, (value) => [...value], easing);
	const pathTrack = (keys, easing = easeInOut) => track(keys, (value) => [value], easing);
	/** Keys for several properties of one kind, by name, in the order written. */
	var KeyLists = class {
		#lists = /* @__PURE__ */ new Map();
		add(name, frame, value) {
			const list = this.#lists.get(name);
			if (list) list.push([frame, value]);
			else this.#lists.set(name, [[frame, value]]);
		}
		get(name) {
			return this.#lists.get(name) ?? [];
		}
	};

//#endregion
//#region src/content/coach/lottie/primitives.ts
	const opaque = (hex) => still([...hexToRgb(hex), 1]);
	const fill = (hex) => ({
		ty: "fl",
		c: opaque(hex),
		o: still(100),
		r: 1
	});
	const stroke = ({ color, width, opacity }) => ({
		ty: "st",
		c: opaque(color),
		o: opacity,
		w: still(width),
		lc: 2,
		lj: 2
	});
	/** Pairs two lists item by item, up to the shorter one's length. */
	function zip(first, second) {
		return first.flatMap((item, i) => {
			const other = second[i];
			return other === void 0 ? [] : [[item, other]];
		});
	}
	function verticalGradient({ colors, offsets, from, to }) {
		const stops = zip(colors, offsets);
		const values = [];
		for (const [color, offset] of stops) values.push(offset, ...hexToRgb(color));
		return {
			ty: "gf",
			o: still(100),
			r: 1,
			t: 1,
			s: still([300 / 2, from]),
			e: still([300 / 2, to]),
			g: {
				p: stops.length,
				k: still(values)
			}
		};
	}
	const group = (items) => ({
		ty: "gr",
		it: [...items, {
			ty: "tr",
			p: still([0, 0]),
			a: still([0, 0]),
			s: still([100, 100]),
			r: still(0),
			o: still(100)
		}]
	});
	const stillTransform = () => ({
		o: still(100),
		r: still(0),
		p: still([
			0,
			0,
			0
		]),
		a: still([
			0,
			0,
			0
		]),
		s: still([
			100,
			100,
			100
		])
	});
	const shapeLayer = ({ name, index, shapes, end, transform = stillTransform() }) => ({
		ddd: 0,
		ind: index,
		ty: 4,
		nm: name,
		sr: 1,
		ip: 0,
		op: end,
		st: 0,
		ks: transform,
		shapes,
		ao: 0,
		bm: 0
	});
	const imageLayer = ({ name, index, asset, end, transform }) => ({
		ddd: 0,
		ind: index,
		ty: 2,
		nm: name,
		refId: asset,
		sr: 1,
		ip: 0,
		op: end,
		st: 0,
		ao: 0,
		bm: 0,
		ks: transform
	});
	const animation = ({ name, layers, end, assets = [] }) => ({
		v: "5.12.0",
		fr: 60,
		ip: 0,
		op: end,
		w: 300,
		h: 275,
		nm: name,
		ddd: 0,
		assets,
		layers
	});

//#endregion
//#region src/content/coach/lottie/lid.ts
/**
	* The lid when it is `closed` of the way shut (0 to 1). When shut, its edge is
	* one smooth arc from corner to corner, as deep as the eye and just past its
	* lower lash, so no white shows.
	*/
	function lidShapes({ x: columns, top, bottom }, closed) {
		const last = columns.length - 1;
		const firstTop = valueAt(top, 0);
		const lastTop = valueAt(top, last);
		const sag = valueAt(bottom, Math.floor(columns.length / 2)) + .6 - lerp(firstTop, lastTop, .5);
		const edge = columns.map((x, i) => {
			const along = i / last;
			const across = 2 * along - 1;
			const shut = Math.max(lerp(firstTop, lastTop, along) + sag * (1 - across * across) ** .75, valueAt(bottom, i) + .3);
			return [x, lerp(valueAt(top, i), shut, closed)];
		});
		const rim = columns.map((x, i) => [x, valueAt(top, i) - .3]);
		return {
			lid: outline(rim, edge),
			edge: openPath(edge)
		};
	}
	function lidSkin(eye, coach) {
		return verticalGradient({
			colors: LID_SKIN.get(coach) ?? eye.skin,
			offsets: [0, 1],
			from: Math.min(...eye.top),
			to: Math.max(...eye.bottom)
		});
	}

//#endregion
//#region src/content/coach/lottie/rig.ts
	const HexColorSchema = string().check(_regex(/^#[0-9a-f]{6}$/i));
	const PairSchema = tuple([number$1(), number$1()]);
	const SamplesSchema = array(number$1()).check(_minLength(2));
	const sameLength = (lists) => lists.every((list) => list.length === lists[0]?.length);
	const MouthCurvesSchema = pipe(object({
		up: SamplesSchema,
		ot: SamplesSchema,
		ob: SamplesSchema,
		lo: SamplesSchema
	}).check(refine(({ up, ot, ob, lo }) => sameLength([
		up,
		ot,
		ob,
		lo
	]))), transform(({ up, ot, ob, lo }) => ({
		upperTop: up,
		openingTop: ot,
		openingBottom: ob,
		lowerBottom: lo
	})));
	const MouthSchema = object({
		x: PairSchema,
		y: PairSchema,
		curves: MouthCurvesSchema,
		colors: object({
			teeth: nullable(HexColorSchema),
			line: nullable(HexColorSchema)
		}),
		shade: object({
			upper: tuple([
				HexColorSchema,
				HexColorSchema,
				HexColorSchema
			]),
			lower: tuple([
				HexColorSchema,
				HexColorSchema,
				HexColorSchema,
				HexColorSchema,
				HexColorSchema
			])
		})
	});
	/** A brow sprite: its box, the point it turns about, and the PNG, drawn at 2x. */
	const BrowSchema = object({
		x: number$1(),
		y: number$1(),
		w: number$1(),
		h: number$1(),
		center: PairSchema,
		png: string()
	});
	/** An eye, corner to corner: the top of the eye and its lower lid, and the lid's skin. */
	const EyeSchema = object({
		x: SamplesSchema,
		top: SamplesSchema,
		bottom: SamplesSchema,
		skin: tuple([HexColorSchema, HexColorSchema])
	}).check(refine(({ x, top, bottom }) => sameLength([
		x,
		top,
		bottom
	])));
	/** Each pair is the portrait's left, then its right. */
	const CoachRigSchema = object({
		mouth: MouthSchema,
		brows: tuple([BrowSchema, BrowSchema]),
		eyes: tuple([EyeSchema, EyeSchema])
	});
	const RigFileSchema = record(string(), CoachRigSchema);
	const SIDES = [0, 1];

//#endregion
//#region src/content/coach/lottie/blink.ts
	function blinkKeys() {
		const scale = [[0, [
			100,
			0,
			100
		]]];
		const lash = [[0, 0]];
		for (const [first, count] of BLINKS) for (let i = 0; i < count; i++) {
			const start = first + i * 20;
			const end = start + 14;
			scale.push([start, [
				100,
				0,
				100
			]], [start + 4, [
				100,
				100,
				100
			]]);
			scale.push([start + 6, [
				100,
				100,
				100
			]], [end, [
				100,
				0,
				100
			]]);
			lash.push([start, 0], [start + 2, 100], [start + 10, 100], [end, 0]);
		}
		scale.push([660, [
			100,
			0,
			100
		]]);
		lash.push([660, 0]);
		return {
			scale,
			lash
		};
	}
	function blinkLayer(rig, coach, side) {
		const eye = rig.eyes[side];
		const { lid, edge } = lidShapes(eye, 1);
		const { scale, lash } = blinkKeys();
		const top = Math.min(...eye.top);
		const centerX = eye.x.reduce((sum, x) => sum + x) / eye.x.length;
		const lashLine = stroke({
			color: LASH_COLOR,
			width: LASH_WIDTH,
			opacity: numberTrack(lash, easeOut)
		});
		return shapeLayer({
			name: `blink ${side}`,
			index: side + 1,
			end: 660 + 1,
			shapes: [group([{
				ty: "sh",
				ks: still(edge)
			}, lashLine]), group([{
				ty: "sh",
				ks: still(lid)
			}, lidSkin(eye, coach)])],
			transform: {
				...stillTransform(),
				p: still([
					centerX,
					top,
					0
				]),
				a: still([
					centerX,
					top,
					0
				]),
				s: vectorTrack(scale, easeOut)
			}
		});
	}
	const blinkAnimation = (rig, coach) => animation({
		name: `coach ${coach} blink`,
		layers: SIDES.map((side) => blinkLayer(rig, coach, side)),
		end: 660 + 1
	});
	/** The loop, and each blink's frames, for the player to play them one at a time. */
	const blinkMeta = () => ({
		loop: 660,
		fps: 60,
		at: BLINKS.map(([first, count]) => [first, first + (count - 1) * 20 + 14])
	});

//#endregion
//#region src/content/coach/lottie/circuit.ts
/**
	* An Eulerian circuit of the complete directed graph on `nodes` (Hierholzer's
	* algorithm): every ordered pair once, from the first node back to it. Laid
	* out on a timeline, each transition between two moods is one segment.
	*/
	function eulerianCircuit(nodes) {
		const unvisited = new Map(nodes.map((node) => [node, nodes.filter((other) => other !== node)]));
		const path = [];
		const stack = [];
		let current = nodes[0];
		while (current !== void 0) {
			const next = unvisited.get(current)?.shift();
			if (next === void 0) {
				path.push(current);
				current = stack.pop();
			} else {
				stack.push(current);
				current = next;
			}
		}
		return path.toReversed();
	}

//#endregion
//#region src/content/coach/lottie/mouth.ts
/** Points per lip curve, corner to corner. */
	const MOUTH_POINTS = 11;
	function resample(curve, position) {
		const j = Math.min(Math.floor(position), curve.length - 2);
		return lerp(valueAt(curve, j), valueAt(curve, j + 1), position - j);
	}
	function samples({ curves }) {
		const span = curves.upperTop.length - 1;
		return Array.from({ length: MOUTH_POINTS }, (_, i) => {
			const position = span * i / 10;
			return {
				upperTop: resample(curves.upperTop, position),
				openingTop: resample(curves.openingTop, position),
				openingBottom: resample(curves.openingBottom, position),
				lowerBottom: resample(curves.lowerBottom, position)
			};
		});
	}
	/** How far the teeth show: as painted if the portrait shows them, else once the mouth opens. */
	function teethDepth(mouth, pose, painted) {
		if (pose.teeth !== null) return pose.teeth;
		if (mouth.colors.teeth !== null) return Math.max(...painted.map((sample) => sample.openingBottom - sample.openingTop)) + 2;
		return 2.4 * Math.min(1, (pose.open + pose.raise) / 3);
	}
	function mouthPoint({ mouth, pose, teeth }, sample, k) {
		const [leftX, rightX] = mouth.x;
		const [leftY, rightY] = mouth.y;
		const centerX = (leftX + rightX) / 2;
		const along = k / 10;
		const across = -1 + 2 * along;
		const middle = 1 - across * across;
		const chord = lerp(leftY, rightY, along);
		const baseline = chord + (pose.lift + (across < 0 ? pose.liftLeft : pose.liftRight)) * across * across + pose.bend * middle;
		const jaw = middle ** lerp(.9, .5, pose.round);
		const upperEdge = sample.upperTop - chord;
		const openTop = sample.openingTop - chord;
		const openBottom = sample.openingBottom - chord;
		const lowerEdge = sample.lowerBottom - chord;
		const openingTop = baseline + openTop - pose.raise * jaw;
		const openingBottom = openingTop + (openBottom - openTop) * (1 - pose.close) + pose.open * jaw;
		return {
			x: centerX + (lerp(leftX, rightX, along) - centerX) * pose.width + pose.shift * middle,
			upperTop: openingTop - (openTop - upperEdge) * pose.upperLip,
			openingTop,
			openingBottom,
			lowerBottom: openingBottom + (lowerEdge - openBottom) * pose.lowerLip,
			teethBottom: Math.min(openingTop + teeth * Math.max(0, 1 - (Math.abs(across) / .82) ** 4), openingBottom),
			tongueTop: Math.max(openingBottom - pose.tongue * middle ** .7, openingTop)
		};
	}
	function curlPath(corner, direction, { pose, style }) {
		const { x, openingTop: y } = corner;
		const turn = pose.lift + (direction < 0 ? pose.liftLeft : pose.liftRight);
		const rise = style.rise * clamp(1 - turn / 2, 0, 1.2);
		return openPath([
			[x - direction * style.inner * pose.width, y + .5 + .2 * turn],
			[x, y],
			[x + direction * style.outer, y - rise]
		]);
	}
	function mouthShapes({ mouth, pose, curl }) {
		const painted = samples(mouth);
		const posed = {
			mouth,
			pose,
			teeth: teethDepth(mouth, pose, painted)
		};
		const points = painted.map((sample, k) => mouthPoint(posed, sample, k));
		const curve = (edge) => points.map((point) => [point.x, point[edge]]);
		const shapes = /* @__PURE__ */ new Map([
			["upper", outline(curve("upperTop"), curve("openingTop"))],
			["lower", outline(curve("openingBottom"), curve("lowerBottom"))],
			["inside", outline(curve("openingTop"), curve("openingBottom"))],
			["teeth", outline(curve("openingTop"), curve("teethBottom"))],
			["tongue", outline(curve("tongueTop"), curve("openingBottom"))]
		]);
		if (curl) {
			const options = {
				pose,
				style: curl
			};
			shapes.set("curlL", curlPath(valueAt(points, 0), -1, options));
			shapes.set("curlR", curlPath(valueAt(points, points.length - 1), 1, options));
		}
		return shapes;
	}

//#endregion
//#region src/content/coach/lottie/poses.ts
	const REST_MOUTH = {
		width: 1,
		lift: 0,
		liftLeft: 0,
		liftRight: 0,
		shift: 0,
		bend: 0,
		close: 0,
		open: 0,
		raise: 0,
		round: 0,
		teeth: null,
		tongue: 0,
		upperLip: 1,
		lowerLip: 1
	};
	const MOUTH_POSES = {
		neutral: {},
		happy: {
			width: 1.05,
			lift: -1.3,
			bend: .4,
			open: .8
		},
		delight: {
			width: 1.1,
			lift: -2.2,
			bend: .6,
			open: 5,
			raise: .8,
			round: .25,
			tongue: 2,
			lowerLip: .85
		},
		doubt: {
			width: .84,
			close: 1,
			liftLeft: -2,
			liftRight: 1,
			shift: 1.6,
			lowerLip: 1.05
		},
		worry: {
			width: .86,
			close: .8,
			lift: 3.4,
			bend: -2.2,
			lowerLip: 1.1
		},
		shock: {
			width: .5,
			lift: .6,
			open: 9,
			raise: 1.6,
			round: 1,
			teeth: 1.3,
			tongue: 2,
			upperLip: .8,
			lowerLip: .8
		}
	};
	const brow = (offsetY, tilt = 0) => ({
		offsetY,
		tilt
	});
	const BROW_POSES = {
		neutral: [brow(0), brow(0)],
		happy: [brow(-1.3), brow(-1.3)],
		delight: [brow(-3.2, 2), brow(-3.2, 2)],
		doubt: [brow(-3.8, -5), brow(1.3, -8)],
		worry: [brow(-1.2, 12), brow(-1.2, 12)],
		shock: [brow(-4.4, 4), brow(-4.4, 4)]
	};
	/** How closed each upper lid rests, 0 open to 1 shut. */
	const LID_POSES = {
		neutral: [0, 0],
		happy: [.1, .1],
		delight: [.38, .38],
		doubt: [0, .42],
		worry: [.24, .24],
		shock: [0, 0]
	};
	/** How wide a talking mouth opens: a grin or an "O" is open already. */
	const TALK_OPENING = {
		delight: .6,
		shock: .45
	};
	/** The moods whose mouth is a smile, which shows the corners' hooks. */
	const SMILES = /* @__PURE__ */ new Set([
		"neutral",
		"happy",
		"delight"
	]);

//#endregion
//#region src/content/coach/lottie/face-poses.ts
	const createFaceKeys = () => ({
		mouth: new KeyLists(),
		insideColor: [],
		curlOpacity: [],
		browPositions: [[], []],
		browTurns: [[], []]
	});
	function writeBrows({ rig, keys }, frame, mood, lift) {
		for (const side of SIDES) {
			const [centerX, centerY] = rig.brows[side].center;
			const { offsetY, tilt } = BROW_POSES[mood][side];
			keys.browPositions[side].push([frame, [
				centerX,
				centerY + offsetY + lift,
				0
			]]);
			keys.browTurns[side].push([frame, side === 0 ? -tilt : tilt]);
		}
	}
	function writePose(writer, frame, options) {
		const { mood, mouth = {}, browLift = 0 } = options;
		const { rig, curl, keys } = writer;
		const pose = {
			...REST_MOUTH,
			...MOUTH_POSES[mood],
			...mouth
		};
		for (const [part, shape] of mouthShapes({
			mouth: rig.mouth,
			pose,
			curl
		})) keys.mouth.add(part, frame, shape);
		const line = hexToRgb(rig.mouth.colors.line ?? "#5b1f22");
		const openness = Math.min(1, (pose.open + pose.raise) / 3.5);
		keys.insideColor.push([frame, [...mixRgb(line, hexToRgb(INSIDE_COLOR), openness), 1]]);
		keys.curlOpacity.push([frame, SMILES.has(mood) ? 100 : 0]);
		if (browLift !== null) writeBrows(writer, frame, mood, browLift);
	}
	/** Every mood's pose along the circuit, one every FACE_STEP frames. */
	function writeCircuit(writer, circuit) {
		for (const [k, mood] of circuit.entries()) writePose(writer, k * 24, { mood });
	}
	/** A syllable's mouth: the jaw drops and the lips part, less so for a shut mouth (doubt, worry). */
	const syllableMouth = (rest, amplitude) => ({
		open: rest.open + amplitude * 2.4,
		width: rest.width * (1 - .04 * amplitude),
		close: rest.close * (1 - .35 * amplitude),
		round: Math.min(1, rest.round + .15)
	});
	/** A mood's talking loop from `start`; the brows lift on the stressed syllables only. */
	function writeTalkLoop(writer, mood, start) {
		const rest = {
			...REST_MOUTH,
			...MOUTH_POSES[mood]
		};
		const stops = [];
		let frame = start;
		writePose(writer, frame, { mood });
		for (const [frames, opening] of SYLLABLES) {
			const amplitude = opening * (TALK_OPENING[mood] ?? 1);
			const stressed = amplitude >= 1;
			if (stressed) writePose(writer, frame, { mood });
			writePose(writer, frame + frames * .45, {
				mood,
				mouth: syllableMouth(rest, amplitude),
				browLift: stressed ? -.7 : null
			});
			frame += frames;
			writePose(writer, frame, {
				mood,
				browLift: stressed ? 0 : null
			});
			stops.push(frame);
		}
		return [
			start,
			frame,
			stops
		];
	}

//#endregion
//#region src/content/coach/lottie/meta.ts
	const moodRecord = (value) => ({
		neutral: value("neutral"),
		happy: value("happy"),
		delight: value("delight"),
		doubt: value("doubt"),
		worry: value("worry"),
		shock: value("shock")
	});
	/** Each mood's pose: its first time round the circuit, a pose every `step` frames. */
	const poseFrames = (circuit, step) => moodRecord((mood) => circuit.indexOf(mood) * step);
	/** Every transition along the circuit, a pose every `step` frames. */
	function transitions(circuit, step) {
		const segments = {};
		for (const [k, mood] of circuit.entries()) {
			const previous = circuit[k - 1];
			if (previous !== void 0) segments[`${previous}>${mood}`] = [(k - 1) * step, k * step];
		}
		return segments;
	}

//#endregion
//#region src/content/coach/lottie/face.ts
	const TALK_FRAMES = SYLLABLES.reduce((sum, [frames]) => sum + frames, 0);
	function lipShade(mouth, lip) {
		const { curves, shade } = mouth;
		const middle = Math.floor(curves.upperTop.length / 2);
		if (lip === "upper") {
			const [from, to] = [valueAt(curves.upperTop, middle), valueAt(curves.openingTop, middle)];
			return verticalGradient({
				colors: shade.upper,
				offsets: [
					.15,
					.5,
					.85
				],
				from,
				to
			});
		}
		const [from, to] = [valueAt(curves.openingBottom, middle), valueAt(curves.lowerBottom, middle)];
		return verticalGradient({
			colors: shade.lower,
			offsets: [
				.2,
				.4,
				.6,
				.8,
				.92
			],
			from,
			to
		});
	}
	/** A brow sprite, drawn at 2x, turning about its middle. */
	function browLayer({ rig, keys, end }, side) {
		const brow = rig.brows[side];
		const [centerX, centerY] = brow.center;
		return imageLayer({
			name: side === 0 ? "brow L" : "brow R",
			index: side + 1,
			asset: `brow${side}`,
			end,
			transform: {
				o: still(100),
				r: numberTrack(keys.browTurns[side]),
				p: vectorTrack(keys.browPositions[side]),
				a: still([
					(centerX - brow.x) * 2,
					(centerY - brow.y) * 2,
					0
				]),
				s: still([
					50,
					50,
					100
				])
			}
		});
	}
	function mouthLayer(context, { name, index, part, paint }) {
		const path = {
			ty: "sh",
			ks: pathTrack(context.keys.mouth.get(part))
		};
		return shapeLayer({
			name,
			index,
			end: context.end,
			shapes: [group([path, paint])]
		});
	}
	/** The corners' hooks, above the lips: Lottie draws its first layer on top. */
	function curlLayers(context, curl) {
		if (!curl) return [];
		const hook = (part, index) => {
			const opacity = numberTrack(context.keys.curlOpacity);
			return mouthLayer(context, {
				name: part,
				index,
				part,
				paint: stroke({
					color: curl.color,
					width: curl.width,
					opacity
				})
			});
		};
		return [hook("curlR", 9), hook("curlL", 8)];
	}
	function faceLayers(context, curl) {
		const { rig, keys } = context;
		const inside = {
			...fill(INSIDE_COLOR),
			c: vectorTrack(keys.insideColor)
		};
		const teeth = fill(rig.mouth.colors.teeth ?? "#fdf6f1");
		return [
			browLayer(context, 0),
			browLayer(context, 1),
			...curlLayers(context, curl),
			mouthLayer(context, {
				name: "upper lip",
				index: 3,
				part: "upper",
				paint: lipShade(rig.mouth, "upper")
			}),
			mouthLayer(context, {
				name: "lower lip",
				index: 4,
				part: "lower",
				paint: lipShade(rig.mouth, "lower")
			}),
			mouthLayer(context, {
				name: "teeth",
				index: 5,
				part: "teeth",
				paint: teeth
			}),
			mouthLayer(context, {
				name: "tongue",
				index: 6,
				part: "tongue",
				paint: fill(TONGUE_COLOR)
			}),
			mouthLayer(context, {
				name: "inside",
				index: 7,
				part: "inside",
				paint: inside
			})
		];
	}
	const browAssets = ({ brows }) => brows.map((brow, side) => ({
		id: `brow${side}`,
		w: brow.w * 2,
		h: brow.h * 2,
		u: "",
		p: `data:image/png;base64,${brow.png}`,
		e: 1
	}));
	function faceAnimation(rig, coach, circuit) {
		const curl = CURLS.get(coach) ?? null;
		const writer = {
			rig,
			curl,
			keys: createFaceKeys()
		};
		writeCircuit(writer, circuit);
		const talkStart = circuit.length * 24;
		const loopStart = (mood) => talkStart + COACH_MOODS.indexOf(mood) * (TALK_FRAMES + 1);
		const talk = moodRecord((mood) => writeTalkLoop(writer, mood, loopStart(mood)));
		const end = talkStart + COACH_MOODS.length * (TALK_FRAMES + 1) + 1;
		const layers = faceLayers({
			rig,
			keys: writer.keys,
			end
		}, curl);
		return {
			animation: animation({
				name: `coach ${coach} face`,
				layers,
				end,
				assets: browAssets(rig)
			}),
			meta: {
				pose: poseFrames(circuit, 24),
				transitions: transitions(circuit, 24),
				talk
			}
		};
	}

//#endregion
//#region src/content/coach/lottie/lids.ts
	function circuitKeys(rig, circuit) {
		const keys = [{
			lid: [],
			edge: [],
			lash: []
		}, {
			lid: [],
			edge: [],
			lash: []
		}];
		const write = (frame, closed) => {
			for (const side of SIDES) {
				const { lid, edge } = lidShapes(rig.eyes[side], closed[side]);
				keys[side].lid.push([frame, lid]);
				keys[side].edge.push([frame, edge]);
				keys[side].lash.push([frame, Math.min(1, closed[side] / .22) * 100]);
			}
		};
		for (const [k, mood] of circuit.entries()) {
			const frame = k * 18;
			if (k > 0 && mood === "shock") {
				write(frame - 18 * .6, [1, 1]);
				write(frame - 18 * .3, LID_POSES[mood]);
			} else if (k > 0 && mood === "worry") write(frame - 18 * .5, [.9, .9]);
			write(frame, LID_POSES[mood]);
		}
		return keys;
	}
	function lidsAnimation(rig, coach, circuit) {
		const keys = circuitKeys(rig, circuit);
		const end = circuit.length * 18 + 1;
		const layers = SIDES.map((side) => {
			const { lid, edge, lash } = keys[side];
			const lashLine = stroke({
				color: LASH_COLOR,
				width: LASH_WIDTH,
				opacity: numberTrack(lash, easeOut)
			});
			return shapeLayer({
				name: `lid ${side}`,
				index: side + 1,
				end,
				shapes: [group([{
					ty: "sh",
					ks: pathTrack(edge, easeOut)
				}, lashLine]), group([{
					ty: "sh",
					ks: pathTrack(lid, easeOut)
				}, lidSkin(rig.eyes[side], coach)])]
			});
		});
		return {
			animation: animation({
				name: `coach ${coach} lids`,
				layers,
				end
			}),
			meta: {
				pose: poseFrames(circuit, 18),
				transitions: transitions(circuit, 18)
			}
		};
	}

//#endregion
//#region src/content/coach/lottie/build.ts
	function buildCoachAnimations(rig, coach) {
		const circuit = eulerianCircuit(COACH_MOODS);
		const face = faceAnimation(rig, coach, circuit);
		const lids = lidsAnimation(rig, coach, circuit);
		return {
			face: face.animation,
			lids: lids.animation,
			blink: blinkAnimation(rig, coach),
			meta: {
				face: face.meta,
				lids: lids.meta,
				blink: blinkMeta()
			}
		};
	}

//#endregion
//#region src/content/coach/rigs.ts
	let rigs = null;
	async function fetchRigs() {
		const json = await (await fetch(extensionUrl("img/coaches/rig.json"))).json();
		return RigFileSchema.parse(json);
	}
	/** Every coach's traced features, fetched once: a failure isn't retried. */
	function loadRigs() {
		rigs ??= fetchRigs();
		return rigs;
	}

//#endregion
//#region src/content/coach/player.ts
	const RIG_CLASS = "cdc-coach__avatar--rig";
	var CoachPlayer = class {
		avatar;
		coach;
		#mood;
		#wanted;
		#box = null;
		#layers = null;
		#blinks = null;
		#expression = null;
		#destroyed = false;
		constructor({ avatar, coach, wanted }) {
			this.avatar = avatar;
			this.coach = coach;
			this.#mood = wanted().mood;
			this.#wanted = wanted;
		}
		/** Builds and mounts the rig. Throws if it can't, and the coach stays a portrait. */
		async load() {
			const rig = (await loadRigs())[String(this.coach)];
			if (!rig) throw new Error(`no rig for coach ${this.coach}`);
			const data = buildCoachAnimations(rig, this.coach);
			if (this.#destroyed) return;
			const face = queryOne(this.avatar, ".cdc-coach__face", HTMLElement);
			if (!face) throw new Error("the coach avatar has no face");
			const box = createElement("span", { className: "cdc-coach__rig" });
			face.append(box);
			this.#box = box;
			const layers = playLayers(box, data);
			this.#layers = layers;
			await whenLoaded(layers);
			if (this.#destroyed) return;
			const expression = new Expression({
				face: layers.face,
				lids: layers.lids,
				meta: data.meta,
				mood: this.#mood,
				wanted: this.#wanted,
				avatar: this.avatar
			});
			layers.face.addEventListener("complete", () => expression.finish());
			layers.face.addEventListener("loopComplete", () => expression.step());
			expression.show();
			const blinks = new Blinks({
				animation: layers.blink,
				meta: data.meta.blink,
				avatar: this.avatar
			});
			blinks.start();
			this.avatar.classList.toggle(RIG_CLASS, true);
			this.#blinks = blinks;
			this.#expression = expression;
			expression.step();
		}
		/** Follows what the review wants, once the rig is in. */
		update() {
			if (!this.#expression) return;
			this.#blinks?.resume();
			this.#expression.step();
		}
		destroy() {
			this.#destroyed = true;
			this.#blinks?.stop();
			const layers = this.#layers;
			layers?.face.destroy();
			layers?.lids.destroy();
			layers?.blink.destroy();
			this.#box?.remove();
			this.avatar.classList.toggle(RIG_CLASS, false);
		}
	};

//#endregion
//#region src/content/coach/index.ts
	let wanted = {
		coach: 0,
		mood: "neutral",
		talking: false
	};
	let player = null;
	function mount(avatar) {
		player?.destroy();
		const mounted = new CoachPlayer({
			avatar,
			coach: wanted.coach,
			wanted: () => wanted
		});
		player = mounted;
		mounted.load().catch((error) => {
			console.warn("[LichessDotCom] coach rig", error);
			if (player !== mounted) return;
			mounted.destroy();
			player = null;
		});
	}
	function sync() {
		const avatar = queryOne(document, ".cdc-coach__avatar", HTMLElement);
		if (!avatar) return;
		if (player?.avatar === avatar && player.coach === wanted.coach) player.update();
		else mount(avatar);
	}
	const coach = {
		name: "coach",
		start: () => {
			onCoachState((state) => {
				wanted = state;
				sync();
			});
		}
	};

//#endregion
//#region src/content/bootstrap/late-reload.ts
	const RELOAD_WINDOW_MS = 3e4;
	/** True when it reloaded the page: the content script should then stop. */
	function reloadIfInjectedLate() {
		if (isParsing()) return false;
		const last = readStored(SessionKey.lateReload, number(), "session") ?? 0;
		if (Date.now() - last <= RELOAD_WINDOW_MS) return false;
		writeStored(SessionKey.lateReload, Date.now(), "session");
		location.reload();
		return true;
	}

//#endregion
//#region src/content/index.ts
	function main() {
		startFeatures([boards]);
		if (reloadIfInjectedLate()) return;
		startFeatures([
			fonts,
			donate,
			coachChoice,
			fideOffset,
			marks,
			hasFlags,
			aiPlayers,
			boardZoom,
			controlsHeight,
			analysisPlayers,
			capturedPieces,
			boardTools,
			moveTimes,
			newGame,
			countryFlags,
			boardInset,
			evalGauge,
			puzzleSession,
			homeHero,
			coachTitles,
			swiss,
			forumLabels,
			tv,
			gameMeta,
			powertip,
			tooltip,
			tabs,
			devReload,
			radar,
			ratingChart,
			coach
		]);
		startSyncLoop();
	}
	main();

//#endregion
})();
