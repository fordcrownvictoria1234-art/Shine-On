// Isolated world. Only this script can download from GitHub/jsdelivr on lichess.org
// (host_permissions); the page's own CSP would block it. It converts each file to a
// data: URL and passes it to inject.js via CustomEvents. No UI here anymore: the
// theme buttons live in Lichess's own sound menu (inject.js).
(function () {
  // The Windows bank: the *_Windows files of the Shine-On repo. raw.githubusercontent.com first,
  // jsDelivr as the backup (a CDN cache can lag behind the repo).
  const BANKS = {
    windows: [
      'https://raw.githubusercontent.com/fordcrownvictoria1234-art/Shine-On/main/',
      'https://cdn.jsdelivr.net/gh/fordcrownvictoria1234-art/Shine-On@main/'
    ]
  };
  const FILES = ['Move', 'Capture', 'Check', 'Checkmate', 'Victory', 'Defeat', 'Draw', 'LowTime',
                 'Berserk', 'Error', 'Confirmation', 'GenericNotify', 'NewPM', 'NewChallenge',
                 'Explosion', 'OutOfBound'];
  const FIRST = ['Move', 'Capture', 'Check', 'Checkmate'];
  // Every sound name maps to its <Name>_Windows file in the repo (Move -> Move_Windows,
  // Berserk -> Berserk_Windows, ...). The repo's own spellings (NewChallenge, OutOfBound)
  // match the sound names, so no special cases.
  const FILE_OVERRIDES = {
    windows: Object.fromEntries(FILES.map(f => [f, f + '_Windows']))
  };

  // 'default' = plain Lichess sounds. A saved bank that no longer exists (older versions had
  // other themes) falls back to Windows.
  const getBank = () => {
    const b = localStorage.getItem('lichess-custom-bank');
    return (b === 'default' || BANKS[b]) ? b : 'windows';
  };
  const toPage = (msg) =>
    window.dispatchEvent(new CustomEvent('CustomSounds.toPage', { detail: JSON.stringify(msg) }));

  async function fetchBuf(url) {
    try {
      const res = await fetch(url, { cache: 'force-cache' });
      if (!res.ok) return null;
      return await res.arrayBuffer();
    } catch (e) { return null; }
  }
  const fileCache = Object.create(null);
  function getFile(bank, f) {
    const key = bank + ':' + f;
    if (!fileCache[key]) {
      fileCache[key] = (async () => {
        const swap = (FILE_OVERRIDES[bank] || {})[f];
        // A swapped file never falls back to the plain name: in this repo that is a different
        // sound (The Shining), and the wrong sound is worse than the Lichess one.
        const names = swap ? [].concat(swap) : (f === 'NewPM' ? ['NewPM', 'NewPm', 'newpm'] : [f]);
        const bases = [].concat(BANKS[bank]);
        for (const n of names) {
          for (const base of bases) {
            const b = await fetchBuf(base + n + '.mp3');
            if (b) return b;
          }
        }
        return null;
      })();
    }
    return fileCache[key];
  }
  const dataUrlCache = Object.create(null);
  function toDataUrl(bank, f, buf) {
    const key = bank + ':' + f;
    if (!dataUrlCache[key]) {
      dataUrlCache[key] = new Promise((res, rej) => {
        const r = new FileReader();
        r.onload = () => res(r.result);
        r.onerror = () => rej(r.error);
        r.readAsDataURL(new Blob([buf], { type: 'audio/mpeg' }));
      });
    }
    return dataUrlCache[key];
  }

  let loadToken = 0;
  async function loadBank(bank) {
    if (!BANKS[bank]) return;
    const token = ++loadToken;
    let n = 0;
    const one = async (f) => {
      const buf = await getFile(bank, f);
      if (!buf || token !== loadToken) return;
      const dataUrl = await toDataUrl(bank, f, buf);
      if (token !== loadToken) return;
      toPage({ type: 'sound', bank, name: f.toLowerCase(), dataUrl });
      n++;
    };
    await Promise.all(FIRST.map(one));
    await Promise.all(FILES.filter(f => !FIRST.includes(f)).map(one));
    if (token === loadToken) toPage({ type: 'bankReady', bank, count: n });
  }

  let pageReady = false;
  window.addEventListener('CustomSounds.toContent', (ev) => {
    let d;
    try { d = JSON.parse(ev.detail); } catch (e) { return; }
    if (!d) return;
    if (d.type === 'ready' && !pageReady) {
      pageReady = true;
      console.log('[custom sounds] page script is ready');
      const bank = getBank();
      if (bank !== 'default') loadBank(bank);
    } else if (d.type === 'load') {
      loadBank(d.bank);
    }
  });

  // Ping until inject.js answers (covers either script starting first).
  let pings = 0;
  const pingTimer = setInterval(() => {
    if (pageReady) { clearInterval(pingTimer); return; }
    if (++pings > 30) {
      clearInterval(pingTimer);
      console.warn('[custom sounds] page script never answered - needs Chrome/Edge 111+ or Firefox 128+');
      return;
    }
    toPage({ type: 'ping' });
  }, 300);
})();
