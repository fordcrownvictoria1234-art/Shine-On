// PAGE world (manifest "world": "MAIN"). Runs inside lichess.org's own JS context.
//  * wraps site.sound.resolvePath so Lichess plays our sounds through its own audio code
//  * adds a Windows button to Lichess's own sound menu
// It never downloads anything (page CSP would block it): content.js downloads the files
// and hands them over as data: URLs through CustomEvents.
(function () {
  if (window.__csInjected) return;
  window.__csInjected = true;

  const TAG = '[custom sounds]';
  const THEMES = [['windows', 'Windows']];
  const KEY = 'lichess-custom-bank';

  let bank = localStorage.getItem(KEY);   // 'default' = plain Lichess sounds
  if (bank !== 'default' && !THEMES.some(t => t[0] === bank)) bank = 'windows';   // missing or removed bank
  let urls = Object.create(null);   // lowercase sound name -> data: URL
  let bufs = Object.create(null);   // data: URL -> ArrayBuffer
  let count = 0;
  let loadingBank = null;           // bank currently downloading (menu shows "...")
  let failedBank = null;
  let previewPending = false;       // play a move sound once the clicked bank is ready

  // ---- bridge to content.js ----
  function toContent(msg) {
    window.dispatchEvent(new CustomEvent('CustomSounds.toContent', { detail: JSON.stringify(msg) }));
  }

  function dataUrlToBuf(u) {
    const bin = atob(u.slice(u.indexOf(',') + 1));
    const out = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
    return out.buffer;
  }

  // Requests for custom sounds wait for the bank (max 4s) so Lichess never caches a stock sound.
  let resolveReady = () => {};
  let ready = Promise.resolve();
  function armReady() {
    ready = new Promise(res => { resolveReady = res; setTimeout(res, 4000); });
  }
  if (bank !== 'default') { armReady(); loadingBank = bank; }

  // ---- fallback: serve custom bytes if a stock sound URL (or our data: URL) is fetched ----
  const SOUND_RE = /\/sound\/[^/]+\/([^/?#]+)\.mp3(?:[?#].*)?$/i;
  const nativeFetch = window.fetch.bind(window);
  window.fetch = async function (input, init) {
    try {
      const url = typeof input === 'string' ? input : (input && input.url) || String(input);
      if (bank !== 'default' && url) {
        if (url.startsWith('data:audio') && bufs[url]) {
          return new Response(bufs[url].slice(0), { status: 200, headers: { 'Content-Type': 'audio/mpeg' } });
        }
        const m = SOUND_RE.exec(url);
        if (m) {
          await ready;
          const u = urls[m[1].toLowerCase()];
          if (u && bufs[u]) {
            return new Response(bufs[u].slice(0), { status: 200, headers: { 'Content-Type': 'audio/mpeg' } });
          }
        }
      }
    } catch (e) {}
    return nativeFetch(input, init);
  };

  // ---- hook Lichess's sound object ----
  function forgetCachedPaths(s) {
    try {
      if (s.paths && typeof s.paths.forEach === 'function') {
        const drop = [];
        s.paths.forEach((_, k) => { if (urls[String(k).toLowerCase()]) drop.push(k); });
        drop.forEach(k => s.paths.delete(k));
      }
    } catch (e) {}
  }

  // Board sounds never play in Silent / Music / Speech mode, so a custom theme
  // switches this page to "standard" (Lichess's saved preference is not touched).
  function ensureAudible() {
    const s = window.__csSound;
    if (!s || bank === 'default') return;
    try {
      if (typeof s.speech === 'function' && s.speech()) s.speech(false);
      if (['silent', 'music', 'speech'].includes(s.theme) && typeof s.changeSet === 'function') {
        console.log(TAG, 'Lichess sound theme was "' + s.theme + '" - using standard on this page');
        s.changeSet('standard');
      }
    } catch (e) {}
  }


  // ---- checkmate plays ONLY the checkmate sound ----
  // Lichess asks for "check" on a mating move and "checkmate" as well, so both would
  // sound. On a mate: a "check" request becomes the "checkmate" sound, and any second
  // "checkmate" request for the same mate is dropped. Plain checks are untouched.
  const MATE_WINDOW = 1500;    // ms a mating move stays "current"
  const SAN_FRESH = 400;       // ms: a move() call with SAN info just happened
  const CHECK_WAIT = 120;      // ms to hold a check that came with no SAN info
  let mateUntil = 0;           // set when the latest move() carried a SAN ending in '#'
  let sanSeenAt = 0;           // when move() last carried a SAN
  let lastMateAt = 0;          // when the checkmate sound last played
  let pendingCheck = null;     // timer for a held check sound

  function installMateGuard(s) {
    const origPlay = s.play;
    const origMove = s.move;
    if (typeof origPlay !== 'function') return;

    if (typeof origMove === 'function') {
      s.move = function (o) {
        try {
          if (o && typeof o.san === 'string' && o.san) {
            sanSeenAt = Date.now();
            mateUntil = o.san.indexOf('#') !== -1 ? sanSeenAt + MATE_WINDOW : 0;
            lastMateAt = 0;   // a new move: forget the previous mate
          }
        } catch (e) {}
        return origMove.apply(s, arguments);
      };
    }

    s.play = function (name) {
      if (bank === 'default') return origPlay.apply(s, arguments);
      const args = arguments;
      const n = String(name || '').toLowerCase();
      const now = Date.now();

      if (n === 'checkmate') {
        if (now - lastMateAt < MATE_WINDOW) return Promise.resolve();   // already played for this mate
        lastMateAt = now;
        if (pendingCheck) { clearTimeout(pendingCheck); pendingCheck = null; }
        return origPlay.apply(s, args);
      }

      if (n === 'check') {
        if (now - lastMateAt < MATE_WINDOW) return Promise.resolve();   // checkmate already played
        if (now < mateUntil) {                                          // this check is the mating move
          lastMateAt = now;
          return origPlay.apply(s, ['checkmate'].concat(Array.prototype.slice.call(args, 1)));
        }
        if (now - sanSeenAt > SAN_FRESH) {
          // No SAN info for this check: wait a moment in case a checkmate follows.
          if (pendingCheck) clearTimeout(pendingCheck);
          pendingCheck = setTimeout(function () {
            pendingCheck = null;
            try { origPlay.apply(s, args); } catch (e) {}
          }, CHECK_WAIT);
          return Promise.resolve();
        }
      }
      return origPlay.apply(s, args);
    };
  }

  function hook() {
    const s = (window.site && window.site.sound) || (window.lichess && window.lichess.sound);
    if (!s || s.__csHooked || typeof s.resolvePath !== 'function') return false;
    s.__csHooked = true;
    window.__csSound = s;
    installMateGuard(s);

    const original = s.resolvePath.bind(s);
    s.resolvePath = function (name) {
      const stock = original(name);       // undefined when sound is off / volume 0
      if (!stock || bank === 'default') return stock;
      const u = urls[String(name || '').toLowerCase()];
      if (u) { console.debug(TAG, 'resolvePath', name, '-> custom'); return u; }
      return stock;
    };
    ensureAudible();
    console.log(TAG, 'hooked site.sound.resolvePath (bank: ' + bank + ')');
    return true;
  }
  const poll = setInterval(() => { if (hook()) clearInterval(poll); }, 50);
  setTimeout(() => clearInterval(poll), 60000);

  // ---- switching banks ----
  function switchBank(key) {
    bank = key;
    try { localStorage.setItem(KEY, key); } catch (e) {}
    urls = Object.create(null); bufs = Object.create(null); count = 0;
    failedBank = null;
    if (window.__csSound) forgetCachedPaths(window.__csSound);
    if (key === 'default') {
      loadingBank = null; previewPending = false;
      resolveReady();
    } else {
      loadingBank = key; previewPending = true;
      armReady();
      ensureAudible();
      toContent({ type: 'load', bank: key });
    }
    paint();
  }

  // ---- Lichess sound menu: #dasher_app .sub.sound .content > .selector ----
  function listEl() {
    return document.querySelector('#dasher_app .sub.sound .content > .selector');
  }

  function paint() {
    const list = listEl();
    if (!list) return;
    const native = Array.from(list.children).filter(el => el.tagName === 'BUTTON' && !el.classList.contains('cs-theme'));
    if (!native.length) return;

    if (list.querySelectorAll('.cs-theme').length !== THEMES.length) {
      list.querySelectorAll('.cs-theme').forEach(el => el.remove());
      for (const [key, label] of THEMES) {
        const b = native[0].cloneNode(false);   // keeps type/data-icon, drops Lichess's listeners
        b.className = 'text cs-theme';
        b.dataset.csBank = key;
        b.textContent = label;
        b.addEventListener('click', ev => {
          ev.preventDefault();
          ev.stopPropagation();
          if (bank !== key) switchBank(key);
          else if (window.__csSound) window.__csSound.play('move');
        });
        list.appendChild(b);
      }
    }
    if (!list.__csBound) {
      list.__csBound = true;
      // capture phase: runs before Lichess's own handler, so its "genericNotify" preview
      // and theme change already use the plain Lichess sounds.
      list.addEventListener('click', ev => {
        const btn = ev.target && ev.target.closest && ev.target.closest('button');
        if (!btn || btn.classList.contains('cs-theme')) return;
        if (bank !== 'default') switchBank('default');
      }, true);
    }

    // idempotent state sync (only touch the DOM when something differs -> no observer loops)
    for (const el of list.querySelectorAll('.cs-theme')) {
      const key = el.dataset.csBank;
      const label = THEMES.find(t => t[0] === key)[1];
      const text = label + (loadingBank === key ? ' …' : failedBank === key ? ' (failed to load)' : '');
      if (el.textContent !== text) el.textContent = text;
      const active = bank === key;
      if (el.classList.contains('active') !== active) el.classList.toggle('active', active);
    }
    if (bank !== 'default') {
      for (const el of native) if (el.classList.contains('active')) el.classList.remove('active');
    }
  }

  let paintQueued = false;
  function schedulePaint() {
    if (paintQueued) return;
    paintQueued = true;
    (window.requestAnimationFrame || setTimeout)(() => { paintQueued = false; try { paint(); } catch (e) {} });
  }

  let observed = null;
  const mo = new MutationObserver(schedulePaint);
  function attach() {
    const el = document.getElementById('dasher_app');
    if (el && el !== observed) {
      mo.disconnect();
      observed = el;
      mo.observe(el, { childList: true, subtree: true, attributes: true, attributeFilter: ['class'] });
      schedulePaint();
    }
  }
  setInterval(attach, 500);
  attach();

  // ---- messages from content.js ----
  window.addEventListener('CustomSounds.toPage', (ev) => {
    let d;
    try { d = JSON.parse(ev.detail); } catch (e) { return; }
    if (!d) return;
    if (d.type === 'ping') {
      toContent({ type: 'ready' });
    } else if (d.type === 'sound') {
      if (d.bank !== bank || !d.dataUrl) return;
      try {
        urls[d.name] = d.dataUrl;
        bufs[d.dataUrl] = dataUrlToBuf(d.dataUrl);
        count++;
      } catch (e) { console.warn(TAG, 'bad sound data for', d.name, e); }
    } else if (d.type === 'bankReady') {
      if (d.bank !== bank) return;
      if (window.__csSound) forgetCachedPaths(window.__csSound);
      resolveReady();
      loadingBank = null;
      if (!count) failedBank = bank;
      console.log(TAG, 'bank ready:', bank, Object.keys(urls).join(','));
      paint();
      if (previewPending && count && window.__csSound) {
        previewPending = false;
        Promise.resolve(window.__csSound.play('move')).catch(() => {});
      }
    }
  });

  toContent({ type: 'ready' });
  console.log(TAG, 'page script running');
})();
