(function() {

//#region src/shared/features.ts
/** Starts each feature in order; one that throws doesn't keep the others from starting. */
	function startFeatures(features) {
		for (const feature of features) try {
			feature.start();
		} catch (error) {
			console.error(`[LichessDotCom] ${feature.name} failed to start`, error);
		}
	}

//#endregion
//#region src/page/motion/queries.ts
	const REDUCED_MOTION = /\(\s*prefers-reduced-motion\s*(?::\s*(reduce|no-preference)\s*)?\)/g;
	const ALWAYS = "(width >= 0)";
	const NEVER = "(width < 0)";
	function unreducedQuery(query) {
		return query.replace(REDUCED_MOTION, (_match, value) => value === "no-preference" ? ALWAYS : NEVER);
	}
	/** Rewrites the reduced-motion media rules, nested ones too. Whether there was any. */
	function rewriteRules(rules) {
		let rewritten = false;
		for (const rule of rules) {
			if (rule instanceof CSSMediaRule && rule.media.mediaText.includes("prefers-reduced-motion")) {
				rule.media.mediaText = unreducedQuery(rule.media.mediaText);
				rewritten = true;
			}
			if (rule instanceof CSSGroupingRule) rewritten = rewriteRules(rule.cssRules) || rewritten;
		}
		return rewritten;
	}

//#endregion
//#region src/shared/dom.ts
	const isParsing = () => document.readyState === "loading";
	function queryOne(root, selector, type) {
		const element = root.querySelector(selector);
		return element instanceof type ? element : null;
	}
	function queryAll(root, selector, type) {
		return [...root.querySelectorAll(selector)].filter((element) => element instanceof type);
	}
	function closestTo(target, selector, type) {
		if (!(target instanceof Element)) return null;
		const element = target.closest(selector);
		return element instanceof type ? element : null;
	}
	/** Sets the class, the id, the text, then the attributes, in that order. */
	function applyOptions(element, options = {}) {
		if (options.className !== void 0) element.className = options.className;
		if (options.id !== void 0) element.id = options.id;
		if (options.text !== void 0) element.textContent = options.text;
		for (const [name, value] of Object.entries(options.attrs ?? {})) element.setAttribute(name, value);
		return element;
	}
	function createElement(tag, options) {
		return applyOptions(document.createElement(tag), options);
	}
	/**
	* Sets a `data-*` attribute only when it changes, and removes it for `null`.
	* Writing an unchanged value still counts as a mutation, which wakes every
	* observer on the page.
	*/
	function setData(element, key, value) {
		const { dataset } = element;
		if (value === null) {
			if (key in dataset) delete dataset[key];
		} else if (dataset[key] !== value) dataset[key] = value;
	}
	/** Sets an inline style property (a custom one, or any other) only when it changes. */
	function setStyleProperty(element, name, value) {
		const current = element.style.getPropertyValue(name);
		if (value === null) {
			if (current !== "") element.style.removeProperty(name);
		} else if (current !== value) element.style.setProperty(name, value);
	}

//#endregion
//#region src/page/motion/sheets.ts
	const seen = /* @__PURE__ */ new WeakSet();
	const copies = /* @__PURE__ */ new WeakMap();
	const isStylesheet = (node) => node instanceof HTMLLinkElement && node.relList.contains("stylesheet");
	function replaceWithCopy(link) {
		if (seen.has(link) || !link.href) return;
		seen.add(link);
		const copy = createElement("link", { attrs: {
			rel: "stylesheet",
			crossorigin: "anonymous",
			...link.media ? { media: link.media } : {},
			href: link.href
		} });
		seen.add(copy);
		copy.addEventListener("load", () => {
			const rules = copy.sheet?.cssRules;
			if (rules && rewriteRules(rules)) link.disabled = true;
			else copy.remove();
		});
		copy.addEventListener("error", () => copy.remove());
		copies.set(link, copy);
		link.after(copy);
	}
	/** Copies the page's sheets, then those Lichess adds; returns the observer that watches for them. */
	function copyStylesheets() {
		const observer = new MutationObserver((records) => {
			for (const record of records) {
				for (const node of record.addedNodes) if (isStylesheet(node)) replaceWithCopy(node);
				for (const node of record.removedNodes) if (isStylesheet(node)) copies.get(node)?.remove();
			}
		});
		observer.observe(document.documentElement, {
			childList: true,
			subtree: true
		});
		for (const link of queryAll(document, "link[rel~=\"stylesheet\"]", HTMLLinkElement)) replaceWithCopy(link);
		return observer;
	}

//#endregion
//#region src/page/motion/index.ts
	function unreduceMatchMedia() {
		const nativeMatchMedia = window.matchMedia.bind(window);
		window.matchMedia = (query) => nativeMatchMedia(unreducedQuery(String(query)));
	}
	const motion = {
		name: "motion",
		start: () => {
			unreduceMatchMedia();
			copyStylesheets();
		}
	};

//#endregion
//#region node_modules/.pnpm/zod@4.6.5/node_modules/zod/v4/core/util.js
	function getEnumValues(entries) {
		const numericValues = Object.values(entries).filter((v) => typeof v === "number");
		return Object.entries(entries).filter(([k, _]) => numericValues.indexOf(+k) === -1).map(([_, v]) => v);
	}
	function jsonStringifyReplacer(_, value) {
		if (typeof value === "bigint") return value.toString();
		return value;
	}
	var Cached = class {
		constructor(getter) {
			this._getter = getter;
			this._value = void 0;
		}
		get value() {
			const getter = this._getter;
			if (getter !== void 0) {
				this._value = getter();
				this._getter = void 0;
			}
			return this._value;
		}
	};
	function cached(getter) {
		return new Cached(getter);
	}
	function nullish(input) {
		return input === null || input === void 0;
	}
	function cleanRegex(source) {
		const start = source.startsWith("^") ? 1 : 0;
		const end = source.endsWith("$") ? source.length - 1 : source.length;
		return source.slice(start, end);
	}
	function assignProp(target, prop, value) {
		Object.defineProperty(target, prop, {
			value,
			writable: true,
			enumerable: true,
			configurable: true
		});
	}
	const captureStackTrace = "captureStackTrace" in Error ? Error.captureStackTrace : (..._args) => {};
	function isObject(data) {
		return typeof data === "object" && data !== null && !Array.isArray(data);
	}
	function isPlainObject(o) {
		if (isObject(o) === false) return false;
		const ctor = o.constructor;
		if (ctor === void 0) return true;
		if (typeof ctor !== "function") return true;
		const prot = ctor.prototype;
		if (isObject(prot) === false) return false;
		if (Object.prototype.hasOwnProperty.call(prot, "isPrototypeOf") === false) return false;
		return true;
	}
	const propertyKeyTypes = /* @__PURE__*/ new Set([
		"string",
		"number",
		"symbol"
	]);
	function escapeRegex(str) {
		return str.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
	}
	function clone(inst, def, params) {
		const cl = new inst._zod.constr(def ?? inst._zod.def);
		if (!def || params?.parent) cl._zod.parent = inst;
		return cl;
	}
	function normalizeParams(_params) {
		const params = _params;
		if (!params) return {};
		if (typeof params === "string") return { error: () => params };
		if (params?.message !== void 0) {
			if (params?.error !== void 0) throw new Error("Cannot specify both `message` and `error` params");
			params.error = params.message;
		}
		delete params.message;
		if (typeof params.error === "string") return {
			...params,
			error: () => params.error
		};
		return params;
	}
	function optionalKeys(shape) {
		return Object.keys(shape).filter((k) => {
			return shape[k]._zod.optin !== void 0 && shape[k]._zod.optout === "optional";
		});
	}
	const NUMBER_FORMAT_RANGES = /*@__PURE__*/ (() => ({
		safeint: [Number.MIN_SAFE_INTEGER, Number.MAX_SAFE_INTEGER],
		int32: [-2147483648, 2147483647],
		uint32: [0, 4294967295],
		float32: [-34028234663852886e22, 34028234663852886e22],
		float64: [-Number.MAX_VALUE, Number.MAX_VALUE]
	}))();
	function aborted(x, startIndex = 0) {
		if (x.aborted === true) return true;
		for (let i = startIndex; i < x.issues.length; i++) if (x.issues[i]?.continue !== true) return true;
		return false;
	}
	function explicitlyAborted(x, startIndex = 0) {
		if (x.aborted === true) return true;
		for (let i = startIndex; i < x.issues.length; i++) if (x.issues[i]?.continue === false) return true;
		return false;
	}
	function prefixIssues(path, issues) {
		return issues.map((iss) => {
			var _a;
			(_a = iss).path ?? (_a.path = []);
			iss.path.unshift(path);
			return iss;
		});
	}
	function unwrapMessage(message) {
		return typeof message === "string" ? message : message?.message;
	}
	function attachSchema(issues, start, inst) {
		var _a;
		for (let i = start; i < issues.length; i++) (_a = issues[i]).schema ?? (_a.schema = inst);
	}
	function finalizeIssue(iss, ctx, config) {
		var _a;
		const traits = iss.inst?._zod?.traits;
		if (traits?.has("$ZodType")) {
			if (traits.has("$ZodCheck")) (_a = iss).schema ?? (_a.schema = iss.inst);
			else iss.schema = iss.inst;
		}
		const schemaError = iss.schema !== iss.inst ? iss.schema?._zod.def?.error : void 0;
		const message = iss.message ? iss.message : unwrapMessage(iss.inst?._zod.def?.error?.(iss)) ?? unwrapMessage(schemaError?.(iss)) ?? unwrapMessage(ctx?.error?.(iss)) ?? unwrapMessage(config.customError?.(iss)) ?? unwrapMessage(config.localeError?.(iss)) ?? "Invalid input";
		const full = {};
		for (const k of Object.keys(iss)) {
			if (k === "inst" || k === "schema" || k === "continue" || k === "input" || k === "__proto__") continue;
			full[k] = iss[k];
		}
		full.path ?? (full.path = []);
		full.message = message;
		if (ctx?.reportInput) full.input = iss.input;
		return full;
	}
	const highSurrogate = /[\uD800-\uDBFF]/;
	function codePointLength(str) {
		const units = str.length;
		if (!highSurrogate.test(str)) return units;
		let count = units;
		for (let i = 0; i < units - 1; i++) if ((str.charCodeAt(i) & 64512) === 55296 && (str.charCodeAt(i + 1) & 64512) === 56320) {
			count--;
			i++;
		}
		return count;
	}
	function getLengthableOrigin(input) {
		if (Array.isArray(input)) return "array";
		if (typeof input === "string") return "string";
		return "unknown";
	}
	function issue(...args) {
		const [iss, input, inst] = args;
		if (typeof iss === "string") return {
			message: iss,
			code: "custom",
			input,
			inst
		};
		return { ...iss };
	}
	/**
	* Installs a trait's members on its prototype. Each value builds that member for the instance on first read; the built value shadows the accessor as an own property, so a detached `const { parse } = schema` keeps working.
	*
	* Call this from a `proto` initializer, which runs once per prototype — never per instance.
	*/
	function members(proto, table) {
		for (const key in table) {
			const desc = Object.getOwnPropertyDescriptor(table, key);
			if (desc.get) Object.defineProperty(proto, key, {
				...desc,
				enumerable: false
			});
			else defineBound(proto, key, desc.value);
		}
	}
	/** Shadows a prototype member with an own value, so a getter that builds from the instance runs once. */
	function own(inst, key, value, enumerable = true) {
		Object.defineProperty(inst, key, {
			configurable: true,
			writable: true,
			enumerable,
			value
		});
		return value;
	}
	/** Like {@link own}, for a member that was never an own data property and has to stay out of `Object.keys`. */
	function hide(inst, key, value) {
		return own(inst, key, value, false);
	}
	function defineBound(proto, key, fn) {
		Object.defineProperty(proto, key, {
			configurable: true,
			get() {
				return this == null ? fn : own(this, key, fn.bind(this));
			},
			set(value) {
				own(this, key, value);
			}
		});
	}
	/** Returns the prototype to install on, or `undefined` if this group is already installed on it. */
	function claim(inst, sentinel) {
		const proto = Object.getPrototypeOf(inst);
		return sentinel in proto ? void 0 : proto;
	}
	let installing;
	let broke = false;
	const breaker = {
		configurable: true,
		get() {
			broke = true;
		}
	};
	/**
	* Installs a lazily-derived internal on the `_zod` prototype of `inst`'s
	* constructor, computed from the internals object itself and cached there on
	* first read. One accessor per constructor rather than one per instance.
	*/
	function defineLazyInternal(inst, key, compute) {
		const proto = Object.getPrototypeOf(inst._zod);
		if (key in proto && installing !== inst._zod) {
			installing = void 0;
			return;
		}
		installing = inst._zod;
		Object.defineProperty(proto, key, {
			configurable: true,
			get() {
				Object.defineProperty(this, key, breaker);
				const outer = broke;
				broke = false;
				try {
					const value = compute(this);
					if (broke) delete this[key];
					else Object.defineProperty(this, key, {
						configurable: true,
						writable: true,
						value
					});
					broke = broke || outer;
					return value;
				} catch (err) {
					delete this[key];
					broke = broke || outer;
					throw err;
				}
			},
			set(value) {
				Object.defineProperty(this, key, {
					configurable: true,
					writable: true,
					value
				});
			}
		});
	}
	/**
	* Installs `key` on `inst`'s prototype, computed by `make` on first read and cached there as an own
	* data property. One accessor per constructor rather than one per instance, because an own accessor
	* puts every instance after the first into v8 dictionary mode. The key doubles as the sentinel.
	*/
	function installLazyProp(inst, key, make, enumerable) {
		const proto = claim(inst, key);
		if (!proto) return;
		Object.defineProperty(proto, key, {
			configurable: true,
			get() {
				const desc = {
					configurable: true,
					writable: true,
					enumerable,
					value: void 0
				};
				Object.defineProperty(this, key, desc);
				desc.value = make(this);
				Object.defineProperty(this, key, desc);
				return desc.value;
			},
			set(value) {
				Object.defineProperty(this, key, {
					configurable: true,
					writable: true,
					enumerable,
					value
				});
			}
		});
	}
	/** Marks the thunk `_catch` synthesises for a constant catch value. `Function.length` cannot tell that thunk from a user callback — rest and defaulted parameters both report arity 0 — and a user callback reads `ctx.error`, whose issues only finalize correctly against the caller's per-parse error map. Provenance can say what arity cannot. A plain string key rather than `Symbol.for`, whose call at module scope no bundler can prove pure — the same shape that anchored `urlCanParse` into every build. */
	const CONSTANT_CATCH = "~constantCatch";
	/** Wraps a constant catch value in a thunk tagged with {@link CONSTANT_CATCH}. */
	function constantCatch(value) {
		const fn = () => value;
		fn[CONSTANT_CATCH] = true;
		return fn;
	}

//#endregion
//#region node_modules/.pnpm/zod@4.6.5/node_modules/zod/v4/core/core.js
	var _a;
	const _zodDesc = {
		value: void 0,
		enumerable: false
	};
	let _E = "captureStackTrace" in Error ? Error : null;
	function newError(Definition) {
		const E = _E;
		if (E) {
			const saved = E.stackTraceLimit;
			if (typeof saved === "number") {
				try {
					E.stackTraceLimit = 0;
				} catch {
					_E = null;
					return new Definition();
				}
				try {
					return new Definition();
				} finally {
					E.stackTraceLimit = saved;
				}
			}
		}
		return new Definition();
	}
	function $constructor(name, initializer, proto, params) {
		const zodProto = {};
		function Internals(def) {
			this.def = def;
			this.constr = _;
			this.traits = /* @__PURE__ */ new Set();
		}
		Internals.prototype = zodProto;
		const protoMembers = proto;
		const initialized = protoMembers && /* @__PURE__ */ new WeakSet();
		function init(inst, def) {
			if (!inst._zod) {
				_zodDesc.value = new Internals(def);
				try {
					Object.defineProperty(inst, "_zod", _zodDesc);
				} finally {
					_zodDesc.value = void 0;
				}
			} else if (inst._zod.traits.has(name)) return;
			inst._zod.traits.add(name);
			initializer(inst, def);
			if (initialized) {
				const own = Object.getPrototypeOf(inst);
				const ctorProto = inst._zod.constr.prototype;
				let up = own;
				while (up && up !== ctorProto) up = Object.getPrototypeOf(up);
				const target = up ?? own;
				if (!initialized.has(target)) {
					initialized.add(target);
					members(target, protoMembers);
				}
			}
			const proto = _.prototype;
			for (const k in proto) {
				if (!Object.prototype.hasOwnProperty.call(proto, k)) continue;
				if (!(k in inst)) inst[k] = proto[k].bind(inst);
			}
		}
		const Parent = params?.Parent ?? Object;
		class Definition extends Parent {}
		Object.defineProperty(Definition, "name", { value: name });
		function _(def) {
			const inst = params?.Parent ? newError(Definition) : this;
			init(inst, def);
			const deferred = inst._zod.deferred;
			if (deferred) {
				for (const fn of deferred) fn();
				inst._zod.deferred = void 0;
			}
			const pp = globalThis.__zod_globalConfig?.postProcessor;
			if (pp) pp(inst);
			return inst;
		}
		Object.defineProperty(_, "init", { value: init });
		Object.defineProperty(_, Symbol.hasInstance, { value: (inst) => {
			if (params?.Parent && inst instanceof params.Parent) return true;
			return inst?._zod?.traits?.has(name);
		} });
		Object.defineProperty(_, "name", { value: name });
		return _;
	}
	var $ZodAsyncError = class extends Error {
		constructor() {
			super(`Encountered Promise during synchronous parse. Use .parseAsync() instead.`);
		}
	};
	(_a = globalThis).__zod_globalConfig ?? (_a.__zod_globalConfig = {});
	const globalConfig = globalThis.__zod_globalConfig;
	function config(newConfig) {
		if (newConfig) Object.assign(globalConfig, newConfig);
		return globalConfig;
	}

//#endregion
//#region node_modules/.pnpm/zod@4.6.5/node_modules/zod/v4/core/errors.js
	function _getMessage() {
		const internals = this._zod;
		internals.message ?? (internals.message = JSON.stringify(internals.def, jsonStringifyReplacer, 2));
		return internals.message;
	}
	function _setMessage(value) {
		this._zod.message = value;
	}
	const _messageDesc = {
		get: _getMessage,
		set: _setMessage,
		enumerable: true,
		configurable: true
	};
	const _issuesDesc = {
		value: void 0,
		enumerable: false
	};
	const _installedToString = /* @__PURE__ */ new WeakSet([Object.prototype, Error.prototype]);
	const initializer = (inst, def) => {
		inst.name = "$ZodError";
		_issuesDesc.value = def;
		Object.defineProperty(inst, "issues", _issuesDesc);
		_issuesDesc.value = void 0;
		Object.defineProperty(inst, "message", _messageDesc);
		const proto = Object.getPrototypeOf(inst);
		if (!_installedToString.has(proto)) {
			_installedToString.add(proto);
			Object.defineProperty(proto, "toString", {
				configurable: true,
				enumerable: false,
				get() {
					const value = () => this.message;
					Object.defineProperty(this, "toString", {
						value,
						configurable: true,
						writable: true
					});
					return value;
				},
				set(value) {
					Object.defineProperty(this, "toString", {
						value,
						configurable: true,
						writable: true
					});
				}
			});
		}
	};
	const $ZodError = $constructor("$ZodError", initializer);
	const $ZodRealError = $constructor("$ZodError", initializer, void 0, { Parent: Error });

//#endregion
//#region node_modules/.pnpm/zod@4.6.5/node_modules/zod/v4/core/parse.js
	function finalizeParams(callee, params) {
		return {
			callee: params?.callee ?? callee,
			Err: params?.Err
		};
	}
	const _parse = (_Err) => {
		const fn = (schema, value, _ctx, _params) => {
			const ctx = _ctx ? {
				..._ctx,
				async: false
			} : { async: false };
			const result = schema._zod.run({
				value,
				issues: []
			}, ctx);
			if (result instanceof Promise) throw new $ZodAsyncError();
			if (result.issues.length) {
				const e = new ((_params?.Err) ?? _Err)(result.issues.map((iss) => finalizeIssue(iss, ctx, config())));
				captureStackTrace(e, _params?.callee ?? fn);
				throw e;
			}
			return result.value;
		};
		return fn;
	};
	const parse = /* @__PURE__*/ _parse($ZodRealError);
	const _parseAsync = (_Err) => {
		const fn = async (schema, value, _ctx, params) => {
			const ctx = _ctx ? {
				..._ctx,
				async: true
			} : { async: true };
			let result = schema._zod.run({
				value,
				issues: []
			}, ctx);
			if (result instanceof Promise) result = await result;
			if (result.issues.length) {
				const e = new ((params?.Err) ?? _Err)(result.issues.map((iss) => finalizeIssue(iss, ctx, config())));
				captureStackTrace(e, params?.callee ?? fn);
				throw e;
			}
			return result.value;
		};
		return fn;
	};
	const parseAsync = /* @__PURE__*/ _parseAsync($ZodRealError);
	const _safeParse = (_Err) => (schema, value, _ctx) => {
		const ctx = _ctx ? {
			..._ctx,
			async: false
		} : { async: false };
		const result = schema._zod.run({
			value,
			issues: []
		}, ctx);
		if (result instanceof Promise) throw new $ZodAsyncError();
		return result.issues.length ? failure(_Err, result.issues, ctx) : {
			success: true,
			data: result.value
		};
	};
	const safeParse = /* @__PURE__*/ _safeParse($ZodRealError);
	function failure(Err, issues, ctx) {
		let error;
		return {
			success: false,
			get error() {
				if (!error) {
					error = new Err(issues.map((iss) => finalizeIssue(iss, ctx, config())));
					issues = void 0;
					ctx = void 0;
				}
				return error;
			},
			set error(e) {
				error = e;
				issues = void 0;
				ctx = void 0;
			}
		};
	}
	const _safeParseAsync = (_Err) => async (schema, value, _ctx) => {
		const ctx = _ctx ? {
			..._ctx,
			async: true
		} : { async: true };
		let result = schema._zod.run({
			value,
			issues: []
		}, ctx);
		if (result instanceof Promise) result = await result;
		return result.issues.length ? failure(_Err, result.issues, ctx) : {
			success: true,
			data: result.value
		};
	};
	const safeParseAsync = /* @__PURE__*/ _safeParseAsync($ZodRealError);
	const _encode = (_Err) => {
		const parse = _parse(_Err);
		const fn = (schema, value, _ctx, _params) => {
			const ctx = _ctx ? {
				..._ctx,
				direction: "backward"
			} : { direction: "backward" };
			return parse(schema, value, ctx, finalizeParams(fn, _params));
		};
		return fn;
	};
	const encode$1 = /* @__PURE__*/ _encode($ZodRealError);

//#endregion
//#region node_modules/.pnpm/zod@4.6.5/node_modules/zod/v4/core/regexes.js
	const anyString = /^[\s\S]{0,}$/;
	const number$2 = /^-?\d+(?:\.\d+)?$/;
	const boolean$1 = /^(?:true|false)$/i;

//#endregion
//#region node_modules/.pnpm/zod@4.6.5/node_modules/zod/v4/core/checks.js
	const $ZodCheck = /*@__PURE__*/ $constructor("$ZodCheck", (inst, def) => {
		var _a;
		inst._zod ?? (inst._zod = {});
		inst._zod.def = def;
		(_a = inst._zod).onattach ?? (_a.onattach = []);
	});
	/** Default `when` for length-based checks: run only on non-nullish values with a `length`. */
	const _whenHasLength = (payload) => {
		const val = payload.value;
		return !nullish(val) && val.length !== void 0;
	};
	const numericOriginMap = {
		number: "number",
		bigint: "bigint",
		object: "date"
	};
	const $ZodCheckLessThan = /*@__PURE__*/ $constructor("$ZodCheckLessThan", (inst, def) => {
		$ZodCheck.init(inst, def);
		const origin = numericOriginMap[typeof def.value];
		inst._zod.check = (payload) => {
			if (def.inclusive ? payload.value <= def.value : payload.value < def.value) return;
			payload.issues.push({
				origin: numericOriginMap[typeof payload.value] ?? origin,
				code: "too_big",
				maximum: typeof def.value === "object" ? def.value.getTime() : def.value,
				input: payload.value,
				inclusive: def.inclusive,
				inst,
				continue: !def.abort
			});
		};
	});
	const $ZodCheckGreaterThan = /*@__PURE__*/ $constructor("$ZodCheckGreaterThan", (inst, def) => {
		$ZodCheck.init(inst, def);
		const origin = numericOriginMap[typeof def.value];
		inst._zod.check = (payload) => {
			if (def.inclusive ? payload.value >= def.value : payload.value > def.value) return;
			payload.issues.push({
				origin: numericOriginMap[typeof payload.value] ?? origin,
				code: "too_small",
				minimum: typeof def.value === "object" ? def.value.getTime() : def.value,
				input: payload.value,
				inclusive: def.inclusive,
				inst,
				continue: !def.abort
			});
		};
	});
	const $ZodCheckNumberFormat = /*@__PURE__*/ $constructor("$ZodCheckNumberFormat", (inst, def) => {
		$ZodCheck.init(inst, def);
		def.format = def.format || "float64";
		const isInt = def.format?.includes("int");
		const origin = isInt ? "int" : "number";
		const [minimum, maximum] = NUMBER_FORMAT_RANGES[def.format];
		inst._zod.check = (payload) => {
			const input = payload.value;
			if (isInt) {
				if (!Number.isInteger(input)) {
					payload.issues.push({
						expected: origin,
						format: def.format,
						code: "invalid_type",
						continue: false,
						input,
						inst
					});
					return;
				}
				if (!Number.isSafeInteger(input)) {
					if (input > 0) payload.issues.push({
						input,
						code: "too_big",
						maximum: Number.MAX_SAFE_INTEGER,
						note: "Integers must be within the safe integer range.",
						inst,
						origin,
						inclusive: true,
						continue: !def.abort
					});
					else payload.issues.push({
						input,
						code: "too_small",
						minimum: Number.MIN_SAFE_INTEGER,
						note: "Integers must be within the safe integer range.",
						inst,
						origin,
						inclusive: true,
						continue: !def.abort
					});
					return;
				}
			}
			if (input < minimum) payload.issues.push({
				origin: "number",
				input,
				code: "too_small",
				minimum,
				inclusive: true,
				inst,
				continue: !def.abort
			});
			if (input > maximum) payload.issues.push({
				origin: "number",
				input,
				code: "too_big",
				maximum,
				inclusive: true,
				inst,
				continue: !def.abort
			});
		};
	});
	const $ZodCheckMinLength = /*@__PURE__*/ $constructor("$ZodCheckMinLength", (inst, def) => {
		var _a;
		$ZodCheck.init(inst, def);
		(_a = inst._zod.def).when ?? (_a.when = _whenHasLength);
		inst._zod.check = (payload) => {
			const input = payload.value;
			const units = input.length;
			if ((typeof input === "string" && units >= def.minimum && units < def.minimum * 2 ? codePointLength(input) : units) >= def.minimum) return;
			const origin = getLengthableOrigin(input);
			payload.issues.push({
				origin,
				code: "too_small",
				minimum: def.minimum,
				inclusive: true,
				input,
				inst,
				continue: !def.abort
			});
		};
	});
	const $ZodCheckLengthEquals = /*@__PURE__*/ $constructor("$ZodCheckLengthEquals", (inst, def) => {
		var _a;
		$ZodCheck.init(inst, def);
		(_a = inst._zod.def).when ?? (_a.when = _whenHasLength);
		inst._zod.check = (payload) => {
			const input = payload.value;
			const units = input.length;
			const length = typeof input === "string" && units >= def.length && units <= def.length * 2 ? codePointLength(input) : units;
			if (length === def.length) return;
			const origin = getLengthableOrigin(input);
			const tooBig = length > def.length;
			payload.issues.push({
				origin,
				...tooBig ? {
					code: "too_big",
					maximum: def.length
				} : {
					code: "too_small",
					minimum: def.length
				},
				inclusive: true,
				exact: true,
				input: payload.value,
				inst,
				continue: !def.abort
			});
		};
	});

//#endregion
//#region node_modules/.pnpm/zod@4.6.5/node_modules/zod/v4/core/versions.js
	const version = {
		major: 4,
		minor: 6,
		patch: 5
	};

//#endregion
//#region node_modules/.pnpm/zod@4.6.5/node_modules/zod/v4/core/schemas.js
	const $ZodType = /*@__PURE__*/ $constructor("$ZodType", (inst, def) => {
		var _a;
		inst ?? (inst = {});
		inst._zod.def = def;
		inst._zod.bag = inst._zod.bag || {};
		inst._zod.version = version;
		const defChecks = inst._zod.def.checks;
		const checks = inst._zod.traits.has("$ZodCheck") ? [inst, ...defChecks ?? []] : defChecks?.length ? [...defChecks] : [];
		for (const ch of checks) for (const fn of ch._zod.onattach) fn(inst);
		if (checks.length === 0) {
			(_a = inst._zod).deferred ?? (_a.deferred = []);
			inst._zod.deferred?.push(() => {
				inst._zod.run = inst._zod.parse;
			});
		} else {
			const runChecks = (payload, checks, ctx) => {
				if (payload.memo) return payload;
				let isAborted = aborted(payload);
				let asyncResult;
				for (const ch of checks) {
					if (ch._zod.def.when) {
						if (explicitlyAborted(payload)) continue;
						if (!ch._zod.def.when(payload)) continue;
					} else if (isAborted) continue;
					const currLen = payload.issues.length;
					const _ = ch._zod.check(payload);
					if (_ instanceof Promise && ctx?.async === false) throw new $ZodAsyncError();
					if (asyncResult || _ instanceof Promise) asyncResult = (asyncResult ?? Promise.resolve()).then(async () => {
						await _;
						if (payload.issues.length === currLen) return;
						attachSchema(payload.issues, currLen, inst);
						if (!isAborted) isAborted = aborted(payload, currLen);
					});
					else {
						if (payload.issues.length === currLen) continue;
						attachSchema(payload.issues, currLen, inst);
						if (!isAborted) isAborted = aborted(payload, currLen);
					}
				}
				if (asyncResult) return asyncResult.then(() => {
					return payload;
				});
				return payload;
			};
			const handleCanaryResult = (canary, payload, ctx) => {
				if (aborted(canary)) {
					canary.aborted = true;
					return canary;
				}
				const checkResult = runChecks(payload, checks, ctx);
				if (checkResult instanceof Promise) {
					if (ctx.async === false) throw new $ZodAsyncError();
					return checkResult.then((checkResult) => inst._zod.parse(checkResult, ctx));
				}
				return inst._zod.parse(checkResult, ctx);
			};
			inst._zod.run = (payload, ctx) => {
				if (ctx.skipChecks) return inst._zod.parse(payload, ctx);
				if (ctx.direction === "backward") {
					const canary = inst._zod.parse({
						value: payload.value,
						issues: []
					}, {
						...ctx,
						skipChecks: true
					});
					if (canary instanceof Promise) return canary.then((canary) => {
						return handleCanaryResult(canary, payload, ctx);
					});
					return handleCanaryResult(canary, payload, ctx);
				}
				const result = inst._zod.parse(payload, ctx);
				if (result instanceof Promise) {
					if (ctx.async === false) throw new $ZodAsyncError();
					return result.then((result) => runChecks(result, checks, ctx));
				}
				return runChecks(result, checks, ctx);
			};
		}
	}, {
		get "~standard"() {
			return hide(this, "~standard", standardProps(this));
		},
		set "~standard"(value) {
			own(this, "~standard", value);
		}
	});
	/** The Standard Schema surface for `inst`. Shared so wrappers can extend it without forcing it. */
	const toStandardResult = (r, ctx) => r.issues.length ? { issues: r.issues.map((iss) => finalizeIssue(iss, ctx, config())) } : { value: r.value };
	async function validateAsync(inst, value) {
		const ctx = { async: true };
		return toStandardResult(await inst._zod.run({
			value,
			issues: []
		}, ctx), ctx);
	}
	function standardProps(inst) {
		return {
			validate: (value) => {
				const ctx = { async: false };
				try {
					const r = inst._zod.run({
						value,
						issues: []
					}, ctx);
					if (!(r instanceof Promise)) return toStandardResult(r, ctx);
				} catch (_) {}
				return validateAsync(inst, value);
			},
			vendor: "zod",
			version: 1
		};
	}
	const $ZodString = /*@__PURE__*/ $constructor("$ZodString", (inst, def) => {
		$ZodType.init(inst, def);
		inst._zod.pattern = def.pattern ?? anyString;
		inst._zod.parse = (payload, _) => {
			if (def.coerce) try {
				payload.value = String(payload.value);
			} catch (_) {}
			if (typeof payload.value === "string") return payload;
			payload.issues.push({
				expected: "string",
				code: "invalid_type",
				input: payload.value,
				inst
			});
			return payload;
		};
	});
	const $ZodNumber = /*@__PURE__*/ $constructor("$ZodNumber", (inst, def) => {
		$ZodType.init(inst, def);
		inst._zod.pattern = number$2;
		inst._zod.parse = (payload, _ctx) => {
			if (def.coerce) try {
				payload.value = Number(payload.value);
			} catch (_) {}
			const input = payload.value;
			if (typeof input === "number" && !Number.isNaN(input) && Number.isFinite(input)) return payload;
			const received = typeof input === "number" ? Number.isNaN(input) ? "NaN" : !Number.isFinite(input) ? String(input) : void 0 : void 0;
			payload.issues.push({
				expected: "number",
				code: "invalid_type",
				input,
				inst,
				...received ? { received } : {}
			});
			return payload;
		};
	});
	const $ZodNumberFormat = /*@__PURE__*/ $constructor("$ZodNumberFormat", (inst, def) => {
		$ZodCheckNumberFormat.init(inst, def);
		$ZodNumber.init(inst, def);
	});
	const $ZodBoolean = /*@__PURE__*/ $constructor("$ZodBoolean", (inst, def) => {
		$ZodType.init(inst, def);
		inst._zod.pattern = boolean$1;
		inst._zod.parse = (payload, _ctx) => {
			if (def.coerce) try {
				payload.value = Boolean(payload.value);
			} catch (_) {}
			const input = payload.value;
			if (typeof input === "boolean") return payload;
			payload.issues.push({
				expected: "boolean",
				code: "invalid_type",
				input,
				inst
			});
			return payload;
		};
	});
	const $ZodUnknown = /*@__PURE__*/ $constructor("$ZodUnknown", (inst, def) => {
		$ZodType.init(inst, def);
		inst._zod.parse = (payload) => payload;
	});
	function handleArrayResult(result, final, index) {
		if (result.issues.length) final.issues.push(...prefixIssues(index, result.issues));
		final.value[index] = result.value;
	}
	const $ZodArray = /*@__PURE__*/ $constructor("$ZodArray", (inst, def) => {
		$ZodType.init(inst, def);
		const memo = globalConfig.memoizer;
		memo?.attach(inst);
		inst._zod.parse = (payload, ctx) => {
			const input = payload.value;
			if (!Array.isArray(input)) {
				payload.issues.push({
					expected: "array",
					code: "invalid_type",
					input,
					inst
				});
				return payload;
			}
			payload.value = memo ? memo.alloc(inst, payload, Array(input.length), ctx) : Array(input.length);
			const proms = [];
			const abortEarly = ctx?.abortEarly;
			for (let i = 0; i < input.length; i++) {
				const item = input[i];
				const result = def.element._zod.run({
					value: item,
					issues: []
				}, ctx);
				if (result instanceof Promise) proms.push(result.then((result) => handleArrayResult(result, payload, i)));
				else {
					handleArrayResult(result, payload, i);
					if (abortEarly && result.issues.length !== 0 && aborted(result)) break;
				}
			}
			if (proms.length) return Promise.all(proms).then(() => payload);
			return payload;
		};
	});
	function handlePropertyResult(result, final, key, input, optin, optout) {
		const isPresent = key in input;
		const isOptionalOut = optout === "optional";
		if (!isPresent && isOptionalOut && optin === "optional") return;
		if (result.issues.length) {
			if (optin !== void 0 && isOptionalOut && !isPresent) return;
			final.issues.push(...prefixIssues(key, result.issues));
		}
		if (!isPresent && optin === void 0) {
			if (!result.issues.length) final.issues.push({
				code: "invalid_type",
				expected: "nonoptional",
				input: void 0,
				path: [key]
			});
			return;
		}
		if (result.value === void 0) {
			if (isPresent || optin === "defaulted" && !isOptionalOut) final.value[key] = void 0;
		} else final.value[key] = result.value;
	}
	const NO_SYMBOL_KEYS = [];
	function normalizeDef(def) {
		const keys = Object.keys(def.shape);
		const ownSymbols = Object.getOwnPropertySymbols(def.shape);
		const symbolKeys = ownSymbols.length ? ownSymbols : NO_SYMBOL_KEYS;
		const allKeys = symbolKeys.length ? [...keys, ...symbolKeys] : keys;
		for (const k of allKeys) if (!def.shape?.[k]?._zod?.traits?.has("$ZodType")) throw new Error(`Invalid element at key "${String(k)}": expected a Zod schema`);
		const okeys = optionalKeys(def.shape);
		return {
			...def,
			allKeys,
			symbolKeys,
			keySet: new Set(keys),
			numKeys: keys.length,
			optionalKeys: new Set(okeys)
		};
	}
	function handleCatchall(proms, input, payload, ctx, def, inst, abortEarly) {
		const unrecognized = [];
		const keySet = def.keySet;
		const _catchall = def.catchall._zod;
		const t = _catchall.def.type;
		const optin = _catchall.optin;
		const optout = _catchall.optout;
		let seen = 0;
		for (const key in input) {
			if (abortEarly && payload.issues.length !== seen) {
				if (aborted(payload, seen)) break;
				seen = payload.issues.length;
			}
			if (keySet.has(key)) continue;
			if (key === "__proto__") {
				if (t === "never") unrecognized.push(key);
				continue;
			}
			if (t === "never") {
				unrecognized.push(key);
				continue;
			}
			const r = _catchall.run({
				value: input[key],
				issues: []
			}, ctx);
			if (r instanceof Promise) proms.push(r.then((r) => handlePropertyResult(r, payload, key, input, optin, optout)));
			else handlePropertyResult(r, payload, key, input, optin, optout);
		}
		if (unrecognized.length) payload.issues.push({
			code: "unrecognized_keys",
			keys: unrecognized,
			input,
			inst,
			continue: true
		});
		if (!proms.length) return payload;
		return Promise.all(proms).then(() => {
			return payload;
		});
	}
	const $ZodObject = /*@__PURE__*/ $constructor("$ZodObject", (inst, def) => {
		$ZodType.init(inst, def);
		const desc = Object.getOwnPropertyDescriptor(def, "shape");
		const sh = desc?.get ? desc.get.raw : def.shape ?? {};
		if (sh) {
			const get = () => {
				const newSh = { ...sh };
				Object.defineProperty(def, "shape", { value: newSh });
				get.raw = newSh;
				return newSh;
			};
			get.raw = sh;
			Object.defineProperty(def, "shape", { get });
		}
		const _normalized = cached(() => normalizeDef(def));
		defineLazyInternal(inst, "propValues", (zod) => {
			const shape = zod.def.shape;
			const propValues = {};
			for (const key in shape) {
				const field = shape[key]._zod;
				if (field.values) {
					if (!Object.prototype.hasOwnProperty.call(propValues, key)) assignProp(propValues, key, /* @__PURE__ */ new Set());
					for (const v of field.values) propValues[key].add(v);
					if (field.optin !== void 0) propValues[key].add(void 0);
				}
			}
			return propValues;
		});
		const isObject$2 = isObject;
		const catchall = def.catchall;
		let value;
		const memo = globalConfig.memoizer;
		memo?.attach(inst);
		inst._zod.parse = (payload, ctx) => {
			value ?? (value = _normalized.value);
			const input = payload.value;
			if (!isObject$2(input)) {
				payload.issues.push({
					expected: "object",
					code: "invalid_type",
					input,
					inst
				});
				return payload;
			}
			payload.value = memo ? memo.alloc(inst, payload, {}, ctx) : {};
			const proms = [];
			const shape = value.shape;
			const abortEarly = ctx?.abortEarly;
			let seen = payload.issues.length;
			for (const key of value.allKeys) {
				if (abortEarly && payload.issues.length !== seen) {
					if (aborted(payload, seen)) break;
					seen = payload.issues.length;
				}
				if (key === "__proto__") continue;
				const el = shape[key];
				const optin = el._zod.optin;
				const optout = el._zod.optout;
				const r = el._zod.run({
					value: input[key],
					issues: []
				}, ctx);
				if (r instanceof Promise) proms.push(r.then((r) => handlePropertyResult(r, payload, key, input, optin, optout)));
				else handlePropertyResult(r, payload, key, input, optin, optout);
			}
			if (!catchall) return proms.length ? Promise.all(proms).then(() => payload) : payload;
			return handleCatchall(proms, input, payload, ctx, _normalized.value, inst, abortEarly === true);
		};
	});
	function handleUnionResults(results, final, inst, ctx) {
		for (const result of results) if (result.issues.length === 0) {
			final.value = result.value;
			return final;
		}
		const nonaborted = results.filter((r) => !aborted(r));
		if (nonaborted.length === 1) {
			final.value = nonaborted[0].value;
			return nonaborted[0];
		}
		final.issues.push({
			code: "invalid_union",
			input: final.value,
			inst,
			errors: results.map((result) => result.issues.map((iss) => finalizeIssue(iss, ctx, config())))
		});
		return final;
	}
	const $ZodUnion = /*@__PURE__*/ $constructor("$ZodUnion", (inst, def) => {
		$ZodType.init(inst, def);
		defineLazyInternal(inst, "optin", (zod) => zod.def.options.some((o) => o._zod.optin === "defaulted") ? "defaulted" : zod.def.options.some((o) => o._zod.optin !== void 0) ? "optional" : void 0);
		defineLazyInternal(inst, "optout", (zod) => zod.def.options.some((o) => o._zod.optout === "optional") ? "optional" : void 0);
		defineLazyInternal(inst, "values", (zod) => {
			if (zod.def.options.every((o) => o._zod.values)) return new Set(zod.def.options.flatMap((option) => Array.from(option._zod.values)));
		});
		defineLazyInternal(inst, "pattern", (zod) => {
			if (zod.def.options.every((o) => o._zod.pattern)) {
				const patterns = zod.def.options.map((o) => o._zod.pattern);
				return new RegExp(`^(${patterns.map((p) => cleanRegex(p.source)).join("|")})$`);
			}
		});
		const first = def.options.length === 1 ? def.options[0]._zod.run : null;
		inst._zod.parse = (payload, ctx) => {
			if (first) return first(payload, ctx);
			let async = false;
			const results = [];
			for (const option of def.options) {
				const result = option._zod.run({
					value: payload.value,
					issues: []
				}, ctx);
				if (result instanceof Promise) {
					results.push(result);
					async = true;
				} else {
					if (result.issues.length === 0) return result;
					results.push(result);
				}
			}
			if (!async) return handleUnionResults(results, payload, inst, ctx);
			return Promise.all(results).then((results) => {
				return handleUnionResults(results, payload, inst, ctx);
			});
		};
	});
	const $ZodTuple = /*@__PURE__*/ $constructor("$ZodTuple", (inst, def) => {
		$ZodType.init(inst, def);
		const items = def.items;
		const memo = globalConfig.memoizer;
		memo?.attach(inst);
		inst._zod.parse = (payload, ctx) => {
			const input = payload.value;
			if (!Array.isArray(input)) {
				payload.issues.push({
					input,
					inst,
					expected: "tuple",
					code: "invalid_type"
				});
				return payload;
			}
			payload.value = memo ? memo.alloc(inst, payload, [], ctx) : [];
			const proms = [];
			const optinStart = getTupleOptStart(items, "optin");
			const optoutStart = getTupleOptStart(items, "optout");
			if (!def.rest) {
				if (input.length < optinStart) {
					payload.issues.push({
						code: "too_small",
						minimum: optinStart,
						inclusive: true,
						input,
						inst,
						origin: "array"
					});
					return payload;
				}
				if (input.length > items.length) payload.issues.push({
					code: "too_big",
					maximum: items.length,
					inclusive: true,
					input,
					inst,
					origin: "array"
				});
			}
			const itemResults = new Array(items.length);
			const abortEarly = def.rest ? ctx?.abortEarly : void 0;
			let itemAborted = false;
			for (let i = 0; i < items.length; i++) {
				const r = items[i]._zod.run({
					value: input[i],
					issues: []
				}, ctx);
				if (r instanceof Promise) proms.push(r.then((rr) => {
					itemResults[i] = rr;
				}));
				else {
					itemResults[i] = r;
					if (abortEarly && !itemAborted && r.issues.length) itemAborted = aborted(r);
				}
			}
			if (def.rest && !itemAborted) {
				let i = items.length - 1;
				const rest = input.slice(items.length);
				let seen = payload.issues.length;
				for (const el of rest) {
					if (abortEarly && payload.issues.length !== seen) {
						if (aborted(payload, seen)) break;
						seen = payload.issues.length;
					}
					i++;
					const result = def.rest._zod.run({
						value: el,
						issues: []
					}, ctx);
					if (result instanceof Promise) proms.push(result.then((r) => handleTupleResult(r, payload, i)));
					else handleTupleResult(result, payload, i);
				}
			}
			if (proms.length) return Promise.all(proms).then(() => handleTupleResults(itemResults, payload, items, input, optoutStart));
			return handleTupleResults(itemResults, payload, items, input, optoutStart);
		};
	});
	function getTupleOptStart(items, key) {
		for (let i = items.length - 1; i >= 0; i--) if (!(key === "optin" ? items[i]._zod.optin !== void 0 : items[i]._zod.optout === "optional")) return i + 1;
		return 0;
	}
	function handleTupleResult(result, final, index) {
		if (result.issues.length) final.issues.push(...prefixIssues(index, result.issues));
		final.value[index] = result.value;
	}
	function handleTupleResults(itemResults, final, items, input, optoutStart) {
		for (let i = 0; i < items.length; i++) {
			const r = itemResults[i];
			const isPresent = i < input.length;
			if (!isPresent && i >= optoutStart && items[i]._zod.optin === "optional") {
				final.value.length = i;
				break;
			}
			if (r.issues.length) {
				if (!isPresent && i >= optoutStart) {
					final.value.length = i;
					break;
				}
				final.issues.push(...prefixIssues(i, r.issues));
			}
			final.value[i] = r.value;
		}
		for (let i = final.value.length - 1; i >= input.length; i--) if (items[i]._zod.optout === "optional" && final.value[i] === void 0) final.value.length = i;
		else break;
		return final;
	}
	const $ZodRecord = /*@__PURE__*/ $constructor("$ZodRecord", (inst, def) => {
		$ZodType.init(inst, def);
		const memo = globalConfig.memoizer;
		memo?.attach(inst);
		inst._zod.parse = (payload, ctx) => {
			const input = payload.value;
			if (!isPlainObject(input)) {
				payload.issues.push({
					expected: "record",
					code: "invalid_type",
					input,
					inst
				});
				return payload;
			}
			const proms = [];
			const values = def.keyType._zod.values;
			if (values && !def.partial) {
				payload.value = memo ? memo.alloc(inst, payload, {}, ctx) : {};
				const recordKeys = /* @__PURE__ */ new Set();
				for (const key of values) if (typeof key === "string" || typeof key === "number" || typeof key === "symbol") {
					recordKeys.add(typeof key === "number" ? key.toString() : key);
					if (key === "__proto__") continue;
					const keyResult = def.keyType._zod.run({
						value: key,
						issues: []
					}, ctx);
					if (keyResult instanceof Promise) throw new Error("Async schemas not supported in object keys currently");
					if (keyResult.issues.length) {
						payload.issues.push({
							code: "invalid_key",
							origin: "record",
							issues: keyResult.issues.map((iss) => finalizeIssue(iss, ctx, config())),
							input: key,
							path: [key],
							inst
						});
						continue;
					}
					const outKey = keyResult.value;
					if (outKey === "__proto__") continue;
					const result = def.valueType._zod.run({
						value: input[key],
						issues: []
					}, ctx);
					if (result instanceof Promise) proms.push(result.then((result) => {
						if (result.issues.length) payload.issues.push(...prefixIssues(key, result.issues));
						payload.value[outKey] = result.value;
					}));
					else {
						if (result.issues.length) payload.issues.push(...prefixIssues(key, result.issues));
						payload.value[outKey] = result.value;
					}
				}
				let unrecognized;
				for (const key in input) if (!recordKeys.has(key)) {
					if (def.mode === "loose") {
						if (key === "__proto__") continue;
						payload.value[key] = input[key];
					} else {
						unrecognized = unrecognized ?? [];
						unrecognized.push(key);
					}
				}
				if (unrecognized && unrecognized.length > 0) payload.issues.push({
					code: "unrecognized_keys",
					input,
					inst,
					keys: unrecognized,
					continue: true
				});
			} else {
				payload.value = memo ? memo.alloc(inst, payload, {}, ctx) : {};
				let unrecognized;
				for (const key of Reflect.ownKeys(input)) {
					if (key === "__proto__") continue;
					if (!Object.prototype.propertyIsEnumerable.call(input, key)) continue;
					let keyResult = def.keyType._zod.run({
						value: key,
						issues: []
					}, ctx);
					if (keyResult instanceof Promise) throw new Error("Async schemas not supported in object keys currently");
					if (typeof key === "string" && number$2.test(key) && keyResult.issues.length) {
						const retryResult = def.keyType._zod.run({
							value: Number(key),
							issues: []
						}, ctx);
						if (retryResult instanceof Promise) throw new Error("Async schemas not supported in object keys currently");
						if (retryResult.issues.length === 0) keyResult = retryResult;
					}
					if (keyResult.issues.length) {
						if (def.mode === "loose") payload.value[key] = input[key];
						else if (values) {
							unrecognized = unrecognized ?? [];
							unrecognized.push(key);
						} else payload.issues.push({
							code: "invalid_key",
							origin: "record",
							issues: keyResult.issues.map((iss) => finalizeIssue(iss, ctx, config())),
							input: key,
							path: [key],
							inst
						});
						continue;
					}
					const outKey = keyResult.value;
					if (outKey === "__proto__") continue;
					const result = def.valueType._zod.run({
						value: input[key],
						issues: []
					}, ctx);
					if (result instanceof Promise) proms.push(result.then((result) => {
						if (result.issues.length) payload.issues.push(...prefixIssues(key, result.issues));
						payload.value[outKey] = result.value;
					}));
					else {
						if (result.issues.length) payload.issues.push(...prefixIssues(key, result.issues));
						payload.value[outKey] = result.value;
					}
				}
				if (unrecognized && unrecognized.length > 0) payload.issues.push({
					code: "unrecognized_keys",
					input,
					inst,
					keys: unrecognized,
					continue: true
				});
			}
			if (proms.length) return Promise.all(proms).then(() => payload);
			return payload;
		};
	});
	const $ZodEnum = /*@__PURE__*/ $constructor("$ZodEnum", (inst, def) => {
		$ZodType.init(inst, def);
		const values = getEnumValues(def.entries);
		const valuesSet = new Set(values);
		inst._zod.values = valuesSet;
		defineLazyInternal(inst, "pattern", (zod) => {
			const patternValues = getEnumValues(zod.def.entries).filter((k) => propertyKeyTypes.has(typeof k));
			return new RegExp(patternValues.length ? `^(${patternValues.map((o) => escapeRegex(o.toString())).join("|")})$` : "^[^\\s\\S]$");
		});
		inst._zod.parse = (payload, _ctx) => {
			const input = payload.value;
			if (valuesSet.has(input)) return payload;
			payload.issues.push({
				code: "invalid_value",
				values,
				input,
				inst
			});
			return payload;
		};
	});
	const $ZodLiteral = /*@__PURE__*/ $constructor("$ZodLiteral", (inst, def) => {
		$ZodType.init(inst, def);
		const values = new Set(def.values);
		inst._zod.values = values;
		defineLazyInternal(inst, "pattern", (zod) => {
			const vals = zod.def.values;
			return new RegExp(vals.length ? `^(${vals.map((o) => typeof o === "string" ? escapeRegex(o) : o ? escapeRegex(o.toString()) : String(o)).join("|")})$` : "^[^\\s\\S]$");
		});
		inst._zod.parse = (payload, _ctx) => {
			const input = payload.value;
			if (values.has(input)) return payload;
			payload.issues.push({
				code: "invalid_value",
				values: def.values,
				input,
				inst
			});
			return payload;
		};
	});
	function handleOptionalResult(payload, result) {
		payload.value = result.issues.length ? void 0 : result.value;
		return payload;
	}
	const $ZodOptional = /*@__PURE__*/ $constructor("$ZodOptional", (inst, def) => {
		$ZodType.init(inst, def);
		defineLazyInternal(inst, "optin", (zod) => zod.def.innerType._zod.optin === "defaulted" ? "defaulted" : "optional");
		inst._zod.optout = "optional";
		defineLazyInternal(inst, "values", (zod) => {
			const values = zod.def.innerType._zod.values;
			return values ? /* @__PURE__ */ new Set([...values, void 0]) : void 0;
		});
		defineLazyInternal(inst, "pattern", (zod) => {
			const pattern = zod.def.innerType._zod.pattern;
			return pattern ? new RegExp(`^(${cleanRegex(pattern.source)})?$`) : void 0;
		});
		inst._zod.parse = (payload, ctx) => {
			if (payload.value === void 0) {
				if (def.innerType._zod.optin !== "defaulted") return payload;
				const result = def.innerType._zod.run({
					value: payload.value,
					issues: []
				}, ctx);
				if (result instanceof Promise) return result.then((result) => handleOptionalResult(payload, result));
				return handleOptionalResult(payload, result);
			}
			return def.innerType._zod.run(payload, ctx);
		};
	});
	const $ZodNullable = /*@__PURE__*/ $constructor("$ZodNullable", (inst, def) => {
		$ZodType.init(inst, def);
		defineLazyInternal(inst, "optin", (zod) => zod.def.innerType._zod.optin);
		defineLazyInternal(inst, "optout", (zod) => zod.def.innerType._zod.optout);
		defineLazyInternal(inst, "pattern", (zod) => {
			const pattern = zod.def.innerType._zod.pattern;
			return pattern ? new RegExp(`^(${cleanRegex(pattern.source)}|null)$`) : void 0;
		});
		defineLazyInternal(inst, "values", (zod) => {
			return zod.def.innerType._zod.values ? /* @__PURE__ */ new Set([...zod.def.innerType._zod.values, null]) : void 0;
		});
		inst._zod.parse = (payload, ctx) => {
			if (payload.value === null) return payload;
			return def.innerType._zod.run(payload, ctx);
		};
	});
	function handleCatchResult(payload, result, def, ctx) {
		if (!result.issues.length) {
			payload.value = result.value;
			if (result.memo) payload.memo = true;
			return payload;
		}
		payload.value = def.catchValue({
			...result,
			value: payload.value,
			error: { issues: result.issues.map((iss) => finalizeIssue(iss, ctx, config())) },
			input: payload.value
		});
		return payload;
	}
	const $ZodCatch = /*@__PURE__*/ $constructor("$ZodCatch", (inst, def) => {
		$ZodType.init(inst, def);
		defineLazyInternal(inst, "optin", (zod) => zod.def.innerType._zod.optin === "defaulted" ? "defaulted" : "optional");
		defineLazyInternal(inst, "optout", (zod) => zod.def.innerType._zod.optout);
		defineLazyInternal(inst, "values", (zod) => zod.def.innerType._zod.values);
		inst._zod.parse = (payload, ctx) => {
			if (ctx.direction === "backward") return def.innerType._zod.run(payload, ctx);
			const result = def.innerType._zod.run({
				value: payload.value,
				issues: []
			}, ctx);
			if (result instanceof Promise) return result.then((result) => handleCatchResult(payload, result, def, ctx));
			return handleCatchResult(payload, result, def, ctx);
		};
	});
	const $ZodPipe = /*@__PURE__*/ $constructor("$ZodPipe", (inst, def) => {
		$ZodType.init(inst, def);
		defineLazyInternal(inst, "values", (zod) => zod.def.in._zod.values);
		defineLazyInternal(inst, "optin", (zod) => zod.def.in._zod.optin);
		defineLazyInternal(inst, "optout", (zod) => zod.def.out._zod.optout);
		defineLazyInternal(inst, "propValues", (zod) => zod.def.in._zod.propValues);
		inst._zod.parse = (payload, ctx) => {
			if (ctx.direction === "backward") {
				const right = def.out._zod.run(payload, ctx);
				if (right instanceof Promise) return right.then((right) => handlePipeResult(right, def.in, ctx));
				return handlePipeResult(right, def.in, ctx);
			}
			const left = def.in._zod.run(payload, ctx);
			if (left instanceof Promise) return left.then((left) => handlePipeResult(left, def.out, ctx));
			return handlePipeResult(left, def.out, ctx);
		};
	});
	function handlePipeResult(left, next, ctx) {
		if (left.issues.some((iss) => iss.code !== "unrecognized_keys")) {
			left.aborted = true;
			return left;
		}
		return next._zod.run({
			value: left.value,
			issues: left.issues
		}, ctx);
	}
	const $ZodCodec = /*@__PURE__*/ $constructor("$ZodCodec", (inst, def) => {
		$ZodType.init(inst, def);
		defineLazyInternal(inst, "values", (zod) => zod.def.in._zod.values);
		defineLazyInternal(inst, "optin", (zod) => zod.def.in._zod.optin);
		defineLazyInternal(inst, "optout", (zod) => zod.def.out._zod.optout);
		defineLazyInternal(inst, "propValues", (zod) => zod.def.in._zod.propValues);
		inst._zod.parse = (payload, ctx) => {
			if ((ctx.direction || "forward") === "forward") {
				const left = def.in._zod.run(payload, ctx);
				if (left instanceof Promise) return left.then((left) => handleCodecAResult(left, def, ctx));
				return handleCodecAResult(left, def, ctx);
			} else {
				const right = def.out._zod.run(payload, ctx);
				if (right instanceof Promise) return right.then((right) => handleCodecAResult(right, def, ctx));
				return handleCodecAResult(right, def, ctx);
			}
		};
	});
	function handleCodecAResult(result, def, ctx) {
		if (result.issues.length) {
			result.aborted = true;
			return result;
		}
		if ((ctx.direction || "forward") === "forward") {
			const transformed = def.transform(result.value, result);
			if (transformed instanceof Promise) return transformed.then((value) => handleCodecTxResult(result, value, def.out, ctx));
			return handleCodecTxResult(result, transformed, def.out, ctx);
		} else {
			const transformed = def.reverseTransform(result.value, result);
			if (transformed instanceof Promise) return transformed.then((value) => handleCodecTxResult(result, value, def.in, ctx));
			return handleCodecTxResult(result, transformed, def.in, ctx);
		}
	}
	function handleCodecTxResult(left, value, nextSchema, ctx) {
		if (left.issues.length) {
			left.aborted = true;
			return left;
		}
		return nextSchema._zod.run({
			value,
			issues: left.issues
		}, ctx);
	}
	const $ZodFunction = /*@__PURE__*/ $constructor("$ZodFunction", (inst, def) => {
		$ZodType.init(inst, def);
		Object.defineProperty(inst, "_def", { value: def });
		inst._zod.def = def;
		inst.implement = (func) => {
			if (typeof func !== "function") throw new Error("implement() must be called with a function");
			return Object.defineProperty(function(...args) {
				const parsedArgs = inst._def.input ? parse(inst._def.input, args) : args;
				const result = Reflect.apply(func, this, parsedArgs);
				if (inst._def.output) return parse(inst._def.output, result);
				return result;
			}, "_zod", {
				value: inst._zod,
				enumerable: false
			});
		};
		inst.implementAsync = (func) => {
			if (typeof func !== "function") throw new Error("implementAsync() must be called with a function");
			return Object.defineProperty(async function(...args) {
				const parsedArgs = inst._def.input ? await parseAsync(inst._def.input, args) : args;
				const result = await Reflect.apply(func, this, parsedArgs);
				if (inst._def.output) return await parseAsync(inst._def.output, result);
				return result;
			}, "_zod", {
				value: inst._zod,
				enumerable: false
			});
		};
		inst._zod.parse = (payload, _ctx) => {
			if (typeof payload.value !== "function") {
				payload.issues.push({
					code: "invalid_type",
					expected: "function",
					input: payload.value,
					inst
				});
				return payload;
			}
			if (inst._def.output && inst._def.output._zod.def.type === "promise") payload.value = inst.implementAsync(payload.value);
			else payload.value = inst.implement(payload.value);
			return payload;
		};
		inst.input = (...args) => {
			const F = inst.constructor;
			if (Array.isArray(args[0])) return new F({
				type: "function",
				input: new $ZodTuple({
					type: "tuple",
					items: args[0],
					rest: args[1]
				}),
				output: inst._def.output
			});
			return new F({
				type: "function",
				input: args[0],
				output: inst._def.output
			});
		};
		inst.output = (output) => {
			const F = inst.constructor;
			return new F({
				type: "function",
				input: inst._def.input,
				output
			});
		};
		return inst;
	});
	const $ZodCustom = /*@__PURE__*/ $constructor("$ZodCustom", (inst, def) => {
		$ZodCheck.init(inst, def);
		$ZodType.init(inst, def);
		inst._zod.parse = (payload, _) => {
			return payload;
		};
		inst._zod.check = (payload) => {
			const input = payload.value;
			const r = def.fn(input);
			if (r instanceof Promise) return r.then((r) => handleRefineResult(r, payload, input, inst));
			handleRefineResult(r, payload, input, inst);
		};
	});
	function handleRefineResult(result, payload, input, inst) {
		if (!result) {
			const _iss = {
				code: "custom",
				input,
				inst,
				path: [...inst._zod.def.path ?? []],
				continue: !inst._zod.def.abort
			};
			if (inst._zod.def.params) _iss.params = inst._zod.def.params;
			payload.issues.push(issue(_iss));
		}
	}

//#endregion
//#region node_modules/.pnpm/zod@4.6.5/node_modules/zod/v4/core/api.js
	function snapshotChecks(def) {
		if (def.checks) def.checks = [...def.checks];
		return def;
	}
	// @__NO_SIDE_EFFECTS__
	function _string(Class, params) {
		return new Class(snapshotChecks({
			type: "string",
			...normalizeParams(params)
		}));
	}
	// @__NO_SIDE_EFFECTS__
	function _number(Class, params) {
		return new Class(snapshotChecks({
			type: "number",
			checks: [],
			...normalizeParams(params)
		}));
	}
	// @__NO_SIDE_EFFECTS__
	function _coercedNumber(Class, params) {
		return new Class(snapshotChecks({
			type: "number",
			coerce: true,
			checks: [],
			...normalizeParams(params)
		}));
	}
	// @__NO_SIDE_EFFECTS__
	function _int(Class, params) {
		return new Class({
			type: "number",
			check: "number_format",
			abort: false,
			format: "safeint",
			...normalizeParams(params)
		});
	}
	// @__NO_SIDE_EFFECTS__
	function _boolean(Class, params) {
		return new Class({
			type: "boolean",
			...normalizeParams(params)
		});
	}
	// @__NO_SIDE_EFFECTS__
	function _unknown(Class) {
		return new Class({ type: "unknown" });
	}
	// @__NO_SIDE_EFFECTS__
	function _lte(value, params) {
		return new $ZodCheckLessThan({
			check: "less_than",
			...normalizeParams(params),
			value,
			inclusive: true
		});
	}
	// @__NO_SIDE_EFFECTS__
	function _gte(value, params) {
		return new $ZodCheckGreaterThan({
			check: "greater_than",
			...normalizeParams(params),
			value,
			inclusive: true
		});
	}
	// @__NO_SIDE_EFFECTS__
	function _minLength(minimum, params) {
		return new $ZodCheckMinLength({
			check: "min_length",
			...normalizeParams(params),
			minimum
		});
	}
	// @__NO_SIDE_EFFECTS__
	function _length(length, params) {
		return new $ZodCheckLengthEquals({
			check: "length_equals",
			...normalizeParams(params),
			length
		});
	}
	// @__NO_SIDE_EFFECTS__
	function _custom(Class, fn, _params) {
		const norm = normalizeParams(_params);
		norm.abort ?? (norm.abort = true);
		return new Class({
			type: "custom",
			check: "custom",
			fn,
			...norm
		});
	}
	// @__NO_SIDE_EFFECTS__
	function _refine(Class, fn, _params) {
		return new Class({
			type: "custom",
			check: "custom",
			fn,
			...normalizeParams(_params)
		});
	}

//#endregion
//#region node_modules/.pnpm/zod@4.6.5/node_modules/zod/v4/mini/schemas.js
	const ZodMiniType = /*@__PURE__*/ $constructor("ZodMiniType", (inst, def) => {
		if (!inst._zod) throw new Error("Uninitialized schema in ZodMiniType.");
		$ZodType.init(inst, def);
		inst.def = def;
		inst.type = def.type;
	}, {
		get with() {
			return this.check;
		},
		set with(value) {
			own(this, "with", value);
		},
		parse(data, params) {
			return parse(this, data, params, { callee: this.parse });
		},
		parseAsync(data, params) {
			return parseAsync(this, data, params, { callee: this.parseAsync });
		},
		safeParse(data, params) {
			return safeParse(this, data, params);
		},
		safeParseAsync(data, params) {
			return safeParseAsync(this, data, params);
		},
		check(...checks) {
			const def = this.def;
			return this.clone({
				...def,
				checks: [...def.checks ?? [], ...checks.map((ch) => typeof ch === "function" ? { _zod: {
					check: ch,
					def: { check: "custom" },
					onattach: []
				} } : ch)]
			}, { parent: true });
		},
		clone(_def, params) {
			return clone(this, _def, params);
		},
		brand() {
			return this;
		},
		register(reg, meta) {
			reg.add(this, meta);
			return this;
		},
		apply(fn, ...args) {
			return args.length === 0 ? fn(this) : fn(this, ...args);
		}
	});
	const ZodMiniString = /*@__PURE__*/ $constructor("ZodMiniString", (inst, def) => {
		$ZodString.init(inst, def);
		ZodMiniType.init(inst, def);
	});
	// @__NO_SIDE_EFFECTS__
	function string(params) {
		return _string(ZodMiniString, params);
	}
	const ZodMiniNumber = /*@__PURE__*/ $constructor("ZodMiniNumber", (inst, def) => {
		$ZodNumber.init(inst, def);
		ZodMiniType.init(inst, def);
	});
	// @__NO_SIDE_EFFECTS__
	function number$1(params) {
		return _number(ZodMiniNumber, params);
	}
	const ZodMiniNumberFormat = /*@__PURE__*/ $constructor("ZodMiniNumberFormat", (inst, def) => {
		$ZodNumberFormat.init(inst, def);
		ZodMiniNumber.init(inst, def);
	});
	function int(params) {
		return _int(ZodMiniNumberFormat, params);
	}
	const ZodMiniBoolean = /*@__PURE__*/ $constructor("ZodMiniBoolean", (inst, def) => {
		$ZodBoolean.init(inst, def);
		ZodMiniType.init(inst, def);
	});
	// @__NO_SIDE_EFFECTS__
	function boolean(params) {
		return _boolean(ZodMiniBoolean, params);
	}
	const ZodMiniUnknown = /*@__PURE__*/ $constructor("ZodMiniUnknown", (inst, def) => {
		$ZodUnknown.init(inst, def);
		ZodMiniType.init(inst, def);
	});
	// @__NO_SIDE_EFFECTS__
	function unknown() {
		return _unknown(ZodMiniUnknown);
	}
	const ZodMiniArray = /*@__PURE__*/ $constructor("ZodMiniArray", (inst, def) => {
		$ZodArray.init(inst, def);
		ZodMiniType.init(inst, def);
	});
	// @__NO_SIDE_EFFECTS__
	function array(element, params) {
		return new ZodMiniArray({
			type: "array",
			element,
			...normalizeParams(params)
		});
	}
	const ZodMiniObject = /*@__PURE__*/ $constructor("ZodMiniObject", (inst, def) => {
		$ZodObject.init(inst, def);
		ZodMiniType.init(inst, def);
		installLazyProp(inst, "shape", (self) => self._zod.def.shape, false);
	});
	// @__NO_SIDE_EFFECTS__
	function object(shape, params) {
		const def = {
			type: "object",
			shape: shape ?? {},
			...normalizeParams(params)
		};
		return new ZodMiniObject(def);
	}
	const ZodMiniUnion = /*@__PURE__*/ $constructor("ZodMiniUnion", (inst, def) => {
		$ZodUnion.init(inst, def);
		ZodMiniType.init(inst, def);
	});
	// @__NO_SIDE_EFFECTS__
	function union(options, params) {
		return new ZodMiniUnion({
			type: "union",
			options,
			...normalizeParams(params)
		});
	}
	const ZodMiniTuple = /*@__PURE__*/ $constructor("ZodMiniTuple", (inst, def) => {
		$ZodTuple.init(inst, def);
		ZodMiniType.init(inst, def);
	});
	// @__NO_SIDE_EFFECTS__
	function tuple(items, _paramsOrRest, _params) {
		const hasRest = _paramsOrRest instanceof $ZodType;
		const params = hasRest ? _params : _paramsOrRest;
		return new ZodMiniTuple({
			type: "tuple",
			items,
			rest: hasRest ? _paramsOrRest : null,
			...normalizeParams(params)
		});
	}
	const ZodMiniRecord = /*@__PURE__*/ $constructor("ZodMiniRecord", (inst, def) => {
		$ZodRecord.init(inst, def);
		ZodMiniType.init(inst, def);
	});
	// @__NO_SIDE_EFFECTS__
	function record(keyType, valueType, params) {
		if (!valueType || !valueType._zod) return new ZodMiniRecord({
			type: "record",
			keyType: /* @__PURE__ */ string(),
			valueType: keyType,
			...normalizeParams(valueType)
		});
		return new ZodMiniRecord({
			type: "record",
			keyType,
			valueType,
			...normalizeParams(params)
		});
	}
	// @__NO_SIDE_EFFECTS__
	function partialRecord(keyType, valueType, params) {
		return new ZodMiniRecord({
			type: "record",
			keyType,
			valueType,
			...normalizeParams(params),
			partial: true
		});
	}
	const ZodMiniEnum = /*@__PURE__*/ $constructor("ZodMiniEnum", (inst, def) => {
		$ZodEnum.init(inst, def);
		ZodMiniType.init(inst, def);
		inst.options = [...inst._zod.values];
	});
	// @__NO_SIDE_EFFECTS__
	function _enum(values, params) {
		const entries = Array.isArray(values) ? Object.fromEntries(values.map((v) => [v, v])) : values;
		return new ZodMiniEnum({
			type: "enum",
			entries,
			...normalizeParams(params)
		});
	}
	const ZodMiniLiteral = /*@__PURE__*/ $constructor("ZodMiniLiteral", (inst, def) => {
		$ZodLiteral.init(inst, def);
		ZodMiniType.init(inst, def);
	});
	// @__NO_SIDE_EFFECTS__
	function literal(value, params) {
		return new ZodMiniLiteral({
			type: "literal",
			values: Array.isArray(value) ? value : [value],
			...normalizeParams(params)
		});
	}
	const ZodMiniOptional = /*@__PURE__*/ $constructor("ZodMiniOptional", (inst, def) => {
		$ZodOptional.init(inst, def);
		ZodMiniType.init(inst, def);
	});
	// @__NO_SIDE_EFFECTS__
	function optional(innerType) {
		return new ZodMiniOptional({
			type: "optional",
			innerType
		});
	}
	const ZodMiniNullable = /*@__PURE__*/ $constructor("ZodMiniNullable", (inst, def) => {
		$ZodNullable.init(inst, def);
		ZodMiniType.init(inst, def);
	});
	// @__NO_SIDE_EFFECTS__
	function nullable(innerType) {
		return new ZodMiniNullable({
			type: "nullable",
			innerType
		});
	}
	const ZodMiniCatch = /*@__PURE__*/ $constructor("ZodMiniCatch", (inst, def) => {
		$ZodCatch.init(inst, def);
		ZodMiniType.init(inst, def);
	});
	// @__NO_SIDE_EFFECTS__
	function _catch(innerType, catchValue) {
		return new ZodMiniCatch({
			type: "catch",
			innerType,
			catchValue: typeof catchValue === "function" ? catchValue : constantCatch(catchValue)
		});
	}
	const ZodMiniPipe = /*@__PURE__*/ $constructor("ZodMiniPipe", (inst, def) => {
		$ZodPipe.init(inst, def);
		ZodMiniType.init(inst, def);
	});
	const ZodMiniCodec = /*@__PURE__*/ $constructor("ZodMiniCodec", (inst, def) => {
		ZodMiniPipe.init(inst, def);
		$ZodCodec.init(inst, def);
	});
	// @__NO_SIDE_EFFECTS__
	function codec(in_, out, params) {
		return new ZodMiniCodec({
			type: "pipe",
			in: in_,
			out,
			transform: params.decode,
			reverseTransform: params.encode
		});
	}
	const ZodMiniCustom = /*@__PURE__*/ $constructor("ZodMiniCustom", (inst, def) => {
		$ZodCustom.init(inst, def);
		ZodMiniType.init(inst, def);
	});
	// @__NO_SIDE_EFFECTS__
	function custom(fn, _params) {
		return _custom(ZodMiniCustom, fn ?? (() => true), _params);
	}
	// @__NO_SIDE_EFFECTS__
	function refine(fn, _params = {}) {
		return _refine(ZodMiniCustom, fn, _params);
	}
	// @__NO_SIDE_EFFECTS__
	function _instanceof(cls, params = {}) {
		const inst = /* @__PURE__ */ custom((data) => data instanceof cls, params);
		inst._zod.bag.Class = cls;
		inst._zod.check = (payload) => {
			if (!(payload.value instanceof cls)) payload.issues.push({
				code: "invalid_type",
				expected: cls.name,
				input: payload.value,
				inst,
				path: [...inst._zod.def.path ?? []]
			});
		};
		return inst;
	}
	const ZodMiniFunction = /*@__PURE__*/ $constructor("ZodMiniFunction", (inst, def) => {
		$ZodFunction.init(inst, def);
		ZodMiniType.init(inst, def);
	});
	// @__NO_SIDE_EFFECTS__
	function _function(params) {
		return new ZodMiniFunction({
			type: "function",
			input: Array.isArray(params?.input) ? /* @__PURE__ */ tuple(params?.input) : params?.input ?? /* @__PURE__ */ array(/* @__PURE__ */ unknown()),
			output: params?.output ?? /* @__PURE__ */ unknown()
		});
	}

//#endregion
//#region node_modules/.pnpm/zod@4.6.5/node_modules/zod/v4/mini/coerce.js
	// @__NO_SIDE_EFFECTS__
	function number(params) {
		return _coercedNumber(ZodMiniNumber, params);
	}

//#endregion
//#region src/shared/json.ts
/** Parses JSON and validates it, or returns null if either step fails. */
	function parseJson(text, schema) {
		if (text === null || text === void 0) return null;
		let value;
		try {
			value = JSON.parse(text);
		} catch {
			return null;
		}
		const result = schema.safeParse(value);
		return result.success ? result.data : null;
	}

//#endregion
//#region src/shared/storage.ts
	const StorageKey = {
		board: "cdc-board",
		pieces: "cdc-pieces",
		coach: "cdc-coach",
		boardZoom: "cdc-board-zoom",
		ratingChartRange: "cdc-rchart:range",
		reviewCache: (gameId, positions, version) => `cdc-review:${gameId}:${positions}:v${version}`
	};
	const SessionKey = {
		lateReload: "cdc-late-reload",
		gameStarted: (gameId) => `cdc-started:${gameId}`
	};
	const area = (name) => name === "local" ? localStorage : sessionStorage;
	/**
	* The stored value if it passes `schema`, else null. A blocked storage throws,
	* as it did in the original: since its writes are lost too, reading it as
	* missing would make a once-per-game check pass on every load. So read before
	* changing the page.
	*/
	function readStored(key, schema, from = "local") {
		const result = schema.safeParse(area(from).getItem(key));
		return result.success ? result.data : null;
	}
	/** Like `readStored`, for a JSON value: a blocked storage throws too. */
	function readStoredJson(key, schema, from = "local") {
		return parseJson(area(from).getItem(key), schema);
	}
	/** Stores a value. A full or blocked storage loses the value without throwing. */
	function writeStored(key, value, to = "local") {
		try {
			area(to).setItem(key, String(value));
		} catch {}
	}
	function writeStoredJson(key, value, to = "local") {
		writeStored(key, JSON.stringify(value), to);
	}

//#endregion
//#region src/shared/coach.ts
/** The Game Review's coaches: one portrait each, in public/img/coaches. */
	const COACH_COUNT = 4;
	const CoachIdSchema = number().check(int(), _gte(1), _lte(4));
	/** The coach's expression for a move, set by its verdict (see the review's move classes). */
	const CoachMoodSchema = _enum([
		"neutral",
		"happy",
		"delight",
		"doubt",
		"worry",
		"shock"
	]);
	const COACH_MOODS = CoachMoodSchema.options;
	/**
	* The coach kept in storage, or one picked at random and kept the first time.
	* The review and the practice drills read the same key, so both show the same coach.
	*/
	function pickCoach() {
		const stored = readStored(StorageKey.coach, CoachIdSchema);
		if (stored !== null) return stored;
		const coach = 1 + Math.floor(Math.random() * 4);
		writeStored(StorageKey.coach, coach);
		return coach;
	}

//#endregion
//#region src/shared/sounds.ts
	const SoundNameSchema = _enum([
		"move-self",
		"move-opponent",
		"move-check",
		"capture",
		"castle",
		"promote",
		"premove",
		"illegal",
		"notify",
		"tenseconds",
		"game-start",
		"game-end"
	]);
	const SOUND_NAMES = SoundNameSchema.options;

//#endregion
//#region src/shared/protocol.ts
	const PageReadySchema = object({ type: literal("cdc:page-ready") });
	const SoundsSchema = object({
		type: literal("cdc:sounds"),
		sounds: partialRecord(SoundNameSchema, _instanceof(ArrayBuffer))
	});
	const CoachStateSchema = object({
		type: literal("cdc:coach"),
		coach: int(),
		mood: CoachMoodSchema,
		talking: boolean()
	});
	function listen$1(schema, handler) {
		const listener = (event) => {
			if (event.source !== window) return;
			const result = schema.safeParse(event.data);
			if (result.success) handler(result.data);
		};
		window.addEventListener("message", listener);
		return () => window.removeEventListener("message", listener);
	}
	function post(message) {
		window.postMessage(message, location.origin);
	}
	/** Page → content: the page script is listening, send the sounds. */
	const postPageReady = () => post({ type: "cdc:page-ready" });
	const onSounds = (handler) => listen$1(SoundsSchema, (message) => handler(message.sounds));
	/** Page → content: which coach the review shows, and how it looks. */
	const postCoachState = (state) => post({
		type: "cdc:coach",
		...state
	});

//#endregion
//#region src/shared/chess/squares.ts
	const FILES = [
		"a",
		"b",
		"c",
		"d",
		"e",
		"f",
		"g",
		"h"
	];
	const RANKS = [
		"1",
		"2",
		"3",
		"4",
		"5",
		"6",
		"7",
		"8"
	];
	/** The square at a 0-based file and rank, or null off the board. */
	function squareAt(file, rank) {
		const fileName = FILES[file];
		const rankName = RANKS[rank];
		return fileName !== void 0 && rankName !== void 0 ? `${fileName}${rankName}` : null;
	}
	const fileIndex$1 = (char) => FILES.findIndex((name) => name === char);
	const rankIndex = (char) => RANKS.findIndex((name) => name === char);
	/** The square named by the first two characters of `text` ("e4", "e2e4"…), or null. */
	function parseSquare(text) {
		return squareAt(fileIndex$1(text[0]), rankIndex(text[1]));
	}
	const isSquare = (text) => text.length === 2 && parseSquare(text) !== null;
	/** 0-based [file, rank] of a square. */
	function squareCoords(square) {
		return [fileIndex$1(square[0]), rankIndex(square[1])];
	}

//#endregion
//#region src/page/lichess/chessground.ts
	function cgKey(element) {
		if (!("cgKey" in element)) return null;
		const key = element.cgKey;
		return typeof key === "string" && isSquare(key) ? key : null;
	}

//#endregion
//#region src/shared/chess/types.ts
	const COLORS = ["white", "black"];
	const ROLES = [
		"pawn",
		"knight",
		"bishop",
		"rook",
		"queen",
		"king"
	];
	const opposite = (color) => color === "white" ? "black" : "white";

//#endregion
//#region src/shared/chessground.ts
/** The side at the bottom of a board's `.cg-wrap`. */
	const wrapOrientation = (wrap) => wrap.classList.contains("orientation-black") ? "black" : "white";
	/** The piece a `piece` element shows, or null for one that isn't on the board. */
	function pieceOf(element) {
		const { classList } = element;
		if (classList.contains("ghost") || classList.contains("fading")) return null;
		const color = COLORS.find((name) => classList.contains(name));
		const role = ROLES.find((name) => classList.contains(name));
		return color && role ? {
			color,
			role
		} : null;
	}

//#endregion
//#region src/page/sounds/board-reader.ts
	const mainBoardWrap = () => queryOne(document, ".main-board .cg-wrap", HTMLElement) ?? queryOne(document, ".cg-wrap", HTMLElement);
	function boardOrientation() {
		const wrap = mainBoardWrap();
		return wrap ? wrapOrientation(wrap) : "white";
	}
	const mainCgBoard = () => mainBoardWrap()?.querySelector("cg-board") ?? null;
	const isKeyed = (square) => square !== null;
	/** The squares chessground marks with `className` (`current-premove`, `selected`…). */
	const markedSquares = (board, className) => queryAll(board, `square.${className}`, Element).map(cgKey).filter(isKeyed);
	function readBoard(wrap) {
		const board = wrap?.querySelector("cg-board");
		if (!board) return null;
		const pieces = /* @__PURE__ */ new Map();
		for (const element of board.children) {
			if (element.tagName !== "PIECE") continue;
			const square = cgKey(element);
			const piece = square && pieceOf(element);
			if (square && piece) pieces.set(square, piece);
		}
		return {
			pieces,
			lastMove: markedSquares(board, "last-move")
		};
	}

//#endregion
//#region src/page/sounds/pointer-square.ts
/** The square under a point of the page, or null off the board. */
	function squareFromPoint({ rect, x, y, orientation }) {
		const column = Math.floor((x - rect.left) / rect.width * 8);
		const row = Math.floor((y - rect.top) / rect.height * 8);
		if (column < 0 || column > 7 || row < 0 || row > 7) return null;
		return orientation === "white" ? squareAt(column, 7 - row) : squareAt(7 - column, row);
	}

//#endregion
//#region src/page/sounds/attempts.ts
	const SETTLE_MS = 80;
	const premoveKey = (board) => markedSquares(board, "current-premove").join();
	function squareUnderPointer(board, event) {
		const rect = board.getBoundingClientRect();
		const { clientX: x, clientY: y } = event;
		return squareFromPoint({
			rect,
			x,
			y,
			orientation: boardOrientation()
		});
	}
	function watchAttempt(session, press, isDrop) {
		const startedAt = Date.now();
		setTimeout(() => {
			if (!session.playOurs || session.lastMoveSoundAt >= startedAt) return;
			const premoves = premoveKey(press.board);
			if (premoves && premoves !== press.premoves) session.playOurs("premove");
			else if (isDrop) session.playOurs("illegal");
		}, SETTLE_MS);
	}
	function isClickToMove(board, pieces, square) {
		const selectedSquare = queryOne(board, "square.selected", Element);
		const selected = selectedSquare ? cgKey(selectedSquare) : null;
		const piece = selected ? pieces.get(selected) : void 0;
		return piece !== void 0 && square !== selected && pieces.get(square)?.color !== piece.color;
	}
	function onPress(session, event) {
		const board = mainCgBoard();
		const onBoard = event.target instanceof Node && board?.contains(event.target);
		if (event.button !== 0 || !board || !onBoard) return null;
		const state = readBoard(mainBoardWrap());
		const square = squareUnderPointer(board, event);
		if (!state || !square) return null;
		session.lastPieces = state.pieces;
		const press = {
			board,
			square,
			premoves: premoveKey(board)
		};
		if (isClickToMove(board, state.pieces, square)) watchAttempt(session, press, false);
		return press;
	}
	/** Listens to the pointer until the returned function is called. */
	function watchMoveAttempts(session) {
		let press = null;
		const onPointerDown = (event) => {
			press = onPress(session, event);
		};
		const onPointerUp = (event) => {
			const released = press;
			press = null;
			if (!released || event.button !== 0 || !released.board.querySelector("piece.dragging")) return;
			const square = squareUnderPointer(released.board, event);
			if (square && square !== released.square) watchAttempt(session, released, true);
		};
		window.addEventListener("pointerdown", onPointerDown, true);
		window.addEventListener("pointerup", onPointerUp, true);
		return () => {
			window.removeEventListener("pointerdown", onPointerDown, true);
			window.removeEventListener("pointerup", onPointerUp, true);
		};
	}

//#endregion
//#region src/shared/page-init-data.ts
	const ID = "page-init-data";
	let node = null;
	let readers = null;
	function watch() {
		readers = [];
		const observer = new MutationObserver(() => {
			node = document.getElementById(ID);
			if (node) observer.disconnect();
		});
		observer.observe(document, {
			childList: true,
			subtree: true
		});
		document.addEventListener("DOMContentLoaded", () => {
			observer.disconnect();
			const text = node?.textContent ?? null;
			node = null;
			const waiting = readers ?? [];
			readers = null;
			for (const read of waiting) try {
				read(text);
			} catch (error) {
				console.error("[LichessDotCom] page init data reader failed", error);
			}
		}, { once: true });
	}
	/**
	* Hands the page's init data to `read` once the page is parsed, or right away
	* (whatever is still in the document) when it already is.
	*/
	function readPageInitData(read) {
		if (!isParsing()) {
			read(document.getElementById(ID)?.textContent ?? null);
			return;
		}
		if (readers === null) watch();
		readers?.push(read);
	}

//#endregion
//#region src/page/sounds/game-start.ts
	const RoundInitSchema = object({ data: object({
		game: object({
			id: string().check(_minLength(1)),
			status: object({ name: _enum(["created", "started"]) }),
			turns: optional(number$1())
		}),
		player: object({ spectator: optional(boolean()) })
	}) });
	const StartedSchema = string().check(_minLength(1));
	/** The id of the game the page opens, if the player is in it and it has just begun. */
	function freshGameId(initData) {
		const round = parseJson(initData, RoundInitSchema);
		if (!round) return null;
		const { game, player } = round.data;
		return !player.spectator && (game.turns ?? 0) <= 1 ? game.id : null;
	}
	function watchGameStart(session) {
		let gameId = null;
		const play = () => {
			if (gameId === null || !session.playOurs) return;
			const key = SessionKey.gameStarted(gameId);
			gameId = null;
			if (readStored(key, StartedSchema, "session") !== null) return;
			writeStored(key, "1", "session");
			session.playOurs("game-start");
		};
		readPageInitData((text) => {
			gameId = freshGameId(text);
			play();
		});
		return { play };
	}

//#endregion
//#region src/shared/poll.ts
/**
	* Calls `read` now, then every `intervalMs` until it gives a value, and hands
	* that to `found`. For what Lichess only sets up after our script starts.
	*/
	function pollUntil(read, found, { intervalMs, giveUpMs, worthWaiting = () => true }) {
		const started = Date.now();
		const attempt = () => {
			const value = read();
			if (value !== null) found(value);
			else if (worthWaiting() && Date.now() - started < giveUpMs) setTimeout(attempt, intervalMs);
		};
		attempt();
	}

//#endregion
//#region src/shared/guards.ts
/**
	* A type guard backed by a schema, for live objects that must keep their
	* identity (a zod parse returns a copy). An object that passed once is
	* remembered, so checking it again is free.
	*
	* It narrows the input, not a parsed copy, so the schema must not rewrite the
	* value: no `lenient`, catch, default or coerce. The signature only rejects
	* transforms and pipes, as zod's types can't tell the others apart.
	*
	* A method described with `z.custom` and `typeof` is only checked to be a
	* function: its parameters and return type are taken on trust.
	*/
	function createGuard(schema) {
		const passed = /* @__PURE__ */ new WeakSet();
		return (value) => {
			const isObject = typeof value === "object" && value !== null;
			if (isObject && passed.has(value)) return true;
			if (!schema.safeParse(value).success) return false;
			if (isObject) passed.add(value);
			return true;
		};
	}

//#endregion
//#region src/page/lichess/globals.ts
	const readSite = () => window.site;
	/** A string of Lichess's `site` translations, or `fallback` if it's missing. */
	function translate(key, fallback) {
		const table = window.i18n;
		if (typeof table !== "object" || table === null || !("site" in table)) return fallback;
		const site = table.site;
		if (typeof site !== "object" || site === null || !(key in site)) return fallback;
		const value = Reflect.get(site, key);
		return typeof value === "string" ? value : fallback;
	}

//#endregion
//#region src/page/lichess/method.ts
	const isFunction = (value) => typeof value === "function";
	const method = () => custom(isFunction);

//#endregion
//#region src/shared/zod.ts
/** An optional field that reads as absent when malformed, rather than failing the whole parse. */
	function lenient(schema) {
		return _catch(optional(schema), void 0);
	}

//#endregion
//#region src/page/lichess/sound.ts
	const SoundPlayerSchema = object({
		paths: _instanceof(Map),
		play: method(),
		move: method(),
		saySan: optional(method()),
		theme: optional(unknown()),
		cdcHooked: optional(boolean())
	});
	const isSoundPlayer = createGuard(SoundPlayerSchema);
	const hasSound = createGuard(object({ sound: unknown() }));
	/** The page's sound player, once Lichess has set it up. */
	function soundPlayer() {
		const site = readSite();
		if (!hasSound(site)) return null;
		const { sound } = site;
		return isSoundPlayer(sound) ? sound : null;
	}
	const MoveOptionsSchema = object({
		san: lenient(string()),
		ply: lenient(number$1()),
		name: lenient(string()),
		filter: lenient(string()),
		volume: lenient(number$1())
	});
	function readMoveOptions(options) {
		const result = MoveOptionsSchema.safeParse(options);
		return result.success ? result.data : {};
	}

//#endregion
//#region src/page/sounds/install.ts
	function toBlobUrls(files) {
		const urls = /* @__PURE__ */ new Map();
		for (const name of SOUND_NAMES) {
			const bytes = files[name];
			if (bytes) urls.set(name, URL.createObjectURL(new Blob([bytes], { type: "audio/mpeg" })));
		}
		return urls;
	}
	/** Hands over Lichess's sound player once it's set up, for up to 30 seconds. */
	function whenSoundPlayerReady(callback) {
		pollUntil(soundPlayer, callback, {
			intervalMs: 50,
			giveUpMs: 3e4
		});
	}

//#endregion
//#region src/shared/chess/attacks.ts
	const KNIGHT_JUMPS = [
		[1, 2],
		[2, 1],
		[2, -1],
		[1, -2],
		[-1, -2],
		[-2, -1],
		[-2, 1],
		[-1, 2]
	];
	const ORTHOGONAL = [
		[1, 0],
		[-1, 0],
		[0, 1],
		[0, -1]
	];
	const DIAGONAL = [
		[1, 1],
		[1, -1],
		[-1, 1],
		[-1, -1]
	];
	/**
	* The roles of `by`'s pieces that attack `target`. Pins are ignored, and a
	* slider only counts up to the first piece in its way.
	*/
	function attackers(board, target, by) {
		const [file, rank] = squareCoords(target);
		const at = (fileStep, rankStep) => {
			const square = squareAt(file + fileStep, rank + rankStep);
			return square ? board.get(square) : void 0;
		};
		const found = [];
		const take = (piece, roles) => {
			if (piece?.color === by && roles.includes(piece.role)) found.push(piece.role);
		};
		const behind = by === "white" ? -1 : 1;
		take(at(-1, behind), ["pawn"]);
		take(at(1, behind), ["pawn"]);
		for (const [fileStep, rankStep] of KNIGHT_JUMPS) take(at(fileStep, rankStep), ["knight"]);
		for (const [fileStep, rankStep] of [...ORTHOGONAL, ...DIAGONAL]) take(at(fileStep, rankStep), ["king"]);
		const slide = (steps, roles) => {
			for (const [fileStep, rankStep] of steps) for (let k = 1; squareAt(file + fileStep * k, rank + rankStep * k); k++) {
				const piece = at(fileStep * k, rankStep * k);
				if (!piece) continue;
				take(piece, roles);
				break;
			}
		};
		slide(ORTHOGONAL, ["rook", "queen"]);
		slide(DIAGONAL, ["bishop", "queen"]);
		return found;
	}
	const isAttacked = (board, target, by) => attackers(board, target, by).length > 0;

//#endregion
//#region src/page/sounds/choose.ts
	const LICHESS_EVENTS = /* @__PURE__ */ new Map([
		["move", "move-self"],
		["capture", "capture"],
		["genericNotify", "game-start"],
		["victory", "game-end"],
		["defeat", "game-end"],
		["draw", "game-end"],
		["lowTime", "tenseconds"],
		["error", "illegal"],
		["confirmation", "notify"],
		["newChallenge", "notify"],
		["newPM", "notify"],
		["socialNotify", "notify"]
	]);
	/** Our sound for one of Lichess's named sounds, if we have one. */
	const soundForLichessEvent = (name) => LICHESS_EVENTS.get(name);
	const fallbackSound = (lichessName) => lichessName === "capture" ? "capture" : "move-self";
	function soundFromSan(san, ply, orientation) {
		if (/[+#]/.test(san)) return "move-check";
		if (san.startsWith("O-O")) return "castle";
		if (san.includes("=")) return "promote";
		if (san.includes("x")) return "capture";
		if (ply === void 0) return "move-self";
		return (ply % 2 === 1 ? "white" : "black") === orientation ? "move-self" : "move-opponent";
	}
	/**
	* The sound of the move on the board after a jump, or a plain move at the
	* start. A quiet move's SAN ends on its destination: the piece there says
	* whose move it was.
	*/
	function soundOfShownMove(san, pieces, orientation) {
		const sound = san ? soundFromSan(san, void 0, orientation) : "move-self";
		if (!san || sound !== "move-self") return sound;
		const destination = parseSquare(san.slice(-2));
		const mover = destination && pieces.get(destination);
		return mover && mover.color !== orientation ? "move-opponent" : "move-self";
	}
	const isAnyKingInCheck = (pieces) => [...pieces].some(([square, piece]) => piece.role === "king" && isAttacked(pieces, square, opposite(piece.color)));
	function leavers(from, to, color) {
		const backRank = color === "white" ? "1" : "8";
		const roles = [];
		for (const [square, piece] of from) {
			if (piece.color !== color) continue;
			const now = to.get(square);
			if (now?.color === color && now.role === piece.role) continue;
			if (square[1] !== backRank) return null;
			roles.push(piece.role);
		}
		return roles;
	}
	const isKingAndRook = (roles) => roles?.length === 2 && roles.includes("king") && roles.includes("rook");
	/**
	* Whether one side castled: its king and a rook, and nothing else, moved
	* along its back rank. Read off the pieces rather than the highlight, which
	* may be off, and in Chess960 the king may move a single square.
	*/
	function castled(before, after) {
		if (!before) return false;
		return COLORS.some((color) => isKingAndRook(leavers(before, after, color)) && isKingAndRook(leavers(after, before, color)));
	}
	function readHighlight(pieces, first, second) {
		let dest = null;
		if (pieces.has(second)) dest = second;
		else if (pieces.has(first)) dest = first;
		return {
			orig: dest === first ? second : first,
			dest,
			mover: dest === null ? void 0 : pieces.get(dest)
		};
	}
	function isCastlingHighlight(first, second, mover) {
		const [firstFile, firstRank] = squareCoords(first);
		const [secondFile, secondRank] = squareCoords(second);
		return firstRank === secondRank && Math.abs(firstFile - secondFile) >= 2 && (!mover || mover.role === "king");
	}
	function isPromotion(highlight, before) {
		const { orig, dest, mover } = highlight;
		const was = before?.get(orig);
		return (mover?.role === "pawn" || was?.role === "pawn" && was.color === mover?.color) && dest !== null && orig !== dest && /[18]$/.test(dest);
	}
	function soundFromBoard(move) {
		const { before, pieces, lastMove, lichessName, orientation } = move;
		if (isAnyKingInCheck(pieces)) return "move-check";
		if (castled(before, pieces)) return "castle";
		const first = lastMove[0];
		if (first === void 0) return fallbackSound(lichessName);
		const second = lastMove[1] ?? first;
		const highlight = readHighlight(pieces, first, second);
		const { mover } = highlight;
		if (isCastlingHighlight(first, second, mover)) return "castle";
		if (isPromotion(highlight, before)) return "promote";
		if (lichessName === "capture") return "capture";
		return !mover || mover.color === orientation ? "move-self" : "move-opponent";
	}

//#endregion
//#region src/page/sounds/jumps.ts
	function watchJumps(session, play) {
		let movedThisTask = false;
		let pending = null;
		const cancel = () => {
			if (pending !== null) cancelAnimationFrame(pending);
			pending = null;
		};
		return {
			moved() {
				movedThisTask = true;
				queueMicrotask(() => {
					movedThisTask = false;
				});
				cancel();
			},
			jumped(san) {
				if (movedThisTask) return;
				cancel();
				pending = requestAnimationFrame(() => {
					pending = null;
					const pieces = readBoard(mainBoardWrap())?.pieces ?? null;
					session.lastPieces = pieces ?? session.lastPieces;
					play(soundOfShownMove(san, pieces ?? /* @__PURE__ */ new Map(), boardOrientation()));
				});
			}
		};
	}

//#endregion
//#region src/page/sounds/player.ts
	const PREFIX = "cdc-";
	const FRESH_SAN_MS = 300;
	function rememberBoard(session) {
		requestAnimationFrame(() => {
			session.lastPieces = readBoard(mainBoardWrap())?.pieces ?? session.lastPieces;
		});
	}
	function soundAfterBoardMove(session, lichessName) {
		const state = readBoard(mainBoardWrap());
		if (!state) return fallbackSound(lichessName);
		const before = session.lastPieces;
		session.lastPieces = state.pieces;
		return soundFromBoard({
			before,
			...state,
			lichessName,
			orientation: boardOrientation()
		});
	}
	function hookPlay({ sound, urls, playOurs, playLichess }) {
		sound.play = (name, volume = 1) => {
			if (typeof name === "string" && !name.startsWith(PREFIX)) {
				if (name === "check" || name === "checkmate") return Promise.resolve();
				const ours = soundForLichessEvent(name);
				if (ours && urls.has(ours)) return playOurs(ours, volume);
			}
			return playLichess(name, volume);
		};
	}
	function hookMove(hook) {
		const { sound, session, playMove, jumps } = hook;
		const moveLichess = sound.move.bind(sound);
		let serverMove = null;
		const playSan = (san, ply, volume) => {
			rememberBoard(session);
			return playMove(soundFromSan(san, ply, boardOrientation()), volume);
		};
		const playBoardMove = ({ name }, volume) => {
			const recent = serverMove;
			serverMove = null;
			if (recent && Date.now() - recent.at < FRESH_SAN_MS) return playSan(recent.san, recent.ply, volume);
			session.lastMoveSoundAt = Date.now();
			jumps.moved();
			requestAnimationFrame(() => playMove(soundAfterBoardMove(session, name), volume));
			return Promise.resolve();
		};
		sound.move = (options) => {
			const move = readMoveOptions(options);
			if (move.filter === "music" && move.san) serverMove = {
				san: move.san,
				ply: move.ply,
				at: Date.now()
			};
			if (move.filter === "music" || sound.theme === "music") return moveLichess(options);
			const volume = move.volume ?? 1;
			if (move.san) return playSan(move.san, move.ply, volume);
			if (!move.name || move.name === "move" || move.name === "capture") return playBoardMove(move, volume);
			return moveLichess(options);
		};
	}
	function hookSaySan({ sound, jumps }) {
		const { saySan } = sound;
		if (!saySan) return;
		const sayLichess = saySan.bind(sound);
		sound.saySan = (san, cut, force) => {
			if (cut === true && sound.theme !== "music") jumps.jumped(typeof san === "string" ? san : void 0);
			return sayLichess(san, cut, force);
		};
	}
	/**
	* Adds our sounds to Lichess's player and wraps its methods, once per page.
	* Returns false when another copy of this script got there first.
	*/
	function hookSoundPlayer(sound, urls, session) {
		for (const [name, url] of urls) sound.paths.set(PREFIX + name, url);
		if (sound.cdcHooked) return false;
		sound.cdcHooked = true;
		const playLichess = sound.play.bind(sound);
		const playOurs = (name, volume) => urls.has(name) ? playLichess(PREFIX + name, volume) : void 0;
		const playMove = (name, volume) => {
			session.lastMoveSoundAt = Date.now();
			jumps.moved();
			return playOurs(name, volume) ?? playLichess("move", volume);
		};
		const jumps = watchJumps(session, (name) => playMove(name, void 0));
		const hook = {
			sound,
			urls,
			session,
			playOurs,
			playLichess,
			playMove,
			jumps
		};
		hookPlay(hook);
		hookMove(hook);
		hookSaySan(hook);
		session.playOurs = (name) => playOurs(name, void 0);
		return true;
	}

//#endregion
//#region src/page/sounds/session.ts
	const createSession$1 = () => ({
		lastPieces: null,
		lastMoveSoundAt: 0,
		playOurs: null
	});

//#endregion
//#region src/page/sounds/index.ts
	function start$2() {
		const session = createSession$1();
		watchMoveAttempts(session);
		const gameStart = watchGameStart(session);
		const stop = onSounds((files) => {
			stop();
			const urls = toBlobUrls(files);
			whenSoundPlayerReady((sound) => {
				if (hookSoundPlayer(sound, urls, session)) gameStart.play();
			});
		});
		postPageReady();
	}
	const sounds = {
		name: "sounds",
		start: start$2
	};

//#endregion
//#region src/shared/text.ts
/** The text, or undefined when it's empty or missing: for `??` fallbacks that skip ''. */
	const nonEmpty = (text) => text === null || text === "" ? void 0 : text;

//#endregion
//#region src/page/board/flip-label.ts
	const flipBoardLabel = () => nonEmpty(translate("flipBoard", "")) ?? null;
	const mayCome = () => isParsing() || document.querySelector("main.round") !== null;
	const flipLabel = {
		name: "flip label",
		start: () => pollUntil(flipBoardLabel, (label) => setData(document.documentElement, "cdcFlipLabel", label), {
			intervalMs: 250,
			giveUpMs: 3e4,
			worthWaiting: mayCome
		})
	};

//#endregion
//#region src/shared/frame.ts
/**
	* Wraps `task` so it runs at most once per animation frame, however many
	* times it is asked for in between.
	*/
	function oncePerFrame(task) {
		let queued = false;
		return () => {
			if (queued) return;
			queued = true;
			requestAnimationFrame(() => {
				queued = false;
				task();
			});
		};
	}

//#endregion
//#region src/shared/lang.ts
/** The page's language, as Lichess sets it on <html> (`fr`, `en-US`…). */
	const pageLang = () => document.documentElement.lang;
	const isFrench = () => pageLang().startsWith("fr");
	/** The page's language for `Intl`, or undefined (the browser's) when the page sets none. */
	function pageLocale() {
		const lang = pageLang();
		return lang === "" ? void 0 : lang;
	}

//#endregion
//#region src/shared/html.ts
	const ENTITIES = {
		"&": "&amp;",
		"<": "&lt;",
		">": "&gt;",
		"\"": "&quot;",
		"'": "&#39;"
	};
	function escapeHtml(value) {
		return value.replace(/[&<>"']/g, (char) => ENTITIES[char] ?? char);
	}
	var SafeHtml = class {
		#markup;
		constructor(markup) {
			this.#markup = markup;
		}
		get value() {
			return this.#markup;
		}
		toString() {
			return this.#markup;
		}
	};
	function render$1(value) {
		if (value instanceof SafeHtml) return value.value;
		if (typeof value === "string") return escapeHtml(value);
		if (typeof value === "number") return String(value);
		if (value === false || value === null || value === void 0) return "";
		return value.map(render$1).join("");
	}
	function html(strings, ...values) {
		let out = strings[0] ?? "";
		for (const [i, value] of values.entries()) out += render$1(value) + (strings[i + 1] ?? "");
		return new SafeHtml(out);
	}
	/** Markup that is known to be safe: a constant, never user or page data. */
	const trustedHtml = (markup) => new SafeHtml(markup);
	function setHtml(element, markup) {
		element.innerHTML = markup.value;
	}

//#endregion
//#region src/shared/svg.ts
	const SVG_NS = "http://www.w3.org/2000/svg";
	function setAttributes(element, attributes) {
		for (const [name, value] of Object.entries(attributes)) element.setAttribute(name, String(value));
	}
	function createSvgElement(tag, attributes = {}) {
		const element = document.createElementNS(SVG_NS, tag);
		setAttributes(element, attributes);
		return element;
	}
	/** Sizes an SVG to `width` × `height` pixels, with a viewBox in pixels too. */
	function sizeSvg(svg, width, height) {
		setAttributes(svg, {
			width,
			height
		});
		svg.setAttribute("viewBox", `0 0 ${width} ${height}`);
	}
	/** The pointer's x from the element's left edge. */
	const pointerX = (event, element) => event.clientX - element.getBoundingClientRect().left;

//#endregion
//#region src/page/lichess/controller.ts
	const TreeSchema = object({ nodeAtPath: method() });
	const ControllerSchema = object({
		data: unknown(),
		tree: TreeSchema,
		node: unknown(),
		path: unknown(),
		nodeList: unknown(),
		mainline: unknown(),
		onMainline: unknown(),
		jumpToMain: method(),
		userJump: method(),
		getOrientation: method(),
		playUci: optional(unknown()),
		redraw: optional(unknown()),
		synthetic: optional(unknown()),
		actionMenu: optional(unknown()),
		practice: optional(unknown()),
		togglePractice: optional(unknown()),
		explorer: optional(unknown())
	});
	const isController = createGuard(ControllerSchema);
	const PlayerSchema = object({
		color: _enum(["white", "black"]),
		user: lenient(object({ username: lenient(string()) })),
		name: lenient(string()),
		ai: lenient(number$1()),
		rating: lenient(number$1())
	});
	/** `ctrl.data`: plain data, parsed once rather than narrowed. */
	const GameDataSchema = object({
		game: object({
			id: string(),
			speed: lenient(string()),
			variant: object({ key: string() })
		}),
		player: PlayerSchema,
		opponent: PlayerSchema
	});
	/** What the opening explorer's masters database says of a position. */
	const MasterOpeningSchema = object({
		white: number$1(),
		draws: number$1(),
		black: number$1(),
		opening: optional(nullable(object({
			name: optional(string()),
			eco: optional(string())
		})))
	});
	const ExplorerSchema = object({
		fetchMasterOpening: optional(method()),
		isAuth: optional(method())
	});
	const isExplorer = createGuard(ExplorerSchema);

//#endregion
//#region src/page/lichess/tree.ts
	const TreeNodeSchema = object({
		id: string(),
		ply: number$1(),
		fen: string(),
		uci: optional(string()),
		san: optional(string()),
		comp: optional(boolean()),
		children: array(unknown())
	});
	const isTreeNode = createGuard(TreeNodeSchema);
	const NODE_ID_LENGTH = 2;
	/** The path of the node's parent: '' for a move from the root. */
	const parentPath = (path) => path.slice(0, -2);
	/** The id of the node the path leads to. */
	const lastNodeId = (path) => path.slice(-2);
	/** The path of each node along `path`, the first move's first, `path` itself last. */
	function pathPrefixes(path) {
		const prefixes = [];
		for (let end = NODE_ID_LENGTH; end <= path.length; end += NODE_ID_LENGTH) prefixes.push(path.slice(0, end));
		return prefixes;
	}
	/** The node's first child: the next move on its line. */
	function firstChild(node) {
		const child = node.children[0];
		return isTreeNode(child) ? child : null;
	}

//#endregion
//#region src/page/lichess/analysis.ts
	const isToggle = createGuard(method());
	const isRedraw = createGuard(method());
	const isPlayUci = createGuard(method());
	function narrowNode(value) {
		if (!isTreeNode(value)) throw new Error("Lichess’s analysis tree has an unexpected node");
		return value;
	}
	function narrowNodes(value) {
		return Array.isArray(value) ? value.map(narrowNode) : [];
	}
	var Analysis = class {
		#controller;
		#dataSource = null;
		#data = null;
		constructor(controller) {
			this.#controller = controller;
		}
		/** `ctrl.data`, or null when it isn't a game's data we know. */
		get data() {
			const source = this.#controller.data;
			if (source !== this.#dataSource) {
				this.#dataSource = source;
				const result = GameDataSchema.safeParse(source);
				this.#data = result.success ? result.data : null;
			}
			return this.#data;
		}
		get gameId() {
			return this.data?.game.id ?? "";
		}
		get chess960() {
			return this.data?.game.variant.key === "chess960";
		}
		/** Both players by color, as Lichess lists them from the viewer's side. */
		players() {
			const data = this.data;
			const byColor = (color) => {
				if (data?.opponent.color === color) return data.opponent;
				return data?.player.color === color ? data.player : void 0;
			};
			return {
				white: byColor("white"),
				black: byColor("black")
			};
		}
		get node() {
			return narrowNode(this.#controller.node);
		}
		get path() {
			const { path } = this.#controller;
			return typeof path === "string" ? path : "";
		}
		get onMainline() {
			return this.#controller.onMainline === true;
		}
		/** The controller has built its game tree. */
		get hasMainline() {
			return Array.isArray(this.#controller.mainline);
		}
		get mainline() {
			return narrowNodes(this.#controller.mainline);
		}
		/** The nodes from the root to the one on the board. */
		get nodeList() {
			return narrowNodes(this.#controller.nodeList);
		}
		/** The free analysis board, whose tree grows as the user plays. */
		get synthetic() {
			return Boolean(this.#controller.synthetic);
		}
		/** The node at `path`, or the deepest one found along it (Lichess's rule). */
		nodeAtPath(path) {
			return narrowNode(this.#controller.tree.nodeAtPath(path));
		}
		jumpToMain(ply) {
			this.#controller.jumpToMain(ply);
		}
		userJump(path) {
			this.#controller.userJump(path);
		}
		get canPlayUci() {
			return isPlayUci(this.#controller.playUci);
		}
		/** Plays a move from the node on the board, if this page can. */
		playUci(uci) {
			const { playUci } = this.#controller;
			if (isPlayUci(playUci)) playUci.call(this.#controller, uci);
		}
		redraw() {
			const { redraw } = this.#controller;
			if (isRedraw(redraw)) redraw.call(this.#controller);
		}
		orientation() {
			return this.#controller.getOrientation() === "black" ? "black" : "white";
		}
		closeActionMenu() {
			const { actionMenu } = this.#controller;
			if (isToggle(actionMenu) && Boolean(actionMenu.call(this.#controller))) actionMenu.call(this.#controller, false);
		}
		/** Ends "practice with computer", which plays moves on its own. */
		stopPractice() {
			const { practice, togglePractice } = this.#controller;
			if (Boolean(practice) && isToggle(togglePractice)) togglePractice.call(this.#controller, false);
		}
		/** The masters database answers only a signed-in user. */
		explorerSignedIn() {
			const { explorer } = this.#controller;
			return isExplorer(explorer) && Boolean(explorer.isAuth?.());
		}
		/** The masters database's games for a position; rejects when it can't tell. */
		async fetchMasterOpening(fen) {
			const { explorer } = this.#controller;
			if (!isExplorer(explorer) || !explorer.fetchMasterOpening) throw new Error("No opening explorer");
			const answer = await explorer.fetchMasterOpening(fen);
			return MasterOpeningSchema.parse(answer);
		}
	};
	const facades = /* @__PURE__ */ new WeakMap();
	const hasAnalysis = createGuard(object({ analysis: unknown() }));
	/** The page's analysis controller, if it has one. */
	function analysis() {
		const site = readSite();
		const controller = hasAnalysis(site) ? site.analysis : null;
		if (!isController(controller)) return null;
		let facade = facades.get(controller);
		if (!facade) {
			facade = new Analysis(controller);
			facades.set(controller, facade);
		}
		return facade;
	}
	const hasNode = createGuard(object({ analysis: object({ node: unknown() }) }));
	/** The node on the board, if this page has an analysis controller. */
	function currentNode() {
		const site = readSite();
		const node = hasNode(site) ? site.analysis.node : null;
		return isTreeNode(node) ? node : null;
	}

//#endregion
//#region src/page/board/colors.ts
	const GREEN = "#15781B";
	const RED = "#882020";
	const ARROWS = /* @__PURE__ */ new Map([
		[GREEN, "255,170,0"],
		[RED, "248,85,63"],
		["#003088", "72,193,249"],
		["#e68f00", "159,207,63"],
		["#4a4a4a", "200,200,200"],
		["#68217a", "170,110,210"],
		["#ee2080", "238,32,128"],
		["#ffffff", "255,255,255"]
	]);
	const SQUARES = new Map([
		...ARROWS,
		[GREEN, "235,97,80"],
		[RED, "255,170,0"]
	]);
	const DEFAULT_ARROW = "255,170,0";
	const DEFAULT_SQUARE = "235,97,80";
	const arrowColor = (stroke) => ARROWS.get(stroke ?? "") ?? DEFAULT_ARROW;
	const squareColor = (stroke) => SQUARES.get(stroke ?? "") ?? DEFAULT_SQUARE;
	/** The Game Review's best move, in green. */
	const REVIEW_COLOR = "159,207,63";
	/** The engine's move after one played off the game, in Lichess's pale blue. */
	const ENGINE_COLOR = "72,193,249";

//#endregion
//#region src/page/board/geometry.ts
	const SHAFT_WIDTH = .22;
	const HEAD_WIDTH = .52;
	const START_GAP = .35;
	/** A square's column and row as shown. */
	function squareOnScreen(square, whiteAtBottom) {
		const [file, rank] = squareCoords(square);
		return whiteAtBottom ? [file, 7 - rank] : [7 - file, rank];
	}
	function squareCenter(square, whiteAtBottom) {
		const [column, row] = squareOnScreen(square, whiteAtBottom);
		return [column + .5, row + .5];
	}
	/** A straight arrow, or an L for a knight's move: the long leg first. */
	function arrowPath(from, tip) {
		const across = Math.abs(tip[0] - from[0]);
		const down = Math.abs(tip[1] - from[1]);
		if (!(across === 1 && down === 2 || across === 2 && down === 1)) return {
			from,
			tip
		};
		return {
			from,
			corner: across > down ? [tip[0], from[1]] : [from[0], tip[1]],
			tip
		};
	}
	function direction(from, to) {
		const length = Math.hypot(to[0] - from[0], to[1] - from[1]) || 1;
		return [(to[0] - from[0]) / length, (to[1] - from[1]) / length];
	}
	const normal = ([x, y]) => [-y, x];
	const offset = (point, vector, distance) => [point[0] + vector[0] * distance, point[1] + vector[1] * distance];
	const formatPoint = ([x, y]) => `${x.toFixed(3)},${y.toFixed(3)}`;
	function arrowOutline({ from, corner, tip }) {
		const firstLeg = direction(from, corner ?? tip);
		const lastLeg = direction(corner ?? from, tip);
		const start = offset(from, firstLeg, START_GAP);
		const base = offset(tip, lastLeg, -.34);
		const firstNormal = normal(firstLeg);
		const lastNormal = normal(lastLeg);
		const half = SHAFT_WIDTH / 2;
		const left = [offset(start, firstNormal, half)];
		const right = [offset(start, firstNormal, -.11)];
		if (corner) {
			const miter = [firstNormal[0] + lastNormal[0], firstNormal[1] + lastNormal[1]];
			left.push(offset(corner, miter, half));
			right.push(offset(corner, miter, -.11));
		}
		left.push(offset(base, lastNormal, half), offset(base, lastNormal, HEAD_WIDTH / 2), tip);
		right.push(offset(base, lastNormal, -.11), offset(base, lastNormal, -.52 / 2));
		return [...left, ...right.toReversed()].map(formatPoint).join(" ");
	}

//#endregion
//#region src/shared/chess/pieces.ts
	const ROLE_LETTERS = {
		pawn: "p",
		knight: "n",
		bishop: "b",
		rook: "r",
		queen: "q",
		king: "k"
	};
	const ROLE_BY_LETTER = new Map(ROLES.map((role) => [ROLE_LETTERS[role], role]));
	/** A role from its letter, either case ("Q", "n"). */
	const roleOfLetter = (letter) => ROLE_BY_LETTER.get(letter.toLowerCase());
	const colorLetter = (color) => color === "white" ? "w" : "b";
	/** The king counts for nothing: it can't be traded. */
	const PIECE_VALUES = {
		pawn: 1,
		knight: 3,
		bishop: 3,
		rook: 5,
		queen: 9,
		king: 0
	};

//#endregion
//#region src/shared/chess/fen.ts
/**
	* The pieces of a FEN's placement field ("rnbqkbnr/pppppppp/8/…"). Crazyhouse
	* adds a `~` after a promoted piece, and its pockets in brackets: both are skipped.
	*/
	function parsePlacement(placement) {
		const board = /* @__PURE__ */ new Map();
		for (const [i, row] of placement.split("/").entries()) {
			let file = 0;
			for (const char of row) {
				if (char === "~") continue;
				if (char === "[") break;
				if (/\d/.test(char)) {
					file += Number(char);
					continue;
				}
				const role = roleOfLetter(char);
				const square = squareAt(file, 7 - i);
				if (role && square) board.set(square, {
					color: char === char.toUpperCase() ? "white" : "black",
					role
				});
				file++;
			}
		}
		return board;
	}
	/** The side to move, or null when the FEN has no such field or an unknown one. */
	function sideToMove(fen) {
		const field = fen.split(" ")[1];
		if (field === "w") return "white";
		return field === "b" ? "black" : null;
	}
	/** The side to move, white when the FEN doesn't say. */
	const fenTurn = (fen) => sideToMove(fen) ?? "white";
	function parseFen(fen) {
		const [placement = ""] = fen.split(" ");
		return {
			board: parsePlacement(placement),
			turn: fenTurn(fen)
		};
	}

//#endregion
//#region src/page/board/mate.ts
	const LABEL_DELAY_MS = 2500;
	/** The mated king's square, if the position is checkmate. */
	function matedKing(node) {
		if (!node?.san?.endsWith("#") || !node.fen) return null;
		const mated = sideToMove(node.fen) ?? "black";
		for (const [square, piece] of parseFen(node.fen).board) if (piece.role === "king" && piece.color === mated) return square;
		return null;
	}
	/**
	* Tells how far into a checkmate the board is. The label comes in after a
	* moment whether or not anything else moves, so `onLabelDue` asks for a
	* redraw then.
	*/
	function createMateClock(onLabelDue) {
		let matedNode = null;
		let since = 0;
		let timer = 0;
		return (node, king) => {
			if (!king) {
				matedNode = null;
				return "none";
			}
			if (node !== matedNode) {
				matedNode = node;
				since = Date.now();
			}
			if (Date.now() - since >= LABEL_DELAY_MS) return "label";
			clearTimeout(timer);
			timer = setTimeout(onLabelDue, since + LABEL_DELAY_MS - Date.now());
			return "badge";
		};
	}

//#endregion
//#region src/page/board/render.ts
	const MATE_ICON = trustedHtml("<svg viewBox=\"0 0 24 24\"><g fill=\"#000\"><path d=\"M3 8.5h1.5v9H3zM5.8 8.5h1.5v9H5.8zM1.5 10.6h7.3v1.5H1.5zM1.5 13.9h7.3v1.5H1.5z\"/><path d=\"M15.1 2h1.8v5h-1.8zM13.5 3.3h5v1.7h-5z\"/><path d=\"M9.6 12.6c0-2.5 2.6-3.6 4.6-2.3.8.5 1.4 1.3 1.8 2.1.4-.8 1-1.6 1.8-2.1 2-1.3 4.6-.2 4.6 2.3 0 2.6-2.2 4.8-2.9 5.5h-7c-.7-.7-2.9-2.9-2.9-5.5z\"/><rect x=\"12.1\" y=\"18.8\" width=\"7.8\" height=\"2.4\" rx=\"0.8\"/></g></svg>");
	/** The marked squares, for the layer under the pieces. */
	const fillsMarkup = (fills) => html`${fills.map(({ at: [x, y], color, opacity }) => html`<rect x="${x - .5}" y="${y - .5}" width="1" height="1" fill="rgba(${color},${opacity})"/>`)}`;
	function arrowsMarkup(arrows) {
		if (arrows.length === 0) return html``;
		const polygons = arrows.map(({ from, to, color, opacity }) => html`<polygon points="${arrowOutline(arrowPath(from, to))}" fill="rgba(${color},${opacity})"/>`);
		return html`<svg class="cdc-shapes__arrows" viewBox="0 0 8 8">${polygons}</svg>`;
	}
	function mateMarkup({ king, phase, whiteAtBottom, label }) {
		const [column, row] = squareOnScreen(king, whiteAtBottom);
		const x = column * 12.5;
		const y = row * 12.5;
		if (phase === "badge") return html`<div class="cdc-mate__badge" style="left:${x + 12.5}%;top:${y}%">${MATE_ICON}</div>`;
		return html`<div class="cdc-mate__square" style="left:${x}%;top:${y}%"><div class="cdc-mate__icon">${MATE_ICON}</div></div><div class="cdc-mate__label" style="left:${x + 6.25}%;top:${y + 1.1}%">${label}</div>`;
	}

//#endregion
//#region src/page/board/review-arrows.ts
	let arrows = [];
	const listeners = /* @__PURE__ */ new Set();
	const reviewArrows = () => arrows;
	function setReviewArrows(next) {
		arrows = next;
		for (const listener of listeners) listener();
	}
	function onReviewArrowsChange(listener) {
		listeners.add(listener);
		return () => listeners.delete(listener);
	}

//#endregion
//#region src/page/board/svg-shapes.ts
	const DEFAULT_VIEW_BOX = "-4 -4 8 8";
	const opacityOf = (element) => Number(element.getAttribute("opacity") ?? 1) < .7 ? .5 : .8;
	const isBeingDrawn = (element) => (element.parentElement?.getAttribute("cgHash") ?? "").split(",")[2] === "true";
	function readShapes(svg, { reviewing }) {
		const viewBox = svg.getAttribute("viewBox") ?? "";
		const [originX = 0, originY = 0] = (viewBox === "" ? DEFAULT_VIEW_BOX : viewBox).split(/\s+/).map(Number);
		const center = (element, xName, yName) => [Math.floor(Number(element.getAttribute(xName)) - originX) + .5, Math.floor(Number(element.getAttribute(yName)) - originY) + .5];
		const isEngineShape = (element) => reviewing && opacityOf(element) < .8;
		return {
			fills: queryAll(svg, "circle", Element).filter((circle) => !isEngineShape(circle)).map((circle) => ({
				at: center(circle, "cx", "cy"),
				color: squareColor(circle.getAttribute("stroke")),
				opacity: opacityOf(circle)
			})),
			arrows: queryAll(svg, "line", Element).filter((line) => !isBeingDrawn(line) && !isEngineShape(line)).map((line) => ({
				from: center(line, "x1", "y1"),
				to: center(line, "x2", "y2"),
				color: arrowColor(line.getAttribute("stroke")),
				opacity: opacityOf(line)
			}))
		};
	}

//#endregion
//#region src/page/board/draw.ts
	function reviewArrow({ orig, dest, brush }, whiteAtBottom) {
		const engine = brush === "engine";
		return {
			from: squareCenter(orig, whiteAtBottom),
			to: squareCenter(dest, whiteAtBottom),
			color: engine ? ENGINE_COLOR : REVIEW_COLOR,
			opacity: engine ? .5 : .8
		};
	}
	const isReviewing = (root) => root.classList.contains("cdc-review-moves") || root.classList.contains("cdc-review-summary");
	/** Returns the draw: cheap when nothing changed, as it runs on most mutations. */
	function createShapeDrawer({ mateLabel, redraw }) {
		const layer = createElement("div", { id: "cdc-shapes" });
		const marks = createSvgElement("svg", {
			class: "cdc-marks",
			viewBox: "0 0 8 8"
		});
		const matePhase = createMateClock(redraw);
		let drawn = null;
		return () => {
			const container = queryOne(document, "main .main-board cg-container", Element);
			const svg = container && queryOne(container, "svg.cg-shapes", Element);
			if (!container || !svg) return;
			if (marks.parentNode !== container) container.append(marks);
			if (layer.parentNode !== container) container.append(layer);
			const root = document.documentElement;
			root.classList.toggle("cdc-shapes", true);
			const wrap = container.closest(".cg-wrap");
			const whiteAtBottom = !wrap || wrapOrientation(wrap) === "white";
			const { fills, arrows } = readShapes(svg, { reviewing: isReviewing(root) });
			arrows.push(...reviewArrows().map((arrow) => reviewArrow(arrow, whiteAtBottom)));
			const node = currentNode();
			const king = matedKing(node);
			const phase = matePhase(node, king);
			root.classList.toggle("cdc-mate", king !== null);
			const mate = king && phase !== "none" ? mateMarkup({
				king,
				phase,
				whiteAtBottom,
				label: mateLabel
			}) : null;
			const under = fillsMarkup(fills);
			const over = html`${arrowsMarkup(arrows)}${mate}`;
			const markup = `${under.value}\n${over.value}`;
			if (markup === drawn) return;
			drawn = markup;
			setHtml(marks, under);
			setHtml(layer, over);
		};
	}

//#endregion
//#region src/page/board/index.ts
	const mayChangeShapes = (record) => record.type === "childList" || record.target instanceof Element && record.target.classList.contains("cg-wrap");
	function start$1() {
		const mateLabel = isFrench() ? "Échec et mat" : "Checkmate";
		const redraw = oncePerFrame(createShapeDrawer({
			mateLabel,
			redraw: () => redraw()
		}));
		new MutationObserver((records) => {
			if (records.some(mayChangeShapes)) redraw();
		}).observe(document, {
			childList: true,
			subtree: true,
			attributes: true,
			attributeFilter: ["class"]
		});
		onReviewArrowsChange(redraw);
		redraw();
	}
	const shapes = {
		name: "board shapes",
		start: start$1
	};

//#endregion
//#region src/shared/math.ts
/** `value`, kept between `low` and `high` (`low` wins if they cross). */
	const clamp = (value, low, high) => Math.max(low, Math.min(high, value));
	/** Rounds to a tenth: precise enough for a pixel coordinate, and short in markup. */
	const roundTenth = (value) => Math.round(value * 10) / 10;

//#endregion
//#region src/page/review/evaluation/score.ts
	const RecordFields = {
		whiteWinChance: number$1(),
		secondLineWinChance: nullable(number$1()),
		best: nullable(string())
	};
	/** What the review knows of a position, from White's view (the cache's format is stored.ts). */
	const PositionRecordSchema = union([object({
		cp: number$1(),
		...RecordFields
	}), object({
		mate: number$1(),
		...RecordFields
	})]);
	/** Lichess's win probability curve, from White's centipawns. */
	const winPercent = (cp) => 50 + 50 * (2 / (1 + Math.exp(-.00368208 * cp)) - 1);
	/** A win probability from White's view, turned to `color`'s. */
	const forColor = (whiteWin, color) => color === "white" ? whiteWin : 100 - whiteWin;
	/** Lichess's accuracy of a move, from the win probability it lost. */
	const moveAccuracy = (loss) => clamp(103.1668 * Math.exp(-.04354 * loss) - 3.1669, 0, 100);

//#endregion
//#region src/page/review/engine/record.ts
	function whiteScore(line, whiteToMove) {
		const sign = whiteToMove ? 1 : -1;
		if ("mate" in line) {
			if (line.mate === 0) return {
				mate: 0,
				whiteWinChance: whiteToMove ? 0 : 100
			};
			const mate = line.mate * sign;
			return {
				mate,
				whiteWinChance: mate > 0 ? 100 : 0
			};
		}
		const cp = line.cp * sign;
		return {
			cp,
			whiteWinChance: winPercent(cp)
		};
	}
	/** One position's engine result, turned into a record from White's view. */
	function toRecord(fen, result) {
		const whiteToMove = fenTurn(fen) === "white";
		const [first, second] = result.lines;
		const head = first?.pv[0];
		const best = head === void 0 || head === "" ? null : head;
		const secondLineWinChance = second ? whiteScore(second, whiteToMove).whiteWinChance : null;
		const score = first ? whiteScore(first, whiteToMove) : {
			cp: 0,
			whiteWinChance: 50
		};
		const { whiteWinChance } = score;
		return "mate" in score ? {
			mate: score.mate,
			whiteWinChance,
			secondLineWinChance,
			best
		} : {
			cp: score.cp,
			whiteWinChance,
			secondLineWinChance,
			best
		};
	}

//#endregion
//#region src/page/review/engine/settings.ts
	const STOCKFISH_BUILD = {
		root: "npm/stockfish-web",
		script: "sf_19_smallnet.js"
	};
	/** What verdicts are made from. */
	const FULL_SEARCH = {
		depth: 16,
		movetime: 1500
	};
	/** The graph's first draft: enough to show the game's trend within seconds. */
	const QUICK_SEARCH = {
		depth: 12,
		movetime: 500
	};

//#endregion
//#region src/page/lichess/assets.ts
	const AssetOptionsSchema = object({ documentOrigin: boolean() });
	const SiteAssetsSchema = object({ asset: object({ url: _function({
		input: [string(), optional(AssetOptionsSchema)],
		output: unknown()
	}) }) });
	const hasAssets = createGuard(SiteAssetsSchema);
	/** The URL of one of Lichess's assets; throws on a page without the helper. */
	function assetUrl(path, options) {
		const site = readSite();
		if (!hasAssets(site)) throw new Error("Lichess’s asset helper is missing");
		const url = options ? site.asset.url(path, options) : site.asset.url(path);
		if (typeof url !== "string") throw new Error("Lichess’s asset helper returned no URL");
		return url;
	}

//#endregion
//#region src/page/review/engine/uci.ts
	const SCORED = / score /;
	const BOUND = / (lower|upper)bound/;
	function parseScore(text, pv) {
		const cp = / score cp (-?\d+)/.exec(text)?.[1];
		if (cp !== void 0) return {
			cp: Number(cp),
			pv
		};
		const mate = / score mate (-?\d+)/.exec(text)?.[1];
		return mate === void 0 ? null : {
			mate: Number(mate),
			pv
		};
	}
	/** Reads one line of engine output; null for anything the review ignores. */
	function parseUciOutput(text) {
		if (text.startsWith("bestmove")) return { kind: "bestmove" };
		if (!text.startsWith("info") || !SCORED.test(text) || BOUND.test(text)) return null;
		const slot = Number(/ multipv (\d+)/.exec(text)?.[1] ?? 1) - 1;
		const line = parseScore(text, (/ pv (.+)$/.exec(text)?.[1] ?? "").trim().split(/\s+/).filter(Boolean));
		return line && slot >= 0 ? {
			kind: "line",
			slot,
			line
		} : null;
	}
	/** Collects one search's lines, best first, until its `bestmove`. */
	var SearchCollector = class {
		#lines = [];
		/** Takes a line of output; returns the result once the search is over. */
		read(text) {
			const output = parseUciOutput(text);
			if (output?.kind === "bestmove") return { lines: this.#lines.filter((line) => line !== void 0) };
			if (output) this.#lines[output.slot] = output.line;
			return null;
		}
	};

//#endregion
//#region src/page/review/engine/stockfish.ts
	const FactorySchema = object({ default: _function({
		input: [unknown()],
		output: unknown()
	}) });
	const StockfishModuleSchema = object({
		uci: _function({
			input: [string()],
			output: unknown()
		}),
		getRecommendedNnue: _function({
			input: [number$1()],
			output: unknown()
		}),
		setNnueBuffer: _function({
			input: [_instanceof(Uint8Array), number$1()],
			output: unknown()
		})
	});
	const isFactory = createGuard(FactorySchema);
	const isStockfishModule = createGuard(StockfishModuleSchema);
	const INITIAL_PAGES = 1536;
	function sharedMemory() {
		for (let maximum = 32767;; maximum = Math.ceil(maximum * .75)) try {
			return new WebAssembly.Memory({
				shared: true,
				initial: INITIAL_PAGES,
				maximum
			});
		} catch (error) {
			if (maximum <= INITIAL_PAGES || !(error instanceof RangeError)) throw error;
		}
	}
	async function loadNetworks(module) {
		for (let i = 0;; i++) {
			const name = module.getRecommendedNnue(i);
			if (typeof name !== "string" || name === "") return;
			const response = await fetch(assetUrl(`lifat/nnue/${name}`));
			module.setNnueBuffer(new Uint8Array(await response.arrayBuffer()), i);
		}
	}
	async function loadModule() {
		const { root, script } = STOCKFISH_BUILD;
		const url = assetUrl(`${root}/${script}`, { documentOrigin: true });
		const wasmMemory = sharedMemory();
		const imported = await import(url);
		if (!isFactory(imported)) throw new Error("Stockfish did not load");
		const module = await imported.default({
			wasmMemory,
			locateFile: (file) => assetUrl(`${root}/${file}`),
			mainScriptUrlOrBlob: url
		});
		if (!isStockfishModule(module)) throw new Error("Stockfish has an unexpected shape");
		return module;
	}
	var Stockfish = class {
		#chess960;
		#module = null;
		#onLine = null;
		#queue = Promise.resolve();
		constructor(options) {
			this.#chess960 = options.chess960;
		}
		async boot() {
			const module = await loadModule();
			await loadNetworks(module);
			Object.assign(module, { listen: (text) => this.#onLine?.(text) });
			this.#module = module;
			const threads = clamp((navigator.hardwareConcurrency || 2) - 1, 1, 4);
			module.uci("uci");
			module.uci(`setoption name Threads value ${threads}`);
			module.uci("setoption name Hash value 64");
			module.uci("setoption name MultiPV value 2");
			if (this.#chess960) module.uci("setoption name UCI_Chess960 value true");
			module.uci("ucinewgame");
		}
		/**
		* The engine's two best lines for a position, from the side to move's view;
		* with `searchMoves`, the lines that start with those moves only.
		*/
		analyse(fen, limits = FULL_SEARCH, searchMoves = []) {
			const run = () => new Promise((resolve) => {
				const module = this.#module;
				if (!module) throw new Error("Stockfish is not booted");
				const collector = new SearchCollector();
				this.#onLine = (text) => {
					const result = collector.read(text);
					if (!result) return;
					this.#onLine = null;
					resolve(result);
				};
				module.uci(`position fen ${fen}`);
				const only = searchMoves.length > 0 ? ` searchmoves ${searchMoves.join(" ")}` : "";
				module.uci(`go depth ${limits.depth} movetime ${limits.movetime}${only}`);
			});
			const search = this.#queue.then(run);
			this.#queue = search;
			return search;
		}
	};

//#endregion
//#region src/page/review/engine-pool.ts
/**
	* One engine for the page, booted once: the game's analysis and the moves
	* played off it share it, one position at a time. A failed boot stays failed.
	*/
	function engineFor(session, analysis) {
		session.engine ??= (async () => {
			const engine = new Stockfish({ chess960: analysis.chess960 });
			await engine.boot();
			return engine;
		})();
		return session.engine;
	}

//#endregion
//#region src/page/review/evaluation/stored.ts
	const StoredFields = {
		wp: number$1(),
		wp2: nullable(number$1()),
		best: nullable(string())
	};
	const StoredRecordSchema = union([object({
		cp: number$1(),
		...StoredFields
	}), object({
		mate: number$1(),
		...StoredFields
	})]);
	function decode(stored) {
		const fields = {
			whiteWinChance: stored.wp,
			secondLineWinChance: stored.wp2,
			best: stored.best
		};
		return "mate" in stored ? {
			mate: stored.mate,
			...fields
		} : {
			cp: stored.cp,
			...fields
		};
	}
	function encode(record) {
		const fields = {
			wp: record.whiteWinChance,
			wp2: record.secondLineWinChance,
			best: record.best
		};
		return "mate" in record ? {
			mate: record.mate,
			...fields
		} : {
			cp: record.cp,
			...fields
		};
	}
	/** Reads a stored record as the review's own; `z.encode` writes one back. */
	const StoredRecordCodec = codec(StoredRecordSchema, PositionRecordSchema, {
		decode,
		encode
	});

//#endregion
//#region src/page/review/game/cache.ts
/** Bump to drop every cached review, when the records' meaning changes. */
	const CACHE_VERSION = 1;
	const CachedSchema = array(StoredRecordCodec);
	const WrittenSchema = array(optional(StoredRecordCodec));
	const cacheKey = (gameId, positions) => StorageKey.reviewCache(gameId, positions, CACHE_VERSION);
	function readCachedRecords(gameId, positions) {
		const records = readStoredJson(cacheKey(gameId, positions), CachedSchema);
		return records?.length === positions ? records : null;
	}
	function cacheRecords(gameId, positions, records) {
		writeStoredJson(cacheKey(gameId, positions), encode$1(WrittenSchema, [...records]));
	}

//#endregion
//#region src/page/review/chess/material.ts
	const ATTACKER_VALUES = {
		...PIECE_VALUES,
		king: 100
	};
	/** The values of `by`'s pieces attacking `target`, pins ignored. */
	const attackerValues = (board, target, by) => attackers(board, target, by).map((role) => ATTACKER_VALUES[role]);
	/** The piece on a square named in text ("e4"), if any. */
	function pieceOn(board, name) {
		const square = parseSquare(name);
		return square ? board.get(square) : void 0;
	}
	/**
	* A piece left to be won: attacked, and either undefended or attacked by
	* something cheaper.
	*/
	function isHanging(board, square, piece) {
		const hits = attackerValues(board, square, opposite(piece.color));
		if (hits.length === 0) return false;
		return Math.min(...hits) < PIECE_VALUES[piece.role] || attackers(board, square, piece.color).length === 0;
	}
	/**
	* A sound piece sacrifice: the moved piece can be taken by something cheaper,
	* or for free, and it wasn't just a trade.
	*/
	function isSacrifice(fenBefore, fenAfter, uci) {
		const before = parseFen(fenBefore).board;
		const after = parseFen(fenAfter).board;
		const dest = parseSquare(uci.slice(2, 4));
		const piece = dest ? after.get(dest) : void 0;
		if (!dest || !piece || piece.role === "pawn" || piece.role === "king") return false;
		const value = PIECE_VALUES[piece.role];
		const taken = before.get(dest);
		if ((taken ? PIECE_VALUES[taken.role] : 0) >= value) return false;
		return isHanging(after, dest, piece);
	}

//#endregion
//#region src/page/review/chess/notation.ts
/** A square's file, 0 for a to 7 for h; -1 for no square. */
	function fileIndex(name) {
		const square = parseSquare(name);
		return square ? squareCoords(square)[0] : -1;
	}
	/**
	* A readable move from UCI: piece letter, capture, destination and
	* promotion, without disambiguation or check marks.
	*/
	function uciToSan(fen, uci) {
		return uci ? sanOn(parseFen(fen).board, uci) : "";
	}
	/** `uciToSan` on a board already parsed. */
	function sanOn(board, uci) {
		const from = uci.slice(0, 2);
		const to = uci.slice(2, 4);
		const piece = pieceOn(board, from);
		if (!piece) return uci;
		const target = pieceOn(board, to);
		const towardsH = fileIndex(to) > fileIndex(from);
		if (piece.role === "king" && (Math.abs(fileIndex(from) - fileIndex(to)) >= 2 || target?.role === "rook" && target.color === piece.color)) return towardsH ? "O-O" : "O-O-O";
		const capture = target !== void 0 || piece.role === "pawn" && from[0] !== to[0];
		const promotion = uci[4] ? `=${uci[4].toUpperCase()}` : "";
		if (piece.role === "pawn") return `${capture ? `${from[0]}x` : ""}${to}${promotion}`;
		return `${ROLE_LETTERS[piece.role].toUpperCase()}${capture ? "x" : ""}${to}`;
	}
	const STANDARD_CASTLING = {
		e1h1: "e1g1",
		e1a1: "e1c1",
		e8h8: "e8g8",
		e8a8: "e8c8"
	};
	function normalizeUci(uci, chess960) {
		if (!uci || chess960) return uci;
		return STANDARD_CASTLING[uci] ?? uci;
	}

//#endregion
//#region src/page/review/engine/cloud.ts
	const CloudLineSchema = union([object({
		moves: string(),
		mate: number$1()
	}), object({
		moves: string(),
		cp: number$1()
	})]);
	const CloudEvalSchema = object({ pvs: optional(array(CloudLineSchema)) });
	/**
	* The cloud's lines as the engine's: scored from the side to move's view,
	* castling as the king's two-square step. Null when it has none (a miss).
	*/
	function fromCloud(fen, cloud) {
		if (!cloud.pvs?.length) return null;
		const sign = fenTurn(fen) === "white" ? 1 : -1;
		return { lines: cloud.pvs.map((line) => {
			const pv = line.moves.split(" ").map((uci) => normalizeUci(uci, false));
			return "mate" in line ? {
				mate: line.mate * sign,
				pv
			} : {
				cp: line.cp * sign,
				pv
			};
		}) };
	}

//#endregion
//#region src/page/review/rating/model.json
	var model_default = {
		pop: {
			"bullet": [1782, 449],
			"blitz": [1643, 438],
			"rapid": [1493, 387],
			"classical": [1641, 306]
		},
		tau: {
			"bullet": 775,
			"blitz": 550,
			"rapid": 450,
			"classical": 350
		},
		cuts: {
			"o": [
				357,
				182,
				-69,
				-284,
				-500
			],
			"t": [
				203,
				96,
				-38,
				-186,
				-346
			],
			"s": [
				225,
				80,
				-66,
				-204,
				-344
			],
			"e": [
				237,
				63,
				-78,
				-224,
				-402
			]
		},
		theta: {
			"bullet": [
				[
					[
						-.445,
						-.107,
						.012
					],
					[
						-.732,
						-.241,
						-.001
					],
					[
						-1.511,
						-.292,
						-.018
					],
					[
						-3.115,
						-.406,
						.015
					],
					[
						-7.075,
						-.027,
						-1.73
					]
				],
				[
					[
						-.248,
						-.002,
						-.009
					],
					[
						-.312,
						-.099,
						-.023
					],
					[
						-.814,
						-.237,
						-.017
					],
					[
						-1.432,
						-.389,
						-.007
					],
					[
						-2.023,
						-.615,
						.018
					]
				],
				[
					[
						-.785,
						.006,
						-.016
					],
					[
						-1.311,
						-.073,
						-.014
					],
					[
						-1.885,
						-.062,
						-.044
					],
					[
						-2.107,
						-.052,
						-.041
					],
					[
						-1.308,
						-.141,
						-.032
					]
				],
				[
					[
						-1.038,
						0,
						-.016
					],
					[
						-1.294,
						-.03,
						-.014
					],
					[
						-1.859,
						.043,
						-.051
					],
					[
						-2.954,
						.125,
						-.057
					],
					[
						-8.163,
						-.052,
						-2.036
					]
				],
				[
					[
						-.791,
						.009,
						-.004
					],
					[
						-1.218,
						-.019,
						-.02
					],
					[
						-1.203,
						-.061,
						-.03
					],
					[
						-.959,
						-.158,
						-.011
					],
					[
						-.849,
						-.326,
						.01
					]
				],
				[
					[
						-1.192,
						.026,
						-.006
					],
					[
						-1.853,
						-.084,
						.013
					],
					[
						-2.239,
						-.05,
						-.024
					],
					[
						-2.339,
						.011,
						-.047
					],
					[
						-1.458,
						-.095,
						-.032
					]
				],
				[
					[
						-.224,
						0,
						-.019
					],
					[
						-.53,
						.044,
						-.033
					],
					[
						-1.395,
						.111,
						-.047
					],
					[
						-2.887,
						.211,
						-.082
					],
					[
						-7.883,
						.001,
						-1.987
					]
				],
				[
					[
						-.29,
						-.03,
						-0
					],
					[
						-.116,
						-.086,
						-.01
					],
					[
						-.254,
						-.161,
						-.011
					],
					[
						-.654,
						-.217,
						-.014
					],
					[
						-1.248,
						-.352,
						.007
					]
				],
				[
					[
						-.621,
						-.022,
						-.015
					],
					[
						-1.129,
						-.023,
						-.03
					],
					[
						-1.899,
						-.018,
						-.026
					],
					[
						-2.64,
						.036,
						-.043
					],
					[
						-2.483,
						-.078,
						-.037
					]
				],
				[
					[
						-.958,
						.053,
						-.056
					],
					[
						-1.387,
						.088,
						-.047
					],
					[
						-2.313,
						.123,
						-.033
					],
					[
						-3.695,
						.181,
						-.014
					],
					[
						-8.557,
						-1.124,
						-3.982
					]
				],
				[
					[
						-.671,
						-.032,
						-.031
					],
					[
						-.822,
						-.097,
						-.03
					],
					[
						-1.02,
						-.131,
						-.037
					],
					[
						-1.089,
						-.225,
						-.016
					],
					[
						-1.091,
						-.275,
						.015
					]
				],
				[
					[
						-1.115,
						.028,
						-.012
					],
					[
						-1.936,
						-.002,
						-.014
					],
					[
						-2.767,
						.027,
						-.032
					],
					[
						-3.43,
						.029,
						-.038
					],
					[
						-2.462,
						-.041,
						-.004
					]
				]
			],
			"blitz": [
				[
					[
						-.626,
						-.131,
						.013
					],
					[
						-.834,
						-.185,
						.034
					],
					[
						-1.521,
						-.217,
						.026
					],
					[
						-3.117,
						-.155,
						.132
					],
					[
						-6.842,
						.268,
						-1.58
					]
				],
				[
					[
						-.28,
						-.012,
						-.028
					],
					[
						-.407,
						-.16,
						-.062
					],
					[
						-.985,
						-.381,
						-.064
					],
					[
						-1.692,
						-.613,
						-.052
					],
					[
						-2.532,
						-.944,
						-.021
					]
				],
				[
					[
						-.858,
						-.054,
						-.013
					],
					[
						-1.421,
						-.14,
						-.007
					],
					[
						-1.898,
						-.202,
						-.022
					],
					[
						-1.924,
						-.133,
						-.036
					],
					[
						-1.341,
						-.25,
						-.01
					]
				],
				[
					[
						-1.096,
						-.017,
						-.013
					],
					[
						-1.302,
						-.024,
						-.012
					],
					[
						-1.833,
						-.016,
						-.031
					],
					[
						-2.922,
						.007,
						-.04
					],
					[
						-8.28,
						-.052,
						-2.963
					]
				],
				[
					[
						-.826,
						-.018,
						-.005
					],
					[
						-1.297,
						-.09,
						-.012
					],
					[
						-1.34,
						-.167,
						-.023
					],
					[
						-1.145,
						-.278,
						-.023
					],
					[
						-1.172,
						-.52,
						-.011
					]
				],
				[
					[
						-1.119,
						.067,
						.002
					],
					[
						-1.902,
						-.031,
						.023
					],
					[
						-2.282,
						-.069,
						.003
					],
					[
						-2.343,
						-.023,
						-.019
					],
					[
						-1.572,
						-.163,
						-.028
					]
				],
				[
					[
						-.276,
						-.053,
						-.016
					],
					[
						-.469,
						-.001,
						-.008
					],
					[
						-1.206,
						.04,
						-.007
					],
					[
						-2.596,
						.103,
						-.036
					],
					[
						-8.005,
						.015,
						-1.756
					]
				],
				[
					[
						-.375,
						-.035,
						-.012
					],
					[
						-.258,
						-.128,
						-.027
					],
					[
						-.433,
						-.243,
						-.029
					],
					[
						-.843,
						-.363,
						-.036
					],
					[
						-1.519,
						-.569,
						-.031
					]
				],
				[
					[
						-.672,
						.007,
						-.014
					],
					[
						-1.155,
						-.057,
						-.031
					],
					[
						-1.828,
						-.031,
						-.005
					],
					[
						-2.47,
						.032,
						-.043
					],
					[
						-2.403,
						-.169,
						-.022
					]
				],
				[
					[
						-1.015,
						.088,
						-.063
					],
					[
						-1.366,
						.131,
						-.055
					],
					[
						-2.234,
						.165,
						-.043
					],
					[
						-3.471,
						.154,
						-.06
					],
					[
						-9.043,
						-.249,
						-3.385
					]
				],
				[
					[
						-.935,
						-.075,
						-.005
					],
					[
						-1.185,
						-.135,
						-.025
					],
					[
						-1.427,
						-.22,
						-.029
					],
					[
						-1.54,
						-.315,
						-.015
					],
					[
						-1.535,
						-.452,
						-.004
					]
				],
				[
					[
						-1.072,
						.158,
						-.04
					],
					[
						-1.991,
						.117,
						-.027
					],
					[
						-2.789,
						.089,
						-.026
					],
					[
						-3.434,
						.127,
						-.035
					],
					[
						-2.595,
						-.005,
						-.017
					]
				]
			],
			"rapid": [
				[
					[
						-.64,
						-.108,
						.029
					],
					[
						-.801,
						-.164,
						.035
					],
					[
						-1.484,
						-.216,
						.024
					],
					[
						-2.981,
						-.174,
						.11
					],
					[
						-6.842,
						.535,
						-1.547
					]
				],
				[
					[
						-.297,
						-.011,
						-.033
					],
					[
						-.424,
						-.187,
						-.056
					],
					[
						-.98,
						-.461,
						-.046
					],
					[
						-1.615,
						-.714,
						-.046
					],
					[
						-2.398,
						-1.087,
						-.03
					]
				],
				[
					[
						-.909,
						-.042,
						.031
					],
					[
						-1.516,
						-.185,
						.012
					],
					[
						-1.924,
						-.169,
						.003
					],
					[
						-1.958,
						-.173,
						-.07
					],
					[
						-1.498,
						-.301,
						.019
					]
				],
				[
					[
						-1.066,
						-.024,
						-.031
					],
					[
						-1.329,
						-.034,
						.019
					],
					[
						-1.904,
						-.037,
						.003
					],
					[
						-3.049,
						-.057,
						.014
					],
					[
						-8.444,
						.072,
						-1.827
					]
				],
				[
					[
						-.821,
						-.027,
						-.017
					],
					[
						-1.294,
						-.112,
						-.028
					],
					[
						-1.341,
						-.22,
						-.031
					],
					[
						-1.164,
						-.388,
						-.021
					],
					[
						-1.188,
						-.68,
						.021
					]
				],
				[
					[
						-1.144,
						.077,
						.005
					],
					[
						-1.97,
						-.12,
						.053
					],
					[
						-2.403,
						-.138,
						.017
					],
					[
						-2.484,
						-.084,
						-.011
					],
					[
						-1.75,
						-.261,
						-.018
					]
				],
				[
					[
						-.267,
						-.072,
						-.065
					],
					[
						-.489,
						-.011,
						-.022
					],
					[
						-1.254,
						.021,
						-.039
					],
					[
						-2.725,
						.072,
						-.028
					],
					[
						-7.918,
						.024,
						-1.796
					]
				],
				[
					[
						-.383,
						-.044,
						-.012
					],
					[
						-.262,
						-.17,
						-.048
					],
					[
						-.421,
						-.321,
						-.047
					],
					[
						-.829,
						-.475,
						-.044
					],
					[
						-1.477,
						-.75,
						-.026
					]
				],
				[
					[
						-.695,
						-.008,
						-.025
					],
					[
						-1.219,
						-.085,
						-.032
					],
					[
						-1.937,
						-.088,
						-.036
					],
					[
						-2.576,
						-.02,
						-.068
					],
					[
						-2.517,
						-.227,
						-.028
					]
				],
				[
					[
						-1.065,
						.128,
						-.084
					],
					[
						-1.418,
						.164,
						-.078
					],
					[
						-2.328,
						.176,
						-.05
					],
					[
						-3.553,
						.181,
						-.084
					],
					[
						-9.159,
						.075,
						-2.739
					]
				],
				[
					[
						-.975,
						-.089,
						-.02
					],
					[
						-1.25,
						-.158,
						-.049
					],
					[
						-1.489,
						-.266,
						-.048
					],
					[
						-1.586,
						-.386,
						-.047
					],
					[
						-1.603,
						-.602,
						.016
					]
				],
				[
					[
						-1.105,
						.218,
						-.076
					],
					[
						-2.076,
						.116,
						-.053
					],
					[
						-2.942,
						.086,
						-.026
					],
					[
						-3.581,
						.137,
						-.091
					],
					[
						-2.781,
						-.097,
						-.015
					]
				]
			],
			"classical": [
				[
					[
						-.588,
						-.2,
						.028
					],
					[
						-.648,
						-.359,
						.076
					],
					[
						-1.459,
						-.043,
						.066
					],
					[
						-2.776,
						.064,
						.139
					],
					[
						-5.019,
						.145,
						-.971
					]
				],
				[
					[
						-.316,
						-.049,
						-.03
					],
					[
						-.366,
						-.28,
						-.146
					],
					[
						-.848,
						-.651,
						-.169
					],
					[
						-1.392,
						-.949,
						-.183
					],
					[
						-2.074,
						-1.377,
						-.246
					]
				],
				[
					[
						-.831,
						-.106,
						-.017
					],
					[
						-1.383,
						-.213,
						-.06
					],
					[
						-1.981,
						-.128,
						.108
					],
					[
						-2.027,
						-.188,
						.038
					],
					[
						-1.341,
						-.617,
						-.276
					]
				],
				[
					[
						-1.014,
						.022,
						-.074
					],
					[
						-1.301,
						-.099,
						-.044
					],
					[
						-2.029,
						.059,
						.016
					],
					[
						-3.166,
						-.169,
						-.212
					],
					[
						-6.39,
						-.125,
						-1.295
					]
				],
				[
					[
						-.826,
						.038,
						-.09
					],
					[
						-1.288,
						-.196,
						.014
					],
					[
						-1.344,
						-.409,
						.013
					],
					[
						-1.075,
						-.502,
						-.091
					],
					[
						-1.07,
						-.983,
						-.061
					]
				],
				[
					[
						-1.125,
						.104,
						-.039
					],
					[
						-1.945,
						-.122,
						-.012
					],
					[
						-2.452,
						-.119,
						-.027
					],
					[
						-2.64,
						.007,
						-.123
					],
					[
						-1.87,
						-.24,
						-.126
					]
				],
				[
					[
						-.25,
						.015,
						-.078
					],
					[
						-.547,
						.01,
						-.101
					],
					[
						-1.338,
						.107,
						-.137
					],
					[
						-2.775,
						.105,
						-.106
					],
					[
						-5.912,
						-.156,
						-1.188
					]
				],
				[
					[
						-.43,
						.031,
						-.066
					],
					[
						-.255,
						-.097,
						-.14
					],
					[
						-.39,
						-.401,
						-.117
					],
					[
						-.753,
						-.623,
						-.122
					],
					[
						-1.416,
						-.913,
						-.1
					]
				],
				[
					[
						-.787,
						.069,
						-.018
					],
					[
						-1.305,
						-.126,
						-.027
					],
					[
						-2.059,
						.092,
						-.141
					],
					[
						-2.78,
						.059,
						-.02
					],
					[
						-2.618,
						-.211,
						-.052
					]
				],
				[
					[
						-1.126,
						.22,
						-.158
					],
					[
						-1.541,
						.294,
						-.083
					],
					[
						-2.51,
						.273,
						-.106
					],
					[
						-3.743,
						.096,
						-.072
					],
					[
						-7.203,
						-.318,
						-1.37
					]
				],
				[
					[
						-.956,
						.004,
						-.154
					],
					[
						-1.183,
						-.044,
						-.285
					],
					[
						-1.398,
						-.3,
						-.227
					],
					[
						-1.51,
						-.428,
						-.29
					],
					[
						-1.497,
						-.668,
						-.323
					]
				],
				[
					[
						-1.235,
						.309,
						-.066
					],
					[
						-2.288,
						.198,
						.015
					],
					[
						-3.125,
						.103,
						-.152
					],
					[
						-3.835,
						-.011,
						.013
					],
					[
						-2.936,
						-.113,
						-.231
					]
				]
			]
		}
	};

//#endregion
//#region src/page/review/rating/model.ts
	const SpeedSchema = _enum([
		"bullet",
		"blitz",
		"rapid",
		"classical"
	]);
	/** The model's phase keys: opening, tactics, strategy, endgame. */
	const PhaseKeySchema = _enum([
		"o",
		"t",
		"s",
		"e"
	]);
	const CONTEXTS = 12;
	const CoefficientsSchema = tuple([
		number$1(),
		number$1(),
		number$1()
	]);
	const RatingModelSchema = object({
		pop: record(SpeedSchema, tuple([number$1(), number$1()])),
		tau: record(SpeedSchema, number$1()),
		cuts: record(PhaseKeySchema, array(number$1())),
		theta: record(SpeedSchema, array(array(CoefficientsSchema).check(_length(5))).check(_length(CONTEXTS)))
	});
	let model = null;
	/**
	* The model, parsed the first time it's needed. A malformed model.json would
	* stop the whole review, which is why rating.test.ts parses the shipped one.
	*/
	function ratingModel() {
		model ??= RatingModelSchema.parse(model_default);
		return model;
	}

//#endregion
//#region src/page/review/rating/odds.ts
/** The ratings the likelihoods are computed over: 100 to 3200, every 10. */
	const RATING_GRID = Array.from({ length: 311 }, (_, i) => 100 + 10 * i);
	const QUADRATIC_FROM = -1.6;
	const QUADRATIC_TO = 2.2;
	function curvature(x) {
		if (x < QUADRATIC_FROM) return QUADRATIC_FROM * QUADRATIC_FROM + 2 * QUADRATIC_FROM * (x - QUADRATIC_FROM);
		if (x > QUADRATIC_TO) return QUADRATIC_TO * QUADRATIC_TO + 2 * QUADRATIC_TO * (x - QUADRATIC_TO);
		return x * x;
	}
	function logSoftmax(logits) {
		const max = Math.max(...logits);
		const sum = Math.log(logits.reduce((total, logit) => total + Math.exp(logit - max), 0)) + max;
		return logits.map((logit) => logit - sum);
	}
	const oddsBySpeed = /* @__PURE__ */ new Map();
	function bandOdds(speed) {
		const cached = oddsBySpeed.get(speed);
		if (cached) return cached;
		const odds = ratingModel().theta[speed].map((context) => RATING_GRID.map((rating) => {
			const x = (rating - 1500) / 500;
			return logSoftmax([0, ...context.map(([intercept, slope, bend]) => intercept + slope * x + bend * curvature(x))]);
		}));
		oddsBySpeed.set(speed, odds);
		return odds;
	}
	/** The mean rating of a likelihood over RATING_GRID, under a normal prior. */
	function posteriorMean(logLikelihood, mean, deviation) {
		const posterior = logLikelihood.map((value, i) => value - .5 * (((RATING_GRID[i] ?? 0) - mean) / deviation) ** 2);
		const max = Math.max(...posterior);
		let weights = 0;
		let total = 0;
		for (const [i, value] of posterior.entries()) {
			const weight = Math.exp(value - max);
			weights += weight;
			total += weight * (RATING_GRID[i] ?? 0);
		}
		return total / weights;
	}

//#endregion
//#region src/page/review/rating/phases.ts
	const PHASES = [
		"opening",
		"tactics",
		"strategy",
		"endgame"
	];
	const majorsAndMinors = (board) => [...board.values()].filter((piece) => piece.role !== "king" && piece.role !== "pawn").length;
	function backRankSparse(board) {
		let white = 0;
		let black = 0;
		for (const [square, piece] of board) {
			if (piece.color === "white" && square[1] === "1") white++;
			if (piece.color === "black" && square[1] === "8") black++;
		}
		return white < 4 || black < 4;
	}
	const none = () => 0;
	const REGION_SCORES = [
		[
			none,
			(y) => 1 + y,
			(y) => y < 6 ? 2 + (6 - y) : 0,
			(y) => y < 7 ? 3 + (7 - y) : 0,
			(y) => y < 7 ? 3 + (7 - y) : 0
		],
		[
			(y) => 1 + (8 - y),
			(y) => 5 + Math.abs(4 - y),
			(y) => 4 + (7 - y),
			(y) => 5 + (7 - y)
		],
		[
			(y) => y > 2 ? 2 + (y - 2) : 0,
			(y) => 4 + (y - 1),
			() => 7
		],
		[(y) => y > 1 ? 3 + (y - 1) : 0, (y) => 5 + (y - 1)],
		[(y) => y > 1 ? 3 + (y - 1) : 0]
	];
	const REGION = [
		[0, 0],
		[1, 0],
		[0, 1],
		[1, 1]
	];
	function regionScore(board, file, rank) {
		let white = 0;
		let black = 0;
		for (const [dx, dy] of REGION) {
			const square = squareAt(file + dx, rank + dy);
			const piece = square ? board.get(square) : void 0;
			if (piece?.color === "white") white++;
			else if (piece) black++;
		}
		return REGION_SCORES[white]?.[black]?.(rank + 1) ?? 0;
	}
	function mixedness(board) {
		let total = 0;
		for (let rank = 0; rank < 7; rank++) for (let file = 0; file < 7; file++) total += regionScore(board, file, rank);
		return total;
	}
	/** Where the middlegame and the endgame start in a game's positions. */
	function divide(fens) {
		const boards = fens.map((fen) => parseFen(fen).board);
		const middle = boards.findIndex((board) => majorsAndMinors(board) <= 10 || backRankSparse(board) || mixedness(board) > 150);
		const end = middle < 0 ? -1 : boards.findIndex((board) => majorsAndMinors(board) <= 6);
		return {
			middle: middle >= 0 && end >= 0 && middle >= end ? -1 : middle,
			end
		};
	}

//#endregion
//#region src/page/review/rating/tactical.ts
/**
	* A position with a tactic in it: the side to move is in check, the last
	* move threw away 10% or more (a chance to punish it), or a piece hangs.
	* tools/game-rating/extract.py must agree.
	*/
	function isTactical(fen, previousLoss) {
		const { board, turn } = parseFen(fen);
		if (previousLoss >= 10) return true;
		const king = [...board].find(([, piece]) => piece.role === "king" && piece.color === turn)?.[0];
		if (king && attackers(board, king, opposite(turn)).length > 0) return true;
		return [...board].some(([square, piece]) => piece.role !== "pawn" && piece.role !== "king" && isHanging(board, square, piece));
	}

//#endregion
//#region src/page/review/rating/rate-game.ts
	const SPEEDS = /* @__PURE__ */ new Map([
		["ultraBullet", "bullet"],
		["bullet", "bullet"],
		["blitz", "blitz"],
		["rapid", "rapid"],
		["classical", "classical"],
		["correspondence", "classical"]
	]);
	const PHASE_KEYS = {
		opening: "o",
		tactics: "t",
		strategy: "s",
		endgame: "e"
	};
	const LOSS_BANDS = [
		.5,
		2,
		5,
		10,
		20
	];
	const VERDICTS = [
		"best",
		"excellent",
		"good",
		"inaccuracy",
		"mistake"
	];
	function movePhase(move, previous, division) {
		const index = move.ply - 1;
		if (division.end >= 0 && index >= division.end) return "endgame";
		if (division.middle < 0 || index < division.middle) return "opening";
		const previousLoss = previous && previous.moveClass !== "book" ? previous.loss : 0;
		return isTactical(move.previousPosition.fen, previousLoss) ? "tactics" : "strategy";
	}
	function standingIndex(winChance) {
		if (winChance < 20) return 0;
		return winChance > 80 ? 2 : 1;
	}
	function scoreMoves(moves, division) {
		return moves.map((move, i) => {
			if (move.moveClass === "book") return {
				color: move.color,
				phase: "book",
				context: 0,
				band: 0
			};
			const phase = movePhase(move, moves[i - 1], division);
			const context = PHASES.indexOf(phase) * 3 + standingIndex(forColor(move.before.whiteWinChance, move.color));
			const band = LOSS_BANDS.findIndex((limit) => move.loss < limit);
			return {
				color: move.color,
				phase,
				context,
				band: band < 0 ? LOSS_BANDS.length : band
			};
		});
	}
	const knownRating = (rating) => rating === void 0 || rating === 0 ? null : rating;
	function phaseVerdict(rater, moves, anchor, phase) {
		const model = ratingModel();
		const gain = posteriorMean(rater.likelihood(moves), anchor, model.tau[rater.speed]) - anchor;
		const cut = model.cuts[PHASE_KEYS[phase]].findIndex((limit) => gain >= limit);
		return VERDICTS[cut] ?? "blunder";
	}
	function ratePlayer(rater, own, rating) {
		const played = own.filter((move) => move.phase !== "book");
		if (played.length === 0) return null;
		const model = ratingModel();
		const tau = model.tau[rater.speed];
		const [popMean, popDeviation] = model.pop[rater.speed];
		const likelihood = rater.likelihood(played);
		const estimate = rating === null ? posteriorMean(likelihood, popMean, Math.hypot(popDeviation, tau)) : posteriorMean(likelihood, rating, tau);
		const anchor = rating ?? estimate;
		const verdict = (phase) => {
			const inPhase = played.filter((move) => move.phase === phase);
			if (inPhase.length > 0) return phaseVerdict(rater, inPhase, anchor, phase);
			return phase === "opening" && own.some((move) => move.phase === "book") ? "book" : null;
		};
		const phases = {
			opening: verdict("opening"),
			tactics: verdict("tactics"),
			strategy: verdict("strategy"),
			endgame: verdict("endgame")
		};
		return {
			elo: Math.round(estimate / 50) * 50,
			phases
		};
	}
	/** Each player's game rating and phase verdicts, once every move is judged. */
	function rateGame(input) {
		const speed = SPEEDS.get(input.speed ?? "") ?? "blitz";
		const odds = bandOdds(speed);
		const scored = scoreMoves(input.moves, divide(input.fens));
		const likelihood = (moves) => RATING_GRID.map((_, index) => moves.reduce((sum, move) => sum + (odds[move.context]?.[index]?.[move.band] ?? 0), 0));
		const rater = {
			likelihood,
			speed
		};
		const rate = (color) => ratePlayer(rater, scored.filter((move) => move.color === color), knownRating(input.ratings[color]));
		return {
			white: rate("white"),
			black: rate("black")
		};
	}

//#endregion
//#region src/page/review/classes/classes.ts
	const MOVE_CLASSES = [
		"brilliant",
		"great",
		"book",
		"best",
		"excellent",
		"good",
		"inaccuracy",
		"mistake",
		"miss",
		"blunder"
	];
	const CLASS_COLORS = {
		brilliant: "#8be9fd",
		great: "#82aaff",
		book: "#8f9bd4",
		best: "#50fa7b",
		excellent: "#50fa7b",
		good: "#6ee7a0",
		inaccuracy: "#f1fa8c",
		mistake: "#ffb86c",
		miss: "#ff79c6",
		blunder: "#ff5555"
	};
	/** From best to worst: a mate verdict only ever makes a move's class worse. Book has no rank. */
	const RANK = [
		"brilliant",
		"great",
		"best",
		"excellent",
		"good",
		"inaccuracy",
		"mistake",
		"miss",
		"blunder"
	];
	const COUNTED = [
		"brilliant",
		"great",
		"best"
	];
	/** The summary's rows before its chevron is opened; a brilliant move joins them when there is one. */
	const SUMMARY_ROWS = /* @__PURE__ */ new Set([
		"great",
		"best",
		"excellent",
		"mistake",
		"miss",
		"blunder"
	]);
	/** The classes marked on the evaluation graph. */
	const GRAPH_DOTS = /* @__PURE__ */ new Set([
		"brilliant",
		"great",
		"inaccuracy",
		"mistake",
		"miss",
		"blunder"
	]);
	/** Move list badges; book only shows on the last book move. */
	const LIST_BADGES = /* @__PURE__ */ new Set([...GRAPH_DOTS, "book"]);
	/** Moves that need no correction: no best-move arrow or button. */
	const GOOD = /* @__PURE__ */ new Set([
		"brilliant",
		"great",
		"best",
		"book"
	]);
	/** The moves the coach corrects: everything below good. */
	const isError = (moveClass) => !GOOD.has(moveClass) && moveClass !== "excellent" && moveClass !== "good";
	const MOODS = {
		brilliant: "delight",
		great: "delight",
		best: "happy",
		excellent: "happy",
		inaccuracy: "doubt",
		mistake: "worry",
		miss: "worry",
		blunder: "shock"
	};
	/** How the coach's face reacts to a verdict; null keeps it neutral. */
	const classMood = (moveClass) => MOODS[moveClass] ?? null;

//#endregion
//#region src/page/review/judge/mate.ts
/**
	* The longest mate our depth gets exact: a longer one comes out long (a mate
	* in 8 as a mate in 12), so only a move's short side is trusted.
	*/
	const SURE_MATE = 5;
	const mateOf = (record) => "mate" in record ? record.mate : void 0;
	const mateLost = (own) => own > 0 ? Infinity : 0;
	function slowerMate(movesLost) {
		if (movesLost <= 0) return null;
		if (movesLost <= 2) return "excellent";
		return movesLost <= 5 ? "good" : "inaccuracy";
	}
	/**
	* The verdict a move deserves from mate distances, which the win probability
	* can't see (a slower mate is 100% all the same). The winner of a sure mate
	* is judged by the moves given away; the loser, when a sure mate comes
	* clearly sooner, by how soon. Never worse than an inaccuracy: the result
	* stays the same.
	*/
	function mateVerdict(before, after, color) {
		const mateBefore = mateOf(before);
		const mateAfter = mateOf(after);
		if (!mateBefore || mateAfter === 0) return null;
		const sign = color === "white" ? 1 : -1;
		const own = mateBefore * sign;
		const ownAfter = mateAfter === void 0 ? mateLost(own) : mateAfter * sign;
		if (own > 0 && own <= 5 && ownAfter > 0) return slowerMate(ownAfter - (own - 1));
		if (own < 0 && ownAfter < 0 && -ownAfter <= 5 && ownAfter - own >= 3) return -ownAfter <= 2 ? "inaccuracy" : "good";
		return null;
	}

//#endregion
//#region src/page/review/judge/judge.ts
	function lossClass(loss) {
		if (loss < 2) return "excellent";
		if (loss < 5) return "good";
		if (loss < 10) return "inaccuracy";
		return loss < 20 ? "mistake" : "blunder";
	}
	function topClass(input, { before, after, loss, second }) {
		const { previousPosition, position } = input;
		if (after >= 50 && before < 95 && loss < 2 && isSacrifice(previousPosition.fen, position.fen, position.uci)) return "brilliant";
		if (second !== null && before - second >= 15 && before < 97 && after > 25) return "great";
		return "best";
	}
	function baseClass(input, standing, isBest) {
		if (input.book) return "book";
		if (isBest || standing.loss < .5) return topClass(input, standing);
		const moveClass = lossClass(standing.loss);
		const punishable = (input.previousMove?.loss ?? 0) >= 10 && standing.before >= 60;
		return (moveClass === "mistake" || moveClass === "blunder") && punishable ? "miss" : moveClass;
	}
	/** Judges one move from the engine's records of the positions before and after it. */
	function judge(input) {
		const { previousPosition, position, before: recordBefore, after: recordAfter } = input;
		const color = fenTurn(previousPosition.fen);
		const before = forColor(recordBefore.whiteWinChance, color);
		const after = forColor(recordAfter.whiteWinChance, color);
		const loss = Math.max(0, before - after);
		const second = recordBefore.secondLineWinChance === null ? null : forColor(recordBefore.secondLineWinChance, color);
		const isBest = normalizeUci(position.uci, input.chess960) === recordBefore.best;
		let moveClass = baseClass(input, {
			before,
			after,
			loss,
			second
		}, isBest);
		const mated = isBest || input.book ? null : mateVerdict(recordBefore, recordAfter, color);
		if (mated && RANK.indexOf(moveClass) < RANK.indexOf(mated)) moveClass = mated;
		return {
			ply: position.ply,
			san: position.san,
			uci: position.uci,
			color,
			moveClass,
			loss,
			slower: mated !== null && moveClass === mated,
			accuracy: moveClass === "book" ? 100 : moveAccuracy(loss),
			best: recordBefore.best,
			bestSan: uciToSan(previousPosition.fen, recordBefore.best),
			before: recordBefore,
			after: recordAfter,
			position,
			previousPosition,
			previousMove: input.previousMove ?? null
		};
	}

//#endregion
//#region src/page/review/judge/summary.ts
/**
	* A player's accuracy: the mean of the arithmetic and harmonic means of
	* their moves', so a few bad moves weigh more than an average would give.
	*/
	function playerAccuracy(moves, color) {
		const accuracies = moves.filter((move) => move.color === color).map((move) => move.accuracy);
		if (accuracies.length === 0) return null;
		return (accuracies.reduce((sum, accuracy) => sum + accuracy, 0) / accuracies.length + accuracies.length / accuracies.reduce((sum, accuracy) => sum + 1 / Math.max(accuracy, 1), 0)) / 2;
	}
	/** How many moves of each class each player made. */
	function classCounts(moves) {
		const counts = {
			white: {},
			black: {}
		};
		for (const { color, moveClass } of moves) counts[color][moveClass] = (counts[color][moveClass] ?? 0) + 1;
		return counts;
	}

//#endregion
//#region src/page/review/judge/types.ts
/** A position reached by a move: every one but the start. */
	const isPlayed = (position) => position.uci !== void 0 && position.san !== void 0;

//#endregion
//#region src/page/review/game/build.ts
/** The move to position `index`, its ply being that index. */
	function judgeIndex(input, { index, before, after, previousMove }) {
		const previousPosition = input.nodes[index - 1];
		const position = input.nodes[index];
		if (!previousPosition || !position || !isPlayed(position) || !before || !after) return void 0;
		return {
			...judge({
				previousPosition,
				position,
				before,
				after,
				previousMove,
				book: index <= input.bookPly,
				chess960: input.chess960
			}),
			ply: index
		};
	}
	/**
	* Judges every move whose positions are in. A move needs the positions before
	* and after it, and also the one before those: a move that fails to punish
	* the opponent's error is a miss, so the opponent's move is judged with it.
	*/
	function judgeMainline(input) {
		const { nodes, deep, moves } = input;
		const at = (index, previousMove) => judgeIndex(input, {
			index,
			before: deep[index - 1],
			after: deep[index],
			previousMove
		});
		for (let i = 1; i < nodes.length; i++) {
			if (moves[i - 1] || !deep[i - 1] || !deep[i] || i >= 2 && !deep[i - 2]) continue;
			moves[i - 1] = at(i, i >= 2 ? moves[i - 2] ?? at(i - 1) : void 0);
		}
		for (let k = 1; k < moves.length; k++) {
			const move = moves[k];
			const previousMove = moves[k - 1];
			if (move && previousMove && move.previousMove !== previousMove) moves[k] = {
				...move,
				previousMove
			};
		}
	}
	/**
	* The moves at full depth, and a draft from the quick pass (or the server
	* analysis) for the others: it stands in on the graph, the move list, the
	* counts and the accuracy until the full depth's verdict comes.
	*/
	function draftMoves(input) {
		const { nodes, deep, rough, moves } = input;
		const record = (index) => deep[index] ?? rough[index];
		const draft = [];
		for (let i = 1; i < nodes.length; i++) {
			const judged = moves[i - 1];
			const before = record(i - 1);
			const after = record(i);
			draft[i - 1] = judged || !before || !after ? judged : judgeIndex(input, {
				index: i,
				before,
				after,
				previousMove: draft[i - 2]
			});
		}
		return draft;
	}
	function buildReview(input) {
		judgeMainline(input);
		const { nodes, deep, rough, moves } = input;
		const draft = draftMoves(input);
		const judged = draft.filter((move) => move !== void 0);
		const judgedMoves = moves.filter((move) => move !== void 0);
		const complete = judgedMoves.length === nodes.length - 1;
		return {
			moves,
			draft,
			total: nodes.length,
			complete,
			positions: nodes.map((_, i) => deep[i] ?? rough[i] ?? null),
			accuracy: {
				white: playerAccuracy(judged, "white"),
				black: playerAccuracy(judged, "black")
			},
			counts: classCounts(judged),
			rating: complete ? input.previous?.rating ?? input.rate(judgedMoves) : null
		};
	}

//#endregion
//#region src/page/review/game/work.ts
/** Takes a full-depth record; the moves played off the game are judged from it too. */
	function setDeep(session, index, record) {
		const { work, live } = session;
		if (work.deep[index]) return;
		work.deep[index] = record;
		const node = work.nodes[index];
		if (node) live.evals.set(node.fen, record);
		live.judged.clear();
	}
	/**
	* Records the game's book moves for the moves played off it, so the masters
	* database isn't asked about them.
	*/
	function seedBooks(session, analysis) {
		const { live, work, view } = session;
		const nodes = analysis.mainline;
		const { bookPly } = work;
		for (let i = 1; i <= bookPly && i < nodes.length; i++) {
			const node = nodes[i];
			if (node) live.books.set(node.fen, {
				book: true,
				name: i === bookPly ? view.openingName : "",
				eco: ""
			});
		}
		const out = nodes[bookPly + 1];
		if (out) live.books.set(out.fen, {
			book: false,
			name: "",
			eco: ""
		});
		live.judged.clear();
	}
	function rate(analysis, moves) {
		const players = analysis.players();
		return rateGame({
			speed: analysis.data?.game.speed,
			fens: analysis.mainline.map((node) => node.fen),
			moves,
			ratings: {
				white: players.white?.rating,
				black: players.black?.rating
			}
		});
	}
	/** Judges what's newly in and rebuilds the review from what's known. */
	function refresh(session, analysis) {
		const { work, view } = session;
		const review = buildReview({
			...work,
			chess960: analysis.chess960,
			previous: view.review,
			rate: (moves) => rate(analysis, moves)
		});
		view.review = review;
		view.progress = work.deep.filter(Boolean).length / work.nodes.length;
		view.version++;
		if (review.complete) view.revealed.add("summary");
	}

//#endregion
//#region src/page/review/game/cloud-lookup.ts
	const MISSES = 3;
	const TIMEOUT_MS = 5e3;
	const cloudUrl = (fen) => `/api/cloud-eval?fen=${encodeURIComponent(fen)}&multiPv=2`;
	async function lookUp$1(session, analysis, index) {
		const fen = session.work.nodes[index]?.fen ?? "";
		const response = await fetch(cloudUrl(fen), {
			headers: { Accept: "application/json" },
			signal: AbortSignal.timeout(TIMEOUT_MS)
		});
		if (response.status === 404) return "miss";
		if (!response.ok) return "stop";
		const cloud = CloudEvalSchema.safeParse(await response.json());
		if (!cloud.success) return "stop";
		const result = fromCloud(fen, cloud.data);
		if (!result) return "miss";
		setDeep(session, index, toRecord(fen, result));
		refresh(session, analysis);
		return "found";
	}
	async function lookUpCloud(session, analysis) {
		const { work } = session;
		let misses = 0;
		for (let i = 0; i < work.nodes.length && misses < MISSES; i++) {
			work.cloudAt = i;
			if (work.deep[i]) continue;
			let answer;
			try {
				answer = await lookUp$1(session, analysis, i);
			} catch {
				answer = "stop";
			}
			if (answer === "stop") break;
			misses = answer === "miss" ? misses + 1 : 0;
		}
		work.cloudAt = Infinity;
	}

//#endregion
//#region src/page/review/game/export.ts
	const GameExportSchema = object({
		opening: lenient(object({
			ply: lenient(number$1()),
			name: lenient(string())
		})),
		analysis: lenient(array(object({
			mate: lenient(number$1()),
			eval: lenient(number$1())
		})))
	});
	const exportUrl = (gameId) => `/game/export/${gameId}?opening=true&moves=false&clocks=false&evals=true`;
	/** Reads the export's text; null when it isn't one (Lichess's error page). */
	function readExport(text, positions) {
		const parsed = parseJson(text, GameExportSchema);
		if (!parsed) return null;
		const rough = [];
		for (const [i, entry] of (parsed.analysis ?? []).entries()) {
			if (i + 1 >= positions) continue;
			if (entry.mate !== void 0) rough[i + 1] = {
				mate: entry.mate,
				whiteWinChance: entry.mate > 0 ? 100 : 0,
				secondLineWinChance: null,
				best: null
			};
			else if (entry.eval !== void 0) rough[i + 1] = {
				cp: entry.eval,
				whiteWinChance: winPercent(entry.eval),
				secondLineWinChance: null,
				best: null
			};
		}
		return {
			bookPly: parsed.opening?.ply ?? 0,
			openingName: parsed.opening?.name ?? "",
			rough
		};
	}
	async function fetchExport(gameId, positions) {
		return readExport(await (await fetch(exportUrl(gameId), { headers: { Accept: "application/json" } })).text(), positions);
	}

//#endregion
//#region src/page/review/game/analyse-game.ts
	const CLOUD_AHEAD = 3;
	/**
	* The next position for the engine. First those the move on the board is
	* judged from (its position, the one before, the one before that for a
	* miss) and the next move's; then a quick pass over the game for the graph;
	* then the rest at full depth, from the start.
	*/
	function nextJob({ work, mode, analysis }) {
		const { nodes, deep, rough, cloudAt } = work;
		if (mode === "moves") {
			const urgent = analysis.nodeList.slice(-3).filter((node) => nodes[node.ply] === node).map((node) => node.ply).toReversed();
			if (analysis.onMainline) urgent.push(analysis.node.ply + 1);
			const index = urgent.find((i) => i >= 0 && i < nodes.length && !deep[i]);
			if (index !== void 0) return {
				index,
				deep: true
			};
		}
		const cloudSoon = (i) => i >= cloudAt && i <= cloudAt + CLOUD_AHEAD;
		for (let i = 0; i < nodes.length; i++) if (!deep[i] && !rough[i] && !cloudSoon(i)) return {
			index: i,
			deep: false
		};
		for (let i = 0; i < nodes.length; i++) if (!deep[i] && !cloudSoon(i)) return {
			index: i,
			deep: true
		};
		return null;
	}
	const pause = (milliseconds) => new Promise((resolve) => {
		setTimeout(resolve, milliseconds);
	});
	async function runEngine(session, analysis, engine) {
		const { work, view } = session;
		for (;;) {
			const job = nextJob({
				work,
				mode: view.mode,
				analysis
			});
			if (!job) {
				if (view.review?.complete) return;
				await pause(100);
				continue;
			}
			const fen = work.nodes[job.index]?.fen ?? "";
			const result = await engine.analyse(fen, job.deep ? FULL_SEARCH : QUICK_SEARCH);
			const record = toRecord(fen, result);
			if (job.deep) setDeep(session, job.index, record);
			else work.rough[job.index] = record;
			refresh(session, analysis);
		}
	}
	async function applyExport(session, analysis) {
		const { work, view } = session;
		try {
			const found = await fetchExport(analysis.gameId, work.nodes.length);
			if (!found) return;
			work.bookPly = found.bookPly;
			view.openingName = found.openingName;
			for (const [i, record] of found.rough.entries()) if (record) work.rough[i] = record;
		} catch {}
	}
	async function analyseGame(session, analysis) {
		const { work, view } = session;
		const gameId = analysis.gameId;
		work.nodes = analysis.mainline;
		const positions = work.nodes.length;
		await applyExport(session, analysis);
		seedBooks(session, analysis);
		for (const [i, record] of (readCachedRecords(gameId, positions) ?? []).entries()) setDeep(session, i, record);
		refresh(session, analysis);
		if (view.review?.complete) return;
		if (!analysis.chess960) lookUpCloud(session, analysis);
		let engine;
		try {
			engine = await engineFor(session, analysis);
		} catch (error) {
			console.error("[LichessDotCom] engine boot failed", error);
			view.error = session.language.ui.engineError;
			session.redraw(true);
			return;
		}
		await runEngine(session, analysis, engine);
		cacheRecords(gameId, positions, work.deep);
	}

//#endregion
//#region src/page/review/comment/tokens.ts
/** [[p:wn]]: a piece, drawn. */
	const pieceToken = ({ color, role }) => `[[p:${colorLetter(color)}${ROLE_LETTERS[role]}]]`;
	/** [[m:w:Nf3]]: a move, as a chip with its piece. */
	const moveToken = (san, color) => `[[m:${colorLetter(color)}:${san}]]`;
	/** [[s:e4]]: a square, in bold. */
	const squareToken = (square) => `[[s:${square}]]`;
	/** [[n:12.:w:Nf3]]: a move with its number, kept on one line. */
	const numberedMoveToken = (number, san, color) => `[[n:${number}:${colorLetter(color)}:${san}]]`;
	function numbered({ san, color, number }, first) {
		if (color === "white") return numberedMoveToken(`${number}.`, san, color);
		return first ? numberedMoveToken(`${number}...`, san, color) : moveToken(san, color);
	}
	/** "12. Nf3 Qd7 13. O-O" as tokens: a line, numbered as on a score sheet. */
	const lineToken = (moves) => moves.map((move, i) => numbered(move, i === 0)).join(" ");

//#endregion
//#region src/page/review/i18n/en-comment.ts
	const ROLE_NAMES$1 = {
		pawn: "pawn",
		knight: "knight",
		bishop: "bishop",
		rook: "rook",
		queen: "queen",
		king: "king"
	};
	const name = (piece) => pieceToken(piece) + ROLE_NAMES$1[piece.role];
	/** "a [knight]". */
	const indefinite$1 = (piece) => `a ${name(piece)}`;
	const side$1 = (color) => color === "white" ? "White" : "Black";
	/** "White’s": a side as a possessive. */
	const possessive = (color) => color === "white" ? "White’s" : "Black’s";
	const trajectoryEn = {
		advantages: [
			"",
			"a slight edge",
			"a clear advantage",
			"a winning position",
			"a forced mate"
		],
		mateIn: (moves) => `a mate in ${moves}`,
		stillBalanced: [
			"The game stays balanced.",
			"It’s still an even game.",
			"The balance holds."
		],
		stillAhead: ({ side: color, advantage }) => [`${side$1(color)} still has ${advantage}.`, `${side$1(color)} keeps ${advantage}.`],
		wasBalanced: (after, forMover) => `The game was balanced, ${forMover ? "and" : "but"} now ${side$1(after.side)} has ${after.advantage}.`,
		nowBalanced: (before) => `${side$1(before.side)} had ${before.advantage}, but the game is now balanced.`,
		grows: (color, from, to) => `${side$1(color)} goes from ${from} to ${to}.`,
		shrinks: (color, from, to) => `${side$1(color)} had ${from}; now it’s only ${to}.`,
		swings: (before, after) => `${side$1(before.side)} had ${before.advantage}, but now ${side$1(after.side)} has ${after.advantage}.`
	};
	const factsEn = {
		checkmate: (king) => `Checkmate: the ${king} king has nowhere to go.`,
		matedIn: (best, moves) => `${best} mated in ${moves}.`,
		heldOutLonger: (best) => `${best} held out longer.`,
		canForceMate: (color, reply) => `${side$1(color)} can now force mate, starting with ${reply}.`,
		wouldForceMate: (best, moves) => `${best} would have forced mate in ${moves}.`,
		missedPunishment: (color, best) => `${possessive(color)} last move was a mistake, and ${best} would have punished it.`,
		leftUndefended: ({ piece, square, reply }) => `The ${name(piece)} on ${square} is left undefended: ${reply} wins it.`,
		answersAndWins: (color, { piece, square, reply }) => `${side$1(color)} answers ${reply} and wins the ${name(piece)} on ${square}.`,
		strongerCapture: (best, piece) => `${best}, taking the ${name(piece)}, was stronger.`,
		morePrecise: (best) => `${best} was more precise.`,
		betterMove: (best) => `${best} was the better move.`,
		punishesAtOnce: (color) => `It punishes ${possessive(color)} mistake right away.`,
		offered: (piece, color) => `The ${name(piece)} is offered, and ${side$1(color)} can’t safely take it.`,
		keepsAdvantage: "Every other move would have let the advantage slip.",
		holdsPosition: (color) => `Every other move would have left ${side$1(color)} worse off.`,
		promotes: (piece) => `The pawn promotes to ${indefinite$1(piece)}.`,
		castles: "The king is safe, and the rook joins the game.",
		takesBack: (square) => `It takes back on ${square}.`,
		winsForFree: (piece) => `It wins ${indefinite$1(piece)} for free.`,
		winsMaterial: (won, given) => `It wins ${indefinite$1(won)} for ${indefinite$1(given)}.`,
		checkForces: (color) => `The check forces ${side$1(color)} to respond.`,
		littleMorePrecise: (best) => `${best} was a little more precise.`
	};

//#endregion
//#region src/page/review/i18n/en-remarks.ts
	const remarksEn = {
		brilliant: [
			"A sacrifice that works. Beautiful.",
			"Wow! Giving up material for a winning attack.",
			"That took courage, and it pays off.",
			"The kind of move people remember.",
			"Seeing that far ahead, impressive.",
			"Stunning. The engine agrees.",
			"Material is temporary; this idea isn’t.",
			"Few players would dare to play this."
		],
		great: [
			"The only move that holds everything together.",
			"Great find! Everything else was worse.",
			"The one good move in the position.",
			"Precise. Nothing else holds here.",
			"A critical moment, handled perfectly.",
			"Sharp eyes! This was hard to see.",
			"That’s the move a master would pick.",
			"Under pressure, the right answer."
		],
		book: [
			"A well-known opening move.",
			"Straight out of the opening books.",
			"Theory. Grandmasters play this all the time.",
			"A solid, time-tested choice.",
			"Following the main lines.",
			"Classic opening play.",
			"Still in theory. So far, so good.",
			"A move played in thousands of games."
		],
		best: [
			"Exactly what the engine wanted.",
			"The engine’s top move. Well played.",
			"Couldn’t have done better.",
			"Spot on.",
			"That’s the most accurate move.",
			"Clean and precise.",
			"Just right. Keep it up!",
			"Nothing better here.",
			"Strong and simple."
		],
		excellent: [
			"Very close to the best move.",
			"A strong move that keeps things under control.",
			"Very good. The engine barely disagrees.",
			"Almost perfect.",
			"A sensible, strong continuation.",
			"Nicely done, the position stays healthy.",
			"Good judgment here.",
			"Solid play. Keep going."
		],
		good: [
			"A decent move, but there was something better.",
			"Playable, though not the most precise.",
			"It’s fine, just a little slow.",
			"Okay, but it gives away a tiny bit.",
			"Not bad, but there was a more active idea.",
			"It works, but the position offered more.",
			"A reasonable choice.",
			"Safe, if a bit passive."
		],
		inaccuracy: [
			"Not the most accurate: some edge slips away.",
			"A small slip. There was a stronger idea.",
			"Hmm, this gives the opponent some air.",
			"Playable, but it misses the point of the position.",
			"A little imprecise. There was a better plan.",
			"This loosens the grip a little.",
			"Not a disaster, but not ideal either.",
			"A bit careless. Take a closer look."
		],
		mistake: [
			"A mistake that hands over a real advantage.",
			"Ouch, this lets the opponent back in.",
			"That’s a costly slip.",
			"This changes the evaluation a lot.",
			"Check the opponent’s replies first.",
			"The position deserved more care here.",
			"This gives the opponent a clear chance.",
			"Careful! That move has a concrete flaw."
		],
		miss: [
			"The opponent slipped, but it goes unpunished.",
			"A missed chance to take advantage.",
			"There was a much stronger punishment.",
			"The opponent’s mistake goes unpunished.",
			"That lets the opponent off the hook.",
			"So close! The chance was right there.",
			"An opportunity slips away.",
			"Always ask: what did their last move allow?"
		],
		blunder: [
			"A blunder that throws away the position.",
			"Oh no! This loses a lot.",
			"That’s a serious error.",
			"This turns the game around.",
			"Ouch. The opponent must be delighted.",
			"Check for threats before moving.",
			"This one hurts.",
			"Take a breath before each move."
		],
		mate: [
			"Checkmate! Game over.",
			"And that’s mate. Well played!",
			"Checkmate. A perfect finish.",
			"The king has nowhere to go. Mate!"
		],
		allowsMate: [
			"This allows a forced checkmate.",
			"Now there’s a mate coming against this king.",
			"Careful: the king is in a mating net now.",
			"This walks into a forced mate."
		],
		missedMate: [
			"There was a forced checkmate here!",
			"There was a mate on the board.",
			"A checkmate slipped away.",
			"Mate was available. Look for checks first!"
		],
		mating: [
			"The mating net tightens.",
			"Mate is coming. Keep going!",
			"One step closer to checkmate.",
			"No escape for the king now."
		],
		castle: [
			"Castling: king safe, rook in the game.",
			"Good time to tuck the king away.",
			"Safety first. Nice castle.",
			"The rooks can now connect."
		],
		promote: [
			"A new queen joins the fight!",
			"Promotion! That pawn went all the way.",
			"The pawn’s long journey pays off."
		],
		check: [
			"A check that keeps the initiative.",
			"Check! The opponent has to respond.",
			"Forcing play. Checks are powerful."
		],
		capture: [
			"Taking is right here.",
			"A good capture.",
			"Cashing in. Well spotted."
		],
		badCapture: [
			"This capture has a hidden downside.",
			"Not every capture is a good one.",
			"Grabbing material here is risky."
		],
		winning: [
			"This is winning. Stay focused.",
			"The position is winning now.",
			"Now just convert calmly."
		],
		losing: ["The position is now very hard to hold.", "This leaves a losing position."],
		earlyQueen: ["Bringing the queen out this early is risky.", "The queen is out early and will get chased."],
		earlyKing: ["Moving the king this early costs castling.", "The king would rather stay safe."]
	};

//#endregion
//#region src/page/review/i18n/en.ts
	const CLASS_LABELS = {
		brilliant: "Brilliant",
		great: "Great",
		book: "Book",
		best: "Best",
		excellent: "Excellent",
		good: "Good",
		inaccuracy: "Inaccuracy",
		mistake: "Mistake",
		miss: "Miss",
		blunder: "Blunder"
	};
	const en = {
		ui: {
			review: "Game Review",
			start: "Start Review",
			next: "Next",
			explain: "Explain",
			best: "Best",
			analysing: "Analyzing game…",
			players: "Players",
			accuracy: "Accuracy",
			anonymous: "Anonymous",
			close: "Close review",
			back: "Back",
			coach: "Change coach",
			intro: "Let's review this game!",
			engineError: "The engine failed to start.",
			liveIntro: "Play a move and I’ll tell you what I think.",
			thinking: "Let me look at this move…",
			startPosition: "Starting position",
			more: "Show all moves",
			less: "Show less",
			gameRating: "Game Rating",
			gameRatingTip: "An estimate of a player’s rating based on a single game.",
			phases: {
				opening: "Opening",
				tactics: "Tactics",
				strategy: "Strategy",
				endgame: "Endgame"
			},
			bestWas: (move) => `${move} was best.`,
			lines: {
				best: (line) => `Best was ${line}.`,
				allows: (move, line) => `${move} allows ${line}.`,
				show: "Show line"
			}
		},
		classLabels: CLASS_LABELS,
		classSentences: {
			brilliant: "{m} is brilliant!",
			great: "{m} is a great move",
			book: "{m} is a book move",
			best: "{m} is best",
			excellent: "{m} is excellent",
			good: "{m} is good",
			inaccuracy: "{m} is an inaccuracy",
			mistake: "{m} is a mistake",
			miss: "{m} is a miss",
			blunder: "{m} is a blunder"
		},
		countLabel: (moveClass, count) => `${count} ${CLASS_LABELS[moveClass]}`,
		typography: (text) => text,
		openingLine: (name) => `Opening: ${name}.`,
		remarks: remarksEn,
		trajectory: trajectoryEn,
		facts: factsEn
	};

//#endregion
//#region src/page/review/i18n/fr-grammar.ts
	const ROLE_NAMES = {
		pawn: "pion",
		knight: "cavalier",
		bishop: "fou",
		rook: "tour",
		queen: "dame",
		king: "roi"
	};
	const isFeminine = ({ role }) => role === "rook" || role === "queen";
	const pieceName = (piece) => pieceToken(piece) + ROLE_NAMES[piece.role];
	/** "la [dame]", "le [fou]". */
	const definite = (piece) => `${isFeminine(piece) ? "la" : "le"} ${pieceName(piece)}`;
	/** "une [tour]", "un [cavalier]". */
	const indefinite = (piece) => `${isFeminine(piece) ? "une" : "un"} ${pieceName(piece)}`;
	/** The object pronoun standing for the piece: "la", "le". */
	const pronoun = (piece) => isFeminine(piece) ? "la" : "le";
	/** A past participle's agreement: "défendue", "défendu". */
	const agreement = (piece) => isFeminine(piece) ? "e" : "";
	const side = (color) => color === "white" ? "les Blancs" : "les Noirs";
	/** "des Blancs": a side as a complement. */
	const sides = (color) => color === "white" ? "des Blancs" : "des Noirs";
	const capitalize = (text) => text.length === 0 ? text : text.charAt(0).toUpperCase() + text.slice(1);
	/** "un net avantage" → "d’un net avantage". */
	const withDe = (text) => text.replace(/^un(e?) /, "d’un$1 ");
	/** French puts a space before ! ? : ;, which mustn't wrap away from its word. */
	const typography = (text) => text.replace(/ ([!?:;])/g, "\xA0$1");

//#endregion
//#region src/page/review/i18n/fr-comment.ts
	const trajectoryFr = {
		advantages: [
			"",
			"un léger avantage",
			"un net avantage",
			"une position gagnante",
			"un mat forcé"
		],
		mateIn: (moves) => `un mat en ${moves}`,
		stillBalanced: [
			"La partie reste équilibrée.",
			"L’équilibre tient toujours.",
			"Les chances restent égales."
		],
		stillAhead: ({ side: color, advantage }) => [`${capitalize(side(color))} ont toujours ${advantage}.`, `${capitalize(side(color))} gardent ${advantage}.`],
		wasBalanced: (after, forMover) => `La partie était équilibrée, ${forMover ? "et" : "mais"} maintenant ${side(after.side)} ont ${after.advantage}.`,
		nowBalanced: (before) => `${capitalize(side(before.side))} avaient ${before.advantage}, mais la partie est maintenant équilibrée.`,
		grows: (color, from, to) => `${capitalize(side(color))} passent ${withDe(from)} à ${to}.`,
		shrinks: (color, from, to) => `${capitalize(side(color))} avaient ${from}, il ne leur reste qu’${to}.`,
		swings: (before, after) => `${capitalize(side(before.side))} avaient ${before.advantage}, mais maintenant ${side(after.side)} ont ${after.advantage}.`
	};
	const factsFr = {
		checkmate: (king) => `Échec et mat\u00a0: le roi ${king === "white" ? "blanc" : "noir"} n’a plus aucune case.`,
		matedIn: (best, moves) => `${best} matait en ${moves}.`,
		heldOutLonger: (best) => `${best} tenait plus longtemps.`,
		canForceMate: (color, reply) => `${capitalize(side(color))} peuvent maintenant forcer le mat, à commencer par ${reply}.`,
		wouldForceMate: (best, moves) => `${best} forçait le mat en ${moves}.`,
		missedPunishment: (color, best) => `Le dernier coup ${sides(color)} était une erreur, et ${best} l’aurait puni.`,
		leftUndefended: ({ piece, square, reply }) => `${capitalize(definite(piece))} en ${square} n’est plus défendu${agreement(piece)}\u00a0: ${reply} ${pronoun(piece)} gagne.`,
		answersAndWins: (color, { piece, square, reply }) => `${capitalize(side(color))} répondent ${reply} et gagnent ${definite(piece)} en ${square}.`,
		strongerCapture: (best, piece) => `${best}, qui prend ${definite(piece)}, était plus fort.`,
		morePrecise: (best) => `${best} était plus précis.`,
		betterMove: (best) => `Il fallait jouer ${best}.`,
		punishesAtOnce: (color) => `Il punit aussitôt l’erreur ${sides(color)}.`,
		offered: (piece, color) => `${capitalize(definite(piece))} est offert${agreement(piece)}, et ${side(color)} ne peuvent pas ${pronoun(piece)} prendre sans risque.`,
		keepsAdvantage: "Tout autre coup laissait filer l’avantage.",
		holdsPosition: (color) => `Tout autre coup mettait ${side(color)} en difficulté.`,
		promotes: (piece) => `Le pion devient ${indefinite(piece)}.`,
		castles: "Le roi est à l’abri, et la tour entre en jeu.",
		takesBack: (square) => `Il reprend en ${square}.`,
		winsForFree: (piece) => `Il gagne ${indefinite(piece)} sans contrepartie.`,
		winsMaterial: (won, given) => `Il gagne ${indefinite(won)} contre ${indefinite(given)}.`,
		checkForces: (color) => `L’échec force ${side(color)} à réagir.`,
		littleMorePrecise: (best) => `${best} était un peu plus précis.`
	};

//#endregion
//#region src/page/review/i18n/fr-remarks.ts
	const remarksFr = {
		brilliant: [
			"Un sacrifice qui fonctionne. Magnifique.",
			"Waouh ! Du matériel donné pour une attaque gagnante.",
			"Il fallait oser, et ça paie.",
			"Le genre de coup dont on se souvient.",
			"Voir aussi loin, chapeau.",
			"Superbe. Le moteur est bien d’accord.",
			"Le matériel passe, l’idée reste.",
			"Peu de joueurs oseraient jouer ça."
		],
		great: [
			"Le seul coup qui tient tout ensemble.",
			"Belle trouvaille ! Tout le reste était moins bon.",
			"Le seul bon coup de la position.",
			"Précis. Rien d’autre ne tenait ici.",
			"Un moment critique, bien négocié.",
			"Bien vu ! Ce n’était pas facile à trouver.",
			"Le coup qu’un maître aurait choisi.",
			"Sous la pression, la bonne réponse."
		],
		book: [
			"Un coup d’ouverture bien connu.",
			"Tout droit sorti des livres d’ouverture.",
			"De la théorie : les grands maîtres jouent ça tout le temps.",
			"Un choix solide, qui a fait ses preuves.",
			"On suit les lignes principales.",
			"Du jeu d’ouverture classique.",
			"Toujours dans la théorie. Jusqu’ici, tout va bien.",
			"Un coup joué dans des milliers de parties."
		],
		best: [
			"Exactement ce que voulait le moteur.",
			"Le coup du moteur. Bien joué.",
			"Impossible de faire mieux.",
			"Dans le mille.",
			"C’est le coup le plus précis.",
			"Propre et précis.",
			"Parfait. Continue comme ça !",
			"Rien de mieux ici.",
			"Simple et fort."
		],
		excellent: [
			"Tout près du meilleur coup.",
			"Un coup fort, la position reste sous contrôle.",
			"Très bien. Le moteur chipote à peine.",
			"Presque parfait.",
			"Une suite sensée et solide.",
			"Bien joué, la position reste saine.",
			"Bon jugement ici.",
			"Du jeu solide. Continue."
		],
		good: [
			"Un coup correct, mais il y avait mieux.",
			"Jouable, sans être le plus précis.",
			"Ça va, juste un peu lent.",
			"D’accord, mais ça lâche un tout petit peu.",
			"Pas mal, mais il y avait plus actif.",
			"Ça marche, mais la position offrait plus.",
			"Un choix raisonnable.",
			"Sûr, quoiqu’un peu passif."
		],
		inaccuracy: [
			"Pas le plus précis : un peu d’avantage s’envole.",
			"Un petit faux pas. Il y avait une idée plus forte.",
			"Hmm, ça laisse respirer l’adversaire.",
			"Jouable, mais ça passe à côté de l’essentiel.",
			"Un peu imprécis. Il y avait un meilleur plan.",
			"L’emprise se relâche un peu.",
			"Pas une catastrophe, mais pas idéal non plus.",
			"Un peu négligent. Regarde de plus près."
		],
		mistake: [
			"Une erreur, qui donne un vrai avantage à l’adversaire.",
			"Aïe, ça remet l’adversaire dans la partie.",
			"Un faux pas qui coûte cher.",
			"Ça change beaucoup l’évaluation.",
			"Vérifie d’abord les réponses de l’adversaire.",
			"La position méritait plus d’attention.",
			"Ça offre une belle occasion à l’adversaire.",
			"Attention ! Ce coup a un défaut concret."
		],
		miss: [
			"L’adversaire s’est trompé, mais ce n’est pas puni.",
			"Une occasion manquée d’en profiter.",
			"Il y avait une punition bien plus forte.",
			"L’erreur de l’adversaire reste impunie.",
			"L’adversaire s’en tire à bon compte.",
			"Si près ! L’occasion était sous tes yeux.",
			"Une occasion qui s’envole.",
			"Demande-toi toujours : qu’a permis son dernier coup ?"
		],
		blunder: [
			"Une gaffe, qui gâche la position.",
			"Oh non ! Ça coûte très cher.",
			"C’est une grosse erreur.",
			"Ça renverse la partie.",
			"Aïe. L’adversaire doit être ravi.",
			"Cherche les menaces avant de jouer.",
			"Celle-là fait mal.",
			"Prends le temps de respirer avant chaque coup."
		],
		mate: [
			"Échec et mat ! La partie est finie.",
			"Et c’est mat. Bien joué !",
			"Échec et mat. Une fin parfaite.",
			"Le roi n’a plus de case. Mat !"
		],
		allowsMate: [
			"Ça permet un mat forcé.",
			"Un mat se prépare maintenant contre ce roi.",
			"Attention : le roi est pris dans un filet de mat.",
			"Ce coup tombe dans un mat forcé."
		],
		missedMate: [
			"Il y avait un mat forcé ici !",
			"Un mat était sur l’échiquier.",
			"Un échec et mat s’est échappé.",
			"Le mat était là. Regarde d’abord les échecs !"
		],
		mating: [
			"Le filet de mat se resserre.",
			"Le mat arrive. Continue !",
			"Encore un pas vers le mat.",
			"Plus d’échappatoire pour le roi."
		],
		castle: [
			"Le roque : roi à l’abri, tour en jeu.",
			"Bon moment pour mettre le roi à l’abri.",
			"La sécurité d’abord. Bien roqué.",
			"Les tours vont pouvoir se connecter."
		],
		promote: [
			"Une nouvelle dame entre en jeu !",
			"Promotion ! Ce pion est allé jusqu’au bout.",
			"Le long voyage du pion paie enfin."
		],
		check: [
			"Un échec qui garde l’initiative.",
			"Échec ! L’adversaire doit répondre.",
			"Du jeu forcé : les échecs sont puissants."
		],
		capture: [
			"Prendre est la bonne décision ici.",
			"Une bonne prise.",
			"Du matériel encaissé. Bien vu."
		],
		badCapture: [
			"Cette prise a un inconvénient caché.",
			"Toutes les prises ne sont pas bonnes.",
			"Prendre du matériel ici est risqué."
		],
		winning: [
			"C’est gagnant. Reste concentré.",
			"La position est gagnante maintenant.",
			"Il ne reste qu’à conclure calmement."
		],
		losing: ["La position est maintenant très dure à tenir.", "Ça laisse une position perdante."],
		earlyQueen: ["Sortir la dame si tôt est risqué.", "La dame sort trop tôt : elle va se faire chasser."],
		earlyKing: ["Bouger le roi si tôt coûte le roque.", "Le roi ferait mieux de rester à l’abri."]
	};

//#endregion
//#region src/page/review/i18n/fr.ts
	const COUNT_LABELS = {
		brilliant: ["coup brillant", "coups brillants"],
		great: ["excellent coup", "excellents coups"],
		best: ["meilleur coup", "meilleurs coups"]
	};
	const fr = {
		ui: {
			review: "Bilan",
			start: "Démarrer le bilan",
			next: "Suivant",
			explain: "Expliquer",
			best: "Meilleur",
			analysing: "Analyse de la partie…",
			players: "Joueurs",
			accuracy: "Précision",
			anonymous: "Anonyme",
			close: "Fermer le bilan",
			back: "Retour",
			coach: "Changer de coach",
			intro: "Passons en revue cette partie !",
			engineError: "Le moteur n'a pas pu démarrer.",
			liveIntro: "Joue un coup, je te dirai ce que j’en pense.",
			thinking: "Voyons ce coup…",
			startPosition: "Position de départ",
			more: "Voir tous les coups",
			less: "Voir moins",
			gameRating: "Classement de la partie",
			gameRatingTip: "Donne une estimation du classement d’un joueur d’après une seule partie.",
			phases: {
				opening: "Ouverture",
				tactics: "Exercices tactiques",
				strategy: "Stratégie",
				endgame: "Finale"
			},
			bestWas: (move) => `Le meilleur coup était ${move}.`,
			lines: {
				best: (line) => `La meilleure suite était ${line}.`,
				allows: (move, line) => `${move} permet ${line}.`,
				show: "Voir la ligne"
			}
		},
		classLabels: {
			brilliant: "Brillant",
			great: "Excellent",
			book: "Théorique",
			best: "Meilleur",
			excellent: "Très bien",
			good: "Bon",
			inaccuracy: "Imprécision",
			mistake: "Erreur",
			miss: "Manqué",
			blunder: "Gaffe"
		},
		classSentences: {
			brilliant: "{m} est brillant !",
			great: "{m} est un excellent coup",
			book: "{m} est un coup théorique",
			best: "{m} est le meilleur coup",
			excellent: "{m} est très bien",
			good: "{m} est bon",
			inaccuracy: "{m} est une imprécision",
			mistake: "{m} est une erreur",
			miss: "{m} est un coup manqué",
			blunder: "{m} est une gaffe"
		},
		countLabel: (moveClass, count) => {
			const [one, many] = COUNT_LABELS[moveClass];
			return `${count} ${count > 1 ? many : one}`;
		},
		typography,
		openingLine: (name) => `Ouverture: ${name}.`,
		remarks: remarksFr,
		trajectory: trajectoryFr,
		facts: factsFr
	};

//#endregion
//#region src/page/review/i18n/language.ts
/** The review's language: French on a French page, English otherwise. */
	const pageLanguage = () => isFrench() ? fr : en;

//#endregion
//#region src/page/review/session.ts
/** What the panel shows: the closed panel, the summary, the move-by-move review, or the free board's coach. */
	const ModeSchema = _enum([
		"normal",
		"summary",
		"moves",
		"live"
	]);
	const MODES = ModeSchema.options;
	function createSession(options) {
		const { language, coach, elements, redraw, setMode } = options;
		return {
			language,
			elements,
			view: {
				mode: "summary",
				review: null,
				progress: 0,
				version: 0,
				error: null,
				lastKey: "",
				explain: false,
				playing: null,
				revealed: /* @__PURE__ */ new Set(),
				bestOf: null,
				lineOf: null,
				allRows: false,
				summaryPly: void 0,
				drawnMode: null,
				openingName: "",
				barPosition: null,
				overlay: ""
			},
			live: {
				evals: /* @__PURE__ */ new Map(),
				books: /* @__PURE__ */ new Map(),
				judged: /* @__PURE__ */ new Map(),
				busy: false,
				bookBusy: false,
				noBook: false,
				error: null
			},
			work: {
				nodes: [],
				deep: [],
				rough: [],
				moves: [],
				bookPly: 0,
				cloudAt: Infinity
			},
			lines: {
				found: /* @__PURE__ */ new Map(),
				busy: false
			},
			coach: {
				id: coach,
				reacted: "",
				avatar: null
			},
			stream: {
				state: {
					key: "",
					shown: 0,
					dropped: false
				},
				timer: 0
			},
			wide: matchMedia("(min-width: 1020px)"),
			tipFor: null,
			engine: null,
			redraw,
			setMode
		};
	}

//#endregion
//#region src/page/review/view/actions.ts
	const CommandSchema = _enum([
		"play",
		"explain",
		"rows",
		"first",
		"last",
		"prev",
		"next",
		"best",
		"line",
		"coach"
	]);
	const PanelActionSchema = union([ModeSchema, CommandSchema]);

//#endregion
//#region src/page/review/view/coach-avatar.ts
/** Whether the marks pop for this verdict: the first time the coach reacts to it on this move. */
	function takeReaction(coach, moveClass, at) {
		const key = moveClass && classMood(moveClass) ? `${at}|${moveClass}` : "";
		const react = key !== "" && key !== coach.reacted;
		coach.reacted = key;
		return react;
	}
	function avatarMarkup({ coachId, moveClass, react, label }) {
		const mood = moveClass ? classMood(moveClass) : null;
		const moodColor = mood && moveClass ? `--cdc-mood-c:${CLASS_COLORS[moveClass]}` : null;
		const style = moodColor === null ? "" : html` style="${moodColor}"`;
		return html`<button class="cdc-coach__avatar${react ? " cdc-coach__avatar--react" : ""}" data-cdc="coach" data-cdc-coach-id="${coachId}" data-cdc-mood="${mood ?? "neutral"}"${style} data-cdc-tip="${label}" aria-label="${label}"><span class="cdc-coach__face"></span></button>`;
	}
	/** Tells the content script which coach shows, how it looks, and whether it talks. */
	function tellCoach(session) {
		const { avatar } = session.coach;
		if (!avatar?.isConnected) return;
		const mood = CoachMoodSchema.safeParse(avatar.dataset.cdcMood);
		postCoachState({
			coach: Number(avatar.dataset.cdcCoachId),
			mood: mood.success ? mood.data : "neutral",
			talking: session.stream.timer !== 0
		});
	}
	const KEPT_ATTRIBUTES = [
		"data-cdc-coach-id",
		"data-cdc-mood",
		"style"
	];
	function keepAvatar(session) {
		const fresh = queryOne(session.elements.panel, ".cdc-coach__avatar", HTMLElement);
		if (!fresh) return;
		const kept = session.coach.avatar;
		if (kept && kept !== fresh) {
			for (const name of KEPT_ATTRIBUTES) {
				const value = fresh.getAttribute(name);
				if (value === null) kept.removeAttribute(name);
				else kept.setAttribute(name, value);
			}
			kept.classList.remove("cdc-coach__avatar--react");
			if (fresh.classList.contains("cdc-coach__avatar--react")) {
				kept.offsetWidth;
				kept.classList.add("cdc-coach__avatar--react");
			}
			fresh.replaceWith(kept);
		} else session.coach.avatar = fresh;
		tellCoach(session);
	}
	/** The next coach, kept for the next review; each words the remarks their own way. */
	function nextCoach(session, avatar) {
		const coach = session.coach.id % 4 + 1;
		session.coach.id = coach;
		writeStored(StorageKey.coach, coach);
		avatar.dataset.cdcCoachId = String(coach);
		tellCoach(session);
	}

//#endregion
//#region src/page/review/explain/lines.ts
	const keyOf = ({ fen, first }) => `${fen} ${first}`;
	/** For a move that wasn't the best, the line from its position before, starting with the best. */
	const bestRequest = (move) => move.best && !GOOD.has(move.moveClass) ? {
		fen: move.previousPosition.fen,
		first: move.best
	} : null;
	/** The line after an error, starting with the engine's best reply. */
	const punishmentRequest = (move) => isError(move.moveClass) && move.after.best ? {
		fen: move.position.fen,
		first: move.after.best
	} : null;
	/** The line asked for, once the engine has played it out. */
	const foundLine = (session, request) => (request && session.lines.found.get(keyOf(request))) ?? null;
	/**
	* The lines Explain shows of a move that wasn't best, once the engine has
	* played out every one: they come in together, so the comment is typed once.
	*/
	function explainLines(session, move) {
		const best = foundLine(session, bestRequest(move));
		const request = punishmentRequest(move);
		const punishment = foundLine(session, request);
		return best && (punishment || !request) ? {
			best,
			punishment
		} : null;
	}
	async function lookUp(session, analysis, request) {
		const { lines } = session;
		lines.busy = true;
		let line = [request.first];
		try {
			const pv = (await (await engineFor(session, analysis)).analyse(request.fen, FULL_SEARCH, [request.first])).lines[0]?.pv ?? [];
			if (pv[0] === request.first) line = pv;
		} catch (error) {
			console.error("[LichessDotCom] engine failed", error);
		}
		lines.found.set(keyOf(request), line);
		lines.busy = false;
		session.redraw();
	}
	/** Asks the engine for the next line Explain shows of `move`, one search at a time. */
	function pumpLines(session, analysis, move) {
		const { lines } = session;
		if (lines.busy) return;
		const request = [bestRequest(move), punishmentRequest(move)].find((candidate) => candidate !== null && !lines.found.has(keyOf(candidate)));
		if (request) lookUp(session, analysis, request);
	}

//#endregion
//#region src/page/review/evaluation/format.ts
/** "+1.25", "-0.40", "+M3", "#" (mated). */
	function formatEval(score) {
		if (!score) return "";
		if ("mate" in score) {
			if (score.mate === 0) return "#";
			return (score.mate > 0 ? "+M" : "-M") + Math.abs(score.mate);
		}
		const pawns = score.cp / 100;
		return (pawns > 0 ? "+" : "") + pawns.toFixed(2);
	}
	/** The eval bar's label: "1.3", "M3", nothing once mated. */
	function barLabel(score) {
		if (!score) return "";
		if ("mate" in score) return score.mate === 0 ? "" : `M${Math.abs(score.mate)}`;
		return Math.abs(score.cp / 100).toFixed(1);
	}

//#endregion
//#region src/page/review/live/judging.ts
/** Deeper than this, no move is "book". */
	const BOOK_PLIES = 30;
	/**
	* Whether the move to `path` is a book move: every move up to it is played
	* in master games. Undefined while that's still being looked up.
	*/
	function bookAt(live, analysis, path) {
		let book = true;
		for (const prefix of pathPrefixes(path)) {
			const node = analysis.nodeAtPath(prefix);
			if (live.noBook || node.ply > 30) return false;
			book = live.books.get(node.fen)?.book;
			if (book !== true) break;
		}
		return book;
	}
	/** The last named opening along `path`: a move out of the book keeps the line's name. */
	function openingAt(live, analysis, path) {
		for (let at = path; at; at = parentPath(at)) {
			const entry = live.books.get(analysis.nodeAtPath(at).fen);
			if (entry?.name) return entry;
		}
		return null;
	}
	function judgeNode(live, analysis, path) {
		const node = analysis.nodeAtPath(path);
		const up = parentPath(path);
		const previous = analysis.nodeAtPath(up);
		const before = live.evals.get(previous.fen);
		const after = live.evals.get(node.fen);
		const book = bookAt(live, analysis, path);
		if (!before || !after || book === void 0 || !isPlayed(node)) return null;
		return {
			...judge({
				previousPosition: previous,
				position: node,
				before,
				after,
				previousMove: judgeAt(live, analysis, up),
				book,
				chess960: analysis.chess960
			}),
			opening: openingAt(live, analysis, path)?.name ?? ""
		};
	}
	/** The move to `path`, judged, or null until its positions are analyzed. */
	function judgeAt(live, analysis, path) {
		if (!path) return null;
		const node = analysis.nodeAtPath(path);
		if (node.id !== lastNodeId(path)) return null;
		const hit = live.judged.get(path);
		if (hit?.node === node) return hit.move;
		const move = judgeNode(live, analysis, path);
		live.judged.set(path, {
			node,
			move
		});
		return move;
	}
	/** What the coach's bubble shows of a move, to draw it again only when that changes. */
	function liveDigest(move) {
		if (!move) return "";
		return [
			move.moveClass,
			formatEval(move.after),
			move.after.best ?? "",
			move.best ?? "",
			move.opening ?? "",
			move.previousMove?.moveClass ?? ""
		].join(",");
	}

//#endregion
//#region src/page/review/view/navigation.ts
	const PLAY_STEP_MS = 1200;
	const LINE_STEP_MS = 900;
	/** The move on the board: the game's, from the review, or one played off it (judged as it comes). */
	function reviewMove(session, analysis) {
		const { review } = session.view;
		const { path } = analysis;
		if (!review || !path) return null;
		if (analysis.onMainline) return review.moves[analysis.node.ply - 1] ?? null;
		return judgeAt(session.live, analysis, path);
	}
	/** The engine's best move, when it's on the board in place of the move played (the Best button). */
	function bestShown(session, analysis) {
		const shown = session.view.bestOf;
		const { path, node } = analysis;
		if (!shown || path === shown.path || path !== parentPath(shown.path) + node.id) return null;
		return normalizeUci(node.uci, analysis.chess960) === shown.move.best ? shown.move : null;
	}
	/** Explain's best line, while the board is somewhere along it. */
	function lineShown(session, analysis) {
		const shown = session.view.lineOf;
		if (!shown) return null;
		const from = parentPath(shown.path);
		if (!analysis.path.startsWith(from)) return null;
		const played = [];
		for (let at = analysis.path; at.length > from.length; at = parentPath(at)) played.unshift(normalizeUci(analysis.nodeAtPath(at).uci ?? "", analysis.chess960));
		return played.length > 0 && played.every((uci, i) => uci === shown.line[i]) ? shown : null;
	}
	/** The move the coach speaks of: the one on the board, or the one Explain's line stands for. */
	const spokenMove = (session, analysis) => lineShown(session, analysis)?.move ?? reviewMove(session, analysis);
	function jump(analysis, ply) {
		analysis.jumpToMain(ply);
		analysis.redraw();
	}
	function goTo(analysis, path) {
		analysis.userJump(path);
		analysis.redraw();
	}
	/** Plays the engine's best move as a variation in place of the one played, or goes back to that one. */
	function showBest(session, analysis) {
		const { view } = session;
		if (view.bestOf && bestShown(session, analysis)) {
			goTo(analysis, view.bestOf.path);
			return;
		}
		const move = reviewMove(session, analysis);
		if (!move?.best || !analysis.canPlayUci) return;
		view.bestOf = {
			path: analysis.path,
			move
		};
		goTo(analysis, parentPath(analysis.path));
		analysis.playUci(move.best);
		analysis.redraw();
	}
	/**
	* Plays Explain's best line as a variation in place of the move played, a
	* move at a time on the player's interval, so any click stops it.
	*/
	function showLine(session, analysis) {
		const { view } = session;
		const move = reviewMove(session, analysis);
		const line = move && foundLine(session, bestRequest(move))?.slice(0, 4);
		if (!move || !line || !analysis.canPlayUci) return;
		view.lineOf = {
			path: analysis.path,
			move,
			line
		};
		view.bestOf = null;
		goTo(analysis, parentPath(analysis.path));
		let played = 0;
		const step = () => {
			const uci = line[played];
			if (uci === void 0 || played > 0 && !lineShown(session, analysis)) {
				stopPlaying(session);
				session.redraw(true);
				return;
			}
			played++;
			analysis.playUci(uci);
			analysis.redraw();
		};
		view.playing = setInterval(step, LINE_STEP_MS);
		step();
	}
	/** The bubble's line button: plays the best line, or goes back to the move it stands for. */
	function toggleLine(session, analysis) {
		const shown = lineShown(session, analysis);
		if (shown) goTo(analysis, shown.path);
		else showLine(session, analysis);
	}
	/**
	* Where the arrows lead along the line on the board: from the best move
	* shown, back to the move it stands for, or on to the one after that.
	*/
	function stepPath(session, analysis, direction) {
		const { path } = analysis;
		const shown = session.view.bestOf;
		const line = lineShown(session, analysis);
		const best = shown && bestShown(session, analysis) ? shown.path : path;
		const from = line ? line.path : best;
		if (direction < 0) {
			if (from !== path) return from;
			return from ? parentPath(from) : null;
		}
		const next = firstChild(analysis.nodeAtPath(from));
		return next ? from + next.id : null;
	}
	function stopPlaying(session) {
		const { view } = session;
		if (view.playing !== null) clearInterval(view.playing);
		view.playing = null;
	}
	/** The play button: a move every 1.2 s along the game, until its end or a move off it. */
	function togglePlay(session, analysis) {
		if (session.view.playing !== null) {
			stopPlaying(session);
			return;
		}
		const step = () => {
			const last = analysis.mainline.length - 1;
			if (!analysis.onMainline || analysis.node.ply >= last) {
				stopPlaying(session);
				session.redraw(true);
				return;
			}
			jump(analysis, analysis.node.ply + 1);
		};
		session.view.playing = setInterval(step, PLAY_STEP_MS);
		step();
	}
	/**
	* Closes Lichess's tools for the move-by-move review, which hides their
	* buttons. Left open, their menu would take the review's move list, and
	* "practice with computer" would play moves on its own.
	*/
	function closeTools(analysis) {
		analysis.closeActionMenu();
		analysis.stopPractice();
		analysis.redraw();
	}

//#endregion
//#region src/page/review/view/clicks.ts
	function toggleExplain(session, analysis) {
		const { view } = session;
		const line = lineShown(session, analysis);
		view.explain = !view.explain;
		if (!view.explain && line) goTo(analysis, line.path);
	}
	function act(session, analysis, action) {
		const { view } = session;
		if (action === "play") togglePlay(session, analysis);
		else if (action === "explain") toggleExplain(session, analysis);
		else if (action === "line") toggleLine(session, analysis);
		else if (action === "rows") view.allRows = !view.allRows;
		else if (action === "first") jump(analysis, 0);
		else if (action === "last") jump(analysis, analysis.mainline.length - 1);
		else if (action === "prev" || action === "next") {
			const path = stepPath(session, analysis, action === "prev" ? -1 : 1);
			if (path !== null) goTo(analysis, path);
		} else if (action === "best") showBest(session, analysis);
		else {
			if (action === "moves" && (!analysis.onMainline || analysis.node.ply === 0)) jump(analysis, 1);
			session.setMode(action);
		}
	}
	function onClick(session, event) {
		const button = closestTo(event.target, "[data-cdc]", HTMLElement);
		if (!button || button instanceof HTMLButtonElement && button.disabled) return;
		const parsed = PanelActionSchema.safeParse(button.dataset.cdc);
		if (!parsed.success) return;
		const action = parsed.data;
		if (action === "coach") {
			nextCoach(session, button);
			if (session.view.mode === "moves" || session.view.mode === "live") session.redraw(true);
			return;
		}
		const analysis$4 = analysis();
		if (!analysis$4) return;
		if (action !== "play") stopPlaying(session);
		act(session, analysis$4, action);
		session.redraw(true);
	}
	function watchClicks(session) {
		const listener = (event) => onClick(session, event);
		session.elements.panel.addEventListener("click", listener);
		session.elements.controls.addEventListener("click", listener);
	}

//#endregion
//#region src/page/review/view/elements.ts
	function createElements() {
		const bar = createElement("div", { id: "cdc-evalbar" });
		const barFill = createElement("div", { className: "cdc-evalbar__fill" });
		const barLabel = createElement("span", { className: "cdc-evalbar__label" });
		bar.append(barFill, barLabel);
		return {
			panel: createElement("div", { id: "cdc-review" }),
			graphBox: createElement("div", { id: "cdc-review-graph" }),
			controls: createElement("div", { id: "cdc-review-controls" }),
			bar,
			barFill,
			barLabel,
			overlay: createElement("div", { id: "cdc-board-overlay" }),
			opening: createElement("div", { id: "cdc-opening" }),
			tip: createElement("div", {
				id: "cdc-tip",
				attrs: { role: "tooltip" }
			})
		};
	}
	/** Puts the elements in the analysis page; false when it has no board yet. */
	function attach(elements) {
		const main = queryOne(document, "main.analyse", HTMLElement);
		const board = main && queryOne(main, ".analyse__board", HTMLElement);
		if (!main || !board) return false;
		for (const element of [
			elements.panel,
			elements.graphBox,
			elements.controls,
			elements.bar
		]) if (element.parentNode !== main) main.append(element);
		if (elements.overlay.parentNode !== board) board.append(elements.overlay);
		return true;
	}

//#endregion
//#region src/page/review/live/lookups.ts
/** A lookup that hangs gives up, or the moves waiting on it would never be judged. */
	const BOOK_TIMEOUT_MS = 8e3;
	function changed(session) {
		session.live.judged.clear();
		session.redraw();
	}
	async function analyseLive(session, analysis, fen) {
		const { live } = session;
		live.busy = true;
		try {
			const engine = await engineFor(session, analysis);
			live.evals.set(fen, toRecord(fen, await engine.analyse(fen)));
		} catch (error) {
			console.error("[LichessDotCom] engine failed", error);
			live.error = session.language.ui.engineError;
		}
		live.busy = false;
		changed(session);
	}
	function withTimeout(promise, milliseconds) {
		let timer = 0;
		const late = new Promise((_, reject) => {
			timer = setTimeout(() => reject(/* @__PURE__ */ new Error("timeout")), milliseconds);
		});
		return Promise.race([promise, late]).finally(() => clearTimeout(timer));
	}
	async function lookUpBook(session, analysis, fen) {
		const { live } = session;
		live.bookBusy = true;
		try {
			const found = await withTimeout(analysis.fetchMasterOpening(fen), BOOK_TIMEOUT_MS);
			live.books.set(fen, {
				book: found.white + found.draws + found.black >= 10,
				name: found.opening?.name ?? "",
				eco: found.opening?.eco ?? ""
			});
		} catch {
			live.noBook = true;
		}
		live.bookBusy = false;
		changed(session);
	}

//#endregion
//#region src/page/review/live/queue.ts
/** Every move in Lichess's move list carries its tree path in `p`, variations included. */
	const treeMovePaths = () => queryAll(document, "main.analyse .tview2 move[p]", Element).map((move) => move.getAttribute("p") ?? "");
	/** The line on from `node`, following each first child. */
	function lineAfter(node) {
		const line = [];
		for (let next = firstChild(node); next; next = firstChild(next)) line.push(next);
		return line;
	}
	/**
	* Positions to analyze, most urgent first: the move on the board (its
	* position, the one before, and the one before that for a miss), the next
	* move, the rest of the line, then everything else in the move list.
	*/
	function wanted(analysis, movePaths) {
		const path = analysis.nodeList;
		const after = lineAfter(analysis.node);
		return [
			...path.slice(-3).toReversed(),
			...after.slice(0, 1),
			...path.slice(0, -3).toReversed(),
			...after.slice(1),
			...analysis.mainline,
			...movePaths.map((movePath) => analysis.nodeAtPath(movePath))
		];
	}
	/** The first position along `path` not looked up in the masters database, while the line is in it. */
	function bookGap(live, analysis, path) {
		for (const prefix of pathPrefixes(path)) {
			const node = analysis.nodeAtPath(prefix);
			if (node.ply > 30) return null;
			const entry = live.books.get(node.fen);
			if (!entry) return node.fen;
			if (!entry.book) return null;
		}
		return null;
	}
	function nextBookGap(live, analysis) {
		const line = analysis.path + lineAfter(analysis.node).map((node) => node.id).join("");
		const mainline = analysis.mainline.slice(1).map((node) => node.id).join("");
		for (const path of [
			line,
			mainline,
			...treeMovePaths()
		]) {
			const fen = bookGap(live, analysis, path);
			if (fen) return fen;
		}
		return null;
	}
	/** Starts the next lookups the moves on the board wait for, if none is running. */
	function pump(session, analysis) {
		const { live, work } = session;
		if (!live.busy && live.error === null) {
			const game = analysis.synthetic ? null : new Set(work.nodes.map((node) => node.fen));
			const node = wanted(analysis, treeMovePaths()).find((candidate) => !live.evals.has(candidate.fen) && !game?.has(candidate.fen));
			if (node) analyseLive(session, analysis, node.fen);
		}
		if (!live.bookBusy && !live.noBook) {
			const fen = nextBookGap(live, analysis);
			if (fen) lookUpBook(session, analysis, fen);
		}
	}

//#endregion
//#region src/page/review/classes/glyphs.ts
	const CLASS_GLYPHS = {
		brilliant: ["M12.57,14.1a.51.51,0,0,1,0,.13.44.44,0,0,1-.08.11l-.11.08-.13,0h-2l-.13,0L10,14.34A.41.41,0,0,1,10,14.1V12.2A.32.32,0,0,1,10,12a.39.39,0,0,1,.1-.08l.13,0h2a.31.31,0,0,1,.24.1.39.39,0,0,1,.08.1.51.51,0,0,1,0,.13Zm-.12-3.93a.17.17,0,0,1,0,.12.41.41,0,0,1-.07.11.4.4,0,0,1-.23.08H10.35a.31.31,0,0,1-.34-.31L9.86,3.4A.36.36,0,0,1,10,3.16a.23.23,0,0,1,.11-.08.27.27,0,0,1,.13,0H12.3a.32.32,0,0,1,.25.1.36.36,0,0,1,.09.24Z", "M8.07,14.1a.51.51,0,0,1,0,.13.44.44,0,0,1-.08.11l-.11.08-.13,0h-2l-.13,0-.11-.08a.41.41,0,0,1-.08-.24V12.2a.27.27,0,0,1,0-.13.36.36,0,0,1,.07-.1.39.39,0,0,1,.1-.08l.13,0h2A.31.31,0,0,1,8,12a.39.39,0,0,1,.08.1.51.51,0,0,1,0,.13ZM8,10.17a.17.17,0,0,1,0,.12.41.41,0,0,1-.07.11.4.4,0,0,1-.23.08H5.85a.31.31,0,0,1-.34-.31L5.36,3.4a.36.36,0,0,1,.09-.24.23.23,0,0,1,.11-.08.27.27,0,0,1,.13,0H7.8a.35.35,0,0,1,.25.1.36.36,0,0,1,.09.24Z"],
		book: ["M8.45,5.4c-1-.75-2.51-1.09-4.83-1.09H3V13h.58a8.09,8.09,0,0,1,4.83,1.17Z", "M9.54,14.19A8.14,8.14,0,0,1,14.38,13H15V4.31h-.58c-2.31,0-3.81.34-4.84,1.09Z"],
		great: ["M10.32,14.1a.27.27,0,0,1,0,.13.44.44,0,0,1-.08.11l-.11.08-.13,0H8l-.13,0-.11-.08a.41.41,0,0,1-.08-.24V12.2a.27.27,0,0,1,0-.13.36.36,0,0,1,.07-.1.39.39,0,0,1,.1-.08l.13,0h2a.31.31,0,0,1,.24.1.39.39,0,0,1,.08.1.51.51,0,0,1,0,.13Zm-.12-3.93a.17.17,0,0,1,0,.12.41.41,0,0,1-.07.11.4.4,0,0,1-.23.08H8.1a.31.31,0,0,1-.34-.31L7.61,3.4a.36.36,0,0,1,.09-.24.23.23,0,0,1,.11-.08.27.27,0,0,1,.13,0h2.11a.32.32,0,0,1,.25.1.36.36,0,0,1,.09.24Z"],
		best: ["M9,2.93A.5.5,0,0,0,8.73,3a.46.46,0,0,0-.17.22L7.24,6.67l-3.68.19A.52.52,0,0,0,3.3,7a.53.53,0,0,0-.16.23.45.45,0,0,0,0,.28.44.44,0,0,0,.15.23L6.15,10l-1,3.56a.45.45,0,0,0,0,.28.46.46,0,0,0,.17.22.41.41,0,0,0,.26.09.43.43,0,0,0,.27-.08l3.09-2,3.09,2a.46.46,0,0,0,.53,0,.46.46,0,0,0,.17-.22.53.53,0,0,0,0-.28l-1-3.56L14.71,7.7a.44.44,0,0,0,.15-.23.45.45,0,0,0,0-.28A.53.53,0,0,0,14.7,7a.52.52,0,0,0-.26-.1l-3.68-.2L9.44,3.23A.46.46,0,0,0,9.27,3,.5.5,0,0,0,9,2.93Z"],
		mistake: ["M9.92,14.52a.27.27,0,0,1,0,.12.41.41,0,0,1-.07.11.32.32,0,0,1-.23.09H7.7a.25.25,0,0,1-.12,0,.27.27,0,0,1-.1-.08.31.31,0,0,1-.09-.22V12.69a.32.32,0,0,1,.09-.23l.1-.07.12,0H9.59a.32.32,0,0,1,.23.09.61.61,0,0,1,.07.1.28.28,0,0,1,0,.13Zm2.2-7.17a3.1,3.1,0,0,1-.36.73,5.58,5.58,0,0,1-.49.6,6,6,0,0,1-.52.49,8,8,0,0,0-.65.63,1,1,0,0,0-.27.7v.22a.24.24,0,0,1,0,.12.17.17,0,0,1-.06.1.3.3,0,0,1-.1.07l-.12,0H7.79l-.12,0a.3.3,0,0,1-.1-.07.26.26,0,0,1-.07-.1.37.37,0,0,1,0-.12v-.35a2.42,2.42,0,0,1,.13-.84,2.55,2.55,0,0,1,.33-.66,3.38,3.38,0,0,1,.45-.55c.16-.15.33-.29.49-.42a7.73,7.73,0,0,0,.64-.64,1,1,0,0,0,.26-.67.77.77,0,0,0-.07-.34A.75.75,0,0,0,9.48,6a1.16,1.16,0,0,0-.72-.24,1.61,1.61,0,0,0-.49.07A3,3,0,0,0,7.86,6a1.41,1.41,0,0,0-.29.18l-.11.09a.5.5,0,0,1-.24.06A.31.31,0,0,1,7,6.19L6,5a.29.29,0,0,1,0-.4,1.36,1.36,0,0,1,.21-.2A3.07,3.07,0,0,1,6.81,4a5.38,5.38,0,0,1,.89-.37,3.75,3.75,0,0,1,1.2-.17,4.07,4.07,0,0,1,1.2.19,4,4,0,0,1,1.09.56,2.76,2.76,0,0,1,.78.92,2.82,2.82,0,0,1,.28,1.28A3,3,0,0,1,12.12,7.35Z"],
		blunder: [
			"M14.74,5A2.58,2.58,0,0,0,14,4a3.76,3.76,0,0,0-1.09-.56,4.07,4.07,0,0,0-1.2-.19,3.92,3.92,0,0,0-1.18.17,5.87,5.87,0,0,0-.9.37,3,3,0,0,0-.32.2,3.46,3.46,0,0,1,.42.63,3.29,3.29,0,0,1,.36,1.47.31.31,0,0,0,.19-.06L10.37,6a2.9,2.9,0,0,1,.29-.19,3.89,3.89,0,0,1,.41-.17,1.55,1.55,0,0,1,.48-.07,1.1,1.1,0,0,1,.72.24.72.72,0,0,1,.23.26.8.8,0,0,1,.07.34,1,1,0,0,1-.25.67,7.71,7.71,0,0,1-.65.63,6.2,6.2,0,0,0-.48.43,2.93,2.93,0,0,0-.45.54,2.55,2.55,0,0,0-.33.66,2.62,2.62,0,0,0-.13.83v.35a.24.24,0,0,0,0,.12.35.35,0,0,0,.17.17l.12,0h1.71l.12,0a.23.23,0,0,0,.1-.07.21.21,0,0,0,.06-.1.27.27,0,0,0,0-.12V10.3a1,1,0,0,1,.26-.7q.27-.28.66-.63a5.79,5.79,0,0,0,.51-.48,4.51,4.51,0,0,0,.48-.6,2.56,2.56,0,0,0,.36-.72,2.81,2.81,0,0,0,.14-1A2.66,2.66,0,0,0,14.74,5Z",
			"M12.38,12.15H10.5l-.12,0a.34.34,0,0,0-.18.29v1.82a.36.36,0,0,0,.08.23.23.23,0,0,0,.1.07l.12,0h1.88a.24.24,0,0,0,.12,0,.26.26,0,0,0,.11-.07.36.36,0,0,0,.07-.1.28.28,0,0,0,0-.13V12.46a.27.27,0,0,0,0-.12.61.61,0,0,0-.07-.1A.32.32,0,0,0,12.38,12.15Z",
			"M6.79,12.15H4.91l-.12,0a.34.34,0,0,0-.18.29v1.82a.36.36,0,0,0,.08.23.23.23,0,0,0,.1.07l.12,0H6.79a.24.24,0,0,0,.12,0A.26.26,0,0,0,7,14.51a.36.36,0,0,0,.07-.1.28.28,0,0,0,0-.13V12.46a.27.27,0,0,0,0-.12.61.61,0,0,0-.07-.1A.32.32,0,0,0,6.79,12.15Z",
			"M8.39,4A3.76,3.76,0,0,0,7.3,3.48a4.07,4.07,0,0,0-1.2-.19,3.92,3.92,0,0,0-1.18.17,5.87,5.87,0,0,0-.9.37,3.37,3.37,0,0,0-.55.38l-.21.19a.32.32,0,0,0,0,.41l1,1.2a.26.26,0,0,0,.2.12.48.48,0,0,0,.24-.06L4.78,6a2.9,2.9,0,0,1,.29-.19l.4-.17A1.66,1.66,0,0,1,6,5.56a1.1,1.1,0,0,1,.72.24.72.72,0,0,1,.23.26A.77.77,0,0,1,7,6.4a1,1,0,0,1-.26.67,7.6,7.6,0,0,1-.64.63,6.28,6.28,0,0,0-.49.43,2.93,2.93,0,0,0-.45.54,2.72,2.72,0,0,0-.33.66,2.62,2.62,0,0,0-.13.83v.35a.43.43,0,0,0,0,.12.39.39,0,0,0,.08.1.18.18,0,0,0,.1.07.21.21,0,0,0,.12,0H6.72l.12,0a.23.23,0,0,0,.1-.07.36.36,0,0,0,.07-.1.5.5,0,0,0,0-.12V10.3a1,1,0,0,1,.27-.7A8,8,0,0,1,8,9c.18-.15.35-.31.52-.48A7,7,0,0,0,9,7.89a3.23,3.23,0,0,0,.36-.72,3.07,3.07,0,0,0,.13-1A2.66,2.66,0,0,0,9.15,5,2.58,2.58,0,0,0,8.39,4Z"
		],
		excellent: ["M13.79,10.84c0-.2.4-.53.4-.94S14,9.22,14,9.08a2.06,2.06,0,0,0,.18-.83,1,1,0,0,0-.3-.69,1.13,1.13,0,0,0-.55-.2,10.29,10.29,0,0,1-2.07,0c-.37-.23,0-1.18.18-1.7s.51-2.12-.77-2.43c-.69-.17-.66.37-.78.9-.05.21-.09.43-.13.57A5,5,0,0,1,7.05,7.73a1.57,1.57,0,0,1-.42.18v4.94A7.23,7.23,0,0,1,8,13c.52.12.91.25,1.44.33a11.11,11.11,0,0,0,1.62.16,6.65,6.65,0,0,0,1.18,0,1.09,1.09,0,0,0,1-.59.66.66,0,0,0,.06-.2,1.63,1.63,0,0,1,.07-.3c.13-.28.37-.3.5-.68S13.74,11,13.79,10.84Z", "M5.49,7.59H4.31a.5.5,0,0,0-.5.5v4.56a.5.5,0,0,0,.5.5H5.49a.5.5,0,0,0,.5-.5V8.09A.5.5,0,0,0,5.49,7.59Z"],
		good: ["M15.11,6.31,9.45,12,7.79,13.63a.39.39,0,0,1-.28.11.39.39,0,0,1-.27-.11L2.89,9.28A.39.39,0,0,1,2.78,9a.39.39,0,0,1,.11-.27L4.28,7.35a.34.34,0,0,1,.12-.09l.15,0a.37.37,0,0,1,.15,0,.38.38,0,0,1,.13.09L7.52,10l5.65-5.65a.38.38,0,0,1,.13-.09.37.37,0,0,1,.15,0,.4.4,0,0,1,.15,0,.34.34,0,0,1,.12.09l1.39,1.38a.41.41,0,0,1,.08.13.33.33,0,0,1,0,.15.4.4,0,0,1,0,.15A.5.5,0,0,1,15.11,6.31Z"],
		inaccuracy: ["M13.66,14.3a.28.28,0,0,1,0,.13.23.23,0,0,1-.08.11.28.28,0,0,1-.11.08l-.12,0h-2l-.13,0a.27.27,0,0,1-.1-.08A.36.36,0,0,1,11,14.3V12.4a.59.59,0,0,1,0-.13.36.36,0,0,1,.07-.1l.1-.08.13,0h2a.33.33,0,0,1,.23.1.39.39,0,0,1,.08.1.28.28,0,0,1,0,.13Zm-.12-3.93a.31.31,0,0,1,0,.13.3.3,0,0,1-.07.1.3.3,0,0,1-.23.08H11.43a.31.31,0,0,1-.34-.31L10.94,3.6A.5.5,0,0,1,11,3.36l.11-.08.13,0h2.11a.35.35,0,0,1,.26.1.41.41,0,0,1,.08.24Z", "M7.65,14.32a.27.27,0,0,1,0,.12.26.26,0,0,1-.07.11l-.1.07-.13,0H5.43a.25.25,0,0,1-.12,0,.27.27,0,0,1-.1-.08.31.31,0,0,1-.09-.22V12.49a.36.36,0,0,1,.09-.23l.1-.07.12,0H7.32a.32.32,0,0,1,.23.09.3.3,0,0,1,.07.1.28.28,0,0,1,0,.13Zm2.2-7.17a3.1,3.1,0,0,1-.36.73,5.58,5.58,0,0,1-.49.6A4.85,4.85,0,0,1,8.48,9a8,8,0,0,0-.65.63,1,1,0,0,0-.27.7v.22a.21.21,0,0,1,0,.12.17.17,0,0,1-.06.1.23.23,0,0,1-.1.07l-.12,0H5.53a.21.21,0,0,1-.12,0,.18.18,0,0,1-.1-.07.2.2,0,0,1-.08-.1.37.37,0,0,1,0-.12v-.35a2.68,2.68,0,0,1,.13-.84,2.91,2.91,0,0,1,.33-.66,3.38,3.38,0,0,1,.45-.55c.16-.15.33-.29.49-.42a7.84,7.84,0,0,0,.65-.64,1,1,0,0,0,.25-.67.77.77,0,0,0-.07-.34.67.67,0,0,0-.23-.27,1.16,1.16,0,0,0-.72-.24A1.61,1.61,0,0,0,6,5.61a3,3,0,0,0-.41.18A1.75,1.75,0,0,0,5.3,6l-.11.09A.5.5,0,0,1,5,6.12.31.31,0,0,1,4.74,6l-1-1.21a.3.3,0,0,1,0-.4A1.36,1.36,0,0,1,4,4.18a3.07,3.07,0,0,1,.56-.38,5.49,5.49,0,0,1,.9-.37,3.69,3.69,0,0,1,1.19-.17A3.92,3.92,0,0,1,8.93,4a2.85,2.85,0,0,1,.77.92A2.82,2.82,0,0,1,10,6.21,3,3,0,0,1,9.85,7.15Z"],
		miss: ["M13.99,12.01s.06,.08,.08,.13c.02,.05,.03,.1,.03,.15s-.01,.1-.03,.15c-.02,.05-.05,.09-.08,.13l-1.37,1.37s-.08,.06-.13,.08c-.05,.02-.1,.03-.15,.03s-.1-.01-.15-.03c-.05-.02-.09-.05-.13-.08l-3.06-3.06-3.06,3.06s-.08,.06-.13,.08c-.05,.02-.1,.03-.15,.03s-.1-.01-.15-.03c-.05-.02-.09-.05-.13-.08l-1.37-1.37c-.07-.07-.11-.17-.11-.28s.04-.2,.11-.28l3.06-3.06-3.06-3.06c-.07-.07-.11-.17-.11-.28s.04-.2,.11-.28l1.37-1.37c.07-.07,.17-.11,.28-.11s.2,.04,.28,.11l3.06,3.06,3.06-3.06c.07-.07,.17-.11,.28-.11s.2,.04,.28,.11l1.37,1.37s.06,.08,.08,.13c.02,.05,.03,.1,.03,.15s-.01,.1-.03,.15c-.02,.05-.05,.09-.08,.13l-3.06,3.06,3.06,3.06Z"]
	};

//#endregion
//#region src/page/review/classes/icon-svg.ts
	const BREAK = "\n      ";
	function buildSvg(moveClass) {
		const glyphs = CLASS_GLYPHS[moveClass].map((path) => html`<path d="${path}"/>`);
		const shadowOpacity = moveClass === "book" ? .3 : .2;
		const glyphFill = moveClass === "miss" ? "#f1f2f2" : "#fff";
		return html`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 18 19">${BREAK}<path opacity="0.3" d="M9,.5a9,9,0,1,0,9,9A9,9,0,0,0,9,.5Z"/>${BREAK}<path fill="${CLASS_COLORS[moveClass]}" d="M9,0a9,9,0,1,0,9,9A9,9,0,0,0,9,0Z"/>${BREAK}<g opacity="${shadowOpacity}" transform="translate(0 .5)">${glyphs}</g>${BREAK}<g fill="${glyphFill}">${glyphs}</g></svg>`;
	}
	const svgCache = /* @__PURE__ */ new Map();
	/** The icon as inline SVG markup. */
	function classSvg(moveClass) {
		let svg = svgCache.get(moveClass);
		if (!svg) {
			svg = buildSvg(moveClass);
			svgCache.set(moveClass, svg);
		}
		return svg;
	}
	/** The icon as a CSS image (`--cdc-class-icon` on the move list's moves, the opening's name). */
	const classImage = (moveClass) => `url("data:image/svg+xml,${encodeURIComponent(classSvg(moveClass).value)}")`;
	/** The icon in its wrapper, as the panel shows it. */
	const classIcon = (moveClass) => html`<span class="cdc-cls-icon">${classSvg(moveClass)}</span>`;

//#endregion
//#region src/page/review/view/board-badge.ts
/** Where the piece landed: the king's square for a castle, which Lichess writes as king takes rook. */
	function landingSquare(uci, san) {
		if (!san.startsWith("O-O")) return uci.slice(2, 4);
		return (san.startsWith("O-O-O") ? "c" : "g") + uci.charAt(1);
	}
	function badgeCell(square, orientation) {
		const parsed = parseSquare(square);
		const whiteAtBottom = orientation === "white";
		if (parsed) return squareOnScreen(parsed, whiteAtBottom);
		return whiteAtBottom ? [-1, NaN] : [8, NaN];
	}
	function badgeMarkup({ moveClass, uci, san, orientation }) {
		const [column, row] = badgeCell(landingSquare(uci, san), orientation);
		const style = `left:${(column + 1) * 12.5}%;top:${row * 12.5}%`;
		return html`<div class="cdc-badge" style="${style}">${classSvg(moveClass)}</div>`;
	}
	function arrow(uci, brush) {
		const orig = parseSquare(uci.slice(0, 2));
		const dest = parseSquare(uci.slice(2, 4));
		return orig && dest ? [{
			orig,
			dest,
			brush
		}] : [];
	}
	/** The best move when the one played needed a correction, and the engine's move off the game. */
	function reviewArrowsFor({ moveClass, best, engine }) {
		const arrows = moveClass && best && !GOOD.has(moveClass) ? arrow(best, "best") : [];
		if (engine) arrows.push(...arrow(engine, "engine"));
		return arrows;
	}

//#endregion
//#region src/page/review/view/eval-bar.ts
	function knownPosition(input) {
		const { review, reviewing, onMainline, ply, bestBefore, offGame } = input;
		if (input.live || !review) return null;
		if (bestBefore) return bestBefore;
		if (onMainline) return review.positions[ply] ?? null;
		return reviewing ? offGame ?? null : null;
	}
	/**
	* What the bar shows. The free board keeps Lichess's own bar. A move played
	* off the game waits a moment for the engine: the bar holds its last score
	* meanwhile, rather than vanish and shift the board over by its width.
	*/
	function barPosition(input) {
		const known = knownPosition(input);
		if (!known && input.reviewing && !input.live && input.review) return input.last;
		return known;
	}
	function drawBar(elements, position, orientation) {
		const { bar, barFill, barLabel: label } = elements;
		bar.classList.toggle("cdc-evalbar--flip", orientation === "black");
		setStyleProperty(barFill, "height", `${position.whiteWinChance}%`);
		const text = barLabel(position);
		if (label.textContent !== text) label.textContent = text;
		const className = `cdc-evalbar__label cdc-evalbar__label--${position.whiteWinChance >= 50 ? "white" : "black"}`;
		if (label.className !== className) label.className = className;
	}

//#endregion
//#region src/page/review/view/move-list.ts
	function markClass(move, moveClass, badge) {
		setData(move, "cdcCls", moveClass);
		setStyleProperty(move, "--cdc-class-color", CLASS_COLORS[moveClass]);
		setStyleProperty(move, "--cdc-class-icon", classImage(moveClass));
		setData(move, "cdcBadge", badge ? "" : null);
	}
	/** The game's moves, from the review's draft; a book badge only on the last book move. */
	function mainlineBadges(tree, review) {
		const moves = queryAll(tree, ":scope > move:not(.empty)", HTMLElement);
		for (const [i, element] of moves.entries()) {
			const move = review.draft[i];
			if (!move || element.dataset.cdcCls === move.moveClass) continue;
			const lastBook = !(move.moveClass === "book" && review.draft[i + 1]?.moveClass === "book");
			markClass(element, move.moveClass, LIST_BADGES.has(move.moveClass) && lastBook);
		}
	}
	function stripes(tree) {
		let even = false;
		for (const child of tree.children) {
			if (!(child instanceof HTMLElement)) continue;
			if (child.tagName === "INDEX") even = Number.parseInt(child.textContent, 10) % 2 === 0;
			if (child.tagName !== "INTERRUPT") setData(child, "cdcEven", even ? "" : null);
		}
	}
	function ownVariations(tree, analysis) {
		for (const line of queryAll(tree, "interrupt line", Element)) {
			const path = line.querySelector("move[p]")?.getAttribute("p");
			const own = Boolean(path) && !analysis.nodeAtPath(path ?? "").comp;
			line.classList.toggle("cdc-var", own);
		}
	}
	/** Each move's verdict as it's judged, variations included: every move carries its path. */
	function liveBadges(live, analysis, moves) {
		for (const element of moves) {
			const path = element.getAttribute("p") ?? "";
			const move = judgeAt(live, analysis, path);
			if (!move) {
				setData(element, "cdcCls", null);
				setData(element, "cdcBadge", null);
				continue;
			}
			const next = firstChild(analysis.nodeAtPath(path));
			const bookGoesOn = next !== null && bookAt(live, analysis, path + next.id) === true;
			const badge = LIST_BADGES.has(move.moveClass) && !(move.moveClass === "book" && bookGoesOn);
			if (element.dataset.cdcCls === move.moveClass && "cdcBadge" in element.dataset === badge) continue;
			markClass(element, move.moveClass, badge);
		}
	}
	const treeMoves = () => queryAll(document, "main.analyse .tview2 move[p]", HTMLElement);
	/** The review's marks on the game's move list, and on the variations played off it. */
	function reviewBadges(live, analysis, review) {
		const tree = queryOne(document, "main.analyse .tview2", Element);
		if (!tree) return;
		mainlineBadges(tree, review);
		stripes(tree);
		ownVariations(tree, analysis);
		liveBadges(live, analysis, queryAll(tree, "interrupt line.cdc-var move[p]", HTMLElement));
	}

//#endregion
//#region src/page/review/view/opening.ts
/** "Ruy Lopez: Morphy Defense": the family in bold, then the variation. */
	function openingMarkup({ name, eco }) {
		const [family = "", ...rest] = name.split(": ");
		const code = eco ? html`<span class="cdc-opening__eco">${eco}</span>` : "";
		const variation = rest.length > 0 ? html`: ${rest.join(": ")}` : "";
		return html`<i class="cdc-opening__icon"></i>${code}<span class="cdc-opening__name"><b>${family}</b>${variation}</span>`;
	}
	function shownOpening(session, analysis) {
		if (!analysis.explorerSignedIn() || session.live.noBook) return null;
		if (analysis.path) return openingAt(session.live, analysis, analysis.path);
		return {
			name: translate("startPosition", session.language.ui.startPosition),
			eco: ""
		};
	}
	function renderOpening(session, analysis) {
		const tools = queryOne(document, "main.analyse .analyse__tools", HTMLElement);
		if (!tools) return;
		const { opening: element } = session.elements;
		if (element.parentNode !== tools) tools.append(element);
		const opening = shownOpening(session, analysis);
		const key = opening ? `${opening.eco}|${opening.name}` : "";
		if (element.dataset.cdcOpening === key) return;
		setData(element, "cdcOpening", key);
		document.documentElement.classList.toggle("cdc-opening-on", opening !== null);
		if (!opening) {
			element.replaceChildren();
			return;
		}
		element.title = opening.name;
		setStyleProperty(element, "--cdc-class-icon", classImage("book"));
		setHtml(element, openingMarkup(opening));
	}

//#endregion
//#region src/page/review/view/board.ts
	function renderBar(session, analysis, shown) {
		const { view, live } = session;
		const reviewing = view.mode !== "normal";
		const position = barPosition({
			review: view.review,
			reviewing,
			live: view.mode === "live",
			onMainline: analysis.onMainline,
			ply: analysis.node.ply,
			bestBefore: shown?.before ?? null,
			offGame: live.evals.get(analysis.node.fen),
			last: view.barPosition
		});
		view.barPosition = reviewing ? position : null;
		document.documentElement.classList.toggle("cdc-evalbar-on", position !== null);
		if (position) drawBar(session.elements, position, analysis.orientation());
	}
	function boardMove(session, analysis, shown) {
		const { mode } = session.view;
		if (!session.wide.matches) return null;
		if (mode === "live") return judgeAt(session.live, analysis, analysis.path);
		if (shown) return {
			...shown,
			moveClass: "best"
		};
		return mode === "normal" ? null : reviewMove(session, analysis);
	}
	const sameArrows = (drawn, next) => JSON.stringify(drawn) === JSON.stringify(next);
	function renderBadge(session, analysis, move) {
		const { view, elements } = session;
		const { node } = analysis;
		const badge = move ? badgeMarkup({
			moveClass: move.moveClass,
			uci: node.uci ?? "",
			san: node.san ?? "",
			orientation: analysis.orientation()
		}) : null;
		const markup = badge?.value ?? "";
		if (view.overlay === markup) return;
		view.overlay = markup;
		if (badge) setHtml(elements.overlay, badge);
		else elements.overlay.replaceChildren();
	}
	function renderArrows(session, analysis, move) {
		const { view, live } = session;
		const offGame = session.wide.matches && view.mode !== "normal" && view.review !== null && !analysis.onMainline;
		const arrows = reviewArrowsFor({
			moveClass: move?.moveClass ?? null,
			best: move?.best ?? null,
			engine: offGame ? live.evals.get(analysis.node.fen)?.best ?? null : null
		});
		if (!sameArrows(reviewArrows(), arrows)) setReviewArrows(arrows);
	}
	function renderBoard(session, analysis) {
		const { view, live } = session;
		const shown = view.mode === "live" ? null : bestShown(session, analysis);
		renderBar(session, analysis, shown);
		const move = boardMove(session, analysis, shown);
		setData(document.documentElement, "cdcCls", move ? move.moveClass : "");
		renderBadge(session, analysis, move);
		renderArrows(session, analysis, move);
		if (view.mode === "live") {
			liveBadges(live, analysis, treeMoves());
			renderOpening(session, analysis);
		} else if (view.review) reviewBadges(live, analysis, view.review);
	}

//#endregion
//#region src/page/review/view/bubble.ts
	let sizes = null;
	function onResize(entries) {
		for (const entry of entries) {
			const size = entry.borderBoxSize[0];
			if (entry.target instanceof HTMLElement && size) setStyleProperty(entry.target, "--cdc-bubble-h", `${size.blockSize}px`);
		}
	}
	function fitBubble(panel) {
		sizes ??= new ResizeObserver(onResize);
		sizes.disconnect();
		const bubble = queryOne(panel, ".cdc-bubble", HTMLElement);
		if (bubble) sizes.observe(bubble);
	}

//#endregion
//#region src/page/review/view/closed-panel.ts
	function countsLine(session, analysis) {
		const { view, language } = session;
		const { review } = view;
		if (view.error) return html`<span class="cdc-review__progress">${view.error}</span>`;
		if (!review?.complete) return html`<span class="cdc-review__progress">${language.ui.analysing} ${Math.round(view.progress * 100)}%</span>`;
		const counts = review.counts[analysis.orientation()];
		const shown = COUNTED.flatMap((moveClass) => {
			const count = counts[moveClass];
			return count ? [html`<span class="cdc-review__count" style="color:${CLASS_COLORS[moveClass]}">${classIcon(moveClass)}${language.countLabel(moveClass, count)}</span>`] : [];
		});
		return html`${shown}`;
	}
	function renderClosed(session, analysis) {
		const { ui } = session.language;
		setHtml(session.elements.panel, html`<div class="cdc-review__counts">${countsLine(session, analysis)}</div>
      <button class="cdc-btn cdc-btn--green cdc-review__open" data-cdc="summary"><span class="cdc-review__star">★</span>${ui.review}</button>`);
	}

//#endregion
//#region src/page/review/view/graph-markup.ts
/**
	* The last position's index. `total` (positions in the game) spaces the graph
	* for the whole game while its analysis fills in: an unknown position is a gap.
	*/
	const lastIndex = (review) => (review.total || review.positions.length) - 1;
	/** Runs of consecutive known positions, as their indexes. */
	function knownRuns(positions) {
		const runs = [];
		for (const [i, position] of positions.entries()) {
			if (!position) continue;
			const run = positions[i - 1] ? runs.at(-1) : void 0;
			if (run) run.push(i);
			else runs.push([i]);
		}
		return runs;
	}
	function graphMarkup(review, ply, { width, height }) {
		const span = lastIndex(review) || 1;
		const x = (index) => (index / span * width).toFixed(1);
		const y = (winChance) => (height - clamp(winChance, 0, 100) / 100 * height).toFixed(1);
		const winChanceAt = (index) => review.positions[index]?.whiteWinChance ?? 0;
		const area = knownRuns(review.positions).map((run) => {
			const points = run.map((index) => `${x(index)},${y(winChanceAt(index))}`).join(" L");
			return `M${x(run[0] ?? 0)},${height} L${points} L${x(run.at(-1) ?? 0)},${height} Z`;
		}).join(" ");
		const dots = review.draft.flatMap((move) => move && GRAPH_DOTS.has(move.moveClass) && review.positions[move.ply] ? [html`<circle cx="${x(move.ply)}" cy="${y(winChanceAt(move.ply))}" r="3.5" fill="${CLASS_COLORS[move.moveClass]}"/>`] : []);
		const marker = ply > 0 ? html`<line x1="${x(ply)}" x2="${x(ply)}" y1="0" y2="${height}" stroke="#bd93f9" stroke-width="2"/>` : "";
		return html`<svg width="${width}" height="${height}" viewBox="0 0 ${width} ${height}">
      <rect width="${width}" height="${height}" fill="#21222c"/>
      <path d="${area}" fill="#fff"/>
      <line x1="0" x2="${width}" y1="${height / 2}" y2="${height / 2}" stroke="#6272a4" stroke-width="1" opacity="0.6"/>
      ${marker}${dots}</svg>`;
	}

//#endregion
//#region src/page/review/view/graph.ts
	function measure(container) {
		const style = getComputedStyle(container);
		const padX = Number.parseFloat(style.paddingLeft) + Number.parseFloat(style.paddingRight);
		const padY = Number.parseFloat(style.paddingTop) + Number.parseFloat(style.paddingBottom);
		return {
			padX,
			width: Math.max(100, Math.floor(container.clientWidth - padX)),
			height: Math.max(40, Math.floor(container.clientHeight - padY))
		};
	}
	/** The position under the pointer's x, from the graph's left edge. */
	function indexAt(pointerX, box, last) {
		return clamp(Math.round((pointerX - box.padX / 2) / box.width * last), 0, last);
	}
	const drawn = /* @__PURE__ */ new WeakMap();
	function pointedIndex(container, { review, box }, event) {
		return indexAt(event.clientX - container.getBoundingClientRect().left, box, lastIndex(review));
	}
	function hover(container, event) {
		const graph = drawn.get(container);
		if (!graph) return;
		const { tip, review, box } = graph;
		const index = pointedIndex(container, graph, event);
		const position = review.positions[index];
		if (!position) {
			setStyleProperty(tip, "display", "none");
			return;
		}
		tip.textContent = formatEval(position) || "0.00";
		setStyleProperty(tip, "display", "block");
		const x = box.padX / 2 + index / (lastIndex(review) || 1) * box.width;
		const right = container.clientWidth - box.padX / 2 - tip.offsetWidth;
		const left = clamp(x - tip.offsetWidth / 2, box.padX / 2, right);
		setStyleProperty(tip, "left", `${left}px`);
	}
	function listen(container) {
		container.addEventListener("mousemove", (event) => hover(container, event));
		container.addEventListener("mouseleave", () => {
			const graph = drawn.get(container);
			if (graph) setStyleProperty(graph.tip, "display", "none");
		});
		container.addEventListener("click", (event) => {
			const graph = drawn.get(container);
			if (graph) graph.pick(pointedIndex(container, graph, event));
		});
	}
	function mountGraph(session, analysis, { container, kind }) {
		const { view } = session;
		const review = view.review;
		if (!review) return;
		const box = measure(container);
		setHtml(container, html`${graphMarkup(review, analysis.node.ply, box)}<span class="cdc-graph-tip"></span>`);
		if (!view.revealed.has(kind)) {
			view.revealed.add(kind);
			container.firstElementChild?.classList.add("cdc-graph-reveal");
		}
		const tip = container.lastElementChild;
		if (!(tip instanceof HTMLElement)) return;
		const pick = (index) => {
			stopPlaying(session);
			jump(analysis, index);
			if (view.mode === "summary") session.setMode("moves");
		};
		if (!drawn.has(container)) listen(container);
		drawn.set(container, {
			tip,
			review,
			box,
			pick
		});
	}
	/** The move-by-move graph, drawn again only as the analysis fills it in (or when forced). */
	function movesGraph(session, analysis, force = false) {
		const { graphBox } = session.elements;
		const { review, version } = session.view;
		if (!review) {
			graphBox.replaceChildren();
			return;
		}
		if (!force && graphBox.dataset.cdcVersion === String(version)) return;
		setData(graphBox, "cdcVersion", String(version));
		mountGraph(session, analysis, {
			container: graphBox,
			kind: "moves"
		});
	}

//#endregion
//#region src/page/review/view/markup.ts
	const ICON_PATHS = {
		first: "<path d=\"M5 4h3v16H5zM20 4v16L9 12z\"/>",
		prev: "<path d=\"M15.6 3.5 7.1 12l8.5 8.5 2.3-2.3-6.2-6.2 6.2-6.2z\"/>",
		play: "<path d=\"M7 3.5v17L20.5 12z\"/>",
		pause: "<path d=\"M6 4h4.5v16H6zM13.5 4H18v16h-4.5z\"/>",
		next: "<path d=\"M8.4 3.5 16.9 12l-8.5 8.5-2.3-2.3 6.2-6.2-6.2-6.2z\"/>",
		last: "<path d=\"M16 4h3v16h-3zM4 4v16l11-8z\"/>",
		star: "<path d=\"M12 2.5a9.5 9.5 0 1 0 0 19 9.5 9.5 0 0 0 0-19zm0 2a7.5 7.5 0 1 1 0 15 7.5 7.5 0 0 1 0-15zm0 2.2-1.6 3.6-3.9.4 2.9 2.6-.8 3.9 3.4-2 3.4 2-.8-3.9 2.9-2.6-3.9-.4z\"/>",
		bulb: "<path d=\"M12 2a7 7 0 0 0-4 12.74V17a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1v-2.26A7 7 0 0 0 12 2zM9 19.5h6V21a1 1 0 0 1-1 1h-4a1 1 0 0 1-1-1z\"/>",
		arrow: "<path d=\"M3 10.5h13.1l-5.3-5.3L13 3l9 9-9 9-2.2-2.2 5.3-5.3H3z\"/>"
	};
	const svgIcon = (name) => html`<svg class="cdc-i" viewBox="0 0 24 24" fill="currentColor" fill-rule="evenodd">${trustedHtml(ICON_PATHS[name])}</svg>`;
	const strokeIcon = (path) => html`<svg viewBox="0 0 24 24" aria-hidden="true"><path d="${path}" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
	const BACK_ICON = strokeIcon("M19 12H5M11 5l-7 7 7 7");
	const CLOSE_ICON = strokeIcon("M6 6l12 12M18 6 6 18");
	const CHEVRON_ICON = strokeIcon("M6 9l6 6 6-6");
	/** The panel's header; `back` is the mode its back button returns to, null for none. */
	function header(title, back, language) {
		const { ui } = language;
		const backButton = back === null ? trustedHtml("<span></span>") : html`<button class="cdc-review__back" data-cdc="${back}" data-cdc-tip="${ui.back}" aria-label="${ui.back}">${BACK_ICON}</button>`;
		return html`<div class="cdc-review__head">
      ${backButton}
      <div class="cdc-review__title"><span class="cdc-review__star">★</span>${title}</div>
      <button class="cdc-review__close" data-cdc="normal" data-cdc-tip="${ui.close}" aria-label="${ui.close}">${CLOSE_ICON}</button>
    </div>`;
	}
	function blackIsBetter(record) {
		if (!record) return false;
		if ("mate" in record) return record.mate < 0 || record.mate === 0 && record.whiteWinChance < 50;
		return record.cp < 0;
	}
	/** The score, dark when Black is better. */
	const evalChip = (record) => html`<span class="cdc-bubble__eval${blackIsBetter(record) ? " cdc-bubble__eval--black" : ""}">${formatEval(record)}</span>`;
	const bubbleTitle = (text) => html`<p class="cdc-bubble__title">${text}</p>`;

//#endregion
//#region src/page/review/coach/context.ts
/** The seed of a move's picks: stable across redraws. */
	const moveSeed = (move, { gameId, coach }) => `${gameId}:${move.ply}:${move.uci}:${coach}`;

//#endregion
//#region src/page/review/coach/trajectory.ts
	function winLevel(winChance) {
		if (winChance >= 90) return 3;
		if (winChance >= 70) return 2;
		return winChance >= 58 ? 1 : 0;
	}
	function lossLevel(winChance) {
		if (winChance <= 10) return 3;
		if (winChance <= 30) return 2;
		return winChance <= 42 ? 1 : 0;
	}
	/** White's view of a position, from -4 (Black mates) to 4 (White mates). */
	function evaluationLevel(record) {
		if ("mate" in record) return record.mate > 0 || record.mate === 0 && record.whiteWinChance > 50 ? 4 : -4;
		return winLevel(record.whiteWinChance) - lossLevel(record.whiteWinChance);
	}
	/** "a clear advantage", or "a mate in 3" when there's a mate to count. */
	function advantageName(level, record, language) {
		const { advantages, mateIn } = language.trajectory;
		if (Math.abs(level) === 4 && "mate" in record && record.mate !== 0) return mateIn(Math.abs(record.mate));
		return advantages[Math.abs(level)] ?? "";
	}
	const sideOf = (level) => level > 0 ? "white" : "black";
	function trajectory(input, language) {
		const sentences = language.trajectory;
		const levelBefore = evaluationLevel(input.before);
		const levelAfter = evaluationLevel(input.after);
		const before = {
			side: sideOf(levelBefore),
			advantage: advantageName(levelBefore, input.before, language)
		};
		const after = {
			side: sideOf(levelAfter),
			advantage: advantageName(levelAfter, input.after, language)
		};
		if (levelBefore === levelAfter) {
			const same = levelAfter === 0 ? sentences.stillBalanced : sentences.stillAhead(after);
			return same[input.seed % same.length] ?? "";
		}
		if (levelBefore === 0) return sentences.wasBalanced(after, after.side === input.mover);
		if (levelAfter === 0) return sentences.nowBalanced(before);
		if (after.side !== before.side) return sentences.swings(before, after);
		return Math.abs(levelAfter) > Math.abs(levelBefore) ? sentences.grows(after.side, before.advantage, after.advantage) : sentences.shrinks(after.side, before.advantage, after.advantage);
	}

//#endregion
//#region src/page/review/coach/fact.ts
	const PUNISHERS = /* @__PURE__ */ new Set([
		"brilliant",
		"great",
		"best"
	]);
	const PUNISHED = /* @__PURE__ */ new Set([
		"mistake",
		"blunder",
		"miss"
	]);
	/** Whether the side of `sign` has a mate on the board. */
	const mates = (record, sign) => "mate" in record && record.mate * sign > 0;
	const mateDistance = (record) => "mate" in record ? record.mate : 0;
	function lostPieceFact(input, reply, replySan) {
		const { move, facts, me, them, after } = input;
		const square = parseSquare(reply.slice(2, 4));
		const victim = square ? after.get(square) : void 0;
		if (!square || !victim || victim.color !== me || victim.role === "king") return null;
		if (move.loss < 10 || PIECE_VALUES[victim.role] < 3) return null;
		const lost = {
			piece: victim,
			square: squareToken(square),
			reply: replySan
		};
		if (attackers(after, square, me).length === 0) return facts.leftUndefended(lost);
		if (Math.min(...attackerValues(after, square, them)) < PIECE_VALUES[victim.role]) return facts.answersAndWins(them, lost);
		return null;
	}
	function mateFact(input, replySan) {
		const { move, facts, them, sign, best } = input;
		if (mates(move.after, -sign) && !mates(move.before, -sign) && replySan) return facts.canForceMate(them, replySan);
		if (mates(move.before, sign) && !mates(move.after, sign) && best) return facts.wouldForceMate(best, Math.abs(mateDistance(move.before)));
		return null;
	}
	function errorFact(input) {
		const { move, facts, them, before, best } = input;
		const reply = move.after.best;
		const replySan = reply ? moveToken(uciToSan(move.position.fen, reply), them) : "";
		const mate = mateFact(input, replySan);
		if (mate !== null) return mate;
		if (move.moveClass === "miss" && best) return facts.missedPunishment(them, best);
		const lost = reply ? lostPieceFact(input, reply, replySan) : null;
		if (lost !== null) return lost;
		if (!best) return null;
		const taken = move.best ? pieceOn(before, move.best.slice(2, 4)) : void 0;
		if (taken?.color === them && taken.role !== "pawn") return facts.strongerCapture(best, taken);
		return move.moveClass === "inaccuracy" ? facts.morePrecise(best) : facts.betterMove(best);
	}
	function captureFact(input, moved, dest) {
		const { move, facts, me, them, before } = input;
		const square = parseSquare(dest);
		if (!square) return null;
		const victim = {
			role: before.get(square)?.role ?? "pawn",
			color: them
		};
		const previous = move.previousPosition;
		if (previous.san?.includes("x") && previous.uci?.slice(2, 4) === dest) return facts.takesBack(squareToken(dest));
		if (attackers(before, square, them).length === 0) return facts.winsForFree(victim);
		if (PIECE_VALUES[victim.role] > PIECE_VALUES[moved.role]) return facts.winsMaterial(victim, {
			role: moved.role,
			color: me
		});
		return null;
	}
	function standoutFact(input, moved) {
		const { move, facts, me, them, sign } = input;
		const previousClass = move.previousMove?.moveClass;
		if (PUNISHERS.has(move.moveClass) && previousClass !== void 0 && PUNISHED.has(previousClass)) return facts.punishesAtOnce(them);
		if (move.moveClass === "brilliant" && moved) return facts.offered({
			role: moved.role,
			color: me
		}, them);
		if (move.moveClass === "great") return evaluationLevel(move.after) * sign >= 2 ? facts.keepsAdvantage : facts.holdsPosition(me);
		return null;
	}
	function goodFact(input) {
		const { move, facts, me, them, after, best } = input;
		const dest = move.uci.slice(2, 4);
		const moved = pieceOn(after, dest);
		const standout = standoutFact(input, moved);
		if (standout !== null) return standout;
		const promotion = roleOfLetter(/=([QRBN])/.exec(move.san)?.[1] ?? "");
		if (promotion) return facts.promotes({
			role: promotion,
			color: me
		});
		if (move.san.startsWith("O-O")) return facts.castles;
		const capture = moved && move.san.includes("x") ? captureFact(input, moved, dest) : null;
		if (capture !== null) return capture;
		if (move.san.includes("+")) return facts.checkForces(them);
		return move.moveClass === "good" && best ? facts.littleMorePrecise(best) : null;
	}
	/** One fact about the move, or null when there's nothing concrete to say. */
	function fact(move, facts) {
		const me = move.color;
		const them = opposite(me);
		const sign = me === "white" ? 1 : -1;
		if (move.san.includes("#")) return facts.checkmate(them);
		const best = move.bestSan ? moveToken(move.bestSan, me) : "";
		if (move.slower && best) return mates(move.before, sign) ? facts.matedIn(best, mateDistance(move.before) * sign) : facts.heldOutLonger(best);
		const input = {
			move,
			facts,
			me,
			them,
			sign,
			before: parseFen(move.previousPosition.fen).board,
			after: parseFen(move.position.fen).board,
			best
		};
		return isError(move.moveClass) ? errorFact(input) : goodFact(input);
	}

//#endregion
//#region src/page/review/coach/hash.ts
/** FNV-1a over UTF-16 code units: a stable pick for a game, a move and a coach. */
	function hash(text) {
		let value = 2166136261;
		for (let i = 0; i < text.length; i++) value = Math.imul(value ^ text.charCodeAt(i), 16777619);
		return value >>> 0;
	}

//#endregion
//#region src/page/review/coach/remark.ts
	function signedMate(record, sign) {
		return "mate" in record ? record.mate * sign : null;
	}
	function overridingPool(move, pools) {
		const sign = move.color === "white" ? 1 : -1;
		const mateAfter = signedMate(move.after, sign);
		if (move.san.includes("#")) return pools.mate;
		if (isError(move.moveClass) && mateAfter !== null && mateAfter < 0) return pools.allowsMate;
		if ((signedMate(move.before, sign) ?? 0) > 0) return (mateAfter ?? 0) > 0 ? pools.mating : pools.missedMate;
		return null;
	}
	function situationPool(move, pools) {
		const { san } = move;
		const winChance = forColor(move.after.whiteWinChance, move.color);
		const pool = [];
		if (!isError(move.moveClass)) {
			if (san.startsWith("O-O")) pool.push(...pools.castle);
			if (san.includes("=Q")) pool.push(...pools.promote);
			if (san.includes("+")) pool.push(...pools.check);
			if (san.includes("x")) pool.push(...pools.capture);
			if (winChance >= 90) pool.push(...pools.winning);
			return pool;
		}
		if (san.includes("x")) pool.push(...pools.badCapture);
		if (san.startsWith("Q") && move.position.ply <= 12) pool.push(...pools.earlyQueen);
		if (san.startsWith("K") && move.position.ply <= 20) pool.push(...pools.earlyKing);
		if (winChance <= 10) pool.push(...pools.losing);
		return pool;
	}
	function remark(move, context) {
		const { remarks, typography } = context.language;
		const seed = moveSeed(move, context);
		const situations = situationPool(move, remarks);
		const pool = overridingPool(move, remarks) ?? (situations.length > 0 && hash(`${seed}:ctx`) % 2 === 1 ? situations : remarks[move.moveClass]);
		return typography(pool[hash(seed) % pool.length] ?? "");
	}

//#endregion
//#region src/page/review/coach/explanation.ts
	const say$1 = (text, droppable = false) => ({
		text,
		droppable
	});
	/**
	* The coach's comment on a move: how the evaluation moved, and one fact from
	* the board and the engine, or a remark when a good move has nothing concrete
	* to say. The trajectory is what's dropped when the bubble lacks room.
	* `opening` names a book move's opening ('' for none).
	*/
	function explanation(move, context, opening) {
		const { language } = context;
		if (move.moveClass === "book") return [say$1(remark(move, context)), ...opening ? [say$1(language.openingLine(opening), true)] : []];
		const found = fact(move, language.facts);
		if (move.san.includes("#")) return [say$1(found ?? "")];
		const seed = hash(`${moveSeed(move, context)}:t`);
		const course = trajectory({
			before: move.before,
			after: move.after,
			mover: move.color,
			seed
		}, language);
		if (isError(move.moveClass)) return found === null ? [say$1(course)] : [say$1(course, true), say$1(found)];
		return [say$1(found ?? remark(move, context)), say$1(course, true)];
	}

//#endregion
//#region src/page/review/comment/markup.ts
	const commentKey = (parts) => parts.map((part) => part.text).join("|");
	/** The stream for `parts`: the same one, or a fresh one for a new comment. */
	function streamFor(stream, parts) {
		const key = commentKey(parts);
		return key === stream.key ? stream : {
			key,
			shown: 0,
			dropped: false
		};
	}
	const TOKEN = /\[\[(\w):(.+?)\]\]/g;
	const PIECE_LETTER = /^[KQRBN]/;
	const pieceImage = (assets, piece) => html`<img class="cdc-pc" alt="" src="${assets}img/pieces/neo/${piece}.webp">`;
	function movedRole(san) {
		if (san.startsWith("O-O")) return "k";
		return PIECE_LETTER.test(san) ? san.charAt(0).toLowerCase() : "p";
	}
	function moveChip(assets, value) {
		const color = value.charAt(0);
		const san = value.slice(2).replace(PIECE_LETTER, "");
		const promotion = /=([QRBN])/.exec(san);
		const text = promotion === null ? html`${san}` : html`${san.slice(0, promotion.index)}=${pieceImage(assets, color + (promotion[1] ?? "").toLowerCase())}${san.slice(promotion.index + promotion[0].length)}`;
		return html`<span class="cdc-mv">${pieceImage(assets, color + movedRole(value.slice(2)))}${text}</span>`;
	}
	function tokenMarkup(assets, kind, value) {
		if (kind === "p") return pieceImage(assets, value);
		if (kind === "s") return html`<b class="cdc-sq">${value}</b>`;
		if (kind === "n") {
			const [number = "", move = ""] = value.split(/:(.*)/);
			return html`<span class="cdc-num">${number} ${moveChip(assets, move)}</span>`;
		}
		return moveChip(assets, value);
	}
	/** A word, its tokens drawn. */
	function wordMarkup(word, assets) {
		const pieces = [];
		let from = 0;
		for (const match of word.matchAll(TOKEN)) {
			pieces.push(html`${word.slice(from, match.index)}`, tokenMarkup(assets, match[1] ?? "", match[2] ?? ""));
			from = match.index + match[0].length;
		}
		return html`${pieces}${word.slice(from)}`;
	}
	function commentMarkup(parts, options) {
		const { stream, assets, language } = options;
		let index = 0;
		const sentences = parts.filter((part) => !(part.droppable && stream.dropped)).map((part) => {
			const spans = (language.typography(part.text).match(/\S+\s*/g) ?? []).map((word) => {
				const hidden = index++ >= stream.shown;
				return html`<span class="cdc-w${hidden ? " cdc-w--off" : ""}">${wordMarkup(word, assets)}</span>`;
			});
			return html`<span class="cdc-say${part.droppable ? " cdc-say--drop" : ""}">${spans} </span>`;
		});
		return html`${sentences}`;
	}

//#endregion
//#region src/page/review/comment/title.ts
	const FIGURINES = {
		K: "♚",
		Q: "♛",
		R: "♜",
		B: "♝",
		N: "♞"
	};
	function sanMarkup(san) {
		const pieces = san.split(/([KQRBN])/).map((text, i) => i % 2 === 1 ? html`<span class="cdc-fig">${FIGURINES[text] ?? text}</span>` : html`${text}`);
		return html`${pieces}`;
	}
	function verdictTitle(moveClass, san, language) {
		const sentence = language.typography(language.classSentences[moveClass]);
		const at = sentence.indexOf("{m}");
		if (at < 0) return html`${sentence}`;
		return html`${sentence.slice(0, at)}${sanMarkup(san)}${sentence.slice(at + 3)}`;
	}

//#endregion
//#region src/page/review/view/verdict.ts
/** The extension's base URL, set on <html> by the content script at document_start. */
	const assetsUrl = () => document.documentElement.dataset.cdcAssets ?? "";
	const coachContext = (session, gameId) => ({
		gameId,
		coach: session.coach.id,
		language: session.language
	});
	/**
	* A book move's opening: its own, or else the game's, named on the move that
	* reaches it. The export names only the game's last book position.
	*/
	const openingOf = (session, move) => move.opening ?? (move.ply === session.work.bookPly ? session.view.openingName : "");
	/** The coach's comment on a move, or Explain's hint in its place. */
	function commentOn(session, { move, gameId, hint }) {
		return {
			move,
			parts: hint.length > 0 ? hint : explanation(move, coachContext(session, gameId), openingOf(session, move))
		};
	}
	/** Keeps the typing going through the renders of one comment; a new comment starts it over. */
	function followComment(session, { parts }) {
		session.stream.state = streamFor(session.stream.state, parts);
	}
	/** The verdict's bubble, its comment typed out as far as the typing has got. */
	function verdictMarkup(session, { move, parts }) {
		const { language, stream } = session;
		const comment = commentMarkup(parts, {
			stream: stream.state,
			assets: assetsUrl(),
			language
		});
		return html`<div class="cdc-bubble__row">${classIcon(move.moveClass)}
      <p class="cdc-bubble__title">${verdictTitle(move.moveClass, move.san, language)}</p>
      ${evalChip(move.after)}</div>
    <p class="cdc-bubble__sub">${comment}</p>`;
	}

//#endregion
//#region src/page/review/view/live-panel.ts
	function liveBubble(session, analysis, comment) {
		const { live, language } = session;
		if (live.error) return bubbleTitle(live.error);
		if (!analysis.path) return bubbleTitle(language.ui.liveIntro);
		if (!comment) return bubbleTitle(language.ui.thinking);
		return verdictMarkup(session, comment);
	}
	function renderLive(session, analysis) {
		const { live, language } = session;
		const move = judgeAt(live, analysis, analysis.path);
		const comment = move && !live.error ? commentOn(session, {
			move,
			gameId: analysis.gameId,
			hint: []
		}) : null;
		if (comment) followComment(session, comment);
		const bubble = liveBubble(session, analysis, comment);
		const moveClass = live.error ? null : move?.moveClass ?? null;
		const avatar = avatarMarkup({
			coachId: session.coach.id,
			moveClass,
			react: takeReaction(session.coach, moveClass, analysis.path),
			label: language.ui.coach
		});
		setHtml(session.elements.panel, html`<div class="cdc-coach">${avatar}<div class="cdc-bubble">${bubble}</div></div>`);
	}

//#endregion
//#region src/page/review/chess/line.ts
	function castle(board, king, from, to) {
		const [fromFile, rank] = squareCoords(from);
		const target = board.get(to);
		const ontoRook = target?.role === "rook" && target.color === king.color;
		const kingside = squareCoords(to)[0] > fromFile;
		const rookFrom = ontoRook ? to : squareAt(kingside ? 7 : 0, rank);
		const rook = rookFrom ? board.get(rookFrom) : void 0;
		board.delete(from);
		if (rookFrom) board.delete(rookFrom);
		const kingTo = squareAt(kingside ? 6 : 2, rank);
		const rookTo = squareAt(kingside ? 5 : 3, rank);
		if (kingTo) board.set(kingTo, king);
		if (rookTo && rook) board.set(rookTo, rook);
	}
	/** The board after a move in the engine's notation. */
	function boardAfter(board, uci) {
		const next = new Map(board);
		const from = parseSquare(uci.slice(0, 2));
		const to = parseSquare(uci.slice(2, 4));
		const piece = from ? next.get(from) : void 0;
		if (!from || !to || !piece) return next;
		const [fromFile, fromRank] = squareCoords(from);
		const toFile = squareCoords(to)[0];
		const target = next.get(to);
		const ontoOwnRook = target?.role === "rook" && target.color === piece.color;
		if (piece.role === "king" && (Math.abs(toFile - fromFile) >= 2 || ontoOwnRook)) {
			castle(next, piece, from, to);
			return next;
		}
		const passed = squareAt(toFile, fromRank);
		if (piece.role === "pawn" && fromFile !== toFile && !target && passed) next.delete(passed);
		next.delete(from);
		const promotion = roleOfLetter(uci.charAt(4));
		next.set(to, promotion ? {
			color: piece.color,
			role: promotion
		} : piece);
		return next;
	}
	/** The moves of `line`, played from `fen`. */
	function lineMoves(fen, line) {
		let board = parseFen(fen).board;
		let color = fenTurn(fen);
		let number = Number(fen.split(" ")[5]) || 1;
		const moves = [];
		for (const uci of line) {
			moves.push({
				san: sanOn(board, uci),
				color,
				number
			});
			board = boardAfter(board, uci);
			if (color === "black") number++;
			color = opposite(color);
		}
		return moves;
	}

//#endregion
//#region src/page/review/view/explain-hint.ts
	const say = (text, droppable = false) => ({
		text,
		droppable
	});
	/** A line written from `fen`, cut to `plies`. */
	const written = (fen, line, plies) => lineToken(lineMoves(fen, line.slice(0, plies)));
	function linesHint(session, move) {
		const { ui } = session.language;
		const lines = explainLines(session, move);
		const best = lines && lines.best.length > 1 ? lines.best : null;
		const bestPart = best ? ui.lines.best(written(move.previousPosition.fen, best, 4)) : ui.bestWas(moveToken(move.bestSan, move.color));
		const punishment = lines?.punishment;
		if (!punishment) return [say(bestPart)];
		const line = written(move.position.fen, punishment, 3);
		return [say(bestPart), say(ui.lines.allows(moveToken(move.san, move.color), line), true)];
	}
	/** Explain's sentences for `move`, none when it has nothing to add to the comment. */
	function explainHint(session, move) {
		if (move.moveClass === "book") {
			const opening = openingOf(session, move);
			return opening ? [say(opening)] : [];
		}
		return bestRequest(move) && move.bestSan ? linesHint(session, move) : [];
	}

//#endregion
//#region src/page/review/view/moves-panel.ts
	function bubbleMarkup(session, analysis, { comment, shown }) {
		const { view, live, language } = session;
		const { ui } = language;
		if (!view.review) return bubbleTitle(`${ui.analysing} ${Math.round(view.progress * 100)}%`);
		if (shown) return html`<div class="cdc-bubble__row">${classIcon("best")}
          <p class="cdc-bubble__title">${verdictTitle("best", analysis.node.san ?? "", language)}</p>
          ${evalChip(shown.before)}</div>`;
		if (!comment) {
			const error = analysis.onMainline ? view.error : live.error;
			return bubbleTitle(analysis.path ? error ?? ui.thinking : ui.intro);
		}
		return verdictMarkup(session, comment);
	}
	/** What the coach says of the move on the board, when the bubble shows its verdict. */
	function movesComment(session, analysis, { move, shown }) {
		if (!session.view.review || shown || !move) return null;
		const hint = session.view.explain ? explainHint(session, move) : [];
		return commentOn(session, {
			move,
			gameId: analysis.gameId,
			hint
		});
	}
	/** Under Explain's lines, the button that plays the best one on the board, or goes back. */
	function lineButton(session, analysis, move) {
		const { view, language } = session;
		const onLine = lineShown(session, analysis) !== null;
		const best = move && explainLines(session, move)?.best;
		if (!view.explain || !best || best.length < 2 || !analysis.canPlayUci) return html``;
		const label = onLine ? html`${svgIcon("prev")}${language.ui.back}` : html`${svgIcon("play")}${language.ui.lines.show}`;
		return html`<button class="cdc-bubble__line" data-cdc="line">${label}</button>`;
	}
	/** The player's controls, each drawn with the icon of its name. */
	const CONTROLS = [
		"first",
		"prev",
		"play",
		"next",
		"last"
	];
	function controlsMarkup(playing) {
		const buttons = CONTROLS.map((action) => {
			return html`<button class="cdc-btn" data-cdc="${action}">${svgIcon(action === "play" && playing ? "pause" : action)}</button>`;
		});
		return html`${buttons}`;
	}
	function scrollMoveList() {
		const box = queryOne(document, "main.analyse .analyse__moves", HTMLElement);
		const active = box && queryOne(box, "move.active", HTMLElement);
		if (!box || !active) return;
		box.scrollTop = active.getBoundingClientRect().top - box.getBoundingClientRect().top + box.scrollTop - box.clientHeight / 2 + active.offsetHeight / 2;
	}
	function coachMarkup(session, analysis, spoken) {
		const { line, move, shown, comment } = spoken;
		const moveClass = shown ? null : move?.moveClass ?? null;
		const avatar = avatarMarkup({
			coachId: session.coach.id,
			moveClass,
			react: takeReaction(session.coach, moveClass, line ? line.path : analysis.path),
			label: session.language.ui.coach
		});
		const bubble = bubbleMarkup(session, analysis, {
			comment,
			shown
		});
		const button = comment ? lineButton(session, analysis, move) : "";
		return html`<div class="cdc-coach">${avatar}<div class="cdc-bubble">${bubble}${button}</div></div>`;
	}
	function navMarkup(session, analysis, spoken) {
		const { view, language } = session;
		const { ui } = language;
		const { line, move, shown } = spoken;
		const atEnd = !stepPath(session, analysis, 1);
		const canBest = !line && (shown !== null || move?.best && !GOOD.has(move.moveClass));
		return html`<div class="cdc-review__nav">
        <button class="cdc-btn${view.explain ? " cdc-btn--on" : ""}" data-cdc="explain">${svgIcon("bulb")}${ui.explain}</button>
        <button class="cdc-btn${shown ? " cdc-btn--on" : ""}" data-cdc="best" ${canBest ? "" : "disabled"}>${svgIcon("star")}${ui.best}</button>
        <button class="cdc-btn cdc-btn--green" data-cdc="next" ${atEnd ? "disabled" : ""}>${svgIcon("arrow")}${ui.next}</button>
      </div>`;
	}
	function renderMoves(session, analysis) {
		const { view, language, elements } = session;
		const line = lineShown(session, analysis);
		const move = spokenMove(session, analysis);
		const shown = line ? null : bestShown(session, analysis);
		const comment = movesComment(session, analysis, {
			move,
			shown
		});
		if (comment) followComment(session, comment);
		const spoken = {
			line,
			move,
			shown,
			comment
		};
		setHtml(elements.panel, html`${header(language.ui.review, "summary", language)}
      ${coachMarkup(session, analysis, spoken)}
      ${navMarkup(session, analysis, spoken)}`);
		setHtml(elements.controls, controlsMarkup(view.playing !== null));
		movesGraph(session, analysis, true);
		requestAnimationFrame(scrollMoveList);
	}

//#endregion
//#region src/page/review/view/render-key.ts
	function progressKey(session, analysis) {
		const { view } = session;
		if (view.mode === "moves") return "";
		const { review } = view;
		const known = review ? review.positions.filter(Boolean).length : 0;
		return [
			Math.round(view.progress * 100),
			Math.round(known / analysis.mainline.length * 20),
			Boolean(review?.complete)
		].join(",");
	}
	function renderKey(session, analysis) {
		const { view, live } = session;
		const { path } = analysis;
		if (view.mode === "live") return [
			"live",
			path,
			liveDigest(judgeAt(live, analysis, path)),
			live.error ?? ""
		].join("|");
		return [
			view.mode,
			path,
			analysis.onMainline,
			analysis.orientation(),
			view.review !== null,
			progressKey(session, analysis),
			view.error ?? "",
			view.explain,
			session.lines.found.size,
			view.lineOf?.path ?? "",
			view.playing !== null,
			liveDigest(reviewMove(session, analysis)),
			live.error ?? ""
		].join("|");
	}

//#endregion
//#region src/page/review/view/stream.ts
	const WORD_MS = 35;
	const FALLBACK_LINE_HEIGHT = 18;
	/**
	* Whether the comment runs past its clamped lines, which overflow by a whole
	* line: a move chip poking a pixel out of the last one doesn't count.
	*/
	const overflows = ({ scrollHeight, clientHeight, lineHeight }) => scrollHeight > clientHeight + (Number.parseFloat(lineHeight) || FALLBACK_LINE_HEIGHT) / 2;
	function tick(session) {
		const { stream } = session;
		const words = queryAll(session.elements.panel, ".cdc-bubble__sub .cdc-w", HTMLElement);
		const word = words[stream.state.shown];
		stream.state = {
			...stream.state,
			shown: stream.state.shown + 1
		};
		if (word) word.className = "cdc-w cdc-w--in";
		if (stream.state.shown >= words.length) {
			clearInterval(stream.timer);
			stream.timer = 0;
			tellCoach(session);
		}
	}
	/** After a render: drops the sentence that doesn't fit, then carries on typing. */
	function startStream(session) {
		const sub = queryOne(session.elements.panel, ".cdc-bubble__sub", HTMLElement);
		if (!sub) return;
		const { stream } = session;
		const drop = queryOne(sub, ".cdc-say--drop", HTMLElement);
		const fit = () => ({
			scrollHeight: sub.scrollHeight,
			clientHeight: sub.clientHeight,
			lineHeight: getComputedStyle(sub).lineHeight
		});
		if (drop && overflows(fit())) {
			drop.remove();
			const shown = stream.state.shown === Infinity ? Infinity : sub.querySelectorAll(".cdc-w:not(.cdc-w--off)").length;
			stream.state = {
				...stream.state,
				dropped: true,
				shown
			};
		}
		if (stream.state.shown < sub.querySelectorAll(".cdc-w").length && stream.timer === 0) {
			stream.timer = setInterval(() => tick(session), WORD_MS);
			tellCoach(session);
		}
	}
	/**
	* On a new width, a comment that is fully typed out is laid out again whole,
	* so a sentence dropped for lack of room can come back. A comment still being
	* typed is left as it is, or its words would be counted again.
	*/
	function refitStream(session) {
		const { stream } = session;
		if (stream.timer !== 0) return;
		stream.state = {
			...stream.state,
			dropped: false,
			shown: Infinity
		};
	}

//#endregion
//#region src/page/review/view/summary-panel.ts
	const NBSP = trustedHtml("&nbsp;");
	const COLUMNS = trustedHtml("<colgroup><col class=\"cdc-t-c-label\"><col><col class=\"cdc-t-c-icon\"><col></colgroup>");
	function playerName(player, language) {
		if (player?.user?.username) return player.user.username;
		if (player?.name) return player.name;
		return player?.ai ? `Stockfish ${player.ai}` : language.ui.anonymous;
	}
	function countRows({ review, allRows, language }) {
		const brilliant = (review?.counts.white.brilliant ?? 0) > 0 || (review?.counts.black.brilliant ?? 0) > 0;
		const count = (color, moveClass) => review?.counts[color][moveClass] ?? 0;
		return MOVE_CLASSES.filter((moveClass) => allRows || SUMMARY_ROWS.has(moveClass) || moveClass === "brilliant" && brilliant).map((moveClass) => html`<tr><td class="cdc-t-label">${language.classLabels[moveClass]}</td>
        <td class="cdc-t-num" style="color:${CLASS_COLORS[moveClass]}">${count("white", moveClass)}</td>
        <td class="cdc-t-icon">${classIcon(moveClass)}</td>
        <td class="cdc-t-num" style="color:${CLASS_COLORS[moveClass]}">${count("black", moveClass)}</td></tr>`);
	}
	function moreToggle({ allRows, language }) {
		const label = allRows ? language.ui.less : language.ui.more;
		return html`<tr class="cdc-t-more"><td colspan="4"><button class="cdc-review__more${allRows ? " cdc-review__more--open" : ""}" data-cdc="rows" data-cdc-tip="${label}" aria-label="${label}" aria-expanded="${String(allRows)}">${CHEVRON_ICON}</button></td></tr>
      <tr class="cdc-t-sep"><td colspan="4"></td></tr>`;
	}
	function ratingRows({ review, language }) {
		const { ui } = language;
		const rating = review?.rating;
		const elo = (color) => rating?.[color]?.elo ?? NBSP;
		const phase = (color, name) => {
			const verdict = rating?.[color]?.phases[name];
			return verdict ? classIcon(verdict) : "";
		};
		const phases = PHASES.filter((name) => !rating || Boolean(rating.white?.phases[name] ?? rating.black?.phases[name])).map((name) => html`<tr class="cdc-t-phase"><td class="cdc-t-label">${ui.phases[name]}</td><td>${phase("white", name)}</td><td></td><td>${phase("black", name)}</td></tr>`);
		return html`<tr class="cdc-t-rating"><td class="cdc-t-label"><span data-cdc-tip="${ui.gameRatingTip}">${ui.gameRating}</span></td>
        <td><span class="cdc-acc cdc-acc--w">${elo("white")}</span></td><td></td>
        <td><span class="cdc-acc cdc-acc--b">${elo("black")}</span></td></tr>
      <tr class="cdc-t-sep"><td colspan="4"></td></tr>
      ${phases}`;
	}
	function topMarkup(input) {
		const { review, error, players, language } = input;
		const { ui } = language;
		const accuracy = (color) => {
			const value = review?.accuracy[color];
			return value === null || value === void 0 ? NBSP : value.toFixed(1);
		};
		const white = playerName(players.white, language);
		const black = playerName(players.black, language);
		return html`<div class="cdc-review__top">
        ${error ? html`<p class="cdc-review__error">${error}</p>` : ""}
        <div class="cdc-review__graph cdc-summary-graph"></div>
        <table class="cdc-review__table">${COLUMNS}
          <tr class="cdc-t-names"><td></td><td title="${white}">${white}</td><td></td><td title="${black}">${black}</td></tr>
          <tr><td class="cdc-t-label">${ui.players}</td><td><span class="cdc-avatar cdc-avatar--w"></span></td><td></td><td><span class="cdc-avatar cdc-avatar--b"></span></td></tr>
          <tr><td class="cdc-t-label">${ui.accuracy}</td>
            <td><span class="cdc-acc cdc-acc--w">${accuracy("white")}</span></td><td></td>
            <td><span class="cdc-acc cdc-acc--b">${accuracy("black")}</span></td></tr>
          <tr class="cdc-t-sep"><td colspan="4"></td></tr>
        </table>
      </div>`;
	}
	function summaryMarkup(input) {
		const { review, error, language } = input;
		const loading = !review?.complete && !error;
		const canStart = review !== null && !error;
		return html`${header(language.ui.review, "normal", language)}
      ${topMarkup(input)}
      <div class="cdc-review__body">
        <table class="cdc-review__table${loading ? " cdc-review__table--loading" : ""}">${COLUMNS}${countRows(input)}${moreToggle(input)}${ratingRows(input)}</table>
      </div>
      <div class="cdc-review__foot"><button class="cdc-btn cdc-btn--green" data-cdc="moves" ${canStart ? "" : "disabled"}>${language.ui.start}</button></div>`;
	}
	function renderSummary(session, analysis) {
		const { view, language, elements } = session;
		const { review, error } = view;
		setHtml(elements.panel, summaryMarkup({
			review,
			error,
			allRows: view.allRows,
			players: analysis.players(),
			language
		}));
		const graph = queryOne(elements.panel, ".cdc-summary-graph", HTMLElement);
		if (!graph) return;
		if (review) mountGraph(session, analysis, {
			container: graph,
			kind: "summary"
		});
		if (!review?.complete && !error) graph.insertAdjacentHTML("afterbegin", html`<span class="cdc-summary-pct">${Math.round(view.progress * 100)}%</span>`.value);
	}

//#endregion
//#region src/page/review/view/tooltip.ts
	const MARGIN = 8;
	const GAP = 10;
	/** Centers the tooltip over its anchor, keeping it inside the window. */
	function tipPlacement({ anchor, width, height, viewportWidth }) {
		const center = anchor.left + anchor.width / 2;
		const left = clamp(center - width / 2, MARGIN, viewportWidth - width - MARGIN);
		return {
			left,
			top: anchor.top - height - GAP,
			tail: center - left
		};
	}
	function hideTip$1(session) {
		session.elements.tip.remove();
		session.tipFor = null;
	}
	function showTip$1(session, target) {
		const { tip } = session.elements;
		session.tipFor = target;
		tip.textContent = target.dataset.cdcTip ?? "";
		document.body.append(tip);
		const { left, top, tail } = tipPlacement({
			anchor: target.getBoundingClientRect(),
			width: tip.offsetWidth,
			height: tip.offsetHeight,
			viewportWidth: window.innerWidth
		});
		setStyleProperty(tip, "left", `${left}px`);
		setStyleProperty(tip, "top", `${top}px`);
		setStyleProperty(tip, "--cdc-tip-x", `${tail}px`);
	}
	function watchTips(session) {
		const { panel } = session.elements;
		panel.addEventListener("pointerover", (event) => {
			const target = closestTo(event.target, "[data-cdc-tip]", HTMLElement);
			if (target) showTip$1(session, target);
		});
		panel.addEventListener("pointerout", (event) => {
			const target = closestTo(event.target, "[data-cdc-tip]", HTMLElement);
			const into = event.relatedTarget instanceof Node ? event.relatedTarget : null;
			if (target && !target.contains(into)) hideTip$1(session);
		});
		panel.addEventListener("scroll", () => hideTip$1(session), true);
	}

//#endregion
//#region src/page/review/view/render.ts
	const KEPT_BUTTONS = "button[data-cdc]:not([data-cdc=\"coach\"])";
	const classOf = (element) => element.getAttribute("class") ?? "";
	function drawPanel(session, analysis) {
		const { mode } = session.view;
		if (mode === "summary") renderSummary(session, analysis);
		else if (mode === "moves") renderMoves(session, analysis);
		else if (mode === "live") renderLive(session, analysis);
		else renderClosed(session, analysis);
	}
	/**
	* Draws the panel again. A button the render leaves as it was stays the same
	* element, so a click spanning a redraw still lands (the summary's Start
	* button redraws with every step of the analysis); a scrolled part stays
	* where it was scrolled to.
	*/
	function redrawPanel(session, analysis) {
		const { panel } = session.elements;
		const { view } = session;
		const kept = new Map(queryAll(panel, KEPT_BUTTONS, Element).map((button) => [button.outerHTML, button]));
		const scrolled = view.mode === view.drawnMode ? queryAll(panel, "*", Element).filter((element) => element.scrollTop).map((element) => ({
			className: classOf(element),
			top: element.scrollTop
		})) : [];
		view.drawnMode = view.mode;
		drawPanel(session, analysis);
		for (const button of queryAll(panel, KEPT_BUTTONS, Element)) {
			const old = kept.get(button.outerHTML);
			if (old && old !== button) button.replaceWith(old);
		}
		for (const { className, top } of scrolled) {
			const element = queryAll(panel, "*", Element).find((candidate) => classOf(candidate) === className);
			if (element) element.scrollTop = top;
		}
		keepAvatar(session);
		if (!session.tipFor?.isConnected) hideTip$1(session);
		startStream(session);
		fitBubble(panel);
	}
	function render(session, force = false) {
		const analysis$2 = analysis();
		if (!analysis$2 || !attach(session.elements)) return;
		const { view } = session;
		if (view.mode === "summary" && analysis$2.node.ply !== view.summaryPly) {
			setMode(session, "moves");
			return;
		}
		if (view.mode === "live" || view.mode === "moves" && view.review) pump(session, analysis$2);
		const explained = view.mode === "moves" && view.explain ? spokenMove(session, analysis$2) : null;
		if (explained) pumpLines(session, analysis$2, explained);
		const key = renderKey(session, analysis$2);
		if (force || key !== view.lastKey) {
			view.lastKey = key;
			redrawPanel(session, analysis$2);
		}
		if (view.mode === "moves") movesGraph(session, analysis$2);
		renderBoard(session, analysis$2);
	}
	/** The summary shows until the user moves; then the move-by-move review. */
	function setMode(session, mode) {
		const { view } = session;
		const analysis$3 = analysis();
		view.mode = mode;
		view.summaryPly = analysis$3?.node.ply;
		if (mode !== "moves") stopPlaying(session);
		if (mode === "moves" && analysis$3) closeTools(analysis$3);
		const root = document.documentElement;
		for (const each of MODES) root.classList.toggle(`cdc-review-${each}`, each === mode);
		render(session, true);
	}

//#endregion
//#region src/page/review/start.ts
	const RENDER_MS = 150;
	const RESIZE_SLACK = 4;
	const REVIEWED_VARIANTS = /* @__PURE__ */ new Set([
		"standard",
		"fromPosition",
		"chess960"
	]);
	function createReview() {
		const session = createSession({
			language: pageLanguage(),
			coach: pickCoach(),
			elements: createElements(),
			redraw: (force) => render(session, force),
			setMode: (mode) => setMode(session, mode)
		});
		watchClicks(session);
		watchTips(session);
		return session;
	}
	function run(session, mode) {
		document.documentElement.classList.toggle("cdc-review", true);
		setMode(session, mode);
		setInterval(() => render(session), RENDER_MS);
		let lastWidth = window.innerWidth;
		const refit = () => {
			lastWidth = window.innerWidth;
			refitStream(session);
			render(session, true);
		};
		window.addEventListener("resize", () => {
			if (Math.abs(window.innerWidth - lastWidth) > RESIZE_SLACK) refit();
		});
		session.wide.addEventListener("change", refit);
	}
	function startReview(session, analysis) {
		if (!REVIEWED_VARIANTS.has(analysis.data?.game.variant.key ?? "")) return;
		if (analysis.synthetic) {
			run(session, "live");
			return;
		}
		if (!analysis.gameId || analysis.mainline.length < 2) return;
		run(session, "summary");
		analyseGame(session, analysis).catch((error) => {
			console.error("[LichessDotCom] game analysis failed", error);
		});
	}
	/** The page's controller once it has a game tree and a board, or null for now. */
	function readyAnalysis() {
		const analysis$1 = analysis();
		const board = document.querySelector("main.analyse .analyse__board");
		return analysis$1?.hasMainline && board ? analysis$1 : null;
	}

//#endregion
//#region src/page/review/index.ts
	const GAME_PAGE = /^\/[a-zA-Z0-9]{8}(?:[a-zA-Z0-9]{4})?(?:\/(?:white|black))?\/?$/;
	const ANALYSIS_BOARD = /^\/analysis(?:\/|$)/;
	function start() {
		const { pathname } = location;
		if (!GAME_PAGE.test(pathname) && !ANALYSIS_BOARD.test(pathname)) return;
		const session = createReview();
		pollUntil(readyAnalysis, (analysis) => startReview(session, analysis), {
			intervalMs: 100,
			giveUpMs: 3e4
		});
	}
	const review = {
		name: "game review",
		start
	};

//#endregion
//#region src/shared/charts/colors.ts
	const GAME_COLORS = /* @__PURE__ */ new Map([
		["ultraBullet", "#bd93f9"],
		["bullet", "#ffb86c"],
		["blitz", "#8be9fd"],
		["rapid", "#50fa7b"],
		["classical", "#7cf0cf"],
		["correspondence", "#f1fa8c"],
		["crazyhouse", "#ff79c6"],
		["chess960", "#9580ff"],
		["kingOfTheHill", "#f0b98d"],
		["threeCheck", "#ff6e96"],
		["antichess", "#a4abcb"],
		["atomic", "#ff5555"],
		["horde", "#b6f26c"],
		["racingKings", "#66d9ef"]
	]);
	const PUZZLE_COLOR = "#ff5555";
	const BLITZ_COLOR = "#8be9fd";
	const SERIES_COLORS = [...GAME_COLORS.values(), PUZZLE_COLOR];
	/** The color of a game rating by its key (`blitz`, `threeCheck`…), Blitz's if unknown. */
	const gameRatingColor = (key) => (key === void 0 ? void 0 : GAME_COLORS.get(key)) ?? BLITZ_COLOR;

//#endregion
//#region src/shared/charts/tooltip.ts
	const ON = "cdc-rchart__tip--on";
	/** The tooltip's left edge: right of the anchor, or left of it when there's no room. */
	function tipLeft({ anchor, width, gap, limit }) {
		return anchor + gap + width > limit ? anchor - gap - width : anchor + gap;
	}
	/** Fills the tooltip and shows it beside `anchor`; its width is only known once filled. */
	function showTip(tip, markup, placement) {
		setHtml(tip, markup);
		tip.classList.toggle(ON, true);
		const left = tipLeft({
			...placement,
			width: tip.offsetWidth
		});
		setStyleProperty(tip, "transform", `translate(${Math.round(left)}px, ${placement.top}px)`);
	}
	function hideTip(tip) {
		tip.classList.toggle(ON, false);
	}

//#endregion
//#region src/page/charts/distribution/formats.ts
	function numberFormats(locale) {
		return {
			count: new Intl.NumberFormat(locale),
			compact: new Intl.NumberFormat(locale, {
				notation: "compact",
				maximumFractionDigits: 1
			}),
			percent: new Intl.NumberFormat(locale, {
				style: "percent",
				maximumFractionDigits: 1
			}),
			wholePercent: new Intl.NumberFormat(locale, {
				style: "percent",
				maximumFractionDigits: 0
			})
		};
	}
	const seriesNames = () => ({
		players: translate("players", "Players"),
		cumulative: translate("cumulative", "Cumulative")
	});
	const yourRatingLabel = () => translate("yourRating", "Your rating");

//#endregion
//#region src/shared/charts/curve.ts
	function segmentsOf(points) {
		const segments = [];
		for (let k = 1; k < points.length; k++) {
			const from = points[k - 1];
			const to = points[k];
			if (!from || !to) continue;
			const width = to[0] - from[0];
			segments.push({
				from,
				to,
				width,
				slope: (to[1] - from[1]) / width
			});
		}
		return segments;
	}
	function tangentBetween(before, after) {
		if (!before) return after?.slope ?? 0;
		if (!after) return before.slope;
		if (before.slope * after.slope <= 0) return 0;
		return 3 * (before.width + after.width) / ((2 * after.width + before.width) / before.slope + (after.width + 2 * before.width) / after.slope);
	}
	/**
	* An SVG path through the points as a monotone cubic (d3's curveMonotoneX):
	* smooth, yet never above or below the points it joins.
	*/
	function monotoneCurve(points) {
		const [first] = points;
		if (!first) return "";
		if (points.length === 1) return `M${first[0]},${first[1]}h0.01`;
		const segments = segmentsOf(points);
		const tangents = points.map((_, k) => tangentBetween(segments[k - 1], segments[k]));
		const curves = segments.map(({ from, to, width }, k) => {
			const handle = width / 3;
			const startTangent = tangents[k] ?? 0;
			const endTangent = tangents[k + 1] ?? 0;
			return `C${[
				from[0] + handle,
				from[1] + startTangent * handle,
				to[0] - handle,
				to[1] - endTangent * handle,
				to[0],
				to[1]
			].map(roundTenth).join(",")}`;
		});
		return `M${roundTenth(first[0])},${roundTenth(first[1])}${curves.join("")}`;
	}

//#endregion
//#region src/shared/charts/markup.ts
	const SWATCH = trustedHtml("<span class=\"cdc-rchart__swatch\"></span>");
	/** A chip's color dot and name. */
	const chipLabel = (name) => html`${SWATCH}<span class="cdc-rchart__name">${name}</span>`;
	const tipTitle = (title) => html`<div class="cdc-rchart__tipdate">${title}</div>`;
	const tipRow = ({ color, name, value }) => html`<div class="cdc-rchart__tiprow" style="--cdc-series-color:${color}">${SWATCH}<span>${name}</span><strong>${value}</strong></div>`;
	const xAxisLabel = ({ x, y, text }) => html`<text class="cdc-rchart__xlabel" x="${x}" y="${y}">${text}</text>`;
	/** A horizontal grid line, its value on the left. */
	const gridLine = ({ y, left, right, label, extraClass = "" }) => html`<line class="cdc-rchart__grid${extraClass}" x1="${left}" x2="${right}" y1="${y}" y2="${y}"/><text class="cdc-rchart__ylabel" x="${left - 10}" y="${y}">${label}</text>`;
	/** The transparent rectangle that catches the pointer over the plot. */
	const hitArea = ({ x, y, width, height }) => html`<rect class="cdc-rchart__hit" x="${x}" y="${y}" width="${width}" height="${height}"/>`;

//#endregion
//#region src/shared/charts/steps.ts
/**
	* The values from `from` up to `to`, `step` (> 0) apart. They're summed one
	* step at a time, so fractional steps drift exactly as a plain loop's would.
	*/
	function steps(from, to, step) {
		const values = [];
		for (let value = from; value <= to; value += step) values.push(value);
		return values;
	}

//#endregion
//#region src/page/charts/distribution/scales.ts
	const MIN_RATING = 400;
	const PADDING = {
		top: 18,
		right: 48,
		bottom: 30,
		left: 50
	};
	const MARKER_ROW = 30;
	/** A round top for the player counts, in about four steps of 1, 2, 2.5 or 5 × 10ⁿ. */
	function countScale(most) {
		const rough = most / 4;
		const magnitude = 10 ** Math.floor(Math.log10(rough === 0 ? 1 : rough));
		const step = [
			1,
			2,
			2.5,
			5,
			10
		].map((k) => k * magnitude).find((candidate) => candidate >= rough) ?? 10 * magnitude;
		return {
			step,
			max: Math.ceil(most / step) * step
		};
	}
	/** A column standing on the axis, its top corners rounded. */
	function columnPath({ x, y, width, bottom }) {
		const radius = Math.min(3, width / 2, (bottom - y) / 2);
		const left = roundTenth(x);
		const right = roundTenth(x + width);
		const top = roundTenth(y);
		const shoulder = roundTenth(y + radius);
		const base = roundTenth(bottom);
		return `M${left},${base}V${shoulder}${`Q${left},${top} ${roundTenth(x + radius)},${top}H${roundTenth(x + width - radius)}Q${right},${top} ${right},${shoulder}`}V${base}Z`;
	}
	function layOut({ width, height, counts, maxRating, markers }) {
		const top = PADDING.top + markers * 30;
		const plotWidth = width - PADDING.left - PADDING.right;
		const bottom = height - PADDING.bottom;
		const plotHeight = bottom - top;
		const scale = countScale(Math.max(...counts));
		return {
			width,
			height,
			plotWidth,
			top,
			bottom,
			counts: scale,
			binWidth: plotWidth / counts.length,
			x: (rating) => PADDING.left + (rating - 400) / (maxRating - 400) * plotWidth,
			yCount: (players) => bottom - players / scale.max * plotHeight,
			yShare: (share) => bottom - share * plotHeight
		};
	}

//#endregion
//#region src/page/charts/distribution/players.ts
	function countPlayers(counts) {
		const total = counts.reduce((sum, count) => sum + count, 0);
		let below = 0;
		return {
			counts,
			total,
			shares: counts.map((count) => {
				below += count;
				return below / total;
			}),
			maxRating: 400 + counts.length * 25
		};
	}
	/** The column a rating falls in. */
	const binOf = (rating, players) => clamp(Math.floor((rating - 400) / 25), 0, players.counts.length - 1);
	/** A rating off the chart is drawn at its edge. */
	const onChart = (rating, players) => clamp(rating, 400, players.maxRating);
	const MINE = "#f8f8f2";
	const OTHER = "#8f9bd4";
	/** Your rating, then the player you came from. */
	function markersOf(data, yourRating) {
		const markers = [];
		if (data.myRating !== void 0) markers.push({
			kind: "mine",
			color: MINE,
			rating: data.myRating,
			label: yourRating
		});
		if (data.otherRating !== void 0 && data.otherPlayer !== void 0) markers.push({
			kind: "other",
			color: OTHER,
			rating: data.otherRating,
			label: data.otherPlayer
		});
		return markers;
	}

//#endregion
//#region src/page/charts/distribution/markup.ts
	const CUMULATIVE_COLOR = "#f8f8f2";
	function chip(color, name, value) {
		const strong = value === "" ? "" : html`<strong>${value}</strong>`;
		return html`<span class="cdc-rchart__chip cdc-dist__chip" style="--cdc-series-color:${color}">${chipLabel(name)}${strong}</span>`;
	}
	/** The chart's frame, filled in by each draw. */
	function chartShell({ color, names, total }) {
		const legend = html`${chip(color, names.players, total)}${chip(CUMULATIVE_COLOR, names.cumulative, "")}`;
		return html`<div class="cdc-dist__legend">${legend}</div><div class="cdc-dist__plot"><svg class="cdc-dist__svg" aria-hidden="true"></svg><div class="cdc-dist__marks"></div><div class="cdc-rchart__tip cdc-dist__tip"></div></div>`;
	}
	function axis(geometry, players, formats) {
		const { x, yCount, yShare, width, height, counts } = geometry;
		const pxPerPoint = geometry.plotWidth / (players.maxRating - 400);
		const every = [
			100,
			200,
			500
		].find((points) => pxPerPoint * points >= 44) ?? 500;
		const ratings = steps(Math.ceil(400 / every) * every, players.maxRating, every).map((rating) => xAxisLabel({
			x: x(rating),
			y: height - 9,
			text: rating
		}));
		const grid = steps(0, counts.max + counts.step / 2, counts.step).map((count) => gridLine({
			y: yCount(count),
			left: PADDING.left,
			right: width - PADDING.right,
			label: count === 0 ? 0 : formats.compact.format(count),
			extraClass: count === 0 ? " cdc-dist__base" : ""
		}));
		const shares = [
			.25,
			.5,
			.75,
			1
		].map((share) => html`<text class="cdc-dist__slabel" x="${width - PADDING.right + 10}" y="${yShare(share)}">${formats.wholePercent.format(share)}</text>`);
		return html`<g class="cdc-rchart__axis">${grid}${ratings}${shares}</g>`;
	}
	function columns(geometry, players, lit) {
		const { binWidth, bottom } = geometry;
		const gap = binWidth > 6 ? Math.min(3, binWidth * .22) : .5;
		const bars = players.counts.map((count, i) => {
			const dim = i > lit ? " cdc-dist__bar--dim" : "";
			const path = columnPath({
				x: PADDING.left + i * binWidth + gap / 2,
				y: geometry.yCount(count),
				width: Math.max(.5, binWidth - gap),
				bottom
			});
			return html`<path class="cdc-dist__bar${dim}" data-cdc-bar="${i}" style="--cdc-bar-index:${i}" d="${path}"/>`;
		});
		return html`<g class="cdc-dist__bars">${bars}</g>`;
	}
	function cumulativeCurve(geometry, players) {
		const points = [[geometry.x(400), geometry.yShare(0)], ...players.shares.map((share, i) => [geometry.x(400 + (i + 1) * 25), geometry.yShare(share)])];
		return monotoneCurve(points);
	}
	function plotMarkup({ geometry, players, markers, lit, color, formats }) {
		const { top, bottom } = geometry;
		const gradient = html`<linearGradient id="cdc-dist-g" gradientUnits="userSpaceOnUse" x1="0" x2="0" y1="${top}" y2="${bottom}"><stop offset="0" stop-color="${color}"/><stop offset="1" stop-color="${color}" stop-opacity="0.35"/></linearGradient>`;
		const lines = markers.map(({ color: markerColor, rating }, k) => {
			const x = geometry.x(onChart(rating, players));
			return html`<line class="cdc-dist__mline" style="--cdc-marker-color:${markerColor}" x1="${x}" x2="${x}" y1="${k * 30 + 24}" y2="${bottom}"/>`;
		});
		const hit = hitArea({
			x: PADDING.left,
			y: top,
			width: geometry.plotWidth,
			height: bottom - top
		});
		return html`<defs>${gradient}</defs>${axis(geometry, players, formats)}${columns(geometry, players, lit)}${lines}<path class="cdc-dist__cumul" pathLength="1" d="${cumulativeCurve(geometry, players)}"/><circle class="cdc-dist__dot" r="4.5"/>${hit}`;
	}
	/** The markers' pills, in HTML over the top of their lines. */
	function marksMarkup(markers, formats) {
		const marks = markers.map(({ kind, color, label, rating }) => html`<span class="cdc-dist__mark cdc-dist__mark--${kind}" style="--cdc-marker-color:${color}">${label} <strong>${formats.count.format(rating)}</strong></span>`);
		return html`${marks}`;
	}
	/** A column's ratings, its players, and the share of players rated below its end. */
	function tipMarkup({ bin, players, color, names, formats }) {
		const low = 400 + bin * 25;
		const count = formats.count.format(players.counts[bin] ?? 0);
		const share = formats.percent.format(players.shares[bin] ?? 0);
		const rows = [tipRow({
			color,
			name: names.players,
			value: count
		}), tipRow({
			color: CUMULATIVE_COLOR,
			name: names.cumulative,
			value: share
		})];
		return html`${tipTitle(`${low}–${low + 25 - 1}`)}${rows}`;
	}

//#endregion
//#region src/page/charts/distribution/chart.ts
	function findParts(root) {
		const plot = queryOne(root, ".cdc-dist__plot", HTMLElement);
		const svg = queryOne(root, "svg", SVGSVGElement);
		const marks = queryOne(root, ".cdc-dist__marks", HTMLElement);
		const tip = queryOne(root, ".cdc-dist__tip", HTMLElement);
		return plot && svg && marks && tip ? {
			root,
			plot,
			svg,
			marks,
			tip
		} : null;
	}
	const perfKey = () => /\/distribution\/(\w+)/.exec(location.pathname)?.[1];
	var DistributionChart = class {
		#setup;
		#lit;
		#geometry = null;
		constructor(setup) {
			this.#setup = setup;
			const [lead] = setup.markers;
			this.#lit = lead ? binOf(lead.rating, setup.players) : setup.players.counts.length - 1;
		}
		draw(animate) {
			const { parts, players, markers, color, formats } = this.#setup;
			const geometry = layOut({
				width: Math.max(240, Math.round(parts.plot.clientWidth)),
				height: Math.max(200, Math.round(parts.plot.clientHeight)),
				counts: players.counts,
				maxRating: players.maxRating,
				markers: markers.length
			});
			this.#geometry = geometry;
			sizeSvg(parts.svg, geometry.width, geometry.height);
			setHtml(parts.svg, plotMarkup({
				geometry,
				players,
				markers,
				lit: this.#lit,
				color,
				formats
			}));
			setHtml(parts.marks, marksMarkup(markers, formats));
			this.#placeMarks(geometry);
			parts.svg.classList.toggle("cdc-dist__svg--intro", animate);
			parts.root.classList.toggle("cdc-dist--intro", animate);
		}
		#placeMarks(geometry) {
			const { parts, players, markers } = this.#setup;
			for (const [k, mark] of [...parts.marks.children].entries()) {
				const marker = markers[k];
				if (!(mark instanceof HTMLElement) || !marker) continue;
				const center = geometry.x(onChart(marker.rating, players));
				const { offsetWidth } = mark;
				const left = clamp(center - offsetWidth / 2, PADDING.left, geometry.width - PADDING.right - offsetWidth);
				setStyleProperty(mark, "transform", `translate(${Math.round(left)}px, ${k * 30}px)`);
			}
		}
		hover(event) {
			const geometry = this.#geometry;
			if (!geometry) return;
			const { parts, players, color, formats } = this.#setup;
			const { binWidth } = geometry;
			const last = players.counts.length - 1;
			const bin = clamp(Math.floor((pointerX(event, parts.svg) - PADDING.left) / binWidth), 0, last);
			parts.svg.classList.toggle("cdc-dist__svg--hover", true);
			for (const bar of this.#bars()) {
				const index = Number(bar.dataset.cdcBar);
				bar.classList.toggle("cdc-dist__bar--on", index === bin);
				bar.classList.toggle("cdc-dist__bar--dim", index > bin);
			}
			const dot = queryOne(parts.svg, ".cdc-dist__dot", SVGElement);
			if (dot) {
				const x = geometry.x(400 + (bin + 1) * 25);
				setAttributes(dot, {
					cx: x,
					cy: geometry.yShare(players.shares[bin] ?? 0)
				});
			}
			const names = seriesNames();
			showTip(parts.tip, tipMarkup({
				bin,
				players,
				color,
				names,
				formats
			}), {
				anchor: PADDING.left + (bin + .5) * binWidth,
				gap: 16,
				limit: geometry.width - PADDING.right,
				top: geometry.top + 24
			});
		}
		leave() {
			const { parts } = this.#setup;
			parts.svg.classList.toggle("cdc-dist__svg--hover", false);
			hideTip(parts.tip);
			for (const bar of this.#bars()) {
				bar.classList.toggle("cdc-dist__bar--on", false);
				bar.classList.toggle("cdc-dist__bar--dim", Number(bar.dataset.cdcBar) > this.#lit);
			}
		}
		#bars() {
			return queryAll(this.#setup.parts.svg, ".cdc-dist__bar", SVGElement);
		}
	};
	function redrawOnResize(plot, draw) {
		let lastSize = "";
		new ResizeObserver(() => {
			const size = `${Math.round(plot.clientWidth)}x${Math.round(plot.clientHeight)}`;
			if (size === lastSize) return;
			const first = lastSize === "";
			lastSize = size;
			draw(first);
		}).observe(plot);
	}
	/** Adds our chart to Lichess's distribution box. */
	function mountDistribution(host, data) {
		const players = countPlayers(data.freq);
		const color = gameRatingColor(perfKey());
		const markers = markersOf(data, yourRatingLabel());
		const formats = numberFormats(pageLocale());
		const root = createElement("div", { className: "cdc-dist" });
		setStyleProperty(root, "--cdc-series-color", color);
		const total = formats.count.format(players.total);
		setHtml(root, chartShell({
			color,
			names: seriesNames(),
			total
		}));
		host.append(root);
		host.classList.toggle("cdc-dist-on", true);
		const page = closestTo(host, ".rating-stats", HTMLElement);
		if (page) setStyleProperty(page, "--cdc-dist-c", color);
		const parts = findParts(root);
		if (!parts) return;
		const chart = new DistributionChart({
			parts,
			players,
			markers,
			color,
			formats
		});
		parts.svg.addEventListener("pointermove", (event) => chart.hover(event));
		parts.svg.addEventListener("pointerleave", () => chart.leave());
		redrawOnResize(parts.plot, (animate) => chart.draw(animate));
	}

//#endregion
//#region src/page/charts/distribution/schema.ts
	const DistributionSchema = object({
		freq: array(number$1()).check(_minLength(2), refine((counts) => counts.some((count) => count > 0))),
		myRating: lenient(number$1()),
		otherRating: lenient(number$1()),
		otherPlayer: lenient(string())
	});

//#endregion
//#region src/page/charts/distribution/index.ts
	const PAGE = /\/stat\/rating\/distribution\//;
	function boot(initData) {
		const host = queryOne(document, "#rating_distribution", HTMLElement);
		if (!host) return;
		const data = parseJson(initData, DistributionSchema);
		if (!data || host.querySelector(".cdc-dist")) return;
		mountDistribution(host, data);
	}
	const distribution = {
		name: "rating distribution",
		start: () => {
			if (PAGE.test(location.pathname)) readPageInitData(boot);
		}
	};

//#endregion
//#region src/page/index.ts
	startFeatures([
		motion,
		flipLabel,
		shapes,
		review,
		distribution
	]);

//#endregion
})();
